const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// Minimal pure Node PNG builder
function createPngBuffer(width, height, fillR, fillG, fillB) {
  const bytesPerPixel = 4;
  const rowSize = width * bytesPerPixel;
  const rawData = Buffer.alloc((rowSize + 1) * height);

  const centerX = width / 2;
  const centerY = height / 2;
  const radius = width * 0.42;

  for (let y = 0; y < height; y++) {
    const rowOffset = y * (rowSize + 1);
    rawData[rowOffset] = 0; // Filter type 0 (None)

    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + (x * bytesPerPixel);
      const dx = x - centerX;
      const dy = y - centerY;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Rounded dark background with amber center
      if (dist < radius * 0.7) {
        // Inner parcel accent
        rawData[pixelOffset] = 245;     // R (Amber gold)
        rawData[pixelOffset + 1] = 158; // G
        rawData[pixelOffset + 2] = 11;  // B
        rawData[pixelOffset + 3] = 255; // A
      } else if (dist < radius) {
        // Outer dark circle
        rawData[pixelOffset] = fillR;
        rawData[pixelOffset + 1] = fillG;
        rawData[pixelOffset + 2] = fillB;
        rawData[pixelOffset + 3] = 255;
      } else {
        // Rounded border
        rawData[pixelOffset] = 28;
        rawData[pixelOffset + 1] = 25;
        rawData[pixelOffset + 2] = 23;
        rawData[pixelOffset + 3] = 255;
      }
    }
  }

  const deflated = zlib.deflateSync(rawData);

  // PNG Header
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // Bit depth
  ihdrData[9] = 6; // Color type (RGBA)
  ihdrData[10] = 0; // Compression
  ihdrData[11] = 0; // Filter
  ihdrData[12] = 0; // Interlace
  const ihdrChunk = createChunk('IHDR', ihdrData);

  // IDAT chunk
  const idatChunk = createChunk('IDAT', deflated);

  // IEND chunk
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

function createChunk(type, data) {
  const length = data.length;
  const chunk = Buffer.alloc(12 + length);
  chunk.writeUInt32BE(length, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);
  const crc = crc32(chunk.subarray(4, 8 + length));
  chunk.writeUInt32BE(crc, 8 + length);
  return chunk;
}

// Standard CRC32
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = (c >>> 8) ^ table[(c ^ buf[i]) & 0xff];
  }
  return (c ^ 0xffffffff) >>> 0;
}

const table = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
  }
  table[n] = c;
}

const pubDir = path.join(__dirname, '..', 'public');
fs.writeFileSync(path.join(pubDir, 'pwa-192x192.png'), createPngBuffer(192, 192, 28, 25, 23));
fs.writeFileSync(path.join(pubDir, 'pwa-512x512.png'), createPngBuffer(512, 512, 28, 25, 23));
fs.writeFileSync(path.join(pubDir, 'pwa-maskable-512x512.png'), createPngBuffer(512, 512, 41, 37, 36));
fs.writeFileSync(path.join(pubDir, 'apple-touch-icon.png'), createPngBuffer(180, 180, 28, 25, 23));

console.log('PWA PNG assets successfully generated in /public');
