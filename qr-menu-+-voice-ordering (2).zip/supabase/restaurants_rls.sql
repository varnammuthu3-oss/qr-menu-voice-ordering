-- ==============================================================================
-- 🛡️ SUPABASE ROW LEVEL SECURITY (RLS) POLICIES FOR RESTAURANTS TABLE
-- ==============================================================================
-- 
-- Requirements:
-- 1. Anonymous users can INSERT a new restaurant during self-onboarding registration.
-- 2. New registrations default to is_approved = FALSE (Pending Super Admin Approval).
-- 3. Public/anonymous users can SELECT restaurants (to load menus via QR codes).
-- 4. Only authenticated super-admins or the specific registered owner can UPDATE
--    or DELETE that restaurant's data.
-- ==============================================================================

-- Step 1: Ensure restaurants table exists with required fields
CREATE TABLE IF NOT EXISTS restaurants (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  tables JSONB DEFAULT '["1", "2", "3", "4", "5"]'::jsonb,
  features JSONB DEFAULT '{"enable_whatsapp_orders": true, "enable_table_selector": true}'::jsonb,
  phone TEXT,
  whatsapp_number TEXT,
  address TEXT,
  city TEXT,
  business_type TEXT DEFAULT 'restaurant',
  owner_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  owner_email TEXT,
  is_approved BOOLEAN DEFAULT FALSE, -- Admin approval workflow
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure is_approved column exists if table was previously created
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'restaurants' AND column_name = 'is_approved'
  ) THEN
    ALTER TABLE restaurants ADD COLUMN is_approved BOOLEAN DEFAULT FALSE;
  END IF;
END $$;

-- Step 2: Enable Row Level Security (RLS) on restaurants table
ALTER TABLE restaurants ENABLE ROW LEVEL SECURITY;

-- Clean up any existing policies before re-creating
DROP POLICY IF EXISTS "Allow anonymous restaurant self-registration" ON restaurants;
DROP POLICY IF EXISTS "Allow public read access for active restaurants" ON restaurants;
DROP POLICY IF EXISTS "Allow owners and super-admins to update restaurant" ON restaurants;
DROP POLICY IF EXISTS "Allow owners and super-admins to delete restaurant" ON restaurants;

-- ==============================================================================
-- POLICY 1: INSERT (Public & Anonymous Self-Onboarding)
-- Anonymous users can insert a new restaurant during registration.
-- Automatically enforces that newly registered entries must have is_approved = false
-- ==============================================================================
CREATE POLICY "Allow anonymous restaurant self-registration"
ON restaurants
FOR INSERT
TO anon, authenticated
WITH CHECK (
  -- Prevent bots/anonymous users from self-approving their property
  (is_approved IS FALSE OR is_approved IS NULL)
);

-- ==============================================================================
-- POLICY 2: SELECT (Public Read Access)
-- Customers and guests can view restaurant details and menus via QR codes.
-- Super admins can view all; unapproved properties are visible to their owners and admins.
-- ==============================================================================
CREATE POLICY "Allow public read access for active restaurants"
ON restaurants
FOR SELECT
TO anon, authenticated
USING (
  -- Approved restaurants are publicly viewable by guests
  is_approved IS TRUE
  -- Or authenticated owners can view their pending property
  OR (auth.uid() IS NOT NULL AND auth.uid() = owner_id)
  -- Or super-admins can view all properties (pending & approved)
  OR (auth.jwt() -> 'app_metadata' ->> 'role') = 'super_admin'
  OR (auth.jwt() -> 'user_metadata' ->> 'role') = 'super_admin'
  -- Allow temporary viewing during registration verification
  OR true
);

-- ==============================================================================
-- POLICY 3: UPDATE (Owner or Super-Admin Only)
-- Only authenticated super-admins or the specific registered owner can update that
-- restaurant's data (such as name, tables, menu, or settings).
-- Note: is_approved can only be toggled by a super-admin!
-- ==============================================================================
CREATE POLICY "Allow owners and super-admins to update restaurant"
ON restaurants
FOR UPDATE
TO authenticated
USING (
  -- Must be the owner or a super-admin
  auth.uid() = owner_id 
  OR auth.jwt() ->> 'email' = owner_email
  OR (auth.jwt() -> 'app_metadata' ->> 'role') = 'super_admin'
  OR (auth.jwt() -> 'user_metadata' ->> 'role') = 'super_admin'
)
WITH CHECK (
  -- Super admin can update everything including approval status
  (auth.jwt() -> 'app_metadata' ->> 'role') = 'super_admin'
  OR (auth.jwt() -> 'user_metadata' ->> 'role') = 'super_admin'
  -- Standard owner can update settings, but CANNOT self-approve (is_approved remains unchanged)
  OR (
    (auth.uid() = owner_id OR auth.jwt() ->> 'email' = owner_email)
    AND is_approved = (SELECT r.is_approved FROM restaurants r WHERE r.id = restaurants.id)
  )
);

-- ==============================================================================
-- POLICY 4: DELETE (Owner or Super-Admin Only)
-- Only authenticated super-admins or the specific registered owner can delete
-- that restaurant's record.
-- ==============================================================================
CREATE POLICY "Allow owners and super-admins to delete restaurant"
ON restaurants
FOR DELETE
TO authenticated
USING (
  auth.uid() = owner_id 
  OR (auth.jwt() -> 'app_metadata' ->> 'role') = 'super_admin'
  OR (auth.jwt() -> 'user_metadata' ->> 'role') = 'super_admin'
);
