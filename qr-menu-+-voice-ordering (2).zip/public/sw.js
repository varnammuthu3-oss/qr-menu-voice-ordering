/**
 * ==============================================================================
 * 🔔 MULTI-DEVICE STAFF ORDER SYNC & BACKGROUND PUSH SERVICE WORKER
 * Stack: Service Worker API + Web Push API + BroadcastChannel
 * Handles Background Alerts when Android/iOS phone is locked or browser is minimized.
 * ==============================================================================
 */

const CACHE_NAME = 'staff-sync-v1';
const ASSETS_TO_CACHE = [
  '/',
  '/staff-dashboard.html',
  '/app.js',
  '/customer-pwa.html'
];

// Cross-tab and Service Worker communication channel
const syncChannel = new BroadcastChannel('staff_order_sync');

// Install event: cache core assets
self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch((err) => {
        console.warn('[SW] Cache assets warning:', err);
      });
    })
  );
});

// Activate event: claim all clients immediately
self.addEventListener('activate', (event) => {
  event.waitUntil(
    Promise.all([
      self.clients.claim(),
      caches.keys().then((keys) => {
        return Promise.all(
          keys.map((key) => {
            if (key !== CACHE_NAME) return caches.delete(key);
          })
        );
      })
    ])
  );
});

// ==============================================================================
// 1. WEB PUSH EVENT (Fired even when phone is locked or browser is backgrounded)
// ==============================================================================
self.addEventListener('push', (event) => {
  let data = {
    title: '🔔 NEW LIVE ORDER ARRIVED!',
    body: 'Table 1 • 2 items (₹180)',
    orderId: 'ord_' + Date.now(),
    tableNumber: 'Table 1',
    totalPrice: 180,
    itemCount: 2,
    soundType: 'church_bell',
    restaurantId: 'sri-murugan-tiffin-center'
  };

  if (event.data) {
    try {
      data = Object.assign(data, event.data.json());
    } catch (e) {
      data.body = event.data.text();
    }
  }

  // Define heavy urgent vibration pattern for staff alert
  // [vibrate 600ms, pause 200ms, vibrate 600ms, pause 200ms, vibrate 800ms]
  const urgentVibration = [600, 200, 600, 200, 800, 400, 600, 200, 1000];

  const notificationOptions = {
    body: `${data.tableNumber || 'Table'} • ${data.itemCount || 'Items'} • ₹${data.totalPrice || 0}\nTap to Accept & Silence all staff devices.`,
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    tag: `order-${data.orderId || 'incoming'}`, // Tag ensures urgent replacement
    renotify: true,
    requireInteraction: true, // Remains on screen until staff acts
    silent: false,
    vibrate: urgentVibration,
    data: {
      orderId: data.orderId,
      tableNumber: data.tableNumber,
      restaurantId: data.restaurantId,
      soundType: data.soundType,
      url: `/staff-dashboard.html?restaurant_id=${data.restaurantId || 'sri-murugan-tiffin-center'}&order_id=${data.orderId || ''}`
    },
    actions: [
      {
        action: 'accept_order',
        title: '✅ ACCEPT & MUTE ALL',
        icon: '/check-icon.png'
      },
      {
        action: 'silence_only',
        title: '🔕 Mute Alert Only',
        icon: '/mute-icon.png'
      }
    ]
  };

  // Broadcast push reception to any active foreground tabs
  syncChannel.postMessage({
    type: 'PUSH_ORDER_RECEIVED',
    order: data
  });

  event.waitUntil(
    self.registration.showNotification(data.title || '🔔 NEW LIVE ORDER!', notificationOptions)
  );
});

// ==============================================================================
// 2. NOTIFICATION CLICK / ACTION HANDLER
// ==============================================================================
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const notifData = event.notification.data || {};
  const action = event.action;

  // 1. If staff clicked "Accept & Mute All" from the lock screen notification
  if (action === 'accept_order') {
    // Notify all open client windows to accept order and silence audio
    syncChannel.postMessage({
      type: 'STAFF_ACTION_TRIGGERED',
      action: 'ACCEPT_ORDER',
      orderId: notifData.orderId,
      staffName: 'Staff (Locked Phone Push Action)'
    });

    // Also attempt background fetch to sync database if network available
    if (notifData.orderId) {
      event.waitUntil(
        fetch(`/api/orders/${notifData.orderId}/status`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'accepted', actionBy: 'Push Notification Action' })
        }).catch((err) => console.warn('[SW] Status update from push action error:', err))
      );
    }
    return;
  }

  // 2. If staff clicked "Silence Only"
  if (action === 'silence_only') {
    syncChannel.postMessage({
      type: 'SILENCE_ALL_AUDIO',
      orderId: notifData.orderId
    });
    return;
  }

  // 3. Default click: Open or focus the Staff Order Dashboard window
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      const targetUrl = notifData.url || '/staff-dashboard.html';

      for (const client of clientList) {
        if (client.url.includes('staff-dashboard') && 'focus' in client) {
          client.postMessage({
            type: 'FOCUS_ORDER',
            orderId: notifData.orderId
          });
          return client.focus();
        }
      }

      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});

// ==============================================================================
// 3. NOTIFICATION CLOSE (DISMISSED)
// ==============================================================================
self.addEventListener('notificationclose', (event) => {
  const notifData = event.notification.data || {};
  syncChannel.postMessage({
    type: 'NOTIFICATION_DISMISSED',
    orderId: notifData.orderId
  });
});

// ==============================================================================
// 4. CLIENT MESSAGE BRIDGE
// ==============================================================================
self.addEventListener('message', (event) => {
  if (!event.data) return;

  if (event.data.type === 'BROADCAST_STAFF_ACTION') {
    // Relay to other clients
    syncChannel.postMessage(event.data.payload);
  }
});
