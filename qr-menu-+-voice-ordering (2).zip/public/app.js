/**
 * ==============================================================================
 * 🚀 MULTI-DEVICE ORDER SYNC & AUDIO ALERT ENGINE (app.js)
 * Stack: Supabase Realtime (WebSockets) + Web Push API + Web Audio Synthesizer
 * Supports: 5-Staff Device Synchronization with Instant Cross-Device Alarm Muting
 * ==============================================================================
 */

(function () {
  'use strict';

  // --- STATE CONFIGURATION ---
  const DEFAULT_RESTAURANT_ID = 'sri-murugan-tiffin-center';
  const SUPABASE_URL = window.SUPABASE_URL || 'https://xyzcompany.supabase.co';
  const SUPABASE_ANON_KEY = window.SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.anon_key_placeholder';

  // Available Staff Profiles (up to 5 devices in restaurant)
  const STAFF_PROFILES = [
    { id: 'dev_owner', name: 'Owner (Counter Tablet)', role: 'Owner / Cashier', icon: 'fa-crown', color: 'amber' },
    { id: 'dev_waiter_1', name: 'Waiter 1 - Ravi (Main Hall)', role: 'Floor Waiter', icon: 'fa-user-tie', color: 'emerald' },
    { id: 'dev_waiter_2', name: 'Waiter 2 - Priya (Garden Tables)', role: 'Floor Waiter', icon: 'fa-user', color: 'teal' },
    { id: 'dev_kitchen', name: 'Kitchen Master (Chef KDS)', role: 'Kitchen Display', icon: 'fa-fire-burner', color: 'rose' },
    { id: 'dev_captain', name: 'Captain Anand (Supervisor)', role: 'Floor Manager', icon: 'fa-shield-halved', color: 'blue' }
  ];

  let currentRestaurantId = DEFAULT_RESTAURANT_ID;
  let currentStaff = STAFF_PROFILES[0]; // Default to Owner
  let currentTone = 'church_bell'; // 'church_bell' | 'ringtone'
  
  let supabaseClient = null;
  let realtimeChannel = null;
  let syncBroadcastChannel = null;
  let serviceWorkerReg = null;

  // Audio Engine State
  let audioContext = null;
  let isAlarmPlaying = false;
  let alarmIntervalTimer = null;
  let activeRingingOrderId = null;

  // Application Data State
  let liveOrders = [];
  let connectedDevices = [];
  let realtimeLogs = [];
  let currentFilter = 'all';

  // Initialize on DOM Ready
  window.addEventListener('DOMContentLoaded', () => {
    parseUrlParams();
    initBroadcastChannel();
    initServiceWorker();
    initSupabase();
    initLocalSSEFallback();
    bindUIEvents();
    renderStaffProfiles();
    renderOrders();
    addLog('INIT', `Staff device loaded as "${currentStaff.name}" on restaurant "${currentRestaurantId}"`);
  });

  // --- 1. PARSE URL PARAMS ---
  function parseUrlParams() {
    const params = new URLSearchParams(window.location.search);
    if (params.get('restaurant_id')) {
      currentRestaurantId = params.get('restaurant_id');
    }
    if (params.get('staff_id')) {
      const found = STAFF_PROFILES.find(p => p.id === params.get('staff_id'));
      if (found) currentStaff = found;
    }
    if (params.get('tone')) {
      currentTone = params.get('tone');
    }

    const tenantLabel = document.getElementById('current-restaurant-label');
    if (tenantLabel) tenantLabel.textContent = currentRestaurantId;
    
    const staffSelect = document.getElementById('staff-device-select');
    if (staffSelect) staffSelect.value = currentStaff.id;
  }

  // --- 2. BROADCAST CHANNEL & SERVICE WORKER (Background Sync) ---
  function initBroadcastChannel() {
    try {
      syncBroadcastChannel = new BroadcastChannel('staff_order_sync');
      syncBroadcastChannel.onmessage = (event) => {
        const msg = event.data;
        if (!msg) return;

        addLog('BROADCAST_RECV', `Cross-tab event: ${msg.type}`);

        if (msg.type === 'PUSH_ORDER_RECEIVED') {
          handleIncomingOrder(msg.order, 'Web Push / Background Service Worker');
        } else if (msg.type === 'STAFF_ACTION_TRIGGERED' && msg.action === 'ACCEPT_ORDER') {
          handleRemoteOrderAccepted(msg.orderId, msg.staffName);
        } else if (msg.type === 'SILENCE_ALL_AUDIO') {
          stopAudioAlarm();
          addLog('SILENCE', 'Alarm muted via Service Worker action');
        }
      };
    } catch (e) {
      console.warn('[BroadcastChannel] Not supported:', e);
    }
  }

  async function initServiceWorker() {
    if ('serviceWorker' in navigator) {
      try {
        serviceWorkerReg = await navigator.serviceWorker.register('/sw.js');
        addLog('SW_READY', 'Background Service Worker registered successfully');

        // Check Push permission status
        if ('Notification' in window) {
          updateNotificationPermissionUI(Notification.permission);
        }
      } catch (err) {
        console.warn('[SW] Registration failed:', err);
      }
    }
  }

  window.requestNotificationAccess = async function () {
    if (!('Notification' in window)) {
      alert('This browser does not support desktop or mobile push notifications.');
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      updateNotificationPermissionUI(permission);
      if (permission === 'granted') {
        addLog('NOTIF_GRANTED', 'Push notification permissions granted for locked-phone alerts');
        showToast('Push Notifications Enabled! Background alerts active.');
      } else {
        showToast('Push permission was declined or blocked.', 'warning');
      }
    } catch (err) {
      console.error('Error requesting notification permission:', err);
    }
  };

  function updateNotificationPermissionUI(perm) {
    const btn = document.getElementById('btn-push-perm');
    const badge = document.getElementById('push-status-badge');
    if (!btn || !badge) return;

    if (perm === 'granted') {
      badge.textContent = '● Background Alerts Active';
      badge.className = 'px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30';
      btn.innerHTML = '<i class="fa-solid fa-bell-check text-emerald-400"></i><span>Push Active</span>';
      btn.disabled = true;
      btn.classList.add('opacity-70');
    } else {
      badge.textContent = '○ Push Inactive';
      badge.className = 'px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30';
      btn.innerHTML = '<i class="fa-solid fa-bell text-amber-400"></i><span>Enable Push</span>';
      btn.disabled = false;
    }
  }

  // --- 3. SUPABASE REALTIME MULTI-DEVICE CHANNELS ---
  function initSupabase() {
    try {
      if (window.supabase && SUPABASE_URL && !SUPABASE_URL.includes('xyzcompany')) {
        supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        setupSupabaseRealtimeChannel();
      } else {
        addLog('INFO', 'Supabase client running in simulated/hybrid live mode with WebSocket/SSE bridge.');
        updatePresenceStateLocally();
      }
    } catch (err) {
      console.warn('Supabase initialization fallback:', err);
      updatePresenceStateLocally();
    }
  }

  function setupSupabaseRealtimeChannel() {
    if (!supabaseClient) return;

    const channelName = `staff-sync-${currentRestaurantId}`;
    realtimeChannel = supabaseClient.channel(channelName, {
      config: {
        broadcast: { self: false },
        presence: { key: currentStaff.id }
      }
    });

    // 1. PostgreSQL Database Changes (New orders or status updates)
    realtimeChannel
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'orders',
          filter: `restaurant_id=eq.${currentRestaurantId}`
        },
        (payload) => {
          addLog('SUPABASE_INSERT', `Order #${payload.new.id} received via Postgres Changes`);
          handleIncomingOrder(payload.new, 'Supabase Postgres INSERT');
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `restaurant_id=eq.${currentRestaurantId}`
        },
        (payload) => {
          addLog('SUPABASE_UPDATE', `Order #${payload.new.id} updated to status: ${payload.new.status}`);
          handleOrderUpdated(payload.new);
        }
      );

    // 2. High-Speed Broadcast Channel (<50ms Cross-Device Instant Event)
    realtimeChannel
      .on('broadcast', { event: 'ORDER_ALERT' }, (payload) => {
        addLog('BROADCAST_ORDER', `Broadcast received from ${payload.payload.senderName}`);
        handleIncomingOrder(payload.payload.order, payload.payload.senderName);
      })
      .on('broadcast', { event: 'ORDER_ACCEPTED' }, (payload) => {
        addLog('BROADCAST_ACCEPT', `Order #${payload.payload.orderId} accepted by ${payload.payload.staffName}! Silencing audio.`);
        handleRemoteOrderAccepted(payload.payload.orderId, payload.payload.staffName);
      })
      .on('broadcast', { event: 'SILENCE_ALL' }, (payload) => {
        addLog('BROADCAST_SILENCE', `Silence alert broadcast by ${payload.payload.staffName}`);
        stopAudioAlarm();
      });

    // 3. Multi-Device Presence Tracking (Showing 5 Staff Devices Online)
    realtimeChannel
      .on('presence', { event: 'sync' }, () => {
        const state = realtimeChannel.presenceState();
        updatePresenceFromSupabase(state);
      })
      .on('presence', { event: 'join' }, ({ key, newPresences }) => {
        addLog('STAFF_JOIN', `Staff device connected: ${key}`);
      })
      .on('presence', { event: 'leave' }, ({ key, leftPresences }) => {
        addLog('STAFF_LEAVE', `Staff device disconnected: ${key}`);
      });

    realtimeChannel.subscribe(async (status) => {
      const badge = document.getElementById('conn-status-badge');
      if (status === 'SUBSCRIBED') {
        if (badge) {
          badge.textContent = '● Realtime WebSockets Active';
          badge.className = 'px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30';
        }
        addLog('CONNECTED', `Subscribed to Supabase Realtime channel "${channelName}"`);

        // Track current staff device presence
        await realtimeChannel.track({
          staffId: currentStaff.id,
          name: currentStaff.name,
          role: currentStaff.role,
          onlineAt: new Date().toISOString(),
          deviceType: navigator.userAgent.includes('Mobi') ? 'Mobile Phone' : 'Tablet/Desktop'
        });
      }
    });
  }

  function updatePresenceFromSupabase(state) {
    const devices = [];
    Object.keys(state).forEach((key) => {
      const presences = state[key];
      if (Array.isArray(presences) && presences[0]) {
        devices.push(presences[0]);
      }
    });
    connectedDevices = devices;
    renderStaffPresenceGrid();
  }

  function updatePresenceStateLocally() {
    // For standalone demo environments, simulate the 5 staff devices
    connectedDevices = STAFF_PROFILES.map((p, idx) => ({
      staffId: p.id,
      name: p.name,
      role: p.role,
      isCurrent: p.id === currentStaff.id,
      status: 'online',
      latency: Math.floor(Math.random() * 25) + 15
    }));
    renderStaffPresenceGrid();
  }

  // --- 4. SSE REAL-TIME FALLBACK BRIDGE ---
  function initLocalSSEFallback() {
    try {
      const sse = new EventSource('/api/orders/events');
      sse.onmessage = (e) => {
        try {
          const payload = JSON.parse(e.data);
          if (payload.type === 'INIT' && Array.isArray(payload.orders)) {
            liveOrders = payload.orders;
            renderOrders();
          } else if (payload.type === 'NEW_ORDER') {
            handleIncomingOrder(payload.order, 'Local Server Engine');
          } else if (payload.type === 'ORDER_UPDATED') {
            handleOrderUpdated(payload.order);
          }
        } catch (err) {}
      };
      sse.onerror = () => {
        // Silent fallback
      };
    } catch (e) {}
  }

  // --- 5. HTML5 WEB AUDIO SYNTHESIZER ENGINE ---
  function getAudioContext() {
    if (!audioContext) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        audioContext = new AudioCtx();
      }
    }
    if (audioContext && audioContext.state === 'suspended') {
      audioContext.resume();
    }
    return audioContext;
  }

  window.unlockAudioEngine = function () {
    const ctx = getAudioContext();
    if (ctx) {
      document.getElementById('audio-unlock-banner')?.classList.add('hidden');
      showToast('Audio Engine Unlocked & Ready!');
      addLog('AUDIO_UNLOCK', 'Web Audio Context resumed by user gesture');
    }
  };

  // 🔔 1. Multi-Harmonic Church Bell Synthesizer (Zero-asset audio)
  function playChurchBellChime(fundamentalFreq = 440, duration = 3.2) {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.9, now);
    masterGain.connect(ctx.destination);

    // Acoustically calibrated bell partials
    const partials = [
      { ratio: 0.5, amp: 0.75, decay: duration * 1.15 }, // Hum tone (sub-octave)
      { ratio: 1.0, amp: 1.00, decay: duration * 0.95 }, // Prime / Fundamental
      { ratio: 1.19, amp: 0.65, decay: duration * 0.85 }, // Tierce (Minor Third)
      { ratio: 1.5, amp: 0.50, decay: duration * 0.75 },  // Quint (Fifth)
      { ratio: 2.0, amp: 0.70, decay: duration * 0.60 },  // Nominal (Octave)
      { ratio: 2.76, amp: 0.35, decay: duration * 0.40 }  // Super-nominal overtone
    ];

    partials.forEach((p) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = p.ratio >= 2.0 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(fundamentalFreq * p.ratio, now);

      gain.gain.setValueAtTime(0.0001, now);
      // Fast strike attack
      gain.gain.exponentialRampToValueAtTime(p.amp * 0.22, now + 0.012);
      // Realistic exponential acoustic decay
      gain.gain.exponentialRampToValueAtTime(0.0001, now + p.decay);

      osc.connect(gain);
      gain.connect(masterGain);
      osc.start(now);
      osc.stop(now + p.decay + 0.05);
    });
  }

  // 🎵 2. High-Urgency Long Call Ringtone Synthesizer
  function playLongCallRingtoneBurst() {
    const ctx = getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(0.85, now);
    masterGain.connect(ctx.destination);

    const notes = [
      { freq: 523.25, time: 0.00, dur: 0.14 }, // C5
      { freq: 659.25, time: 0.14, dur: 0.14 }, // E5
      { freq: 783.99, time: 0.28, dur: 0.14 }, // G5
      { freq: 1046.50, time: 0.42, dur: 0.28 }, // C6
      { freq: 783.99, time: 0.74, dur: 0.14 }, // G5
      { freq: 1046.50, time: 0.88, dur: 0.38 }  // C6 sustain
    ];

    notes.forEach((n) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(n.freq, now + n.time);

      gain.gain.setValueAtTime(0.0001, now + n.time);
      gain.gain.linearRampToValueAtTime(0.28, now + n.time + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + n.time + n.dur);

      osc.connect(gain);
      gain.connect(masterGain);
      osc.start(now + n.time);
      osc.stop(now + n.time + n.dur + 0.05);
    });
  }

  // Test current sound
  window.testSound = function () {
    window.unlockAudioEngine();
    if (currentTone === 'church_bell') {
      playChurchBellChime(440, 2.5);
      showToast('🔔 Church Bell Chime Playing');
    } else {
      playLongCallRingtoneBurst();
      showToast('🎵 Long Call Ringtone Playing');
    }
  };

  // Start continuous looping alarm
  function startAudioAlarm(toneType = currentTone) {
    stopAudioAlarm();
    isAlarmPlaying = true;
    window.unlockAudioEngine();

    addLog('ALARM_START', `Foreground Web Audio loop initiated: ${toneType}`);

    if (toneType === 'church_bell') {
      const playBellPair = () => {
        if (!isAlarmPlaying) return;
        playChurchBellChime(392.00, 2.6); // G4 chime
        setTimeout(() => {
          if (isAlarmPlaying) playChurchBellChime(523.25, 3.0); // C5 chime
        }, 1100);
      };
      playBellPair();
      alarmIntervalTimer = setInterval(playBellPair, 3400);
    } else {
      const playRing = () => {
        if (!isAlarmPlaying) return;
        playLongCallRingtoneBurst();
      };
      playRing();
      alarmIntervalTimer = setInterval(playRing, 1600);
    }
  }

  function stopAudioAlarm() {
    isAlarmPlaying = false;
    if (alarmIntervalTimer) {
      clearInterval(alarmIntervalTimer);
      alarmIntervalTimer = null;
    }
    const banner = document.getElementById('ringing-alarm-banner');
    if (banner) banner.classList.add('hidden');
  }

  window.silenceCurrentAlarmOnly = function () {
    stopAudioAlarm();
    addLog('SILENCE_LOCAL', 'Staff manually silenced local device audio alarm');

    // Broadcast silence to other 4 devices
    if (realtimeChannel) {
      realtimeChannel.send({
        type: 'broadcast',
        event: 'SILENCE_ALL',
        payload: { staffName: currentStaff.name, orderId: activeRingingOrderId }
      });
    }
    if (syncBroadcastChannel) {
      syncBroadcastChannel.postMessage({ type: 'SILENCE_ALL_AUDIO', orderId: activeRingingOrderId });
    }
  };

  // --- 6. ORDER HANDLING & MULTI-DEVICE SYNC LOGIC ---
  function handleIncomingOrder(order, source = 'Realtime') {
    if (!order || !order.id) return;

    // Deduplicate
    const exists = liveOrders.find((o) => o.id === order.id);
    if (!exists) {
      liveOrders.unshift(order);
    } else {
      Object.assign(exists, order);
    }

    renderOrders();

    // Trigger Ringing Alert if status is pending
    if (order.status === 'pending') {
      activeRingingOrderId = order.id;
      showRingingBanner(order);
      startAudioAlarm(order.alertSoundType || order.alert_sound_type || currentTone);
      addLog('ORDER_ALERT', `🚨 LIVE ORDER RINGING! Table ${order.tableNumber || order.table_number || '1'} (${source})`);
    }
  }

  function handleOrderUpdated(updatedOrder) {
    const idx = liveOrders.findIndex((o) => o.id === updatedOrder.id);
    if (idx !== -1) {
      liveOrders[idx] = updatedOrder;
      renderOrders();
    }
    if (activeRingingOrderId === updatedOrder.id && updatedOrder.status !== 'pending') {
      stopAudioAlarm();
    }
  }

  // Cross-device remote acknowledgment
  function handleRemoteOrderAccepted(orderId, staffName) {
    const ord = liveOrders.find((o) => o.id === orderId);
    if (ord) {
      ord.status = 'accepted';
      ord.acceptedBy = staffName;
      renderOrders();
    }

    if (activeRingingOrderId === orderId) {
      stopAudioAlarm();
      showToast(`Order Accepted & Silenced by ${staffName}!`);
    }
  }

  function showRingingBanner(order) {
    const banner = document.getElementById('ringing-alarm-banner');
    if (!banner) return;

    const tableBadge = document.getElementById('ring-table-badge');
    const heading = document.getElementById('ring-order-heading');
    const itemsCount = (order.items || []).length;
    const total = order.totalPrice || order.total_price || 0;
    const table = order.tableNumber || order.table_number || '1';

    if (tableBadge) tableBadge.textContent = String(table).toUpperCase();
    if (heading) heading.textContent = `${itemsCount} Items • ₹${total}`;

    banner.classList.remove('hidden');
  }

  // --- 7. STAFF ACTIONS (ACCEPT / COMPLETE / CANCEL) ---
  window.acceptCurrentRingingOrder = async function () {
    if (activeRingingOrderId) {
      await window.updateOrderStatus(activeRingingOrderId, 'accepted');
    }
    stopAudioAlarm();
  };

  window.updateOrderStatus = async function (orderId, newStatus) {
    stopAudioAlarm();
    addLog('ACTION', `Updating Order #${orderId} to "${newStatus}" by ${currentStaff.name}`);

    // 1. Immediately update local state
    const ord = liveOrders.find((o) => o.id === orderId);
    if (ord) {
      ord.status = newStatus;
      ord.acceptedBy = currentStaff.name;
      renderOrders();
    }

    // 2. BROADCAST TO ALL 4 OTHER STAFF DEVICES SIMULTANEOUSLY (<50ms)
    if (realtimeChannel) {
      realtimeChannel.send({
        type: 'broadcast',
        event: 'ORDER_ACCEPTED',
        payload: {
          orderId,
          status: newStatus,
          staffId: currentStaff.id,
          staffName: currentStaff.name,
          timestamp: Date.now()
        }
      });
    }

    // 3. Broadcast to local tabs and Service Worker
    if (syncBroadcastChannel) {
      syncBroadcastChannel.postMessage({
        type: 'STAFF_ACTION_TRIGGERED',
        action: 'ACCEPT_ORDER',
        orderId,
        staffName: currentStaff.name
      });
    }

    // 4. Update Database in Supabase
    if (supabaseClient) {
      try {
        await supabaseClient
          .from('orders')
          .update({ status: newStatus })
          .eq('id', orderId);
      } catch (err) {
        console.warn('Supabase DB update fallback:', err);
      }
    }

    // 5. Update Backend Express API
    try {
      await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus, actionBy: currentStaff.name })
      });
    } catch (e) {}

    showToast(`Order marked as ${newStatus}! All 5 staff devices synced.`);
  };

  // --- 8. SIMULATE ACTIONS & PERSONA SWITCHING ---
  window.switchStaffPersona = function (staffId) {
    const profile = STAFF_PROFILES.find((p) => p.id === staffId);
    if (!profile) return;

    currentStaff = profile;
    addLog('PERSONA_SWITCH', `Active device changed to: ${profile.name} (${profile.role})`);
    
    // Update Supabase presence
    if (realtimeChannel) {
      realtimeChannel.track({
        staffId: profile.id,
        name: profile.name,
        role: profile.role,
        onlineAt: new Date().toISOString()
      });
    } else {
      updatePresenceStateLocally();
    }

    renderStaffProfiles();
    showToast(`Device switched to: ${profile.name}`);
  };

  window.setAlertTone = function (tone) {
    currentTone = tone;
    const bBell = document.getElementById('tone-btn-bell');
    const bRing = document.getElementById('tone-btn-ring');

    if (tone === 'church_bell') {
      bBell?.classList.add('bg-amber-500', 'text-stone-950');
      bBell?.classList.remove('text-stone-300');
      bRing?.classList.remove('bg-amber-500', 'text-stone-950');
      bRing?.classList.add('text-stone-300');
    } else {
      bRing?.classList.add('bg-amber-500', 'text-stone-950');
      bRing?.classList.remove('text-stone-300');
      bBell?.classList.remove('bg-amber-500', 'text-stone-950');
      bBell?.classList.add('text-stone-300');
    }
    showToast(`Alert sound set to: ${tone === 'church_bell' ? 'Church Bell Chime' : 'Long Call Ringtone'}`);
  };

  window.simulateCustomerOrder = async function () {
    window.unlockAudioEngine();
    const tables = ['Table 1', 'Table 3', 'Table 7', 'Takeaway Parcel #12', 'Garden Cabana 2'];
    const randomTable = tables[Math.floor(Math.random() * tables.length)];

    const menuPicks = [
      { name: 'Ghee Podi Idli (2 Pcs)', quantity: 2, price: 70, isVeg: 'veg' },
      { name: 'Butter Masala Dosa', quantity: 1, price: 110, isVeg: 'veg' },
      { name: 'Degree Filter Coffee', quantity: 2, price: 35, isVeg: 'veg' }
    ];

    const totalPrice = menuPicks.reduce((acc, i) => acc + i.price * i.quantity, 0);

    const newOrder = {
      id: `ord_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      restaurant_id: currentRestaurantId,
      tableNumber: randomTable,
      items: menuPicks,
      totalPrice: totalPrice,
      customerNotes: 'Extra coconut chutney and hot sambar please',
      alertSoundType: currentTone,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    addLog('SIMULATE', `Simulating order from ${randomTable} (₹${totalPrice})`);

    // 1. Trigger Supabase broadcast to all 5 devices
    if (realtimeChannel) {
      realtimeChannel.send({
        type: 'broadcast',
        event: 'ORDER_ALERT',
        payload: {
          order: newOrder,
          senderName: 'Customer QR Menu Scan'
        }
      });
    }

    // 2. Post to backend
    try {
      await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrder)
      });
    } catch (e) {}

    // 3. Local ingestion
    handleIncomingOrder(newOrder, 'Customer Table QR');
  };

  window.simulateBackgroundPush = function () {
    if (serviceWorkerReg && 'showNotification' in serviceWorkerReg) {
      const urgentVibration = [600, 200, 600, 200, 800, 400, 600, 200, 1000];
      serviceWorkerReg.showNotification('🔔 NEW LIVE ORDER! (LOCKED PHONE SIMULATION)', {
        body: 'Table 4 • 3 Items (₹320)\nTap Accept below to silence all 5 staff devices.',
        icon: '/icon-192.png',
        tag: `order-sim-${Date.now()}`,
        renotify: true,
        requireInteraction: true,
        vibrate: urgentVibration,
        data: {
          orderId: `ord_sim_${Date.now()}`,
          tableNumber: 'Table 4',
          totalPrice: 320
        },
        actions: [
          { action: 'accept_order', title: '✅ ACCEPT & MUTE ALL' },
          { action: 'silence_only', title: '🔕 Silence' }
        ]
      });
      showToast('Simulated Web Push Notification sent to device!');
      addLog('PUSH_SIM', 'Dispatched background push notification with action buttons');
    } else {
      showToast('Please enable notification permissions first!', 'warning');
    }
  };

  // --- 9. UI RENDERING FUNCTIONS ---
  function renderStaffPresenceGrid() {
    const container = document.getElementById('presence-devices-grid');
    if (!container) return;

    container.innerHTML = STAFF_PROFILES.map((p) => {
      const isSelf = p.id === currentStaff.id;
      const device = connectedDevices.find((d) => d.staffId === p.id);
      const isOnline = Boolean(device || isSelf);

      return `
        <div class="p-3.5 rounded-2xl border transition-all ${
          isSelf 
            ? 'bg-amber-500/10 border-amber-500/60 shadow-lg shadow-amber-500/5' 
            : isOnline 
            ? 'bg-stone-900 border-stone-750' 
            : 'bg-stone-900/40 border-stone-850 opacity-60'
        }">
          <div class="flex items-start justify-between gap-2">
            <div class="flex items-center gap-2.5">
              <div class="w-8 h-8 rounded-xl bg-stone-800 text-${p.color}-400 flex items-center justify-center text-xs font-bold border border-stone-700">
                <i class="fa-solid ${p.icon}"></i>
              </div>
              <div>
                <div class="flex items-center gap-1.5">
                  <span class="text-xs font-bold text-white leading-none">${p.name}</span>
                  ${isSelf ? '<span class="px-1.5 py-0.2 bg-amber-500 text-stone-950 font-black text-[9px] rounded-sm">YOU</span>' : ''}
                </div>
                <span class="text-[10px] text-stone-400 block mt-0.5">${p.role}</span>
              </div>
            </div>

            <div class="text-right">
              <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                isOnline ? 'bg-emerald-500/20 text-emerald-300' : 'bg-stone-800 text-stone-500'
              }">
                <span class="w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-stone-600'}"></span>
                <span>${isOnline ? 'Sync Live' : 'Offline'}</span>
              </span>
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  function renderStaffProfiles() {
    renderStaffPresenceGrid();
    const badge = document.getElementById('current-staff-badge');
    if (badge) {
      badge.textContent = currentStaff.name;
    }
  }

  function renderOrders() {
    const container = document.getElementById('orders-container');
    const counter = document.getElementById('pending-orders-count');
    if (!container) return;

    const pendingCount = liveOrders.filter((o) => o.status === 'pending').length;
    if (counter) counter.textContent = `${pendingCount} Ringing`;

    const filtered = liveOrders.filter((o) => {
      if (currentFilter === 'all') return true;
      return o.status === currentFilter;
    });

    if (filtered.length === 0) {
      container.innerHTML = `
        <div class="col-span-full p-12 text-center bg-stone-900/40 rounded-3xl border border-stone-800/80">
          <i class="fa-solid fa-bell-slash text-3xl text-stone-600 mb-3"></i>
          <h3 class="text-sm font-bold text-stone-300">No ${currentFilter !== 'all' ? currentFilter : ''} orders right now</h3>
          <p class="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
            Click "Simulate Customer Order" above to trigger instant multi-device synchronized audio alerts!
          </p>
        </div>
      `;
      return;
    }

    container.innerHTML = filtered.map((ord) => {
      const isPending = ord.status === 'pending';
      const isAccepted = ord.status === 'accepted';
      const items = ord.items || [];
      const table = ord.tableNumber || ord.table_number || '1';
      const total = ord.totalPrice || ord.total_price || 0;
      const notes = ord.customerNotes || ord.customer_notes || '';
      const orderDate = ord.orderDate || ord.order_date || new Date(ord.createdAt || ord.created_at || Date.now()).toISOString().slice(0, 10);
      const orderTime = (ord.orderTime || ord.order_time || new Date(ord.createdAt || ord.created_at || Date.now()).toTimeString()).slice(0, 5);
      const orderId = ord.orderId || ord.order_id || 102;
      const formattedSummary = ord.formattedSummary || `Order #${orderId} | Date: ${orderDate} | Time: ${orderTime} | Table ${table}`;

      return `
        <div class="p-5 rounded-3xl border flex flex-col justify-between transition-all ${
          isPending
            ? 'bg-stone-900 border-red-500/80 shadow-xl shadow-red-500/10 ring-1 ring-red-500/50'
            : isAccepted
            ? 'bg-stone-900 border-emerald-500/50 shadow-md shadow-emerald-500/5'
            : 'bg-stone-900/60 border-stone-800 opacity-80'
        }">
          <div>
            <!-- Order Tracking Summary Banner -->
            <div class="mb-3 px-3 py-1.5 bg-stone-950/80 border border-stone-800 rounded-xl flex items-center justify-between gap-2">
              <span class="text-xs font-mono font-bold text-amber-400">
                ${formattedSummary}
              </span>
            </div>

            <!-- Order Header -->
            <div class="flex items-center justify-between pb-3 border-b border-stone-800">
              <div class="flex items-center gap-2">
                <span class="px-2.5 py-1 rounded-xl bg-amber-500 text-stone-950 font-black text-xs">
                  ${String(table).toUpperCase()}
                </span>
                <span class="text-xs font-mono text-stone-400">${orderTime}</span>
              </div>

              <div class="text-right">
                <span class="px-2.5 py-0.5 rounded-md text-[11px] font-bold uppercase tracking-wider ${
                  isPending
                    ? 'bg-red-500/20 text-red-300 border border-red-500/40 animate-pulse'
                    : isAccepted
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-stone-800 text-stone-400'
                }">
                  ${isPending ? '🔔 RINGING' : ord.status}
                </span>
              </div>
            </div>

            <!-- Items -->
            <div class="py-3.5 space-y-2 text-xs">
              ${items.map((it) => `
                <div class="flex justify-between items-center text-stone-200">
                  <span class="font-medium"><strong class="text-amber-400">${it.quantity}x</strong> ${it.name}</span>
                  <span class="font-mono text-stone-400">₹${(it.price || 0) * (it.quantity || 1)}</span>
                </div>
              `).join('')}
            </div>

            ${notes ? `
              <div class="p-2.5 bg-stone-800/80 rounded-xl text-xs text-amber-200 border border-stone-700/80 mb-3">
                <strong class="block text-[10px] text-amber-400 uppercase tracking-wider">Kitchen Note:</strong>
                ${notes}
              </div>
            ` : ''}

            ${ord.acceptedBy ? `
              <div class="text-[11px] text-emerald-400 flex items-center gap-1.5 mb-2">
                <i class="fa-solid fa-user-check text-xs"></i>
                <span>Accepted by <strong>${ord.acceptedBy}</strong></span>
              </div>
            ` : ''}
          </div>

          <!-- Actions -->
          <div class="pt-3 border-t border-stone-800 space-y-2.5">
            <div class="flex justify-between items-center text-sm font-bold text-white">
              <span class="text-xs text-stone-400">Bill Total:</span>
              <span class="text-lg text-amber-400 font-mono">₹${total}</span>
            </div>

            ${isPending ? `
              <button onclick="updateOrderStatus('${ord.id}', 'accepted')" class="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/40 transition-all cursor-pointer">
                <i class="fa-solid fa-check-double text-base"></i>
                <span>ACCEPT & SILENCE ALL 5 PHONES</span>
              </button>
            ` : isAccepted ? `
              <div class="grid grid-cols-2 gap-2">
                <button onclick="updateOrderStatus('${ord.id}', 'completed')" class="py-2.5 bg-stone-800 hover:bg-emerald-600 hover:text-white text-stone-200 text-xs font-bold rounded-xl border border-stone-700 transition-colors">
                  Complete
                </button>
                <button onclick="updateOrderStatus('${ord.id}', 'cancelled')" class="py-2.5 bg-stone-800 hover:bg-red-900/50 hover:text-red-300 text-stone-400 text-xs font-bold rounded-xl border border-stone-700 transition-colors">
                  Cancel
                </button>
              </div>
            ` : `
              <div class="text-[11px] text-center text-stone-500 py-1 font-medium">Order Complete</div>
            `}
          </div>
        </div>
      `;
    }).join('');
  }

  function addLog(type, message) {
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    realtimeLogs.unshift({ timestamp, type, message });
    if (realtimeLogs.length > 25) realtimeLogs.pop();
    renderLogs();
  }

  function renderLogs() {
    const container = document.getElementById('realtime-logs-feed');
    if (!container) return;

    container.innerHTML = realtimeLogs.map((log) => `
      <div class="flex items-start gap-2 text-[11px] font-mono leading-relaxed">
        <span class="text-stone-500 shrink-0">${log.timestamp}</span>
        <span class="px-1.5 py-0.2 rounded text-[10px] font-bold shrink-0 ${
          log.type.includes('INSERT') || log.type.includes('ALERT') ? 'bg-red-500/20 text-red-300' :
          log.type.includes('ACCEPT') || log.type.includes('CONNECTED') ? 'bg-emerald-500/20 text-emerald-300' :
          'bg-stone-800 text-amber-300'
        }">${log.type}</span>
        <span class="text-stone-300 truncate">${log.message}</span>
      </div>
    `).join('');
  }

  function showToast(msg, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `fixed bottom-5 right-5 z-50 px-4 py-3 rounded-2xl text-xs font-bold shadow-2xl flex items-center gap-2 border transition-all animate-bounce ${
      type === 'warning' ? 'bg-amber-600 text-white border-amber-400' : 'bg-stone-900 text-white border-stone-700'
    }`;
    toast.innerHTML = `<i class="fa-solid fa-circle-info text-amber-400"></i><span>${msg}</span>`;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.remove();
    }, 3200);
  }

  function bindUIEvents() {
    // Filter tabs
    ['all', 'pending', 'accepted', 'completed'].forEach((f) => {
      const btn = document.getElementById(`filter-tab-${f}`);
      if (btn) {
        btn.addEventListener('click', () => {
          currentFilter = f;
          ['all', 'pending', 'accepted', 'completed'].forEach((other) => {
            const ob = document.getElementById(`filter-tab-${other}`);
            if (other === f) {
              ob?.classList.add('bg-amber-500', 'text-stone-950');
              ob?.classList.remove('bg-stone-800', 'text-stone-300');
            } else {
              ob?.classList.remove('bg-amber-500', 'text-stone-950');
              ob?.classList.add('bg-stone-800', 'text-stone-300');
            }
          });
          renderOrders();
        });
      }
    });
  }

})();
