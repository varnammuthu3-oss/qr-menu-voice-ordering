import React from 'react';
import { StaffDutyRoster } from './StaffDutyRoster';
import { Business, AppStaffRole } from '../types';

interface StaffAllocationViewProps {
  business: Business;
  onOpenLiveDashboard?: () => void;
  currentStaffRole?: AppStaffRole;
  staffName?: string;
  onOpenRoleSwitcher?: () => void;
}

export const StaffAllocationView: React.FC<StaffAllocationViewProps> = (props) => {
  return <StaffDutyRoster {...props} />;
};

export default StaffAllocationView;
