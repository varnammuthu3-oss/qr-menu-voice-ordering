import React, { useState, useRef, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  Store,
  Sparkles,
  Upload,
  FileText,
  Image as ImageIcon,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Plus,
  Trash2,
  Copy,
  Printer,
  ExternalLink,
  AlertCircle,
  QrCode,
  MapPin,
  Mail,
  Phone,
  Layers,
  Check,
  RefreshCw,
  Camera,
  MessageSquare,
  FileDown,
  ChevronRight,
  Sliders,
  Utensils,
  Hotel,
  Package
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Business, ExtractedCategory, ExtractedMenuItem, FoodDietType } from '../types';
import { saveBusiness, applyExtractedMenu } from '../services/db';
import { saveRestaurant } from '../utils/shopPersistence';
import { extractMenuWithAI, parseMenuTextOffline, PRESET_SAMPLE_MENUS } from '../utils/menuExtractor';
import { generateSlug, buildRestaurantMenuUrl } from '../utils/slug';
import { sanitizeWhatsappNumber, generateKotMessage } from '../utils/phone';

interface MerchantOnboardingViewProps {
  onComplete: (business: Business) => void;
  onSelectExistingRestaurant?: (businessId: string) => void;
  availableBusinesses?: Business[];
}

type OnboardingStep = 'details' | 'upload' | 'review' | 'success';

interface UploadedFileItem {
  id: string;
  name: string;
  size: number;
  mimeType: string;
  base64Data: string;
  previewUrl?: string;
  isPdf: boolean;
}

const COUNTRY_CODES = [
  { code: '91', label: 'India (+91)', flag: '🇮🇳', placeholder: '98450 12345' },
  { code: '1', label: 'US / Canada (+1)', flag: '🇺🇸', placeholder: '(555) 234-5678' },
  { code: '44', label: 'UK (+44)', flag: '🇬🇧', placeholder: '7911 123456' },
  { code: '65', label: 'Singapore (+65)', flag: '🇸🇬', placeholder: '8123 4567' },
  { code: '60', label: 'Malaysia (+60)', flag: '🇲🇾', placeholder: '12-345 6789' },
  { code: '971', label: 'UAE (+971)', flag: '🇦🇪', placeholder: '50 123 4567' },
  { code: '61', label: 'Australia (+61)', flag: '🇦🇺', placeholder: '412 345 678' }
];

export const MerchantOnboardingView: React.FC<MerchantOnboardingViewProps> = ({
  onComplete,
  onSelectExistingRestaurant,
  availableBusinesses = []
}) => {
  const [currentStep, setCurrentStep] = useState<OnboardingStep>('details');

  // Step 1: Merchant Information
  const [restaurantName, setRestaurantName] = useState('');
  const [selectedCountryCode, setSelectedCountryCode] = useState('91');
  const [phoneDigits, setPhoneDigits] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [city, setCity] = useState('Bengaluru');
  const [currencySymbol, setCurrencySymbol] = useState('₹');
  const [tagline, setTagline] = useState('');
  // Business Model: Table Service vs Room Service / Parcel Pickup
  const [businessType, setBusinessType] = useState<'restaurant' | 'guesthouse'>('restaurant');
  // Menu Display: Rich Image Cards vs Text-Only Clean List
  const [menuDisplayMode, setMenuDisplayMode] = useState<'photo' | 'text'>('photo');

  // Step 2: Upload & Extraction
  const [uploadMode, setUploadMode] = useState<'upload' | 'text' | 'preset'>('upload');
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFileItem[]>([]);
  const [rawText, setRawText] = useState('');
  const [isExtracting, setIsExtracting] = useState(false);
  const [extractionProgress, setExtractionProgress] = useState<string>('');
  const [extractionError, setExtractionError] = useState<string | null>(null);
  const [extractionNote, setExtractionNote] = useState<string | null>(null);

  // Step 3: Review & Edit
  const [categories, setCategories] = useState<ExtractedCategory[]>([]);
  const [items, setItems] = useState<ExtractedMenuItem[]>([]);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');

  // Step 4: Live QR Standee
  const [createdBusiness, setCreatedBusiness] = useState<Business | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [showKotPreview, setShowKotPreview] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Derived slug from restaurant name
  const existingIds = availableBusinesses.map(b => b.id);
  const derivedSlug = generateSlug(restaurantName, existingIds);

  // Sanitized WhatsApp number with selected country code
  const fullWhatsappNumber = phoneDigits.trim()
    ? sanitizeWhatsappNumber(`${selectedCountryCode}${phoneDigits.replace(/[^0-9]/g, '')}`)
    : `${selectedCountryCode}9845012345`;

  // Handle file uploads (Images & PDFs)
  const handleFilesSelected = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setExtractionError(null);

    const newFilesList: UploadedFileItem[] = [];
    const fileArray = Array.from(files);

    fileArray.forEach((file) => {
      const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
      const isImg = file.type.startsWith('image/');

      if (!isPdf && !isImg) {
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const base64Data = reader.result as string;
        newFilesList.push({
          id: `file_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          name: file.name,
          size: file.size,
          mimeType: isPdf ? 'application/pdf' : (file.type || 'image/jpeg'),
          base64Data,
          previewUrl: isImg ? base64Data : undefined,
          isPdf
        });

        if (newFilesList.length === fileArray.length) {
          setUploadedFiles((prev) => [...prev, ...newFilesList]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // Remove single uploaded file
  const handleRemoveFile = (id: string) => {
    setUploadedFiles((prev) => prev.filter((f) => f.id !== id));
  };

  // Run OCR Vision Extraction via Gemini endpoint
  const handleRunOcrExtraction = async () => {
    setExtractionError(null);
    setIsExtracting(true);
    setExtractionProgress('Uploading menu documents to Gemini Vision OCR...');

    try {
      if (uploadMode === 'upload' && uploadedFiles.length > 0) {
        setExtractionProgress(`Analyzing ${uploadedFiles.length} menu page(s) with Gemini Vision...`);

        const formattedImages = uploadedFiles.map((f) => ({
          base64Data: f.base64Data,
          mimeType: f.mimeType
        }));

        const result = await extractMenuWithAI({
          images: formattedImages,
          text: rawText
        });

        if (!result.items || result.items.length === 0) {
          throw new Error('No menu items could be detected. Please ensure the menu photo is well-lit and readable.');
        }

        setCategories(result.categories);
        setItems(result.items);
        setExtractionNote(result.confidenceNote || `Extracted ${result.items.length} items across ${result.categories.length} categories.`);
        setCurrentStep('review');
      } else if (rawText.trim().length > 0) {
        setExtractionProgress('Parsing menu categories and dish prices...');
        const result = await extractMenuWithAI({
          text: rawText
        });

        setCategories(result.categories);
        setItems(result.items);
        setExtractionNote(result.confidenceNote || `Parsed ${result.items.length} items.`);
        setCurrentStep('review');
      } else {
        // Preset fallback
        handleLoadPreset('southIndian');
        setCurrentStep('review');
      }
    } catch (err: any) {
      console.warn('[MerchantOnboarding] OCR Extraction notice:', err);
      // Fallback to offline rule-based parser if text was entered
      if (rawText.trim().length > 0) {
        const offline = parseMenuTextOffline(rawText);
        setCategories(offline.categories);
        setItems(offline.items);
        setExtractionNote(offline.confidenceNote || 'Extracted menu via offline parser.');
        setCurrentStep('review');
      } else {
        setExtractionError(err?.message || 'Failed to read menu. Please verify image clarity, select a preset starter menu, or paste text.');
      }
    } finally {
      setIsExtracting(false);
      setExtractionProgress('');
    }
  };

  // Load Preset Starter Menu
  const handleLoadPreset = (key: keyof typeof PRESET_SAMPLE_MENUS) => {
    const preset = PRESET_SAMPLE_MENUS[key];
    setRawText(preset.text);
    const parsed = parseMenuTextOffline(preset.text);
    setCategories(parsed.categories);
    setItems(parsed.items);
    setExtractionNote(`Loaded "${preset.name}" starter template with ${parsed.items.length} items.`);
    setExtractionError(null);
  };

  // Edit item helpers
  const handleUpdateItem = (index: number, updates: Partial<ExtractedMenuItem>) => {
    setItems((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], ...updates };
      return next;
    });
  };

  const handleDeleteItem = (index: number) => {
    setItems((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleAddNewItem = () => {
    const targetCat = activeCategoryFilter !== 'all' 
      ? activeCategoryFilter 
      : (categories[0]?.name || 'House Specials');

    const newItem: ExtractedMenuItem = {
      tempId: `item_${Date.now()}`,
      categoryName: targetCat,
      name: 'New Takeaway Dish',
      description: 'Freshly prepared for parcel takeaway',
      price: 100,
      isVeg: 'veg',
      isAvailable: true,
      needsReview: false
    };
    setItems((prev) => [newItem, ...prev]);
  };

  // Final submission and database persistence
  const handleCompleteAndGoLive = async () => {
    if (!restaurantName.trim()) {
      setCurrentStep('details');
      return;
    }

    setIsSaving(true);
    try {
      const now = new Date().toISOString();
      const finalPhone = `+${fullWhatsappNumber}`;

      const isTableService = businessType === 'restaurant';

      const newBiz: Business = {
        id: derivedSlug,
        ownerUid: `owner_${Date.now()}`,
        name: restaurantName.trim(),
        ownerEmail: emailAddress.trim() || undefined,
        whatsappNumber: finalPhone,
        phone: finalPhone,
        address: city ? (isTableService ? `Dining Station, ${city}` : `Takeaway / Room Station, ${city}`) : (isTableService ? 'Dine-in Restaurant' : 'Takeaway Pickup Counter'),
        city: city.trim() || 'Bengaluru',
        currencySymbol: currencySymbol || '₹',
        tagline: tagline.trim() || (isTableService ? 'Live Table Service & In-App Kitchen Orders' : 'Instant Room Service & Counter Parcel Pickup'),
        description: `Registered owner: ${emailAddress.trim() || 'Merchant'} • Type: ${isTableService ? 'Table Service' : 'Room Service / Parcel Pickup'}`,
        openingHours: 'Mon - Sun: 7:00 AM – 11:00 PM',
        businessType: businessType,
        menuStyle: menuDisplayMode === 'text' ? 'minimal' : 'classic',
        menuDisplayMode: menuDisplayMode,
        isActive: true,
        isApproved: true,
        is_approved: true,
        status: 'active',
        subscriptionTier: 'starter',
        features: {
          enable_whatsapp_orders: false,
          enable_table_selector: isTableService,
          enable_visual_menu: menuDisplayMode === 'photo',
          enable_visual_menu_images: menuDisplayMode === 'photo'
        },
        createdAt: now,
        updatedAt: now
      };

      // 1. Save to local shops storage
      saveRestaurant({
        id: newBiz.id,
        name: newBiz.name,
        tables: isTableService
          ? ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
          : ['101', '102', '103', '104', 'Parcel Pickup'],
        features: { 
          enable_whatsapp_orders: false,
          enable_table_selector: isTableService,
          enable_visual_menu: menuDisplayMode === 'photo',
          enable_visual_menu_images: menuDisplayMode === 'photo'
        },
        phone: newBiz.phone,
        whatsappNumber: newBiz.whatsappNumber,
        address: newBiz.address,
        city: newBiz.city,
        is_approved: true
      });

      // 2. Save business to Firestore / local cache
      await saveBusiness(newBiz);

      // 3. Save extracted menu categories & items
      const finalCats = categories.length > 0 
        ? categories 
        : [{ name: 'Chef Specials' }];

      const finalItems = items.length > 0
        ? items
        : [
            {
              tempId: 'default_item_1',
              categoryName: 'Chef Specials',
              name: 'Special Parcel Meal',
              description: 'Freshly packed takeaway combo',
              price: 120,
              isVeg: 'veg' as FoodDietType,
              isAvailable: true,
              needsReview: false
            }
          ];

      await applyExtractedMenu(
        newBiz.id,
        finalCats,
        finalItems,
        'replace',
        [],
        []
      );

      setCreatedBusiness(newBiz);
      setCurrentStep('success');
    } catch (err: any) {
      console.error('[MerchantOnboarding] Error completing registration:', err);
      alert('Error saving restaurant: ' + (err?.message || 'Please check your connection and retry.'));
    } finally {
      setIsSaving(false);
    }
  };

  // URLs for success state
  const liveMenuUrl = createdBusiness ? buildRestaurantMenuUrl(createdBusiness.id) : '';

  const handleCopyMenuLink = () => {
    if (!liveMenuUrl) return;
    navigator.clipboard.writeText(liveMenuUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2200);
  };

  // Download Standee as PNG
  const handleDownloadQrPng = () => {
    const svgEl = document.getElementById('merchant-onboard-qr');
    if (!svgEl) return;

    const svgData = new XMLSerializer().serializeToString(svgEl);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.onload = () => {
      canvas.width = 1000;
      canvas.height = 1000;
      if (ctx) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 100, 100, 800, 800);
        const pngFile = canvas.toDataURL('image/png');
        const downloadLink = document.createElement('a');
        downloadLink.download = `${createdBusiness?.id || 'restaurant'}-counter-qr.png`;
        downloadLink.href = pngFile;
        downloadLink.click();
      }
    };
    img.src = `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(svgData)))}`;
  };

  const handlePrintStandee = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col selection:bg-amber-400 selection:text-stone-950">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-30 bg-stone-950/90 backdrop-blur-md border-b border-stone-800 px-4 sm:px-8 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-stone-950 flex items-center justify-center font-black shadow-md shadow-amber-500/20">
            <Store className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-black tracking-tight text-white">Merchant Onboarding</span>
              <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                Self-Service OCR
              </span>
            </div>
            <p className="text-xs text-stone-400 hidden sm:block">
              Zero-database setup • Go live with WhatsApp takeaway orders in 60 seconds
            </p>
          </div>
        </div>

        {/* Quick Demo Selector for fast evaluation */}
        {availableBusinesses.length > 0 && onSelectExistingRestaurant && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-400 hidden md:inline">Or preview live menu:</span>
            <div className="flex items-center gap-1.5 overflow-x-auto max-w-[280px] sm:max-w-none py-1">
              {availableBusinesses.slice(0, 3).map((biz) => (
                <button
                  key={biz.id}
                  onClick={() => onSelectExistingRestaurant(biz.id)}
                  className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-stone-900 hover:bg-stone-800 text-stone-300 hover:text-white border border-stone-800 transition-all shrink-0 cursor-pointer"
                  title={`View ${biz.name}`}
                >
                  {biz.name}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-4 sm:p-6 md:p-8 flex flex-col">
        {/* Stepper Header */}
        <div className="mb-8">
          <div className="grid grid-cols-4 gap-2 sm:gap-4 relative">
            {[
              { key: 'details', step: 1, label: 'Store Details', icon: Store },
              { key: 'upload', step: 2, label: 'OCR Menu Upload', icon: Upload },
              { key: 'review', step: 3, label: 'Review Dishes', icon: Sliders },
              { key: 'success', step: 4, label: 'Live QR & WhatsApp', icon: QrCode }
            ].map(({ key, step, label, icon: Icon }) => {
              const isActive = currentStep === key;
              const isPast = (
                (currentStep === 'upload' && step < 2) ||
                (currentStep === 'review' && step < 3) ||
                (currentStep === 'success')
              );

              return (
                <div
                  key={key}
                  className={`flex flex-col items-center text-center p-2.5 rounded-xl border transition-all ${
                    isActive
                      ? 'bg-amber-500/10 border-amber-500 text-amber-400 shadow-sm'
                      : isPast
                      ? 'bg-stone-900 border-stone-700 text-stone-300'
                      : 'bg-stone-900/40 border-stone-800/80 text-stone-500'
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black mb-1 ${
                      isActive
                        ? 'bg-amber-500 text-stone-950'
                        : isPast
                        ? 'bg-emerald-500 text-stone-950'
                        : 'bg-stone-800 text-stone-400'
                    }`}
                  >
                    {isPast ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : step}
                  </div>
                  <span className="text-xs font-bold truncate max-w-full">{label}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Step 1: Merchant Details */}
        {currentStep === 'details' && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-stone-900 border border-stone-800 rounded-2xl p-6 sm:p-8 shadow-xl max-w-2xl mx-auto w-full"
          >
            <div className="mb-6 text-center sm:text-left">
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2.5 justify-center sm:justify-start">
                <Store className="w-6 h-6 text-amber-400" />
                Register Your Restaurant
              </h2>
              <p className="text-sm text-stone-400 mt-1">
                Enter your shop details and WhatsApp number. Customers' takeaway parcel orders will arrive directly on your phone.
              </p>
            </div>

            <div className="space-y-5">
              {/* Restaurant Name */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-300 mb-1.5">
                  Restaurant / Business Name <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  value={restaurantName}
                  onChange={(e) => setRestaurantName(e.target.value)}
                  placeholder="e.g. Kannayah Briyani & Tiffin, Royal Spice Diner, Hilltop Residency"
                  className="w-full bg-stone-950 border border-stone-700 focus:border-amber-400 rounded-xl px-4 py-3 text-white text-sm font-medium focus:outline-none transition-colors"
                  autoFocus
                />
                {restaurantName.trim() && (
                  <p className="text-[11px] text-stone-400 mt-1.5 flex items-center gap-1.5">
                    <span className="text-stone-500">Live URL Slug:</span>
                    <span className="font-mono text-amber-400 bg-stone-950 px-2 py-0.5 rounded border border-stone-800">
                      /{derivedSlug}
                    </span>
                  </p>
                )}
              </div>

              {/* Business Type: Table Service vs Room Service / Parcel Pickup */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-300 mb-2 flex items-center justify-between">
                  <span>Business Service Type <span className="text-amber-400">*</span></span>
                  <span className="text-[11px] text-stone-400 font-normal">Controls ordering context & KOT labels</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setBusinessType('restaurant')}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-3 ${
                      businessType === 'restaurant'
                        ? 'bg-amber-500/10 border-amber-500 text-white shadow-md shadow-amber-500/10'
                        : 'bg-stone-950 border-stone-800 text-stone-400 hover:border-stone-700 hover:text-stone-300'
                    }`}
                  >
                    <div className={`p-2 rounded-lg shrink-0 mt-0.5 ${
                      businessType === 'restaurant' ? 'bg-amber-500 text-stone-950 font-bold' : 'bg-stone-800 text-stone-400'
                    }`}>
                      <Utensils className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 font-bold text-sm text-white">
                        Table Service
                        {businessType === 'restaurant' && (
                          <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-semibold border border-amber-500/30">Active</span>
                        )}
                      </div>
                      <p className="text-xs text-stone-400 mt-0.5 leading-relaxed">
                        Dine-in tables, table QR standees, waitstaff duty allocations & table KOTs.
                      </p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setBusinessType('guesthouse')}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-3 ${
                      businessType === 'guesthouse'
                        ? 'bg-amber-500/10 border-amber-500 text-white shadow-md shadow-amber-500/10'
                        : 'bg-stone-950 border-stone-800 text-stone-400 hover:border-stone-700 hover:text-stone-300'
                    }`}
                  >
                    <div className={`p-2 rounded-lg shrink-0 mt-0.5 ${
                      businessType === 'guesthouse' ? 'bg-amber-500 text-stone-950 font-bold' : 'bg-stone-800 text-stone-400'
                    }`}>
                      <Hotel className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 font-bold text-sm text-white">
                        Room Service / Parcel Pickup
                        {businessType === 'guesthouse' && (
                          <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-semibold border border-amber-500/30">Active</span>
                        )}
                      </div>
                      <p className="text-xs text-stone-400 mt-0.5 leading-relaxed">
                        Hotel/guesthouse room delivery & direct counter takeaway parcel pickup.
                      </p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Menu Display Presentation: Text-only vs Rich Image Cards */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-300 mb-2 flex items-center justify-between">
                  <span>Menu Display Presentation <span className="text-amber-400">*</span></span>
                  <span className="text-[11px] text-stone-400 font-normal">Customer-facing catalog layout</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setMenuDisplayMode('photo')}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-3 ${
                      menuDisplayMode === 'photo'
                        ? 'bg-amber-500/10 border-amber-500 text-white shadow-md shadow-amber-500/10'
                        : 'bg-stone-950 border-stone-800 text-stone-400 hover:border-stone-700 hover:text-stone-300'
                    }`}
                  >
                    <div className={`p-2 rounded-lg shrink-0 mt-0.5 ${
                      menuDisplayMode === 'photo' ? 'bg-amber-500 text-stone-950 font-bold' : 'bg-stone-800 text-stone-400'
                    }`}>
                      <Layers className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 font-bold text-sm text-white">
                        Rich Image Cards
                        {menuDisplayMode === 'photo' && (
                          <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-semibold border border-amber-500/30">Default</span>
                        )}
                      </div>
                      <p className="text-xs text-stone-400 mt-0.5 leading-relaxed">
                        Appetizing dish photos, dietary badges, visual tags, and rich card layout.
                      </p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMenuDisplayMode('text')}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex items-start gap-3 ${
                      menuDisplayMode === 'text'
                        ? 'bg-amber-500/10 border-amber-500 text-white shadow-md shadow-amber-500/10'
                        : 'bg-stone-950 border-stone-800 text-stone-400 hover:border-stone-700 hover:text-stone-300'
                    }`}
                  >
                    <div className={`p-2 rounded-lg shrink-0 mt-0.5 ${
                      menuDisplayMode === 'text' ? 'bg-amber-500 text-stone-950 font-bold' : 'bg-stone-800 text-stone-400'
                    }`}>
                      <FileText className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 font-bold text-sm text-white">
                        Text-Only Clean List
                        {menuDisplayMode === 'text' && (
                          <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-semibold border border-amber-500/30">Minimal</span>
                        )}
                      </div>
                      <p className="text-xs text-stone-400 mt-0.5 leading-relaxed">
                        Clean typography list, ultra-fast loading, zero photo clutter, high scannability.
                      </p>
                    </div>
                  </button>
                </div>
              </div>

              {/* WhatsApp Number with Country Code */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-300 mb-1.5 flex items-center justify-between">
                  <span>WhatsApp Number (For Incoming Orders) <span className="text-amber-400">*</span></span>
                  <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                    <MessageSquare className="w-3 h-3" /> Direct WhatsApp routing
                  </span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <select
                    value={selectedCountryCode}
                    onChange={(e) => setSelectedCountryCode(e.target.value)}
                    className="bg-stone-950 border border-stone-700 focus:border-amber-400 rounded-xl px-3 py-3 text-white text-xs font-medium focus:outline-none"
                  >
                    {COUNTRY_CODES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.flag} {c.label}
                      </option>
                    ))}
                  </select>
                  <div className="sm:col-span-2 relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-500 text-xs font-mono">
                      +{selectedCountryCode}
                    </div>
                    <input
                      type="tel"
                      value={phoneDigits}
                      onChange={(e) => setPhoneDigits(e.target.value)}
                      placeholder={COUNTRY_CODES.find((c) => c.code === selectedCountryCode)?.placeholder || '98450 12345'}
                      className="w-full bg-stone-950 border border-stone-700 focus:border-amber-400 rounded-xl pl-14 pr-4 py-3 text-white text-sm font-medium focus:outline-none"
                    />
                  </div>
                </div>
                <p className="text-[11px] text-stone-400 mt-1.5">
                  Destination: <span className="font-mono text-stone-200">+{fullWhatsappNumber}</span>. Orders will open a pre-formatted takeaway KOT message to this number.
                </p>
              </div>

              {/* Email Address */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-300 mb-1.5">
                  Owner Email Address <span className="text-amber-400">*</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-stone-500 absolute left-3.5 top-3.5" />
                  <input
                    type="email"
                    value={emailAddress}
                    onChange={(e) => setEmailAddress(e.target.value)}
                    placeholder="owner@restaurant.com"
                    className="w-full bg-stone-950 border border-stone-700 focus:border-amber-400 rounded-xl pl-10 pr-4 py-3 text-white text-sm font-medium focus:outline-none"
                  />
                </div>
              </div>

              {/* City and Currency in 2 cols */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-stone-300 mb-1.5">
                    City / Location
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-stone-500 absolute left-3.5 top-3.5" />
                    <input
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="e.g. Bengaluru, Mumbai, Chennai"
                      className="w-full bg-stone-950 border border-stone-700 focus:border-amber-400 rounded-xl pl-10 pr-4 py-3 text-white text-sm font-medium focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-stone-300 mb-1.5">
                    Currency Symbol
                  </label>
                  <select
                    value={currencySymbol}
                    onChange={(e) => setCurrencySymbol(e.target.value)}
                    className="w-full bg-stone-950 border border-stone-700 focus:border-amber-400 rounded-xl px-4 py-3 text-white text-sm font-medium focus:outline-none"
                  >
                    <option value="₹">₹ (INR - Indian Rupee)</option>
                    <option value="$">$ (USD / CAD / AUD)</option>
                    <option value="£">£ (GBP - British Pound)</option>
                    <option value="€">€ (EUR - Euro)</option>
                    <option value="S$">S$ (SGD - Singapore Dollar)</option>
                    <option value="RM">RM (MYR - Malaysian Ringgit)</option>
                    <option value="AED">AED (UAE Dirham)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-8 pt-6 border-t border-stone-800 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  if (!restaurantName.trim()) {
                    alert('Please enter your restaurant name.');
                    return;
                  }
                  setCurrentStep('upload');
                }}
                className="w-full sm:w-auto px-6 py-3 bg-amber-500 hover:bg-amber-400 text-stone-950 font-black rounded-xl text-sm flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-lg shadow-amber-500/20 cursor-pointer"
              >
                Continue to Menu Upload
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}

        {/* Step 2: OCR Menu Upload & Parsing */}
        {currentStep === 'upload' && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-stone-900 border border-stone-800 rounded-2xl p-6 sm:p-8 shadow-xl max-w-3xl mx-auto w-full"
          >
            <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
                  <Upload className="w-6 h-6 text-amber-400" />
                  OCR Menu Upload & AI Extraction
                </h2>
                <p className="text-sm text-stone-400 mt-1">
                  Upload photos (JPEG, PNG) or PDF menu files. Gemini Vision will automatically extract dishes, sections, and prices.
                </p>
              </div>

              {/* Mode Toggle */}
              <div className="flex p-1 bg-stone-950 border border-stone-800 rounded-xl shrink-0">
                <button
                  type="button"
                  onClick={() => setUploadMode('upload')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                    uploadMode === 'upload' ? 'bg-amber-500 text-stone-950' : 'text-stone-400 hover:text-white'
                  }`}
                >
                  File / Camera
                </button>
                <button
                  type="button"
                  onClick={() => setUploadMode('text')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                    uploadMode === 'text' ? 'bg-amber-500 text-stone-950' : 'text-stone-400 hover:text-white'
                  }`}
                >
                  Paste Text
                </button>
                <button
                  type="button"
                  onClick={() => setUploadMode('preset')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                    uploadMode === 'preset' ? 'bg-amber-500 text-stone-950' : 'text-stone-400 hover:text-white'
                  }`}
                >
                  1-Click Presets
                </button>
              </div>
            </div>

            {/* Error Banner */}
            {extractionError && (
              <div className="mb-6 p-4 rounded-xl bg-rose-950/40 border border-rose-800 text-rose-300 text-xs flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-rose-200">Extraction Issue</div>
                  <div className="mt-0.5">{extractionError}</div>
                  <div className="mt-2 text-stone-400">Tip: You can also choose a Starter Preset menu to go live immediately.</div>
                </div>
              </div>
            )}

            {/* Mode 1: File Upload (Images & PDFs) */}
            {uploadMode === 'upload' && (
              <div className="space-y-6">
                {/* Drag and Drop Box */}
                <div
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    handleFilesSelected(e.dataTransfer.files);
                  }}
                  className="border-2 border-dashed border-stone-700 hover:border-amber-400/80 rounded-2xl p-8 text-center bg-stone-950/60 transition-colors flex flex-col items-center justify-center cursor-pointer group"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    accept="image/jpeg,image/png,image/webp,application/pdf,.pdf,.jpg,.jpeg,.png,.webp"
                    onChange={(e) => handleFilesSelected(e.target.files)}
                    className="hidden"
                  />
                  <input
                    ref={cameraInputRef}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={(e) => handleFilesSelected(e.target.files)}
                    className="hidden"
                  />

                  <div className="w-14 h-14 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                    <Upload className="w-7 h-7" />
                  </div>

                  <h3 className="text-base font-bold text-white mb-1">
                    Drag & Drop Menu Photos or PDF Documents
                  </h3>
                  <p className="text-xs text-stone-400 max-w-sm mb-4">
                    Supports JPEG, PNG, and PDF files. You can select multiple files or both sides of a physical printed menu.
                  </p>

                  <div className="flex flex-wrap items-center justify-center gap-2.5">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        fileInputRef.current?.click();
                      }}
                      className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold rounded-xl border border-stone-700 flex items-center gap-2 cursor-pointer"
                    >
                      <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
                      Browse Files
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        cameraInputRef.current?.click();
                      }}
                      className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold rounded-xl border border-stone-700 flex items-center gap-2 cursor-pointer"
                    >
                      <Camera className="w-3.5 h-3.5 text-amber-400" />
                      Take Photo
                    </button>
                  </div>
                </div>

                {/* Uploaded Files Queue */}
                {uploadedFiles.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold text-stone-400 px-1">
                      <span>Uploaded Files ({uploadedFiles.length})</span>
                      <button
                        type="button"
                        onClick={() => setUploadedFiles([])}
                        className="text-stone-500 hover:text-rose-400 transition-colors"
                      >
                        Clear all
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {uploadedFiles.map((file) => (
                        <div
                          key={file.id}
                          className="flex items-center justify-between p-3 rounded-xl bg-stone-950 border border-stone-800"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            {file.previewUrl ? (
                              <img
                                src={file.previewUrl}
                                alt={file.name}
                                className="w-10 h-10 rounded-lg object-cover bg-stone-900 border border-stone-800 shrink-0"
                              />
                            ) : (
                              <div className="w-10 h-10 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center shrink-0 font-black text-xs">
                                PDF
                              </div>
                            )}
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-stone-200 truncate">{file.name}</p>
                              <p className="text-[10px] text-stone-500">
                                {(file.size / 1024).toFixed(0)} KB • {file.isPdf ? 'PDF Document' : 'Photo Image'}
                              </p>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleRemoveFile(file.id)}
                            className="p-1.5 text-stone-500 hover:text-rose-400 hover:bg-stone-900 rounded-lg transition-colors cursor-pointer"
                            title="Remove file"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Mode 2: Paste Menu Text */}
            {uploadMode === 'text' && (
              <div className="space-y-4">
                <p className="text-xs text-stone-400">
                  Paste your menu items, WhatsApp list, or raw text below. The extractor will automatically identify sections, prices, and dish names:
                </p>
                <textarea
                  rows={8}
                  value={rawText}
                  onChange={(e) => setRawText(e.target.value)}
                  placeholder={`[Starters]
Gobi Manchurian - 120
Paneer 65 - 160

[Main Course]
Masala Dosa - 70
Idli Sambar (2 pcs) - 40
Biryani Rice - 140`}
                  className="w-full bg-stone-950 border border-stone-700 focus:border-amber-400 rounded-xl p-4 text-white text-xs font-mono focus:outline-none"
                />
              </div>
            )}

            {/* Mode 3: Starter Presets for 1-Click Setup */}
            {uploadMode === 'preset' && (
              <div className="space-y-4">
                <p className="text-xs text-stone-400">
                  Select a curated starter menu to test the live takeaway flow in seconds:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    {
                      key: 'southIndian' as const,
                      title: 'South Indian Tiffin',
                      desc: 'Idli, Vada, Dosa, Pongal, Filter Coffee',
                      itemsCount: '10 dishes'
                    },
                    {
                      key: 'biryaniNorth' as const,
                      title: 'Royal Biryani & Kebab',
                      desc: 'Chicken Dum Biryani, Paneer Tikka, Naan',
                      itemsCount: '8 dishes'
                    },
                    {
                      key: 'cafeBakery' as const,
                      title: 'Urban Cafe & Bakery',
                      desc: 'Espresso, Sandwiches, Fries, Croissants',
                      itemsCount: '9 dishes'
                    }
                  ].map((p) => (
                    <button
                      key={p.key}
                      type="button"
                      onClick={() => handleLoadPreset(p.key)}
                      className="p-4 rounded-xl bg-stone-950 hover:bg-stone-800/80 border border-stone-800 hover:border-amber-500/50 text-left transition-all group cursor-pointer"
                    >
                      <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                        <Utensils className="w-4 h-4" />
                      </div>
                      <div className="text-sm font-bold text-white">{p.title}</div>
                      <div className="text-[11px] text-stone-400 mt-1">{p.desc}</div>
                      <div className="text-[10px] text-amber-400 font-semibold mt-2">{p.itemsCount}</div>
                    </button>
                  ))}
                </div>
                {rawText && (
                  <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-800/60 text-emerald-300 text-xs flex items-center justify-between">
                    <span>Preset menu loaded into memory. Click "Extract Menu with AI" to continue.</span>
                    <button
                      type="button"
                      onClick={() => setCurrentStep('review')}
                      className="font-bold underline cursor-pointer"
                    >
                      View dishes
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Action Bar */}
            <div className="mt-8 pt-6 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4">
              <button
                type="button"
                onClick={() => setCurrentStep('details')}
                className="w-full sm:w-auto px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-300 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back to Details
              </button>

              <button
                type="button"
                disabled={isExtracting || (uploadMode === 'upload' && uploadedFiles.length === 0 && !rawText)}
                onClick={handleRunOcrExtraction}
                className={`w-full sm:w-auto px-6 py-3 font-black rounded-xl text-sm flex items-center justify-center gap-2 transition-transform shadow-lg cursor-pointer ${
                  isExtracting || (uploadMode === 'upload' && uploadedFiles.length === 0 && !rawText)
                    ? 'bg-stone-800 text-stone-500 cursor-not-allowed'
                    : 'bg-amber-500 hover:bg-amber-400 text-stone-950 active:scale-95 shadow-amber-500/20'
                }`}
              >
                {isExtracting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-stone-950" />
                    {extractionProgress || 'Running Gemini Vision OCR...'}
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Extract Menu with AI
                  </>
                )}
              </button>
            </div>
          </motion.div>
        )}

        {/* Step 3: Review & Edit Extracted Menu */}
        {currentStep === 'review' && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-stone-900 border border-stone-800 rounded-2xl p-6 sm:p-8 shadow-xl max-w-4xl mx-auto w-full"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    Review Extracted Dishes
                  </h2>
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    {items.length} dishes
                  </span>
                </div>
                {extractionNote && (
                  <p className="text-xs text-stone-400 mt-1">{extractionNote}</p>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleAddNewItem}
                  className="px-3 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold rounded-xl border border-stone-700 flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 text-amber-400" />
                  Add Dish
                </button>
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-4 border-b border-stone-800">
              <button
                type="button"
                onClick={() => setActiveCategoryFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  activeCategoryFilter === 'all'
                    ? 'bg-amber-500 text-stone-950'
                    : 'bg-stone-950 text-stone-400 hover:text-white border border-stone-800'
                }`}
              >
                All Sections ({items.length})
              </button>
              {categories.map((cat) => {
                const count = items.filter((i) => i.categoryName === cat.name).length;
                return (
                  <button
                    key={cat.name}
                    type="button"
                    onClick={() => setActiveCategoryFilter(cat.name)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                      activeCategoryFilter === cat.name
                        ? 'bg-amber-500 text-stone-950'
                        : 'bg-stone-950 text-stone-400 hover:text-white border border-stone-800'
                    }`}
                  >
                    {cat.name} ({count})
                  </button>
                );
              })}
            </div>

            {/* Items List */}
            <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
              {items
                .filter((item) => activeCategoryFilter === 'all' || item.categoryName === activeCategoryFilter)
                .map((item, index) => {
                  const actualIndex = items.findIndex((i) => i.tempId === item.tempId);
                  return (
                    <div
                      key={item.tempId}
                      className="p-3.5 rounded-xl bg-stone-950 border border-stone-800/90 hover:border-stone-700 transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                    >
                      {/* Name & Details */}
                      <div className="flex-1 min-w-0 w-full sm:w-auto">
                        <div className="flex items-center gap-2 mb-1">
                          {/* Diet Badge Toggle */}
                          <button
                            type="button"
                            onClick={() => {
                              const nextDiet: FoodDietType =
                                item.isVeg === 'veg' ? 'non-veg' : item.isVeg === 'non-veg' ? 'egg' : 'veg';
                              handleUpdateItem(actualIndex, { isVeg: nextDiet });
                            }}
                            className={`px-2 py-0.5 rounded text-[10px] font-black border uppercase cursor-pointer ${
                              item.isVeg === 'veg'
                                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                                : item.isVeg === 'egg'
                                ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                                : 'bg-rose-500/10 text-rose-400 border-rose-500/30'
                            }`}
                            title="Click to toggle Veg / Non-Veg / Egg"
                          >
                            {item.isVeg}
                          </button>

                          <input
                            type="text"
                            value={item.name}
                            onChange={(e) => handleUpdateItem(actualIndex, { name: e.target.value })}
                            className="text-sm font-bold text-white bg-transparent border-b border-transparent hover:border-stone-700 focus:border-amber-400 focus:outline-none flex-1 truncate px-1"
                          />
                        </div>

                        <input
                          type="text"
                          value={item.description || ''}
                          onChange={(e) => handleUpdateItem(actualIndex, { description: e.target.value })}
                          placeholder="Optional short description / ingredients"
                          className="text-xs text-stone-400 bg-transparent border-b border-transparent hover:border-stone-700 focus:border-amber-400 focus:outline-none w-full px-1"
                        />
                      </div>

                      {/* Price & Section & Delete */}
                      <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                        <div className="flex items-center gap-1 bg-stone-900 px-3 py-1.5 rounded-xl border border-stone-800">
                          <span className="text-xs font-bold text-amber-400">{currencySymbol}</span>
                          <input
                            type="number"
                            value={item.price}
                            onChange={(e) => handleUpdateItem(actualIndex, { price: parseFloat(e.target.value) || 0 })}
                            className="w-16 text-sm font-black text-white bg-transparent focus:outline-none text-right"
                          />
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDeleteItem(actualIndex)}
                          className="p-2 text-stone-500 hover:text-rose-400 hover:bg-stone-900 rounded-xl transition-colors cursor-pointer"
                          title="Delete dish"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>

            {/* Actions */}
            <div className="mt-8 pt-6 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4">
              <button
                type="button"
                onClick={() => setCurrentStep('upload')}
                className="w-full sm:w-auto px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-300 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                Back to Upload
              </button>

              <button
                type="button"
                disabled={isSaving || items.length === 0}
                onClick={handleCompleteAndGoLive}
                className={`w-full sm:w-auto px-8 py-3.5 font-black rounded-xl text-sm flex items-center justify-center gap-2 transition-transform shadow-xl cursor-pointer ${
                  isSaving || items.length === 0
                    ? 'bg-stone-800 text-stone-500 cursor-not-allowed'
                    : 'bg-emerald-500 hover:bg-emerald-400 text-stone-950 active:scale-95 shadow-emerald-500/20'
                }`}
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-stone-950" />
                    Saving Restaurant & Generating QR...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    Save & Go Live Instantly
                  </>
                )}
              </button>
            </div>
          </motion.div>
        )}

        {/* Step 4: Success & Live QR Standee */}
        {currentStep === 'success' && createdBusiness && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-stone-900 border border-stone-800 rounded-2xl p-6 sm:p-8 shadow-2xl max-w-2xl mx-auto w-full text-center"
          >
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {createdBusiness.name} is Live!
            </h2>
            <p className="text-sm text-stone-400 mt-1 max-w-md mx-auto">
              {createdBusiness.businessType === 'restaurant'
                ? 'Your live table menu is ready. Customers scan table QR standees to view your menu and place in-app orders with automatic sequential KOT numbers.'
                : 'Your room service and parcel pickup menu is ready. Guests order directly with automatic sequential serial tracking.'}
            </p>

            {/* Counter Standee Card Preview */}
            <div className="my-6 p-6 rounded-2xl bg-white text-stone-950 max-w-sm mx-auto shadow-2xl border border-stone-300 relative">
              <div className="text-center mb-3">
                <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                  {createdBusiness.businessType === 'restaurant' ? 'SCAN FOR TABLE ORDERING' : 'SCAN FOR ROOM SERVICE / PARCEL'}
                </span>
                <h3 className="text-lg font-black text-stone-950 mt-1.5 truncate">
                  {createdBusiness.name}
                </h3>
                <p className="text-[11px] text-stone-500 font-medium">
                  Direct In-App Kitchen Orders & Instant KOT Tickets
                </p>
              </div>

              {/* QR Code */}
              <div className="flex justify-center p-3 bg-stone-50 rounded-xl border border-stone-200 shadow-inner">
                <QRCodeSVG
                  id="merchant-onboard-qr"
                  value={liveMenuUrl}
                  size={190}
                  level="H"
                  includeMargin={false}
                />
              </div>

              {/* Destination check */}
              <div className="mt-3.5 pt-3 border-t border-stone-200 text-center">
                <p className="text-[11px] text-stone-600 flex items-center justify-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="font-bold text-stone-900">
                    {createdBusiness.businessType === 'restaurant' ? 'Table Service' : 'Room Service / Parcel Pickup'}
                  </span>
                  <span className="text-stone-300">•</span>
                  <span className="font-medium text-stone-600">
                    {createdBusiness.menuDisplayMode === 'text' ? 'Clean Text List' : 'Rich Photo Cards'}
                  </span>
                </p>
              </div>
            </div>

            {/* Quick Share Link */}
            <div className="mb-6 p-3 rounded-xl bg-stone-950 border border-stone-800 flex items-center justify-between gap-3 text-left">
              <div className="min-w-0">
                <div className="text-[10px] uppercase font-bold text-stone-500 tracking-wider">Customer Menu Slug Link</div>
                <div className="text-xs font-mono text-amber-400 truncate">{liveMenuUrl}</div>
              </div>
              <button
                type="button"
                onClick={handleCopyMenuLink}
                className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold rounded-lg shrink-0 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {copiedUrl ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    Copy Link
                  </>
                )}
              </button>
            </div>

            {/* Standee Action Buttons */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              <button
                type="button"
                onClick={handleDownloadQrPng}
                className="px-4 py-3 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold rounded-xl border border-stone-700 flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <FileDown className="w-4 h-4 text-amber-400" />
                Download QR (PNG)
              </button>

              <button
                type="button"
                onClick={handlePrintStandee}
                className="px-4 py-3 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold rounded-xl border border-stone-700 flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Printer className="w-4 h-4 text-amber-400" />
                Print Standee
              </button>
            </div>

            {/* Launch CTA */}
            <div className="space-y-3">
              <button
                type="button"
                onClick={() => onComplete(createdBusiness)}
                className="w-full py-4 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-stone-950 font-black rounded-xl text-base flex items-center justify-center gap-2 shadow-xl shadow-amber-500/20 active:scale-95 transition-transform cursor-pointer"
              >
                <ExternalLink className="w-5 h-5" />
                Open Live Customer Menu
              </button>

              <button
                type="button"
                onClick={() => {
                  window.history.pushState(null, '', `/#b/${createdBusiness.id}`);
                  onComplete(createdBusiness);
                }}
                className="w-full py-2.5 bg-stone-950 hover:bg-stone-800 text-stone-300 text-xs font-bold rounded-xl border border-stone-800 transition-colors cursor-pointer"
              >
                Manage Menu & Live Orders
              </button>
            </div>
          </motion.div>
        )}
      </main>
    </div>
  );
};
