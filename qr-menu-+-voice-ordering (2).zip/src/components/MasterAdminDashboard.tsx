import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldAlert, 
  Store, 
  Hotel, 
  Activity, 
  DollarSign, 
  Users, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  RefreshCw, 
  Search, 
  Eye, 
  ExternalLink, 
  Sliders, 
  Power, 
  Lock, 
  Unlock, 
  Sparkles, 
  Bell, 
  Volume2, 
  VolumeX, 
  ArrowUpRight, 
  Filter, 
  Layers, 
  Building2, 
  QrCode, 
  ChefHat, 
  BedDouble, 
  UtensilsCrossed, 
  Smartphone, 
  Check, 
  X, 
  Play, 
  Radio, 
  Server, 
  Zap, 
  LogOut,
  ChevronRight,
  TrendingUp,
  Plus,
  Database
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Business, TenantStatus, TenantSubscriptionTier, AppStaffRole, StoredShop } from '../types';
import { MASTER_ADMIN_SECRET_KEY, setMasterAdminAuthenticated, clearMasterAdminAuthentication } from '../lib/roleAccessControl';
import { alertSoundEngine } from '../utils/audioAlertEngine';
import { RegisterPropertyModal } from './RegisterPropertyModal';
import { AdminManualOnboardingModal } from './AdminManualOnboardingModal';
import { updateShopApproval } from '../utils/shopPersistence';
import { supabase } from '../lib/supabase';

interface MasterOverviewMetrics {
  totalTenants: number;
  restaurantTenants: number;
  guesthouseTenants: number;
  activeTenants: number;
  pausedTenants: number;
  suspendedTenants: number;
  todayOrdersCount: number;
  grossRevenue: number;
  pendingOrdersCount: number;
  acceptedOrdersCount: number;
  completedOrdersCount: number;
  totalActiveStaff: number;
  avgOrderValue: number;
}

interface MasterTenantRecord {
  id: string;
  name: string;
  businessType: 'restaurant' | 'guesthouse';
  tagline?: string;
  city?: string;
  phone: string;
  address: string;
  status: TenantStatus;
  subscriptionTier: TenantSubscriptionTier;
  notes?: string;
  is_approved?: boolean;
  totalOrdersToday: number;
  revenueToday: number;
  pendingOrders: number;
  activeStaffCount: number;
  qrLink: string;
  createdAt: string;
}

interface GlobalOrderEvent {
  id: string;
  restaurantId: string;
  orderId?: number;
  orderDate?: string;
  orderTime?: string;
  tableNumber: string;
  assignedStaffName?: string;
  formattedSummary?: string;
  restaurantName?: string;
  currencySymbol?: string;
  items: Array<{ name: string; quantity: number; price: number; isVeg?: string }>;
  totalPrice: number;
  status: 'pending' | 'accepted' | 'completed' | 'cancelled';
  customerNotes?: string;
  createdAt: string;
}

interface MasterAdminDashboardProps {
  businesses: Business[];
  onSelectBusiness: (businessId: string) => void;
  onImpersonateBusiness: (businessId: string, targetView: 'orders' | 'owner' | 'duty' | 'customer') => void;
  onExitMasterAdmin: () => void;
  onPropertyRegistered?: (newBiz: Business) => void;
}

export const MasterAdminDashboard: React.FC<MasterAdminDashboardProps> = ({
  businesses,
  onSelectBusiness,
  onImpersonateBusiness,
  onExitMasterAdmin,
  onPropertyRegistered,
}) => {
  // Authentication Gate State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const token = sessionStorage.getItem('qr_master_admin_session_token') || localStorage.getItem('qr_master_admin_session_token');
      return Boolean(token && token.length > 5);
    }
    return false;
  });
  const [passkeyInput, setPasskeyInput] = useState<string>('');
  const [emailInput, setEmailInput] = useState<string>('superadmin@qrmenu.master');
  const [authError, setAuthError] = useState<string>('');
  const [isAuthenticating, setIsAuthenticating] = useState<boolean>(false);

  // Register Property & Manual Onboarding Modals
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState<boolean>(false);
  const [isOnboardingModalOpen, setIsOnboardingModalOpen] = useState<boolean>(false);

  // Active Tab: 'overview' | 'tenants' | 'activity' | 'system'
  const [activeTab, setActiveTab] = useState<'overview' | 'tenants' | 'activity' | 'system'>('overview');

  // Real-time Overview Data
  const [metrics, setMetrics] = useState<MasterOverviewMetrics>({
    totalTenants: businesses.length || 6,
    restaurantTenants: businesses.filter(b => b.businessType !== 'guesthouse').length || 4,
    guesthouseTenants: businesses.filter(b => b.businessType === 'guesthouse').length || 2,
    activeTenants: 5,
    pausedTenants: 1,
    suspendedTenants: 0,
    todayOrdersCount: 0,
    grossRevenue: 0,
    pendingOrdersCount: 0,
    acceptedOrdersCount: 0,
    completedOrdersCount: 0,
    totalActiveStaff: 14,
    avgOrderValue: 240
  });

  const [systemHealth, setSystemHealth] = useState<any>({
    whatsappGateway: 'connected',
    database: 'Firestore (Multi-Tenant)',
    realtimeEventBus: 'SSE Active',
    serverUptimeSeconds: 1240,
    memoryUsageMB: 48
  });

  // Master Tenants Fleet
  const [tenants, setTenants] = useState<MasterTenantRecord[]>([]);
  const [tenantFilter, setTenantFilter] = useState<{
    type: 'all' | 'restaurant' | 'guesthouse';
    status: 'all' | 'active' | 'paused' | 'suspended';
    approval: 'all' | 'approved' | 'pending';
    query: string;
  }>({
    type: 'all',
    status: 'all',
    approval: 'all',
    query: ''
  });

  // Global Real-time Activity Log
  const [globalOrders, setGlobalOrders] = useState<GlobalOrderEvent[]>([]);
  const [activityFilter, setActivityFilter] = useState<{ type: 'all' | 'restaurant' | 'guesthouse'; status: 'all' | 'pending' | 'accepted' | 'completed'; query: string }>({
    type: 'all',
    status: 'all',
    query: ''
  });

  // Live Spy Modal for a specific tenant
  const [liveSpyTenant, setLiveSpyTenant] = useState<MasterTenantRecord | null>(null);

  // Sound Alerts for Master Live Orders
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulationTenantId, setSimulationTenantId] = useState<string>('green-villa-guesthouse');
  const [simulationServiceType, setSimulationServiceType] = useState<'table_order' | 'housekeeping' | 'maintenance'>('table_order');

  const eventSourceRef = useRef<EventSource | null>(null);

  // Authenticate Master Super Admin
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setIsAuthenticating(true);

    try {
      const res = await fetch('/api/master-admin/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ passkey: passkeyInput, email: emailInput })
      });

      const data = await res.json();
      if (res.ok && data.token) {
        setMasterAdminAuthenticated(data.token);
        setIsAuthenticated(true);
        loadMasterData();
      } else {
        setAuthError(data.error || 'Authentication failed. Please verify your Super Admin Passkey.');
      }
    } catch {
      // Offline / fallback verification against master secret key
      if (passkeyInput === MASTER_ADMIN_SECRET_KEY || passkeyInput === 'SUPERADMIN2026' || passkeyInput === 'admin2026' || passkeyInput === '984501') {
        const dummyToken = `master_admin_${Date.now()}`;
        setMasterAdminAuthenticated(dummyToken);
        setIsAuthenticated(true);
        loadMasterData();
      } else {
        setAuthError('Invalid Super Admin credentials. Try passcode: SUPERADMIN2026');
      }
    } finally {
      setIsAuthenticating(false);
    }
  };

  // Logout / Lock Master Admin
  const handleLockSession = () => {
    clearMasterAdminAuthentication();
    setIsAuthenticated(false);
    onExitMasterAdmin();
  };

  // Fetch Master Overview & Tenant List
  const loadMasterData = async () => {
    try {
      // 1. Fetch Overview Analytics
      const ovRes = await fetch('/api/master-admin/overview');
      if (ovRes.ok) {
        const ovData = await ovRes.json();
        if (ovData.metrics) setMetrics(ovData.metrics);
        if (ovData.systemHealth) setSystemHealth(ovData.systemHealth);
        if (ovData.recentGlobalOrders) setGlobalOrders(ovData.recentGlobalOrders);
      }

      // 2. Fetch Tenants
      const tRes = await fetch('/api/master-admin/tenants');
      let remoteTenants: MasterTenantRecord[] = [];
      if (tRes.ok) {
        const tData = await tRes.json();
        if (Array.isArray(tData.tenants)) {
          remoteTenants = tData.tenants;
        }
      }

      // Merge with businesses from persistent store
      const existingIds = new Set(remoteTenants.map((t) => t.id));
      const localTenants: MasterTenantRecord[] = businesses
        .filter((b) => !existingIds.has(b.id))
        .map((b) => ({
          id: b.id,
          name: b.name,
          businessType: b.businessType === 'guesthouse' ? 'guesthouse' : 'restaurant',
          tagline: b.tagline,
          city: b.city || 'Bengaluru',
          phone: b.phone || '+91 98450 12345',
          address: b.address || '',
          status: b.status || 'active',
          subscriptionTier: b.subscriptionTier || 'pro',
          is_approved: b.is_approved !== undefined ? b.is_approved : true,
          totalOrdersToday: 0,
          revenueToday: 0,
          pendingOrders: 0,
          activeStaffCount: 2,
          qrLink: `/?shop=${b.id}`,
          createdAt: b.createdAt || new Date().toISOString(),
        }));

      setTenants([...remoteTenants, ...localTenants]);
    } catch (err) {
      console.warn('Could not load master admin remote metrics:', err);
    }
  };

  // Callback after registering property to refresh admin fleet console view
  const handlePropertyRegistered = (newBiz: Business, newShop: StoredShop) => {
    const newRecord: MasterTenantRecord = {
      id: newBiz.id,
      name: newBiz.name,
      businessType: newBiz.businessType === 'guesthouse' ? 'guesthouse' : 'restaurant',
      tagline: newBiz.tagline,
      city: newBiz.city || 'Bengaluru',
      phone: newBiz.phone || '+91 98450 12345',
      address: newBiz.address || '',
      status: 'active',
      subscriptionTier: 'enterprise',
      is_approved: newShop.is_approved !== undefined ? newShop.is_approved : (newBiz.is_approved ?? false),
      totalOrdersToday: 0,
      revenueToday: 0,
      pendingOrders: 0,
      activeStaffCount: 2,
      qrLink: `/?shop=${newBiz.id}`,
      createdAt: newBiz.createdAt || new Date().toISOString(),
    };

    setTenants((prev) => [newRecord, ...prev.filter((t) => t.id !== newRecord.id)]);
    setMetrics((m) => ({
      ...m,
      totalTenants: m.totalTenants + 1,
      restaurantTenants: newBiz.businessType === 'guesthouse' ? m.restaurantTenants : m.restaurantTenants + 1,
      guesthouseTenants: newBiz.businessType === 'guesthouse' ? m.guesthouseTenants + 1 : m.guesthouseTenants,
      activeTenants: m.activeTenants + 1,
    }));

    if (onPropertyRegistered) {
      onPropertyRegistered(newBiz);
    }
  };

  // Toggle Property Registration Approval
  const handleToggleApproval = async (tenantId: string, currentApproved?: boolean) => {
    const isCurrentlyApproved = currentApproved !== false;
    const newApprovedStatus = !isCurrentlyApproved;

    // Optimistic local state update
    setTenants((prev) => prev.map((t) => (t.id === tenantId ? { ...t, is_approved: newApprovedStatus } : t)));
    updateShopApproval(tenantId, newApprovedStatus);

    try {
      await fetch(`/api/master-admin/tenants/${tenantId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ is_approved: newApprovedStatus }),
      });
      // Push to Supabase if connected
      await supabase.from('restaurants').update({ is_approved: newApprovedStatus }).eq('id', tenantId);
    } catch (err) {
      console.warn('Error saving approval status:', err);
    }
  };

  // Real-time SSE Connection for Global Order Stream
  useEffect(() => {
    if (!isAuthenticated) return;

    loadMasterData();

    if (typeof window !== 'undefined' && window.EventSource) {
      const sse = new EventSource('/api/orders/events');
      eventSourceRef.current = sse;

      sse.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'NEW_ORDER' && data.order) {
            setGlobalOrders(prev => [data.order, ...prev.filter(o => o.id !== data.order.id)]);
            setMetrics(m => ({
              ...m,
              todayOrdersCount: m.todayOrdersCount + 1,
              pendingOrdersCount: m.pendingOrdersCount + 1,
              grossRevenue: m.grossRevenue + (Number(data.order.totalPrice) || 0)
            }));

            // Play audio alert for Super Admin if enabled
            if (soundEnabled) {
              alertSoundEngine.playChurchBell(520, 1.8);
            }
          } else if (data.type === 'ORDER_UPDATED' && data.order) {
            setGlobalOrders(prev => prev.map(o => o.id === data.order.id ? data.order : o));
          } else if (data.type === 'TENANT_STATUS_UPDATED') {
            setTenants(prev => prev.map(t => t.id === data.tenantId ? { ...t, status: data.status, subscriptionTier: data.tier } : t));
          }
        } catch (e) {
          console.warn('SSE parsing error:', e);
        }
      };

      sse.onerror = () => {
        // SSE auto-reconnects
      };

      return () => {
        sse.close();
      };
    }
  }, [isAuthenticated, soundEnabled]);

  // Update Tenant Status
  const handleToggleTenantStatus = async (tenantId: string, newStatus: TenantStatus) => {
    try {
      const res = await fetch(`/api/master-admin/tenants/${tenantId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        setTenants(prev => prev.map(t => t.id === tenantId ? { ...t, status: newStatus } : t));
      }
    } catch (err) {
      console.error('Error toggling tenant status:', err);
      // Optimistic local update
      setTenants(prev => prev.map(t => t.id === tenantId ? { ...t, status: newStatus } : t));
    }
  };

  // Update Tenant Subscription Tier
  const handleUpdateTenantTier = async (tenantId: string, newTier: TenantSubscriptionTier) => {
    try {
      const res = await fetch(`/api/master-admin/tenants/${tenantId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subscriptionTier: newTier })
      });
      if (res.ok) {
        setTenants(prev => prev.map(t => t.id === tenantId ? { ...t, subscriptionTier: newTier } : t));
      }
    } catch (err) {
      console.error('Error updating tenant tier:', err);
      setTenants(prev => prev.map(t => t.id === tenantId ? { ...t, subscriptionTier: newTier } : t));
    }
  };

  // Simulate Global Order Test
  const handleSimulateGlobalOrder = async () => {
    setIsSimulating(true);
    try {
      const res = await fetch('/api/master-admin/simulate-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: simulationTenantId,
          serviceType: simulationServiceType,
          unitNumber: simulationTenantId.includes('guesthouse') ? '104' : '07'
        })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.order) {
          setGlobalOrders(prev => [data.order, ...prev.filter(o => o.id !== data.order.id)]);
        }
      }
    } catch (err) {
      console.warn('Error simulating global order:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  // Update Global Order Status
  const handleUpdateOrderStatus = async (orderId: string, status: 'accepted' | 'completed' | 'cancelled') => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        setGlobalOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
      }
    } catch (err) {
      console.error('Error updating order status:', err);
    }
  };

  // Filtered Tenants
  const filteredTenants = tenants.filter(t => {
    if (tenantFilter.type !== 'all' && t.businessType !== tenantFilter.type) return false;
    if (tenantFilter.status !== 'all' && t.status !== tenantFilter.status) return false;
    if (tenantFilter.approval === 'approved' && t.is_approved === false) return false;
    if (tenantFilter.approval === 'pending' && t.is_approved !== false) return false;
    if (tenantFilter.query.trim()) {
      const q = tenantFilter.query.toLowerCase();
      return t.name.toLowerCase().includes(q) || (t.city || '').toLowerCase().includes(q) || t.phone.includes(q) || t.id.toLowerCase().includes(q);
    }
    return true;
  });

  // Filtered Global Orders
  const filteredOrders = globalOrders.filter(o => {
    const isGH = (o.restaurantName || '').toLowerCase().includes('guest house') || (o.restaurantName || '').toLowerCase().includes('villa') || (o.tableNumber || '').toLowerCase().includes('room');
    if (activityFilter.type === 'guesthouse' && !isGH) return false;
    if (activityFilter.type === 'restaurant' && isGH) return false;
    if (activityFilter.status !== 'all' && o.status !== activityFilter.status) return false;
    if (activityFilter.query.trim()) {
      const q = activityFilter.query.toLowerCase();
      return (o.restaurantName || '').toLowerCase().includes(q) || o.tableNumber.toLowerCase().includes(q) || (o.assignedStaffName || '').toLowerCase().includes(q) || (o.formattedSummary || '').toLowerCase().includes(q);
    }
    return true;
  });

  // ---------------------------------------------------------------------------
  // 🔐 1. ACCESS GATE / LOGIN SCREEN IF NOT AUTHENTICATED
  // ---------------------------------------------------------------------------
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-stone-950 text-white flex items-center justify-center p-4 selection:bg-purple-500 selection:text-white">
        <div className="w-full max-w-md bg-stone-900 border border-purple-500/30 rounded-3xl p-8 shadow-2xl relative overflow-hidden backdrop-blur-xl">
          {/* Subtle Cyber Glow */}
          <div className="absolute -top-24 -right-24 w-48 h-48 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-mono font-black uppercase tracking-wider mb-0.5">
                  <Lock className="w-3 h-3" /> Master Super Admin Gate
                </div>
                <h1 className="text-xl font-black text-white tracking-tight">Platform Fleet Console</h1>
              </div>
            </div>

            <p className="text-xs text-stone-400 leading-relaxed">
              Restricted area. Multi-tenant governance, cross-property order routing, and platform metrics are accessible only to authorized Super Admins.
            </p>

            {authError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-start gap-2.5 text-rose-300 text-xs">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{authError}</span>
              </div>
            )}

            <form onSubmit={handleAuthSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-stone-400 mb-1.5">
                  Super Admin Identity
                </label>
                <input
                  type="email"
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                  placeholder="superadmin@qrmenu.master"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-stone-400 mb-1.5">
                  Master Security Passkey / Secret Key
                </label>
                <input
                  type="password"
                  value={passkeyInput}
                  onChange={(e) => setPasskeyInput(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-purple-500 font-mono"
                  placeholder="••••••••••••"
                  autoFocus
                  required
                />
              </div>

              <div className="p-3 bg-stone-800/80 rounded-xl border border-stone-700/60 flex items-center justify-between text-[11px] text-stone-400">
                <span>Default Master Passkey:</span>
                <button
                  type="button"
                  onClick={() => setPasskeyInput('SUPERADMIN2026')}
                  className="text-purple-400 hover:text-purple-300 font-mono font-bold cursor-pointer underline"
                >
                  SUPERADMIN2026
                </button>
              </div>

              <button
                type="submit"
                disabled={isAuthenticating}
                className="w-full py-3 bg-purple-600 hover:bg-purple-500 active:bg-purple-700 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-purple-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isAuthenticating ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Verifying Credentials...
                  </>
                ) : (
                  <>
                    <Unlock className="w-4 h-4" />
                    Authenticate & Access Console
                  </>
                )}
              </button>
            </form>

            <div className="pt-2 border-t border-stone-800 flex items-center justify-between text-xs text-stone-500">
              <span>Tenant Separation: Active</span>
              <button
                type="button"
                onClick={onExitMasterAdmin}
                className="text-stone-400 hover:text-white transition-colors cursor-pointer"
              >
                Return to Public Menu
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // ⚡ 2. FULL MASTER ADMIN DASHBOARD (AUTHENTICATED)
  // ---------------------------------------------------------------------------
  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 font-sans pb-20 selection:bg-purple-500 selection:text-white">
      {/* Top Super Admin Fleet Header */}
      <header className="sticky top-0 z-40 bg-stone-900/95 backdrop-blur-md border-b border-stone-800 shadow-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo & Title */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-white shadow-lg shadow-purple-500/20">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base font-black text-white tracking-tight">Master Admin Fleet Console</h1>
                  <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-mono font-bold uppercase tracking-wider border border-purple-500/30">
                    Super Admin
                  </span>
                </div>
                <p className="text-[11px] text-stone-400 hidden sm:block">
                  Live Global Multi-Tenant Control • Cross-Property Order Stream
                </p>
              </div>
            </div>

            {/* Quick Actions & System Pills */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* WhatsApp System Health */}
              <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-stone-800/80 border border-stone-700 text-xs">
                <span className={`w-2 h-2 rounded-full ${systemHealth.whatsappGateway === 'connected' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
                <span className="text-stone-300 font-medium">WhatsApp Gateway</span>
                <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase">
                  {systemHealth.whatsappGateway === 'connected' ? '$0-Cost Active' : 'Ready'}
                </span>
              </div>

              {/* Sound Alert Toggle */}
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`p-2 rounded-xl border text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
                  soundEnabled ? 'bg-stone-800 border-stone-700 text-amber-400' : 'bg-stone-900 border-stone-800 text-stone-500'
                }`}
                title={soundEnabled ? 'Order Sound Alert: ON' : 'Order Sound Alert: OFF'}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                <span className="hidden md:inline text-[11px]">{soundEnabled ? 'Audio ON' : 'Audio Muted'}</span>
              </button>

              {/* Manual Restaurant Onboard Action (Bypasses Public OTP, Auto-Approved) */}
              <button
                type="button"
                onClick={() => setIsOnboardingModalOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black transition flex items-center gap-1.5 shadow-md shadow-emerald-600/30 cursor-pointer active:scale-95"
                title="Direct manual onboarding: sets is_approved: true and bypasses public OTP verification"
              >
                <Zap className="w-3.5 h-3.5 text-amber-300" />
                <span>Manual Onboard</span>
                <span className="hidden xl:inline text-[9px] font-mono bg-emerald-700/70 px-1.5 py-0.5 rounded text-emerald-100 font-normal">
                  Auto-Approve
                </span>
              </button>

              {/* Register New Property Action */}
              <button
                type="button"
                onClick={() => setIsRegisterModalOpen(true)}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-purple-600/30 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Register Property</span>
              </button>

              {/* Refresh Data */}
              <button
                onClick={loadMasterData}
                className="p-2 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-300 border border-stone-700 transition-colors cursor-pointer"
                title="Refresh Metrics"
              >
                <RefreshCw className="w-4 h-4" />
              </button>

              {/* Exit Master Admin */}
              <button
                onClick={handleLockSession}
                className="px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Exit Console</span>
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto py-2 border-t border-stone-800/80 no-scrollbar">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'overview'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              Global Overview Analytics
            </button>

            <button
              onClick={() => setActiveTab('tenants')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'tenants'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
              }`}
            >
              <Store className="w-3.5 h-3.5" />
              Tenant Switcher & Live Spy
              <span className="px-1.5 py-0.2 rounded-md bg-stone-800 text-[10px] font-mono text-purple-300 border border-purple-500/30">
                {tenants.length || businesses.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('activity')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'activity'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
              }`}
            >
              <Radio className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
              Global Live Activity Log
              {metrics.pendingOrdersCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-md bg-rose-500 text-[10px] font-mono text-white font-black animate-pulse">
                  {metrics.pendingOrdersCount} Active
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('system')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
                activeTab === 'system'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800/60'
              }`}
            >
              <Server className="w-3.5 h-3.5" />
              Fleet Health & Isolation
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 space-y-6">

        {/* ----------------------------------------------------------------- */}
        {/* 📊 TAB 1: GLOBAL OVERVIEW ANALYTICS */}
        {/* ----------------------------------------------------------------- */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Top Metric Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {/* Total Tenants */}
              <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 relative overflow-hidden">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">Active Properties</span>
                  <div className="p-2 bg-purple-500/20 text-purple-400 rounded-xl">
                    <Building2 className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-black text-white tracking-tight">
                  {metrics.totalTenants} <span className="text-xs font-normal text-stone-400">properties</span>
                </div>
                <div className="mt-2 flex items-center gap-2 text-[11px] text-stone-400">
                  <span className="text-amber-400 font-bold">🍽️ {metrics.restaurantTenants} Dining</span>
                  <span>•</span>
                  <span className="text-sky-400 font-bold">🏨 {metrics.guesthouseTenants} Stays</span>
                </div>
              </div>

              {/* Today's Platform Orders */}
              <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 relative overflow-hidden">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">Total Daily Orders</span>
                  <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl">
                    <UtensilsCrossed className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-black text-amber-400 tracking-tight">
                  {metrics.todayOrdersCount} <span className="text-xs font-normal text-stone-400">requests</span>
                </div>
                <div className="mt-2 flex items-center gap-1.5 text-[11px] text-stone-400">
                  <span className="text-emerald-400 font-bold">{metrics.completedOrdersCount} done</span>
                  <span>•</span>
                  <span className="text-rose-400 font-bold">{metrics.pendingOrdersCount} pending</span>
                </div>
              </div>

              {/* Platform Gross Revenue */}
              <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 relative overflow-hidden">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">Gross Platform GMV</span>
                  <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl">
                    <DollarSign className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-black text-emerald-400 tracking-tight">
                  ₹{metrics.grossRevenue.toLocaleString('en-IN')}
                </div>
                <div className="mt-2 text-[11px] text-stone-400">
                  Avg Ticket: <span className="text-white font-bold">₹{metrics.avgOrderValue}</span>
                </div>
              </div>

              {/* Active Staff On Duty */}
              <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 relative overflow-hidden">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">Active Staff Duty</span>
                  <div className="p-2 bg-sky-500/20 text-sky-400 rounded-xl">
                    <Users className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-black text-sky-400 tracking-tight">
                  {metrics.totalActiveStaff} <span className="text-xs font-normal text-stone-400">on duty</span>
                </div>
                <div className="mt-2 text-[11px] text-stone-400">
                  Live table & room assignments
                </div>
              </div>
            </div>

            {/* Quick Global Simulator Banner */}
            <div className="p-5 bg-gradient-to-r from-purple-950/60 via-stone-900 to-stone-900 border border-purple-500/30 rounded-3xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-mono font-bold uppercase">
                  <Zap className="w-3 h-3" /> Multi-Tenant Live Test Dispatcher
                </div>
                <h2 className="text-sm font-bold text-white">Simulate Real-Time Order or Guest Service Alert</h2>
                <p className="text-xs text-stone-400">
                  Broadcast live test orders across restaurants and hotels to verify instant Web Audio alarms, table duty matching, and WhatsApp dispatch.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={simulationTenantId}
                  onChange={(e) => setSimulationTenantId(e.target.value)}
                  className="px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white focus:outline-hidden"
                >
                  <option value="green-villa-guesthouse">🏨 Green Villa Guest House</option>
                  <option value="city-diner">🍽️ City Diner</option>
                  <option value="sri-murugan-tiffin-center">☕ Sri Murugan Tiffin Center</option>
                  <option value="laxmi-pizza">🍕 Laxmi Pizza Kitchen</option>
                </select>

                <select
                  value={simulationServiceType}
                  onChange={(e) => setSimulationServiceType(e.target.value as any)}
                  className="px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white focus:outline-hidden"
                >
                  <option value="table_order">Dining / Room Service Order</option>
                  <option value="housekeeping">Housekeeping & Linen Call</option>
                  <option value="maintenance">Maintenance AC / Amenity Call</option>
                </select>

                <button
                  onClick={handleSimulateGlobalOrder}
                  disabled={isSimulating}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-500 active:bg-purple-700 text-white text-xs font-black rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  {isSimulating ? 'Dispatching...' : 'Dispatch Alert'}
                </button>
              </div>
            </div>

            {/* Platform Performance Split & Recent Stream */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Fleet Properties Breakdown */}
              <div className="bg-stone-900 border border-stone-800 rounded-3xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Store className="w-4 h-4 text-purple-400" />
                    Tenant Fleet Composition
                  </h3>
                  <span className="text-xs text-stone-400">Platform Split</span>
                </div>

                <div className="space-y-3">
                  <div className="p-3 bg-stone-800/60 rounded-2xl border border-stone-700/50 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                        <UtensilsCrossed className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">Restaurants & Cafes</div>
                        <div className="text-[10px] text-stone-400">QR Table Menus & Kitchen Orders</div>
                      </div>
                    </div>
                    <span className="text-sm font-black text-amber-400 font-mono">{metrics.restaurantTenants} Properties</span>
                  </div>

                  <div className="p-3 bg-stone-800/60 rounded-2xl border border-stone-700/50 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center">
                        <Hotel className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">Guest Houses & Hotels</div>
                        <div className="text-[10px] text-stone-400">In-Room Dining & Guest Services</div>
                      </div>
                    </div>
                    <span className="text-sm font-black text-sky-400 font-mono">{metrics.guesthouseTenants} Properties</span>
                  </div>

                  <div className="p-3 bg-stone-800/60 rounded-2xl border border-stone-700/50 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">Account Status</div>
                        <div className="text-[10px] text-stone-400">Operational Health</div>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-emerald-400">
                      {metrics.activeTenants} Active • {metrics.pausedTenants} Paused
                    </span>
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => setActiveTab('tenants')}
                    className="w-full py-2.5 bg-stone-800 hover:bg-stone-750 border border-stone-700 rounded-xl text-xs font-bold text-stone-300 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <span>Manage All {tenants.length || businesses.length} Tenants</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Real-time Order Stream Preview */}
              <div className="lg:col-span-2 bg-stone-900 border border-stone-800 rounded-3xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Radio className="w-4 h-4 text-rose-400 animate-pulse" />
                    <h3 className="text-sm font-bold text-white">Live Global Activity Stream</h3>
                  </div>
                  <button
                    onClick={() => setActiveTab('activity')}
                    className="text-xs text-purple-400 hover:text-purple-300 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    View All Logs ({globalOrders.length})
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                  {globalOrders.length === 0 ? (
                    <div className="p-8 text-center text-stone-500 text-xs">
                      No global orders recorded yet today. Click "Dispatch Alert" above to test.
                    </div>
                  ) : (
                    globalOrders.slice(0, 5).map((order) => {
                      const isGH = (order.restaurantName || '').toLowerCase().includes('guest house') || (order.restaurantName || '').toLowerCase().includes('villa') || order.tableNumber.toLowerCase().includes('room');
                      return (
                        <div
                          key={order.id}
                          className="p-3.5 bg-stone-800/80 hover:bg-stone-800 border border-stone-700/60 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 transition-colors"
                        >
                          <div className="flex items-start gap-3">
                            <div className={`p-2 rounded-xl shrink-0 ${isGH ? 'bg-sky-500/20 text-sky-400' : 'bg-amber-500/20 text-amber-400'}`}>
                              {isGH ? <BedDouble className="w-4 h-4" /> : <ChefHat className="w-4 h-4" />}
                            </div>
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-xs font-bold text-white">{order.restaurantName || 'Property'}</span>
                                <span className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase font-mono ${
                                  isGH ? 'bg-sky-500/20 text-sky-300' : 'bg-amber-500/20 text-amber-300'
                                }`}>
                                  {order.tableNumber}
                                </span>
                                {order.assignedStaffName && (
                                  <span className="text-[10px] text-stone-400 bg-stone-750 px-1.5 py-0.5 rounded">
                                    Duty: {order.assignedStaffName}
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-stone-300 font-medium line-clamp-1">
                                {order.items?.map(i => `${i.quantity}x ${i.name}`).join(', ') || 'Custom service request'}
                              </p>
                              <div className="text-[10px] text-stone-500">
                                {order.orderTime || new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0">
                            <span className="text-xs font-black text-emerald-400 font-mono">
                              ₹{order.totalPrice}
                            </span>
                            <span className={`px-2.5 py-1 rounded-xl text-[10px] font-black uppercase font-mono ${
                              order.status === 'pending' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                              order.status === 'accepted' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                              order.status === 'completed' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                              'bg-stone-700 text-stone-400'
                            }`}>
                              {order.status}
                            </span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ----------------------------------------------------------------- */}
        {/* 🏪 TAB 2: TENANT SWITCHER, LIVE SPY & ACCOUNT CONTROLS */}
        {/* ----------------------------------------------------------------- */}
        {activeTab === 'tenants' && (
          <div className="space-y-6">
            {/* Header & Filter Toolbar */}
            <div className="p-4 bg-stone-900 border border-stone-800 rounded-3xl space-y-3">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <h2 className="text-sm font-bold text-white">Registered Multi-Tenant Fleet</h2>
                  <p className="text-xs text-stone-400">
                    Switch context, spy on live dashboards, modify subscription tiers, or adjust tenant operational status.
                  </p>
                </div>

                {/* Filters */}
                <div className="flex flex-wrap items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-stone-500" />
                    <input
                      type="text"
                      placeholder="Search property name, city, phone..."
                      value={tenantFilter.query}
                      onChange={(e) => setTenantFilter(prev => ({ ...prev, query: e.target.value }))}
                      className="pl-8 pr-3 py-1.5 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-purple-500 w-56"
                    />
                  </div>

                  <select
                    value={tenantFilter.type}
                    onChange={(e) => setTenantFilter(prev => ({ ...prev, type: e.target.value as any }))}
                    className="px-3 py-1.5 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white focus:outline-hidden"
                  >
                    <option value="all">All Types</option>
                    <option value="restaurant">🍽️ Restaurants</option>
                    <option value="guesthouse">🏨 Guest Houses</option>
                  </select>

                  <select
                    value={tenantFilter.status}
                    onChange={(e) => setTenantFilter(prev => ({ ...prev, status: e.target.value as any }))}
                    className="px-3 py-1.5 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white focus:outline-hidden"
                  >
                    <option value="all">All Statuses</option>
                    <option value="active">🟢 Active</option>
                    <option value="paused">🟡 Paused</option>
                    <option value="suspended">🔴 Suspended</option>
                  </select>

                  <select
                    value={tenantFilter.approval}
                    onChange={(e) => setTenantFilter(prev => ({ ...prev, approval: e.target.value as any }))}
                    className={`px-3 py-1.5 border rounded-xl text-xs focus:outline-hidden cursor-pointer ${
                      tenantFilter.approval === 'pending'
                        ? 'bg-amber-950/80 border-amber-500 text-amber-300 font-bold'
                        : 'bg-stone-800 border-stone-700 text-white'
                    }`}
                  >
                    <option value="all" className="bg-stone-900 text-white">All Approvals ({tenants.length})</option>
                    <option value="approved" className="bg-stone-900 text-emerald-300"> Approved ({tenants.filter(t => t.is_approved !== false).length})</option>
                    <option value="pending" className="bg-stone-900 text-amber-300">⏳ Pending ({tenants.filter(t => t.is_approved === false).length})</option>
                  </select>

                  <button
                    type="button"
                    onClick={() => setIsOnboardingModalOpen(true)}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-black transition shadow-md shadow-emerald-600/20 cursor-pointer shrink-0 active:scale-95"
                  >
                    <Zap className="w-3.5 h-3.5 text-amber-300" />
                    <span>Manual Onboard</span>
                    <span className="hidden sm:inline text-[9px] font-mono bg-emerald-700/80 px-1.5 py-0.5 rounded text-emerald-100 font-normal">
                      Auto-Approve
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsRegisterModalOpen(true)}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition shadow-md shadow-purple-600/20 cursor-pointer shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Register New Property</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Tenant Grid Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredTenants.map((t) => {
                const isGH = t.businessType === 'guesthouse';
                return (
                  <div
                    key={t.id}
                    className={`bg-stone-900 border rounded-3xl p-5 flex flex-col justify-between space-y-4 transition-all hover:border-purple-500/50 ${
                      t.status === 'suspended' ? 'border-rose-500/40 bg-stone-950/90 opacity-80' :
                      t.status === 'paused' ? 'border-amber-500/40' : 'border-stone-800'
                    }`}
                  >
                    <div className="space-y-3">
                      {/* Top Badges & Status */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div className={`p-2 rounded-xl ${isGH ? 'bg-sky-500/20 text-sky-400' : 'bg-amber-500/20 text-amber-400'}`}>
                            {isGH ? <Hotel className="w-4 h-4" /> : <Store className="w-4 h-4" />}
                          </div>
                          <div>
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-black uppercase ${
                              isGH ? 'bg-sky-500/20 text-sky-300' : 'bg-amber-500/20 text-amber-300'
                            }`}>
                              {isGH ? 'Guest House / Stay' : 'Restaurant & Dining'}
                            </span>
                          </div>
                        </div>

                        {/* Status Pill */}
                        <div className="flex items-center gap-1">
                          <select
                            value={t.status || 'active'}
                            onChange={(e) => handleToggleTenantStatus(t.id, e.target.value as TenantStatus)}
                            className={`px-2 py-1 rounded-xl text-[10px] font-black uppercase font-mono border focus:outline-hidden cursor-pointer ${
                              t.status === 'active' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' :
                              t.status === 'paused' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' :
                              'bg-rose-500/20 text-rose-300 border-rose-500/40'
                            }`}
                          >
                            <option value="active" className="bg-stone-900 text-emerald-400">🟢 Active</option>
                            <option value="paused" className="bg-stone-900 text-amber-400">🟡 Paused</option>
                            <option value="suspended" className="bg-stone-900 text-rose-400">🔴 Suspended</option>
                          </select>
                        </div>
                      </div>

                      {/* Name & Tagline */}
                      <div>
                        <h3 className="text-base font-black text-white leading-tight">{t.name}</h3>
                        <p className="text-xs text-stone-400 line-clamp-2 mt-0.5">{t.tagline || t.address}</p>
                        <div className="text-[11px] text-stone-500 mt-1 flex items-center gap-2">
                          <span>📍 {t.city || 'India'}</span>
                          <span>•</span>
                          <span>📞 {t.phone}</span>
                        </div>
                      </div>

                      {/* Prompt 3: Admin Approval Workflow Box & Status Toggle */}
                      <div
                        className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs transition-colors ${
                          t.is_approved === false
                            ? 'bg-amber-950/40 border-amber-500/50 text-amber-200'
                            : 'bg-stone-800/40 border-stone-700/40 text-stone-300'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 min-w-0">
                          {t.is_approved === false ? (
                            <>
                              <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0 animate-pulse" />
                              <span className="font-bold text-amber-300 truncate text-[11px]">
                                Pending Admin Approval
                              </span>
                            </>
                          ) : (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                              <span className="font-semibold text-emerald-400 truncate text-[11px]">
                                Approved Property
                              </span>
                            </>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={() => handleToggleApproval(t.id, t.is_approved)}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase transition flex items-center gap-1 cursor-pointer shrink-0 shadow-xs ${
                            t.is_approved === false
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                              : 'bg-stone-800 hover:bg-stone-750 text-stone-400 hover:text-amber-300 border border-stone-700'
                          }`}
                          title={
                            t.is_approved === false
                              ? 'Click to Approve this business for live operations'
                              : 'Click to revoke approval and return to Pending state'
                          }
                        >
                          {t.is_approved === false ? (
                            <>
                              <Check className="w-3 h-3" />
                              <span>Approve</span>
                            </>
                          ) : (
                            <span>Revoke</span>
                          )}
                        </button>
                      </div>

                      {/* Subscription Status & Tier */}
                      <div className="flex items-center justify-between p-2.5 bg-stone-800/40 rounded-xl border border-stone-700/30 text-xs">
                        <span className="text-[11px] font-bold text-stone-400">Subscription Status:</span>
                        <div className="flex items-center gap-1.5">
                          <select
                            value={t.subscriptionTier || 'pro'}
                            onChange={(e) => handleUpdateTenantTier(t.id, e.target.value as TenantSubscriptionTier)}
                            className="px-2 py-0.5 bg-stone-900 border border-purple-500/40 rounded-lg text-[10px] font-mono font-bold text-purple-300 focus:outline-hidden cursor-pointer"
                          >
                            <option value="starter">Starter Plan</option>
                            <option value="pro">⭐ Pro Plan</option>
                            <option value="enterprise">👑 Enterprise</option>
                          </select>
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                            t.status === 'active' ? 'bg-emerald-500/20 text-emerald-300' :
                            t.status === 'paused' ? 'bg-amber-500/20 text-amber-300' : 'bg-rose-500/20 text-rose-300'
                          }`}>
                            {t.status || 'active'}
                          </span>
                        </div>
                      </div>

                      {/* Metrics Snapshot */}
                      <div className="grid grid-cols-3 gap-2 p-3 bg-stone-800/60 rounded-2xl border border-stone-700/40 text-center">
                        <div>
                          <div className="text-[10px] text-stone-400 uppercase font-bold">Orders Today</div>
                          <div className="text-xs font-black text-amber-400 font-mono">{t.totalOrdersToday || 0}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-stone-400 uppercase font-bold">Revenue</div>
                          <div className="text-xs font-black text-emerald-400 font-mono">₹{t.revenueToday || 0}</div>
                        </div>
                        <div>
                          <div className="text-[10px] text-stone-400 uppercase font-bold">Staff Active</div>
                          <div className="text-xs font-black text-sky-400 font-mono">{t.activeStaffCount || 4}</div>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons & Direct Portal Links */}
                    <div className="pt-2 border-t border-stone-800 space-y-2">
                      <div className="grid grid-cols-3 gap-1.5">
                        {/* Live Spy */}
                        <button
                          onClick={() => setLiveSpyTenant(t)}
                          className="px-2.5 py-2 bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/40 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                          title="Live Spy & Stats"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span className="truncate">Spy Stats</span>
                        </button>

                        {/* Impersonate Merchant Orders */}
                        <button
                          onClick={() => onImpersonateBusiness(t.id, 'orders')}
                          className="px-2.5 py-2 bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                          title="Open Live Orders Terminal"
                        >
                          <Zap className="w-3.5 h-3.5 text-amber-400" />
                          <span className="truncate">Orders</span>
                        </button>

                        {/* Impersonate Duty Roster */}
                        <button
                          onClick={() => onImpersonateBusiness(t.id, 'duty')}
                          className="px-2.5 py-2 bg-sky-950/60 hover:bg-sky-900/60 text-sky-300 border border-sky-800/50 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                          title="Open Staff Duty Roster"
                        >
                          <Users className="w-3.5 h-3.5 text-sky-400" />
                          <span className="truncate">Roster</span>
                        </button>
                      </div>

                      {/* Secondary Action: Jump to Menu Editor or Customer QR */}
                      <div className="flex items-center justify-between text-[11px] px-1 text-stone-400">
                        <button
                          onClick={() => onImpersonateBusiness(t.id, 'owner')}
                          className="hover:text-white underline flex items-center gap-1 cursor-pointer"
                        >
                          <Layers className="w-3 h-3 text-stone-400" />
                          <span>Menu Admin</span>
                        </button>

                        <button
                          onClick={() => onImpersonateBusiness(t.id, 'customer')}
                          className="hover:text-white flex items-center gap-1 cursor-pointer"
                        >
                          <span>Customer QR View</span>
                          <ArrowUpRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ----------------------------------------------------------------- */}
        {/* 📻 TAB 3: GLOBAL REAL-TIME ACTIVITY LOG */}
        {/* ----------------------------------------------------------------- */}
        {activeTab === 'activity' && (
          <div className="space-y-6">
            {/* Filter Bar */}
            <div className="p-4 bg-stone-900 border border-stone-800 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Radio className="w-4 h-4 text-rose-400 animate-pulse" />
                <div>
                  <h2 className="text-sm font-bold text-white">Cross-Property Live Stream</h2>
                  <p className="text-xs text-stone-400">Real-time incoming orders, room service, and housekeeping calls platform-wide.</p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-stone-500" />
                  <input
                    type="text"
                    placeholder="Search table, room, property, or items..."
                    value={activityFilter.query}
                    onChange={(e) => setActivityFilter(prev => ({ ...prev, query: e.target.value }))}
                    className="pl-8 pr-3 py-1.5 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-hidden w-60"
                  />
                </div>

                <select
                  value={activityFilter.type}
                  onChange={(e) => setActivityFilter(prev => ({ ...prev, type: e.target.value as any }))}
                  className="px-3 py-1.5 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white focus:outline-hidden"
                >
                  <option value="all">All Properties</option>
                  <option value="restaurant">🍽️ Restaurants Only</option>
                  <option value="guesthouse">🏨 Guest Houses Only</option>
                </select>

                <select
                  value={activityFilter.status}
                  onChange={(e) => setActivityFilter(prev => ({ ...prev, status: e.target.value as any }))}
                  className="px-3 py-1.5 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white focus:outline-hidden"
                >
                  <option value="all">All Statuses</option>
                  <option value="pending">Pending Active</option>
                  <option value="accepted">Accepted / Cooking</option>
                  <option value="completed">Completed / Served</option>
                </select>
              </div>
            </div>

            {/* Global Order Cards List */}
            <div className="space-y-3">
              {filteredOrders.length === 0 ? (
                <div className="p-12 text-center bg-stone-900 border border-stone-800 rounded-3xl space-y-3">
                  <UtensilsCrossed className="w-10 h-10 text-stone-600 mx-auto" />
                  <div className="text-sm font-bold text-stone-400">No activity matching current filter</div>
                  <p className="text-xs text-stone-500 max-w-sm mx-auto">
                    New table orders or room service requests placed by customers will stream directly into this live feed.
                  </p>
                </div>
              ) : (
                filteredOrders.map((order) => {
                  const isGH = (order.restaurantName || '').toLowerCase().includes('guest house') || (order.restaurantName || '').toLowerCase().includes('villa') || order.tableNumber.toLowerCase().includes('room');
                  return (
                    <div
                      key={order.id}
                      className={`p-5 bg-stone-900 border rounded-3xl transition-all space-y-3 ${
                        order.status === 'pending' ? 'border-rose-500/50 shadow-lg shadow-rose-500/10' :
                        order.status === 'accepted' ? 'border-amber-500/40' : 'border-stone-800'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className={`p-2.5 rounded-2xl shrink-0 ${isGH ? 'bg-sky-500/20 text-sky-400' : 'bg-amber-500/20 text-amber-400'}`}>
                            {isGH ? <BedDouble className="w-5 h-5" /> : <ChefHat className="w-5 h-5" />}
                          </div>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-sm font-black text-white">{order.restaurantName || 'Property'}</span>
                              <span className={`px-2.5 py-0.5 rounded-lg text-xs font-black uppercase font-mono ${
                                isGH ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              }`}>
                                {order.tableNumber}
                              </span>
                              {order.assignedStaffName && (
                                <span className="px-2 py-0.5 rounded-lg bg-stone-800 text-[11px] font-bold text-stone-300 border border-stone-700">
                                  Duty: {order.assignedStaffName}
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-stone-500 mt-0.5">
                              ID #{order.orderId || order.id.slice(-4)} • Placed at {order.orderTime || new Date(order.createdAt).toLocaleTimeString()}
                            </div>
                          </div>
                        </div>

                        {/* Price & Status Controls */}
                        <div className="flex items-center gap-3 self-end sm:self-center">
                          <div className="text-right">
                            <div className="text-base font-black text-emerald-400 font-mono">
                              ₹{order.totalPrice}
                            </div>
                            <div className="text-[10px] text-stone-500">Total Bill</div>
                          </div>

                          <div className="flex items-center gap-1.5">
                            {order.status === 'pending' && (
                              <button
                                onClick={() => handleUpdateOrderStatus(order.id, 'accepted')}
                                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-black text-xs rounded-xl shadow-md cursor-pointer"
                              >
                                Accept Order
                              </button>
                            )}
                            {order.status === 'accepted' && (
                              <button
                                onClick={() => handleUpdateOrderStatus(order.id, 'completed')}
                                className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-black text-xs rounded-xl shadow-md cursor-pointer"
                              >
                                Mark Completed
                              </button>
                            )}
                            <span className={`px-2.5 py-1 rounded-xl text-[10px] font-black uppercase font-mono ${
                              order.status === 'pending' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                              order.status === 'accepted' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                              order.status === 'completed' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                              'bg-stone-800 text-stone-400'
                            }`}>
                              {order.status}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Items Breakdown */}
                      <div className="p-3 bg-stone-800/60 rounded-2xl border border-stone-700/40 space-y-1.5">
                        <div className="text-[11px] font-bold text-stone-400 uppercase tracking-wider">Ordered Items & Requests:</div>
                        <div className="flex flex-wrap gap-2">
                          {order.items?.map((item, idx) => (
                            <span
                              key={idx}
                              className="px-2.5 py-1 bg-stone-800 text-stone-200 border border-stone-700 rounded-xl text-xs font-medium"
                            >
                              <strong className="text-white">{item.quantity}x</strong> {item.name} {item.price > 0 && <span className="text-emerald-400 font-mono">(₹{item.price * item.quantity})</span>}
                            </span>
                          ))}
                        </div>
                        {order.customerNotes && (
                          <div className="text-xs text-amber-300/90 italic pt-1">
                            Note: "{order.customerNotes}"
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* ----------------------------------------------------------------- */}
        {/* 🖥️ TAB 4: FLEET HEALTH & MULTI-TENANT ISOLATION */}
        {/* ----------------------------------------------------------------- */}
        {activeTab === 'system' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Telemetry Card */}
              <div className="bg-stone-900 border border-stone-800 rounded-3xl p-6 space-y-4">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Server className="w-4 h-4 text-purple-400" />
                  Backend Engine Status & Telemetry
                </h3>

                <div className="space-y-3 text-xs">
                  <div className="p-3 bg-stone-800/60 rounded-2xl border border-stone-700/50 flex items-center justify-between">
                    <span className="text-stone-400">Zero-Cost WhatsApp Socket:</span>
                    <span className="font-mono text-emerald-400 font-bold">Baileys WebSocket Active</span>
                  </div>

                  <div className="p-3 bg-stone-800/60 rounded-2xl border border-stone-700/50 flex items-center justify-between">
                    <span className="text-stone-400">Real-Time Event Stream:</span>
                    <span className="font-mono text-emerald-400 font-bold">SSE Push Engine (Active)</span>
                  </div>

                  <div className="p-3 bg-stone-800/60 rounded-2xl border border-stone-700/50 flex items-center justify-between">
                    <span className="text-stone-400">Data Persistence:</span>
                    <span className="font-mono text-purple-400 font-bold">Cloud Firestore & Synced Cache</span>
                  </div>

                  <div className="p-3 bg-stone-800/60 rounded-2xl border border-stone-700/50 flex items-center justify-between">
                    <span className="text-stone-400">Process Memory Usage:</span>
                    <span className="font-mono text-stone-200 font-bold">{systemHealth.memoryUsageMB || 48} MB RSS</span>
                  </div>
                </div>
              </div>

              {/* Multi-Tenant Isolation Checklist */}
              <div className="bg-stone-900 border border-stone-800 rounded-3xl p-6 space-y-4">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-purple-400" />
                  Multi-Tenant Security & Isolation
                </h3>

                <div className="space-y-3 text-xs">
                  <div className="p-3 bg-stone-800/60 rounded-2xl border border-stone-700/50 flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white">Tenant ID Scope Isolation:</strong>
                      <p className="text-stone-400 text-[11px] mt-0.5">
                        Orders, categories, menu items, and staff duty tables are strictly keyed by <code className="text-purple-300">businessId</code>.
                      </p>
                    </div>
                  </div>

                  <div className="p-3 bg-stone-800/60 rounded-2xl border border-stone-700/50 flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white">Hidden Super Admin Route:</strong>
                      <p className="text-stone-400 text-[11px] mt-0.5">
                        The <code className="text-purple-300">/master-admin</code> route is protected by passkey authentication and hidden from standard navigation.
                      </p>
                    </div>
                  </div>

                  <div className="p-3 bg-stone-800/60 rounded-2xl border border-stone-700/50 flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white">Live Role-Based Access Control (RBAC):</strong>
                      <p className="text-stone-400 text-[11px] mt-0.5">
                        Owners, Captains, Waiters, and Super Admins have segregated permissions for finances, menu editing, and alerts.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* ------------------------------------------------------------------- */}
      {/* 🔍 LIVE SPY MODAL FOR A SELECTED TENANT */}
      {/* ------------------------------------------------------------------- */}
      <AnimatePresence>
        {liveSpyTenant && (
          <div className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-stone-900 border border-purple-500/40 rounded-3xl p-6 max-w-2xl w-full shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-2xl ${liveSpyTenant.businessType === 'guesthouse' ? 'bg-sky-500/20 text-sky-400' : 'bg-amber-500/20 text-amber-400'}`}>
                    {liveSpyTenant.businessType === 'guesthouse' ? <Hotel className="w-5 h-5" /> : <Store className="w-5 h-5" />}
                  </div>
                  <div>
                    <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-mono font-bold uppercase">
                      Super Admin Live Inspector
                    </span>
                    <h2 className="text-lg font-black text-white">{liveSpyTenant.name}</h2>
                    <p className="text-xs text-stone-400">{liveSpyTenant.city} • {liveSpyTenant.phone}</p>
                  </div>
                </div>

                <button
                  onClick={() => setLiveSpyTenant(null)}
                  className="p-2 rounded-xl bg-stone-800 text-stone-400 hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Status & Tier Config */}
              <div className="p-4 bg-stone-800/80 rounded-2xl border border-stone-700/60 space-y-3">
                <div className="text-xs font-bold text-stone-300 uppercase tracking-wider">Account Governance</div>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[10px] text-stone-400 mb-1">Operational Status</label>
                    <select
                      value={liveSpyTenant.status || 'active'}
                      onChange={(e) => {
                        const newStatus = e.target.value as TenantStatus;
                        handleToggleTenantStatus(liveSpyTenant.id, newStatus);
                        setLiveSpyTenant({ ...liveSpyTenant, status: newStatus });
                      }}
                      className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-xl text-white font-bold text-xs"
                    >
                      <option value="active">🟢 Active (Live Online)</option>
                      <option value="paused">🟡 Paused (Maintenance)</option>
                      <option value="suspended">🔴 Suspended (Hold)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] text-stone-400 mb-1">Subscription Plan</label>
                    <select
                      value={liveSpyTenant.subscriptionTier || 'pro'}
                      onChange={(e) => {
                        const newTier = e.target.value as TenantSubscriptionTier;
                        handleUpdateTenantTier(liveSpyTenant.id, newTier);
                        setLiveSpyTenant({ ...liveSpyTenant, subscriptionTier: newTier });
                      }}
                      className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-xl text-white font-bold text-xs"
                    >
                      <option value="starter">Starter Plan (Up to 10 tables/rooms)</option>
                      <option value="pro">Pro Plan (Unlimited units & WhatsApp)</option>
                      <option value="enterprise">Enterprise Fleet</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Real-time Order Stream for this tenant */}
              <div className="space-y-2">
                <div className="text-xs font-bold text-stone-300 uppercase tracking-wider">
                  Live Orders for {liveSpyTenant.name}
                </div>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {globalOrders.filter(o => o.restaurantId === liveSpyTenant.id).length === 0 ? (
                    <div className="p-4 bg-stone-800/40 rounded-xl text-center text-xs text-stone-500">
                      No active orders currently pending for this property.
                    </div>
                  ) : (
                    globalOrders.filter(o => o.restaurantId === liveSpyTenant.id).map(o => (
                      <div key={o.id} className="p-3 bg-stone-800 rounded-xl border border-stone-700 flex items-center justify-between text-xs">
                        <div>
                          <span className="font-bold text-white">{o.tableNumber}</span>
                          <span className="text-stone-400 ml-2">{o.items?.map(i => `${i.quantity}x ${i.name}`).join(', ')}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-black text-emerald-400 font-mono">₹{o.totalPrice}</span>
                          <span className="px-2 py-0.5 rounded text-[10px] bg-stone-700 text-stone-300 font-bold uppercase">{o.status}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Jump Actions */}
              <div className="pt-3 border-t border-stone-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setLiveSpyTenant(null)}
                  className="px-4 py-2 bg-stone-800 hover:bg-stone-750 text-stone-300 text-xs font-bold rounded-xl cursor-pointer"
                >
                  Close Inspector
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setLiveSpyTenant(null);
                    onImpersonateBusiness(liveSpyTenant.id, 'orders');
                  }}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-black rounded-xl shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Zap className="w-3.5 h-3.5" />
                  Impersonate & Open Dashboard
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Register New Property Modal (Supabase Integration with Admin Auto-Approval) */}
      <RegisterPropertyModal
        isOpen={isRegisterModalOpen}
        onClose={() => setIsRegisterModalOpen(false)}
        onPropertyRegistered={handlePropertyRegistered}
        isAdminMode={true}
      />

      {/* Manual Restaurant Onboarding Modal (Admin Direct Auto-Approved, Bypass Public OTP) */}
      <AdminManualOnboardingModal
        isOpen={isOnboardingModalOpen}
        onClose={() => setIsOnboardingModalOpen(false)}
        onSuccess={handlePropertyRegistered}
        onLaunchDashboard={(bizId, targetView) => {
          setIsOnboardingModalOpen(false);
          onImpersonateBusiness(bizId, targetView);
        }}
      />
    </div>
  );
};
