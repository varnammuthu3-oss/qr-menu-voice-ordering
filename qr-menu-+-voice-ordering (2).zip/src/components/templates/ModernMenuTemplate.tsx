import React, { useState, useMemo, useEffect } from 'react';
import { Business, MenuCategory, MenuItem, MenuItemVariant, FoodDietType, CartItem } from '../../types';
import { DietBadge } from '../DietBadge';
import { sanitizeWhatsappNumber, createWhatsappOrderUrl, createWhatsappDirectUrl } from '../../utils/phone';
import { CartDrawer } from '../CartDrawer';
import { 
  MessageCircle,
  MessageSquare, 
  Clock, 
  MapPin, 
  Search, 
  Sparkles, 
  ChevronRight, 
  Utensils,
  Hotel,
  CheckCircle2,
  Plus,
  Minus,
  Check,
  Package
} from 'lucide-react';

interface ModernMenuTemplateProps {
  business: Business;
  categories: MenuCategory[];
  items: MenuItem[];
  previewMode?: boolean;
  onOpenOwnerDashboard?: () => void;
  tenantType?: 'restaurant' | 'guesthouse';
  initialLocationNumber?: string;
}

export const ModernMenuTemplate: React.FC<ModernMenuTemplateProps> = ({
  business,
  categories,
  items,
  previewMode = false,
  onOpenOwnerDashboard,
  tenantType = 'restaurant',
  initialLocationNumber,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [dietFilter, setDietFilter] = useState<'all' | FoodDietType>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleAddItem = (item: MenuItem, variant?: MenuItemVariant) => {
    const selectedVariant = variant || (item.variants && item.variants.length > 0 ? (item.variants.find(v => v.isDefault) || item.variants[0]) : undefined);
    const effectivePrice = selectedVariant ? selectedVariant.price : item.price;
    const variantId = selectedVariant?.id;
    const cartItemKey = variantId ? `cart_${item.id}_${variantId}` : `cart_${item.id}`;

    setCartItems((prev) => {
      const existingIndex = prev.findIndex((ci) => 
        variantId 
          ? ci.itemId === item.id && ci.selectedVariant?.id === variantId
          : ci.itemId === item.id && !ci.selectedVariant
      );

      if (existingIndex >= 0) {
        const next = [...prev];
        const exist = next[existingIndex];
        const newQty = exist.quantity + 1;
        next[existingIndex] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: (exist.unitPrice || exist.price) * newQty,
        };
        return next;
      } else {
        const displayName = selectedVariant ? `${item.name} (${selectedVariant.name})` : item.name;
        const newItem: CartItem = {
          cartItemId: `${cartItemKey}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          itemId: item.id,
          name: displayName,
          price: effectivePrice,
          unitPrice: effectivePrice,
          quantity: 1,
          item: item,
          selectedVariant: selectedVariant,
          selectedOptions: [],
          customNote: '',
          totalItemPrice: effectivePrice,
        };
        return [...prev, newItem];
      }
    });
  };

  const handleUpdateQuantity = (cartItemIdOrItemId: string, delta: number) => {
    setCartItems((prev) => {
      // Find by cartItemId first
      const byCartId = prev.findIndex((ci) => ci.cartItemId === cartItemIdOrItemId);
      if (byCartId >= 0) {
        const exist = prev[byCartId];
        const newQty = exist.quantity + delta;
        if (newQty <= 0) {
          return prev.filter((_, idx) => idx !== byCartId);
        }
        const next = [...prev];
        next[byCartId] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: exist.unitPrice * newQty,
        };
        return next;
      }

      // Fallback: match by itemId
      const byItemId = prev.findIndex((ci) => ci.itemId === cartItemIdOrItemId);
      if (byItemId >= 0) {
        const exist = prev[byItemId];
        const newQty = exist.quantity + delta;
        if (newQty <= 0) {
          return prev.filter((_, idx) => idx !== byItemId);
        }
        const next = [...prev];
        next[byItemId] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: exist.unitPrice * newQty,
        };
        return next;
      }

      return prev;
    });
  };

  const handleRemoveItem = (cartItemIdOrItemId: string) => {
    setCartItems((prev) => prev.filter((ci) => ci.cartItemId !== cartItemIdOrItemId && ci.itemId !== cartItemIdOrItemId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const activeCategories = useMemo(() => {
    return [...categories]
      .filter((c) => c.isActive)
      .sort((a, b) => a.displayOrder - b.displayOrder);
  }, [categories]);

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      if (selectedCategory !== 'all' && item.categoryId !== selectedCategory) {
        return false;
      }
      if (dietFilter !== 'all' && item.isVeg !== dietFilter) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesDesc = (item.description || '').toLowerCase().includes(q);
        const matchesTags = (item.tags || []).some((t) => t.toLowerCase().includes(q));
        if (!matchesName && !matchesDesc && !matchesTags) {
          return false;
        }
      }
      return true;
    });
  }, [items, selectedCategory, dietFilter, searchQuery]);

  const itemsByCategory = useMemo(() => {
    const map = new Map<string, MenuItem[]>();
    for (const cat of activeCategories) {
      map.set(cat.id, []);
    }
    for (const item of filteredItems) {
      const list = map.get(item.categoryId);
      if (list) {
        list.push(item);
      } else {
        if (!map.has('other')) map.set('other', []);
        map.get('other')?.push(item);
      }
    }
    return map;
  }, [activeCategories, filteredItems]);

  // Calculate item quantity in cart across customizations
  const getItemCartQuantity = (itemId: string) => {
    return cartItems
      .filter((ci) => ci.itemId === itemId)
      .reduce((sum, ci) => sum + ci.quantity, 0);
  };

  return (
    <div className="min-h-screen bg-stone-100 text-stone-900 pb-28 font-sans antialiased">
      {/* Container max width for mobile & tablet comfort */}
      <div className="max-w-2xl mx-auto bg-white min-h-screen shadow-xl border-x border-stone-200/80">
        
        {/* Cover / Header Banner */}
        <div className="relative bg-gradient-to-b from-stone-900 via-stone-850 to-stone-900 text-white p-5 sm:p-7 overflow-hidden">
          {/* Subtle Ambient Glow */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

          <div className="relative z-10 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  <Sparkles className="w-3 h-3" />
                  Live Digital Menu
                </span>
                <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                  {business.name || 'Gourmet Kitchen'}
                </h1>
                {business.tagline && (
                  <p className="text-xs sm:text-sm text-stone-300 font-medium">
                    {business.tagline}
                  </p>
                )}
                {business.description && (
                  <p className="text-xs text-stone-400 font-normal leading-relaxed max-w-lg pt-0.5">
                    {business.description}
                  </p>
                )}
              </div>

              {business.logoUrl && (
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl overflow-hidden bg-stone-800 border-2 border-stone-700/80 shrink-0 shadow-lg">
                  <img
                    src={business.logoUrl}
                    alt={business.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>

            {/* Quick Metadata Bar */}
            <div className="flex flex-wrap items-center gap-3 pt-2 text-xs text-stone-300 border-t border-stone-800/80">
              {business.address && (
                <div className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="truncate max-w-[200px]">{business.address}</span>
                </div>
              )}
              {(business.whatsappNumber || business.phone) && (
                <a
                  href={createWhatsappDirectUrl(business.whatsappNumber || business.phone, business.name)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 hover:text-emerald-200 border border-emerald-500/40 text-xs font-semibold transition-all cursor-pointer shadow-xs"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>WhatsApp Us</span>
                </a>
              )}
            </div>

            {/* Parcel Takeaway Badge */}
            <div className="p-3 rounded-xl bg-amber-950/60 border border-amber-500/40 flex items-center justify-between gap-3 text-amber-100 shadow-inner">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500 text-stone-950 flex items-center justify-center font-black shrink-0 shadow-xs">
                  <Package className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black uppercase tracking-wider text-white">
                      Counter Parcel Pickup
                    </span>
                    <span className="text-[10px] px-2 py-0.2 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                      Takeaway Order
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-300 leading-tight mt-0.5">
                    Orders sent directly to kitchen counter for fresh parcel packing
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 shrink-0 hidden sm:inline">
                Parcel Mode
              </span>
            </div>
          </div>
        </div>

        {/* Sticky Search & Category Bar */}
        <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-stone-200 shadow-2xs">
          {/* Search Input */}
          <div className="p-3 border-b border-stone-100">
            <div className="relative">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search dishes (e.g., Pizza, Biryani, Coffee)..."
                className="w-full pl-9 pr-4 py-2 bg-stone-100/80 hover:bg-stone-100 focus:bg-white text-stone-900 placeholder:text-stone-400 text-xs sm:text-sm rounded-xl border border-stone-200 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 outline-none transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs font-bold cursor-pointer"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Diet Filter Chips */}
          <div className="px-3 py-2 flex items-center gap-1.5 overflow-x-auto no-scrollbar border-b border-stone-100 text-xs">
            <button
              type="button"
              onClick={() => setDietFilter('all')}
              className={`px-3 py-1 rounded-full font-bold transition-colors shrink-0 cursor-pointer ${
                dietFilter === 'all'
                  ? 'bg-stone-900 text-white'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              All Diet
            </button>
            <button
              type="button"
              onClick={() => setDietFilter('veg')}
              className={`px-3 py-1 rounded-full font-bold transition-colors shrink-0 flex items-center gap-1 cursor-pointer ${
                dietFilter === 'veg'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>Veg Only</span>
            </button>
            <button
              type="button"
              onClick={() => setDietFilter('non-veg')}
              className={`px-3 py-1 rounded-full font-bold transition-colors shrink-0 flex items-center gap-1 cursor-pointer ${
                dietFilter === 'non-veg'
                  ? 'bg-rose-600 text-white'
                  : 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-rose-500" />
              <span>Non-Veg</span>
            </button>
          </div>

          {/* Categories Horizontal Scroller */}
          {activeCategories.length > 0 && (
            <div className="px-3 py-2 flex items-center gap-2 overflow-x-auto no-scrollbar">
              <button
                type="button"
                onClick={() => setSelectedCategory('all')}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs shrink-0 transition-all cursor-pointer ${
                  selectedCategory === 'all'
                    ? 'bg-amber-500 text-stone-950 shadow-2xs font-black'
                    : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                All Menu ({filteredItems.length})
              </button>
              {activeCategories.map((cat) => {
                const count = (itemsByCategory.get(cat.id) || []).length;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs shrink-0 transition-all cursor-pointer ${
                      selectedCategory === cat.id
                        ? 'bg-amber-500 text-stone-950 shadow-2xs font-black'
                        : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                    }`}
                  >
                    {cat.name} ({count})
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Menu Items List */}
        <div className="p-3.5 sm:p-5 space-y-6">
          {filteredItems.length === 0 ? (
            <div className="py-16 text-center space-y-2 bg-stone-50 rounded-2xl border border-stone-200">
              <Utensils className="w-8 h-8 text-stone-400 mx-auto" />
              <h3 className="font-bold text-stone-700 text-base">No items found</h3>
              <p className="text-xs text-stone-500">
                Try searching for something else or clearing filters
              </p>
            </div>
          ) : selectedCategory === 'all' ? (
            // Grouped By Category
            activeCategories.map((cat) => {
              const catItems = itemsByCategory.get(cat.id) || [];
              if (catItems.length === 0) return null;

              return (
                <section key={cat.id} className="space-y-3">
                  <div className="flex items-center justify-between pt-2 border-b border-stone-200/80 pb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-amber-500" />
                      <h2 className="font-black text-base text-stone-900">{cat.name}</h2>
                    </div>
                    <span className="text-[11px] text-stone-400 font-bold font-mono">
                      {catItems.length} {catItems.length === 1 ? 'item' : 'items'}
                    </span>
                  </div>

                  <div className="space-y-3">
                    {catItems.map((item) => (
                      <ModernItemCard 
                        key={item.id} 
                        item={item} 
                        currencySymbol={business.currencySymbol || '₹'} 
                        quantity={getItemCartQuantity(item.id)}
                        onAddItem={handleAddItem}
                        onUpdateQuantity={handleUpdateQuantity}
                      />
                    ))}
                  </div>
                </section>
              );
            })
          ) : (
            // Flat List View
            <div className="space-y-3">
              {filteredItems.map((item) => (
                <ModernItemCard 
                  key={item.id} 
                  item={item} 
                  currencySymbol={business.currencySymbol || '₹'} 
                  quantity={getItemCartQuantity(item.id)}
                  onAddItem={handleAddItem}
                  onUpdateQuantity={handleUpdateQuantity}
                />
              ))}
            </div>
          )}
        </div>

        {/* Modern Footer */}
        <div className="p-5 text-center border-t border-stone-200 text-stone-500 text-xs bg-stone-50 space-y-1">
          <p className="font-bold text-stone-700">
            {business.name}
          </p>
          <p className="text-[11px] text-stone-400">
            Real-time Digital Menu • Powered by QR Menu
          </p>
          {onOpenOwnerDashboard && (
            <button
              onClick={onOpenOwnerDashboard}
              className="text-[11px] text-amber-600 hover:underline pt-2 block mx-auto font-medium cursor-pointer"
            >
              Owner Portal
            </button>
          )}
        </div>

      </div>

      {/* Sticky Cart Summary & WhatsApp Order Drawer */}
      <CartDrawer
        business={business}
        cartItems={cartItems}
        items={items}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        previewMode={previewMode}
        tenantType={tenantType}
        initialLocationNumber={initialLocationNumber}
      />
    </div>
  );
};

const ModernItemCard: React.FC<{ 
  item: MenuItem; 
  currencySymbol: string; 
  quantity: number;
  onAddItem: (item: MenuItem, variant?: MenuItemVariant) => void;
  onUpdateQuantity: (itemId: string, delta: number) => void;
}> = ({ item, currencySymbol, quantity, onAddItem, onUpdateQuantity }) => {
  const [justAdded, setJustAdded] = useState(false);

  const defaultVariant = item.variants?.find((v) => v.isDefault) || item.variants?.[0];
  const [selectedVariant, setSelectedVariant] = useState<MenuItemVariant | undefined>(defaultVariant);

  useEffect(() => {
    if (item.variants && item.variants.length > 0) {
      setSelectedVariant(item.variants.find((v) => v.isDefault) || item.variants[0]);
    } else {
      setSelectedVariant(undefined);
    }
  }, [item.variants]);

  const activePrice = selectedVariant ? selectedVariant.price : item.price;

  const handleAdd = () => {
    if (!item.isAvailable) return;
    onAddItem(item, selectedVariant);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1000);
  };

  return (
    <div
      className={`p-3.5 sm:p-4 bg-white rounded-xl sm:rounded-2xl border transition-all ${
        item.isAvailable
          ? 'border-stone-200 shadow-2xs hover:border-amber-400'
          : 'border-stone-200 bg-stone-50/70 opacity-60'
      }`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 space-y-1.5 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 flex-wrap min-w-0">
              <DietBadge type={item.isVeg} size="sm" />
              <h3 className="font-black text-sm sm:text-base text-stone-900 leading-snug">
                {item.name}
              </h3>
            </div>
          </div>

          {item.description && (
            <p className="text-xs text-stone-500 leading-relaxed line-clamp-2">
              {item.description}
            </p>
          )}

          {/* Size / Variant Selector */}
          {item.variants && item.variants.length > 0 && (
            <div className="pt-2 pb-1">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500">
                  Select Size:
                </span>
                <span className="text-[10px] text-amber-800 font-semibold font-mono">
                  {selectedVariant?.name}
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {item.variants.map((v) => {
                  const isSelected = selectedVariant?.id === v.id;
                  return (
                    <button
                      key={v.id}
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedVariant(v);
                      }}
                      className={`px-2.5 py-1 text-xs rounded-lg border transition-all cursor-pointer flex items-center gap-1.5 active:scale-95 ${
                        isSelected
                          ? 'bg-amber-500 text-stone-950 border-amber-500 shadow-2xs font-bold'
                          : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border-stone-200 hover:border-stone-300 font-medium'
                      }`}
                    >
                      <span>{v.name}</span>
                      <span className={`text-[11px] font-mono ${isSelected ? 'text-stone-950 font-bold' : 'text-stone-500'}`}>
                        {currencySymbol}{v.price}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Price & Single Clean ADD button */}
          <div className="flex items-center justify-between gap-2 pt-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-1 rounded-lg bg-amber-50 text-stone-950 font-black text-xs sm:text-sm border border-amber-200/80 font-mono">
                {currencySymbol}{activePrice}
              </span>

              {selectedVariant && (
                <span className="text-[10px] text-stone-500 font-medium hidden sm:inline">
                  ({selectedVariant.name})
                </span>
              )}

              {quantity > 0 && (
                <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-bold">
                  {quantity} in cart
                </span>
              )}

              {!item.isAvailable && (
                <span className="px-2 py-0.5 rounded-full bg-stone-200 text-stone-600 text-[10px] font-bold uppercase tracking-wider">
                  Sold Out
                </span>
              )}
            </div>

            {item.isAvailable && (
              <button
                type="button"
                onClick={handleAdd}
                className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-stone-950 font-black text-xs transition-all shadow-2xs cursor-pointer flex items-center gap-1.5 shrink-0"
              >
                {justAdded ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-stone-950" />
                    <span>ADDED</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-3.5 h-3.5" />
                    <span>ADD</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {item.imageUrl && (
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl overflow-hidden bg-stone-100 shrink-0 border border-stone-200">
            <img
              src={item.imageUrl}
              alt={item.name}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </div>
        )}
      </div>
    </div>
  );
};
