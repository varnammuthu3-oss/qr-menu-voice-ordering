import React, { useState, useMemo, useEffect } from 'react';
import { Business, MenuCategory, MenuItem, MenuItemVariant, FoodDietType, CartItem } from '../../types';
import { DietBadge } from '../DietBadge';
import { sanitizeWhatsappNumber, createWhatsappDirectUrl } from '../../utils/phone';
import { CartDrawer } from '../CartDrawer';
import { ItemModifierModal } from '../ItemModifierModal';
import { getFoodImageUrl } from '../../utils/foodImages';
import { 
  MessageCircle, 
  Clock, 
  MapPin, 
  Search, 
  Sparkles, 
  Utensils, 
  Hotel, 
  Plus, 
  Minus, 
  Check, 
  SlidersHorizontal,
  Flame,
  Camera,
  Layers,
  ChevronRight,
  Info
} from 'lucide-react';

interface VisualMenuTemplateProps {
  business: Business;
  categories: MenuCategory[];
  items: MenuItem[];
  previewMode?: boolean;
  onOpenOwnerDashboard?: () => void;
  tenantType?: 'restaurant' | 'guesthouse';
  initialLocationNumber?: string;
}

export const VisualMenuTemplate: React.FC<VisualMenuTemplateProps> = ({
  business,
  categories,
  items,
  previewMode = false,
  onOpenOwnerDashboard,
  tenantType = 'restaurant',
  initialLocationNumber,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [dietFilter, setDietFilter] = useState<'all' | FoodDietType>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeLayout, setActiveLayout] = useState<'cards' | 'compact'>('cards');

  // Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  // Customizer modal state
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);

  // Map category IDs to category names for fast lookups
  const categoryMap = useMemo(() => {
    const map = new Map<string, string>();
    categories.forEach((c) => map.set(c.id, c.name));
    return map;
  }, [categories]);

  // Add item with variant
  const handleAddItem = (item: MenuItem, variant?: MenuItemVariant) => {
    const selectedVariant = variant || (item.variants && item.variants.length > 0 ? (item.variants.find(v => v.isDefault) || item.variants[0]) : undefined);
    const effectivePrice = selectedVariant ? selectedVariant.price : item.price;
    const variantId = selectedVariant?.id;
    const cartItemKey = variantId ? `cart_${item.id}_${variantId}` : `cart_${item.id}`;

    setCartItems((prev) => {
      const existingIndex = prev.findIndex((ci) => 
        variantId 
          ? ci.itemId === item.id && ci.selectedVariant?.id === variantId
          : ci.itemId === item.id && !ci.selectedVariant
      );

      if (existingIndex >= 0) {
        const next = [...prev];
        const exist = next[existingIndex];
        const newQty = exist.quantity + 1;
        next[existingIndex] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: (exist.unitPrice || exist.price) * newQty,
        };
        return next;
      } else {
        const displayName = selectedVariant ? `${item.name} (${selectedVariant.name})` : item.name;
        const newItem: CartItem = {
          cartItemId: `${cartItemKey}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          itemId: item.id,
          name: displayName,
          price: effectivePrice,
          unitPrice: effectivePrice,
          quantity: 1,
          item: item,
          selectedVariant: selectedVariant,
          selectedOptions: [],
          customNote: '',
          totalItemPrice: effectivePrice,
        };
        return [...prev, newItem];
      }
    });
  };

  const handleUpdateQuantity = (cartItemIdOrItemId: string, delta: number) => {
    setCartItems((prev) => {
      const byCartId = prev.findIndex((ci) => ci.cartItemId === cartItemIdOrItemId);
      if (byCartId >= 0) {
        const exist = prev[byCartId];
        const newQty = exist.quantity + delta;
        if (newQty <= 0) {
          return prev.filter((_, idx) => idx !== byCartId);
        }
        const next = [...prev];
        next[byCartId] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: exist.unitPrice * newQty,
        };
        return next;
      }

      const byItemId = prev.findIndex((ci) => ci.itemId === cartItemIdOrItemId);
      if (byItemId >= 0) {
        const exist = prev[byItemId];
        const newQty = exist.quantity + delta;
        if (newQty <= 0) {
          return prev.filter((_, idx) => idx !== byItemId);
        }
        const next = [...prev];
        next[byItemId] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: exist.unitPrice * newQty,
        };
        return next;
      }

      return prev;
    });
  };

  const handleRemoveItem = (cartItemId: string) => {
    setCartItems((prev) => prev.filter((ci) => ci.cartItemId !== cartItemId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleConfirmCustomization = (customized: {
    item: MenuItem;
    selectedVariant?: MenuItemVariant;
    selectedOptions: string[];
    customNote: string;
    quantity: number;
    totalItemPrice: number;
  }) => {
    const { item, selectedVariant, selectedOptions, customNote, quantity, totalItemPrice } = customized;
    const unitPrice = quantity > 0 ? Math.round(totalItemPrice / quantity) : totalItemPrice;
    const variantId = selectedVariant?.id;
    const cartItemKey = variantId ? `cart_${item.id}_${variantId}_custom` : `cart_${item.id}_custom`;
    const displayName = selectedVariant ? `${item.name} (${selectedVariant.name})` : item.name;

    const newItem: CartItem = {
      cartItemId: `${cartItemKey}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      itemId: item.id,
      name: displayName,
      price: unitPrice,
      unitPrice: unitPrice,
      quantity,
      item,
      selectedVariant,
      selectedOptions,
      customNote,
      totalItemPrice,
    };

    setCartItems((prev) => [...prev, newItem]);
    setCustomizingItem(null);
  };

  // Filter items
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      if (!item.isAvailable) return false;
      if (selectedCategory !== 'all' && item.categoryId !== selectedCategory) return false;
      if (dietFilter !== 'all' && item.isVeg !== dietFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesDesc = (item.description || '').toLowerCase().includes(q);
        const matchesTags = (item.tags || []).some((t) => t.toLowerCase().includes(q));
        const catName = categoryMap.get(item.categoryId) || '';
        const matchesCat = catName.toLowerCase().includes(q);
        return matchesName || matchesDesc || matchesTags || matchesCat;
      }
      return true;
    });
  }, [items, selectedCategory, dietFilter, searchQuery, categoryMap]);

  // Group filtered items by category if "all" is selected
  const groupedItems = useMemo(() => {
    if (selectedCategory !== 'all') {
      const cat = categories.find((c) => c.id === selectedCategory);
      return [{ category: cat, items: filteredItems }];
    }

    return categories
      .map((cat) => ({
        category: cat,
        items: filteredItems.filter((i) => i.categoryId === cat.id),
      }))
      .filter((group) => group.items.length > 0);
  }, [categories, filteredItems, selectedCategory]);

  const currencySymbol = business.currencySymbol || '₹';
  const totalCartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const totalCartValue = cartItems.reduce((sum, item) => sum + item.totalItemPrice, 0);

  const cleanWhatsapp = sanitizeWhatsappNumber(business.whatsappNumber || business.phone || '');
  const directWhatsappUrl = cleanWhatsapp ? createWhatsappDirectUrl(cleanWhatsapp) : null;

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 pb-32 selection:bg-amber-500 selection:text-stone-950">
      
      {/* 1. Header Banner & Business Identity */}
      <div className="relative bg-stone-900 border-b border-stone-800 overflow-hidden">
        {/* Cover Photo */}
        <div className="h-44 sm:h-60 w-full relative overflow-hidden bg-stone-900">
          <img
            src={business.coverUrl || 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200&auto=format&fit=crop&q=80'}
            alt={business.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover brightness-60 scale-105 transition-transform duration-700 hover:scale-100"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent" />
          
          {/* Top Badge Overlay */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-950/80 backdrop-blur-md border border-amber-500/40 text-[11px] font-black tracking-wide text-amber-400 shadow-md">
              <Camera className="w-3.5 h-3.5" />
              <span>VISUAL MENU</span>
            </span>

            {directWhatsappUrl && (
              <a
                href={directWhatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600/90 hover:bg-emerald-500 text-white rounded-full text-xs font-bold shadow-lg backdrop-blur-md transition-all active:scale-95"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-current" />
                <span className="hidden sm:inline">WhatsApp Us</span>
              </a>
            )}
          </div>
        </div>

        {/* Business Info Container */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 relative -mt-16 pb-5">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            
            <div className="flex items-end gap-4">
              {/* Logo */}
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-stone-900 border-2 border-amber-500/50 p-1.5 shadow-2xl overflow-hidden shrink-0 relative z-10">
                <img
                  src={business.logoUrl || 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=200&auto=format&fit=crop&q=80'}
                  alt={business.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover rounded-xl"
                />
              </div>

              {/* Title & Tagline */}
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-white tracking-tight">
                    {business.name}
                  </h1>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold uppercase tracking-wider">
                    Live Menu
                  </span>
                </div>
                {business.tagline && (
                  <p className="text-xs sm:text-sm text-stone-300 line-clamp-1">
                    {business.tagline}
                  </p>
                )}
              </div>
            </div>

            {/* Timings & Address pills */}
            <div className="flex flex-wrap items-center gap-2 text-[11px] text-stone-400">
              {business.openingHours && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-stone-900 border border-stone-800">
                  <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>{business.openingHours}</span>
                </span>
              )}
              {business.address && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-stone-900 border border-stone-800 line-clamp-1 max-w-xs">
                  <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="truncate">{business.address}</span>
                </span>
              )}
            </div>

          </div>
        </div>
      </div>

      {/* 2. Sticky Filter & Category Navigation Bar */}
      <div className="sticky top-0 z-30 bg-stone-950/95 backdrop-blur-md border-b border-stone-800/80 px-4 sm:px-6 py-3 space-y-3">
        <div className="max-w-7xl mx-auto space-y-3">
          
          {/* Top Controls: Search & Diet Filters */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative w-full sm:max-w-md">
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search pizzas, coffee, starters, biryani..."
                className="w-full pl-10 pr-9 py-2 bg-stone-900 border border-stone-800 rounded-xl text-xs sm:text-sm text-stone-100 placeholder-stone-500 focus:outline-hidden focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-200 text-xs px-1"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Dietary Tabs */}
            <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto no-scrollbar">
              <button
                type="button"
                onClick={() => setDietFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer whitespace-nowrap ${
                  dietFilter === 'all'
                    ? 'bg-amber-500 text-stone-950 border-amber-500 shadow-xs'
                    : 'bg-stone-900 border-stone-800 text-stone-300 hover:border-stone-700'
                }`}
              >
                All Items ({items.length})
              </button>

              <button
                type="button"
                onClick={() => setDietFilter('veg')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                  dietFilter === 'veg'
                    ? 'bg-emerald-500 text-stone-950 border-emerald-500 shadow-xs'
                    : 'bg-stone-900 border-stone-800 text-emerald-400 hover:border-emerald-500/40'
                }`}
              >
                <DietBadge type="veg" size="sm" />
                <span>Veg Only</span>
              </button>

              <button
                type="button"
                onClick={() => setDietFilter('non-veg')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                  dietFilter === 'non-veg'
                    ? 'bg-rose-500 text-white border-rose-500 shadow-xs'
                    : 'bg-stone-900 border-stone-800 text-rose-400 hover:border-rose-500/40'
                }`}
              >
                <DietBadge type="non-veg" size="sm" />
                <span>Non-Veg</span>
              </button>

              <button
                type="button"
                onClick={() => setDietFilter('egg')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap ${
                  dietFilter === 'egg'
                    ? 'bg-amber-400 text-stone-950 border-amber-400 shadow-xs'
                    : 'bg-stone-900 border-stone-800 text-amber-300 hover:border-amber-400/40'
                }`}
              >
                <DietBadge type="egg" size="sm" />
                <span>Egg</span>
              </button>
            </div>
          </div>

          {/* Horizontal Category Navigation Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar scroll-smooth">
            <button
              type="button"
              onClick={() => setSelectedCategory('all')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                selectedCategory === 'all'
                  ? 'bg-stone-100 text-stone-950 border-white font-extrabold shadow-sm'
                  : 'bg-stone-900/80 border-stone-800 text-stone-400 hover:text-stone-200 hover:border-stone-700'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Full Menu ({filteredItems.length})</span>
            </button>

            {categories.map((cat) => {
              const count = items.filter((i) => i.categoryId === cat.id && (dietFilter === 'all' || i.isVeg === dietFilter)).length;
              const isSelected = selectedCategory === cat.id;

              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-amber-500 text-stone-950 border-amber-500 font-extrabold shadow-sm'
                      : 'bg-stone-900/80 border-stone-800 text-stone-300 hover:text-white hover:border-stone-700'
                  }`}
                >
                  <span>{cat.name}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                    isSelected ? 'bg-stone-950/30 text-stone-950 font-black' : 'bg-stone-800 text-stone-400'
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

        </div>
      </div>

      {/* 3. Main Menu Content: Visual Cards Grid */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 space-y-8">
        
        {groupedItems.length === 0 ? (
          <div className="text-center py-16 px-4 bg-stone-900/50 border border-stone-800/80 rounded-2xl max-w-md mx-auto space-y-3">
            <Utensils className="w-10 h-10 text-stone-600 mx-auto" />
            <h3 className="text-base font-bold text-stone-200">No dishes matched your criteria</h3>
            <p className="text-xs text-stone-400">
              Try changing your dietary filter or searching for another dish.
            </p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setDietFilter('all');
                setSelectedCategory('all');
              }}
              className="mt-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          groupedItems.map(({ category, items: categoryItems }) => {
            if (!categoryItems || categoryItems.length === 0) return null;
            const categoryName = category?.name || 'Menu Section';

            return (
              <section key={category?.id || 'all-section'} className="space-y-4">
                
                {/* Category Header */}
                <div className="flex items-center justify-between border-b border-stone-800 pb-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-lg sm:text-xl font-black text-white tracking-tight">
                        {categoryName}
                      </h2>
                      <span className="px-2 py-0.5 rounded-full bg-stone-800 text-stone-400 text-[11px] font-mono">
                        {categoryItems.length}
                      </span>
                    </div>
                    {category?.description && (
                      <p className="text-xs text-stone-400 mt-0.5 line-clamp-1">
                        {category.description}
                      </p>
                    )}
                  </div>
                </div>

                {/* Responsive Visual Card Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
                  {categoryItems.map((item) => (
                    <VisualItemCard
                      key={item.id}
                      item={item}
                      categoryName={categoryName}
                      currencySymbol={currencySymbol}
                      cartItems={cartItems}
                      onAddItem={handleAddItem}
                      onUpdateQuantity={handleUpdateQuantity}
                      onOpenCustomize={(it) => setCustomizingItem(it)}
                    />
                  ))}
                </div>

              </section>
            );
          })
        )}

      </main>

      {/* 4. Sticky Cart Summary & WhatsApp Order Drawer */}
      <CartDrawer
        business={business}
        cartItems={cartItems}
        items={items}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        previewMode={previewMode}
        tenantType={tenantType}
        initialLocationNumber={initialLocationNumber}
      />

      {/* 6. Item Customization Modal */}
      {customizingItem && (
        <ItemModifierModal
          item={customizingItem}
          isOpen={true}
          currencySymbol={currencySymbol}
          onClose={() => setCustomizingItem(null)}
          onConfirm={handleConfirmCustomization}
        />
      )}

    </div>
  );
};

// ----------------------------------------------------------------------
// Visual Item Card Component
// ----------------------------------------------------------------------
const VisualItemCard: React.FC<{
  item: MenuItem;
  categoryName: string;
  currencySymbol: string;
  cartItems: CartItem[];
  onAddItem: (item: MenuItem, variant?: MenuItemVariant) => void;
  onUpdateQuantity: (cartItemIdOrItemId: string, delta: number) => void;
  onOpenCustomize: (item: MenuItem) => void;
}> = ({
  item,
  categoryName,
  currencySymbol,
  cartItems,
  onAddItem,
  onUpdateQuantity,
  onOpenCustomize,
}) => {
  const [justAdded, setJustAdded] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  // Variant selector
  const defaultVariant = item.variants?.find((v) => v.isDefault) || item.variants?.[0];
  const [selectedVariant, setSelectedVariant] = useState<MenuItemVariant | undefined>(defaultVariant);

  useEffect(() => {
    if (item.variants && item.variants.length > 0) {
      setSelectedVariant(item.variants.find((v) => v.isDefault) || item.variants[0]);
    } else {
      setSelectedVariant(undefined);
    }
  }, [item.variants]);

  // Map image from item or cloud repository
  const imageUrl = useMemo(() => {
    return getFoodImageUrl(item, categoryName);
  }, [item, categoryName]);

  const activePrice = selectedVariant ? selectedVariant.price : item.price;

  // Calculate quantity of this item / variant in cart
  const lineItemInCart = useMemo(() => {
    if (selectedVariant) {
      return cartItems.find((ci) => ci.itemId === item.id && ci.selectedVariant?.id === selectedVariant.id);
    }
    return cartItems.find((ci) => ci.itemId === item.id && !ci.selectedVariant);
  }, [cartItems, item.id, selectedVariant]);

  const itemQty = lineItemInCart ? lineItemInCart.quantity : 0;

  const handleAdd = () => {
    if (!item.isAvailable) return;
    onAddItem(item, selectedVariant);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 900);
  };

  return (
    <div
      id={`visual-card-${item.id}`}
      className="group bg-stone-900/90 border border-stone-800/90 hover:border-amber-500/50 rounded-2xl overflow-hidden shadow-lg transition-all duration-300 flex flex-col justify-between hover:shadow-2xl"
    >
      <div>
        {/* Responsive Food Photography Container */}
        <div className="relative aspect-16/10 w-full overflow-hidden bg-stone-950">
          <img
            src={imageUrl}
            alt={item.name}
            loading="lazy"
            referrerPolicy="no-referrer"
            onLoad={() => setImageLoaded(true)}
            onError={(e) => {
              // Fallback to general cuisine image if network glitch
              (e.currentTarget as HTMLImageElement).src = 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600&auto=format&fit=crop&q=80';
            }}
            className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 ${
              imageLoaded ? 'opacity-100' : 'opacity-80 blur-xs'
            }`}
          />

          {/* Vignette Shadow Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-black/30 pointer-events-none" />

          {/* Floating Diet Badge & Tags */}
          <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
            <span className="p-1 rounded-md bg-stone-950/80 backdrop-blur-md shadow-xs border border-stone-700/60">
              <DietBadge type={item.isVeg} size="sm" />
            </span>

            {item.tags && item.tags.length > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-amber-500/90 text-stone-950 font-black text-[9px] uppercase tracking-wider backdrop-blur-md shadow-sm">
                {item.tags[0]}
              </span>
            )}
          </div>

          {/* Floating Price Pill on Image */}
          <div className="absolute bottom-2.5 right-2.5">
            <span className="px-2.5 py-1 rounded-xl bg-stone-950/90 backdrop-blur-md border border-amber-500/40 text-amber-400 font-mono font-black text-xs sm:text-sm shadow-md">
              {currencySymbol}{activePrice}
            </span>
          </div>
        </div>

        {/* Card Body */}
        <div className="p-3.5 sm:p-4 space-y-2">
          {/* Category Tag */}
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider">
              {categoryName}
            </span>
            {!item.isAvailable && (
              <span className="text-[10px] text-rose-400 font-bold bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/30">
                Out of Stock
              </span>
            )}
          </div>

          {/* Title */}
          <h3 className="font-bold text-sm sm:text-base text-stone-100 group-hover:text-amber-400 transition-colors leading-snug line-clamp-1">
            {item.name}
          </h3>

          {/* Description */}
          {item.description && (
            <p className="text-xs text-stone-400 line-clamp-2 leading-relaxed">
              {item.description}
            </p>
          )}

          {/* Size / Variant Selector (if item has variants) */}
          {item.variants && item.variants.length > 0 && (
            <div className="pt-1">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] text-stone-400 font-semibold">Select Size:</span>
                <span className="text-[10px] font-bold text-amber-400 font-mono">
                  {selectedVariant?.name}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                {item.variants.map((v) => {
                  const isSelected = selectedVariant?.id === v.id;
                  return (
                    <button
                      key={v.id}
                      type="button"
                      onClick={() => setSelectedVariant(v)}
                      className={`px-1.5 py-1 rounded-lg text-[10px] font-mono font-bold border transition-all cursor-pointer flex flex-col items-center justify-center ${
                        isSelected
                          ? 'bg-amber-500 text-stone-950 border-amber-500 font-black'
                          : 'bg-stone-950/60 border-stone-800 text-stone-300 hover:border-stone-700'
                      }`}
                    >
                      <span className="truncate w-full text-center">{v.name}</span>
                      <span className={isSelected ? 'text-stone-950' : 'text-amber-400'}>
                        {currencySymbol}{v.price}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Card Action Footer */}
      <div className="p-3.5 sm:p-4 pt-0">
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-stone-800/80">
          
          {/* Customizer trigger */}
          <button
            type="button"
            onClick={() => onOpenCustomize(item)}
            className="text-[11px] text-stone-400 hover:text-amber-400 flex items-center gap-1 font-semibold transition-colors cursor-pointer py-1 px-1.5 rounded-lg hover:bg-stone-800"
          >
            <SlidersHorizontal className="w-3 h-3" />
            <span>Customize</span>
          </button>

          {/* Add / Stepper Button */}
          {itemQty > 0 ? (
            <div className="flex items-center bg-amber-500 text-stone-950 rounded-xl font-bold overflow-hidden shadow-sm">
              <button
                type="button"
                onClick={() => lineItemInCart && onUpdateQuantity(lineItemInCart.cartItemId, -1)}
                className="px-2.5 py-1.5 hover:bg-amber-600 active:scale-95 transition-all cursor-pointer"
                title="Decrease"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="px-2 font-mono text-xs font-black min-w-[20px] text-center">
                {itemQty}
              </span>
              <button
                type="button"
                onClick={() => lineItemInCart && onUpdateQuantity(lineItemInCart.cartItemId, 1)}
                className="px-2.5 py-1.5 hover:bg-amber-600 active:scale-95 transition-all cursor-pointer"
                title="Increase"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              disabled={!item.isAvailable}
              onClick={handleAdd}
              className={`flex items-center gap-1 px-3.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer shadow-sm active:scale-95 ${
                justAdded
                  ? 'bg-emerald-500 text-white'
                  : 'bg-amber-500 hover:bg-amber-400 text-stone-950'
              } disabled:opacity-40 disabled:cursor-not-allowed`}
            >
              {justAdded ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Added</span>
                </>
              ) : (
                <>
                  <Plus className="w-3.5 h-3.5" />
                  <span>ADD</span>
                </>
              )}
            </button>
          )}

        </div>
      </div>
    </div>
  );
};
