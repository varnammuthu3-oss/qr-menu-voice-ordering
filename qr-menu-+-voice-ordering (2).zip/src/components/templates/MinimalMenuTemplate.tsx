import React, { useState, useMemo, useEffect } from 'react';
import { Business, MenuCategory, MenuItem, MenuItemVariant, FoodDietType, CartItem } from '../../types';
import { DietBadge } from '../DietBadge';
import { sanitizeWhatsappNumber, createWhatsappOrderUrl, createWhatsappDirectUrl } from '../../utils/phone';
import { CartDrawer } from '../CartDrawer';
import { 
  MessageCircle, 
  MessageSquare, 
  MapPin, 
  Search, 
  Clock,
  Utensils,
  Hotel,
  Plus,
  Minus,
  Check,
  Package
} from 'lucide-react';

interface MinimalMenuTemplateProps {
  business: Business;
  categories: MenuCategory[];
  items: MenuItem[];
  previewMode?: boolean;
  onOpenOwnerDashboard?: () => void;
  tenantType?: 'restaurant' | 'guesthouse';
  initialLocationNumber?: string;
}

export const MinimalMenuTemplate: React.FC<MinimalMenuTemplateProps> = ({
  business,
  categories,
  items,
  previewMode = false,
  onOpenOwnerDashboard,
  tenantType = 'restaurant',
  initialLocationNumber,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [dietFilter, setDietFilter] = useState<'all' | FoodDietType>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleAddItem = (item: MenuItem, variant?: MenuItemVariant) => {
    const selectedVariant = variant || (item.variants && item.variants.length > 0 ? (item.variants.find(v => v.isDefault) || item.variants[0]) : undefined);
    const effectivePrice = selectedVariant ? selectedVariant.price : item.price;
    const variantId = selectedVariant?.id;
    const cartItemKey = variantId ? `cart_${item.id}_${variantId}` : `cart_${item.id}`;

    setCartItems((prev) => {
      const existingIndex = prev.findIndex((ci) => 
        variantId 
          ? ci.itemId === item.id && ci.selectedVariant?.id === variantId
          : ci.itemId === item.id && !ci.selectedVariant
      );

      if (existingIndex >= 0) {
        const next = [...prev];
        const exist = next[existingIndex];
        const newQty = exist.quantity + 1;
        next[existingIndex] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: (exist.unitPrice || exist.price) * newQty,
        };
        return next;
      } else {
        const displayName = selectedVariant ? `${item.name} (${selectedVariant.name})` : item.name;
        const newItem: CartItem = {
          cartItemId: `${cartItemKey}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          itemId: item.id,
          name: displayName,
          price: effectivePrice,
          unitPrice: effectivePrice,
          quantity: 1,
          item: item,
          selectedVariant: selectedVariant,
          selectedOptions: [],
          customNote: '',
          totalItemPrice: effectivePrice,
        };
        return [...prev, newItem];
      }
    });
  };

  const handleUpdateQuantity = (cartItemIdOrItemId: string, delta: number) => {
    setCartItems((prev) => {
      const byCartId = prev.findIndex((ci) => ci.cartItemId === cartItemIdOrItemId);
      if (byCartId >= 0) {
        const exist = prev[byCartId];
        const newQty = exist.quantity + delta;
        if (newQty <= 0) {
          return prev.filter((_, idx) => idx !== byCartId);
        }
        const next = [...prev];
        next[byCartId] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: exist.unitPrice * newQty,
        };
        return next;
      }

      const byItemId = prev.findIndex((ci) => ci.itemId === cartItemIdOrItemId);
      if (byItemId >= 0) {
        const exist = prev[byItemId];
        const newQty = exist.quantity + delta;
        if (newQty <= 0) {
          return prev.filter((_, idx) => idx !== byItemId);
        }
        const next = [...prev];
        next[byItemId] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: exist.unitPrice * newQty,
        };
        return next;
      }

      return prev;
    });
  };

  const handleRemoveItem = (cartItemIdOrItemId: string) => {
    setCartItems((prev) => prev.filter((ci) => ci.cartItemId !== cartItemIdOrItemId && ci.itemId !== cartItemIdOrItemId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const activeCategories = useMemo(() => {
    return [...categories]
      .filter((c) => c.isActive)
      .sort((a, b) => a.displayOrder - b.displayOrder);
  }, [categories]);

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      if (selectedCategory !== 'all' && item.categoryId !== selectedCategory) {
        return false;
      }
      if (dietFilter !== 'all' && item.isVeg !== dietFilter) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesDesc = (item.description || '').toLowerCase().includes(q);
        if (!matchesName && !matchesDesc) {
          return false;
        }
      }
      return true;
    });
  }, [items, selectedCategory, dietFilter, searchQuery]);

  const itemsByCategory = useMemo(() => {
    const map = new Map<string, MenuItem[]>();
    for (const cat of activeCategories) {
      map.set(cat.id, []);
    }
    for (const item of filteredItems) {
      const list = map.get(item.categoryId);
      if (list) {
        list.push(item);
      } else {
        if (!map.has('other')) map.set('other', []);
        map.get('other')?.push(item);
      }
    }
    return map;
  }, [activeCategories, filteredItems]);

  const getItemCartQuantity = (itemId: string) => {
    return cartItems
      .filter((ci) => ci.itemId === itemId)
      .reduce((sum, ci) => sum + ci.quantity, 0);
  };

  return (
    <div className="min-h-screen bg-white text-stone-900 pb-28 font-mono">
      <div className="max-w-xl mx-auto min-h-screen px-4 sm:px-6">
        
        {/* Minimalist Header */}
        <div className="py-8 border-b border-stone-900 space-y-2">
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-1">
              <h1 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-stone-950">
                {business.name || 'MENU'}
              </h1>
              {business.tagline && (
                <p className="text-xs text-stone-500 font-normal">
                  {business.tagline}
                </p>
              )}
              {business.address && (
                <p className="text-[11px] text-stone-400">
                  {business.address}
                </p>
              )}
            </div>

            {(business.whatsappNumber || business.phone) && (
              <a
                href={createWhatsappDirectUrl(business.whatsappNumber || business.phone, business.name)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-stone-950 hover:bg-stone-950 hover:text-white text-stone-950 text-[11px] font-bold uppercase transition-colors shrink-0 cursor-pointer"
              >
                <MessageCircle className="w-3 h-3" />
                <span>WhatsApp Us</span>
              </a>
            )}
          </div>

          {/* Parcel Takeaway Badge */}
          <div className="mt-3 p-3 bg-stone-100 border border-stone-900 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <Package className="w-4 h-4 text-stone-900" />
              <span className="font-black uppercase tracking-wider text-stone-950">
                PARCEL TAKEAWAY
              </span>
              <span className="text-[10px] text-stone-600 font-mono">
                [COUNTER PICKUP]
              </span>
            </div>
            <span className="text-[10px] bg-stone-900 text-white px-2 py-0.5 font-bold uppercase">
              Direct Counter Order
            </span>
          </div>
        </div>

        {/* Filter / Search */}
        <div className="py-4 border-b border-stone-200 space-y-3">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="TYPE TO FILTER ITEMS..."
            className="w-full text-xs uppercase bg-stone-50 text-stone-900 placeholder:text-stone-400 p-2 border border-stone-300 focus:border-stone-900 outline-none rounded-none"
          />

          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar text-xs">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-2 py-1 uppercase text-[11px] font-bold cursor-pointer transition-colors ${
                selectedCategory === 'all'
                  ? 'bg-stone-950 text-white'
                  : 'text-stone-600 hover:text-stone-950'
              }`}
            >
              [ ALL ]
            </button>
            {activeCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-2 py-1 uppercase text-[11px] font-bold cursor-pointer transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-stone-950 text-white'
                    : 'text-stone-600 hover:text-stone-950'
                }`}
              >
                [ {cat.name} ]
              </button>
            ))}
          </div>
        </div>

        {/* Minimal Item List */}
        <div className="py-6 space-y-8">
          {filteredItems.length === 0 ? (
            <div className="py-12 text-center text-xs text-stone-400 uppercase">
              NO ITEMS FOUND
            </div>
          ) : selectedCategory === 'all' ? (
            activeCategories.map((cat) => {
              const catItems = itemsByCategory.get(cat.id) || [];
              if (catItems.length === 0) return null;

              return (
                <div key={cat.id} className="space-y-3">
                  <div className="border-b border-stone-900 pb-1">
                    <h2 className="text-xs font-black uppercase tracking-widest text-stone-950">
                      // {cat.name}
                    </h2>
                  </div>

                  <div className="space-y-2.5 divide-y divide-stone-100">
                    {catItems.map((item) => (
                      <MinimalItemRow
                        key={item.id}
                        item={item}
                        currencySymbol={business.currencySymbol || '₹'}
                        quantity={getItemCartQuantity(item.id)}
                        onAddItem={handleAddItem}
                        onUpdateQuantity={handleUpdateQuantity}
                      />
                    ))}
                  </div>
                </div>
              );
            })
          ) : (
            <div className="space-y-2.5 divide-y divide-stone-100">
              {filteredItems.map((item) => (
                <MinimalItemRow
                  key={item.id}
                  item={item}
                  currencySymbol={business.currencySymbol || '₹'}
                  quantity={getItemCartQuantity(item.id)}
                  onAddItem={handleAddItem}
                  onUpdateQuantity={handleUpdateQuantity}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Sticky Cart Summary & WhatsApp Order Drawer */}
      <CartDrawer
        business={business}
        cartItems={cartItems}
        items={items}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        previewMode={previewMode}
        tenantType={tenantType}
        initialLocationNumber={initialLocationNumber}
      />
    </div>
  );
};

const MinimalItemRow: React.FC<{ 
  item: MenuItem; 
  currencySymbol: string; 
  quantity: number;
  onAddItem: (item: MenuItem, variant?: MenuItemVariant) => void;
  onUpdateQuantity: (itemId: string, delta: number) => void;
}> = ({ item, currencySymbol, quantity, onAddItem, onUpdateQuantity }) => {
  const [justAdded, setJustAdded] = useState(false);

  const defaultVariant = item.variants?.find((v) => v.isDefault) || item.variants?.[0];
  const [selectedVariant, setSelectedVariant] = useState<MenuItemVariant | undefined>(defaultVariant);

  useEffect(() => {
    if (item.variants && item.variants.length > 0) {
      setSelectedVariant(item.variants.find((v) => v.isDefault) || item.variants[0]);
    } else {
      setSelectedVariant(undefined);
    }
  }, [item.variants]);

  const activePrice = selectedVariant ? selectedVariant.price : item.price;

  const handleAdd = () => {
    if (!item.isAvailable) return;
    onAddItem(item, selectedVariant);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1000);
  };

  return (
    <div className={`py-2.5 ${!item.isAvailable ? 'opacity-40' : ''}`}>
      <div className="flex items-baseline justify-between gap-3">
        <div className="flex-1 min-w-0 pr-2">
          <div className="flex items-center gap-1.5 flex-wrap">
            <DietBadge type={item.isVeg} size="sm" showLabel={false} />
            <span className="font-bold text-xs sm:text-sm text-stone-900">
              {item.name}
            </span>
            {!item.isAvailable && (
              <span className="text-[9px] font-mono uppercase bg-stone-200 text-stone-700 px-1 rounded">
                Out
              </span>
            )}
          </div>

          {/* Minimal Size Selector */}
          {item.variants && item.variants.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5 mb-1">
              {item.variants.map((v) => {
                const isSelected = selectedVariant?.id === v.id;
                return (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => setSelectedVariant(v)}
                    className={`px-1.5 py-0.5 text-[10px] font-mono border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-stone-900 text-white border-stone-900 font-bold'
                        : 'bg-white text-stone-700 border-stone-300 hover:border-stone-500'
                    }`}
                  >
                    {v.name} ({currencySymbol}{v.price})
                  </button>
                );
              })}
            </div>
          )}

          {item.description && (
            <p className="text-[11px] text-stone-500 leading-tight mt-0.5 line-clamp-1">
              {item.description}
            </p>
          )}
        </div>

        {/* Price & Single Clean ADD Button */}
        <div className="shrink-0 flex items-center gap-2">
          <span className="font-mono font-bold text-xs sm:text-sm text-stone-950 text-right">
            {currencySymbol}{activePrice}
          </span>

          {item.isAvailable && (
            <button
              type="button"
              onClick={handleAdd}
              className="shrink-0 px-2.5 py-1 bg-stone-950 hover:bg-stone-800 active:scale-95 text-white font-mono font-bold text-[11px] transition-colors cursor-pointer flex items-center gap-1"
            >
              {justAdded ? (
                <>
                  <Check className="w-2.5 h-2.5 text-white" />
                  <span>ADDED</span>
                </>
              ) : (
                <>
                  <Plus className="w-2.5 h-2.5" />
                  <span>ADD</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {quantity > 0 && (
        <div className="pt-1 text-[11px] text-emerald-700 font-bold">
          [{quantity} in cart]
        </div>
      )}
    </div>
  );
};
