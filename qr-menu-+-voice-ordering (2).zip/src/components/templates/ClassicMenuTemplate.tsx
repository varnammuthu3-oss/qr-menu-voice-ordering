import React, { useState, useMemo, useEffect } from 'react';
import { Business, MenuCategory, MenuItem, MenuItemVariant, FoodDietType, CartItem } from '../../types';
import { DietBadge } from '../DietBadge';
import { sanitizeWhatsappNumber, createWhatsappOrderUrl, createWhatsappDirectUrl } from '../../utils/phone';
import { CartDrawer } from '../CartDrawer';
import { 
  MessageCircle, 
  MessageSquare, 
  Clock, 
  MapPin, 
  Search, 
  Sparkles, 
  ChevronRight, 
  UtensilsCrossed,
  Utensils,
  Hotel,
  Info,
  Plus,
  Minus,
  Check,
  Package
} from 'lucide-react';

interface ClassicMenuTemplateProps {
  business: Business;
  categories: MenuCategory[];
  items: MenuItem[];
  previewMode?: boolean;
  onOpenOwnerDashboard?: () => void;
  tenantType?: 'restaurant' | 'guesthouse';
  initialLocationNumber?: string;
}

export const ClassicMenuTemplate: React.FC<ClassicMenuTemplateProps> = ({
  business,
  categories,
  items,
  previewMode = false,
  onOpenOwnerDashboard,
  tenantType = 'restaurant',
  initialLocationNumber,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [dietFilter, setDietFilter] = useState<'all' | FoodDietType>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleAddItem = (item: MenuItem, variant?: MenuItemVariant) => {
    const selectedVariant = variant || (item.variants && item.variants.length > 0 ? (item.variants.find(v => v.isDefault) || item.variants[0]) : undefined);
    const effectivePrice = selectedVariant ? selectedVariant.price : item.price;
    const variantId = selectedVariant?.id;
    const cartItemKey = variantId ? `cart_${item.id}_${variantId}` : `cart_${item.id}`;

    setCartItems((prev) => {
      const existingIndex = prev.findIndex((ci) => 
        variantId 
          ? ci.itemId === item.id && ci.selectedVariant?.id === variantId
          : ci.itemId === item.id && !ci.selectedVariant
      );

      if (existingIndex >= 0) {
        const next = [...prev];
        const exist = next[existingIndex];
        const newQty = exist.quantity + 1;
        next[existingIndex] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: (exist.unitPrice || exist.price) * newQty,
        };
        return next;
      } else {
        const displayName = selectedVariant ? `${item.name} (${selectedVariant.name})` : item.name;
        const newItem: CartItem = {
          cartItemId: `${cartItemKey}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          itemId: item.id,
          name: displayName,
          price: effectivePrice,
          unitPrice: effectivePrice,
          quantity: 1,
          item: item,
          selectedVariant: selectedVariant,
          selectedOptions: [],
          customNote: '',
          totalItemPrice: effectivePrice,
        };
        return [...prev, newItem];
      }
    });
  };

  const handleUpdateQuantity = (cartItemIdOrItemId: string, delta: number) => {
    setCartItems((prev) => {
      const byCartId = prev.findIndex((ci) => ci.cartItemId === cartItemIdOrItemId);
      if (byCartId >= 0) {
        const exist = prev[byCartId];
        const newQty = exist.quantity + delta;
        if (newQty <= 0) {
          return prev.filter((_, idx) => idx !== byCartId);
        }
        const next = [...prev];
        next[byCartId] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: exist.unitPrice * newQty,
        };
        return next;
      }

      const byItemId = prev.findIndex((ci) => ci.itemId === cartItemIdOrItemId);
      if (byItemId >= 0) {
        const exist = prev[byItemId];
        const newQty = exist.quantity + delta;
        if (newQty <= 0) {
          return prev.filter((_, idx) => idx !== byItemId);
        }
        const next = [...prev];
        next[byItemId] = {
          ...exist,
          quantity: newQty,
          totalItemPrice: exist.unitPrice * newQty,
        };
        return next;
      }

      return prev;
    });
  };

  const handleRemoveItem = (cartItemIdOrItemId: string) => {
    setCartItems((prev) => prev.filter((ci) => ci.cartItemId !== cartItemIdOrItemId && ci.itemId !== cartItemIdOrItemId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const activeCategories = useMemo(() => {
    return [...categories]
      .filter((c) => c.isActive)
      .sort((a, b) => a.displayOrder - b.displayOrder);
  }, [categories]);

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      if (selectedCategory !== 'all' && item.categoryId !== selectedCategory) {
        return false;
      }
      if (dietFilter !== 'all' && item.isVeg !== dietFilter) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesDesc = (item.description || '').toLowerCase().includes(q);
        const matchesTags = (item.tags || []).some((t) => t.toLowerCase().includes(q));
        if (!matchesName && !matchesDesc && !matchesTags) {
          return false;
        }
      }
      return true;
    });
  }, [items, selectedCategory, dietFilter, searchQuery]);

  const itemsByCategory = useMemo(() => {
    const map = new Map<string, MenuItem[]>();
    for (const cat of activeCategories) {
      map.set(cat.id, []);
    }
    for (const item of filteredItems) {
      const list = map.get(item.categoryId);
      if (list) {
        list.push(item);
      } else {
        if (!map.has('other')) map.set('other', []);
        map.get('other')?.push(item);
      }
    }
    return map;
  }, [activeCategories, filteredItems]);

  const getItemCartQuantity = (itemId: string) => {
    return cartItems
      .filter((ci) => ci.itemId === itemId)
      .reduce((sum, ci) => sum + ci.quantity, 0);
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-[#2C1E14] pb-28 font-serif">
      <div className="max-w-xl mx-auto bg-[#FFFDF9] min-h-screen shadow-lg border-x border-[#EBE3D5]">
        
        {/* Classic Heritage Header */}
        <div className="p-6 sm:p-8 text-center border-b-2 border-[#D9C4AC] bg-[#FAF5EC] relative">
          <div className="max-w-md mx-auto space-y-2">
            <div className="inline-block border-y border-[#B39373] py-1 px-4 mb-1">
              <span className="text-[11px] font-sans font-bold tracking-widest text-[#8C6B43] uppercase">
                Est. Gastronomy • Dine & WhatsApp
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-[#2C1E14]">
              {business.name || 'Traditional Kitchen'}
            </h1>

            {business.tagline && (
              <p className="text-xs sm:text-sm text-[#6E4B2F] italic">
                &ldquo;{business.tagline}&rdquo;
              </p>
            )}

            <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
              {business.address && (
                <div className="flex items-center justify-center gap-1.5 text-xs text-[#8C6B43] font-sans">
                  <MapPin className="w-3.5 h-3.5 shrink-0" />
                  <span>{business.address}</span>
                </div>
              )}
              {(business.whatsappNumber || business.phone) && (
                <a
                  href={createWhatsappDirectUrl(business.whatsappNumber || business.phone, business.name)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-sans font-semibold transition-all cursor-pointer shadow-xs"
                >
                  <MessageCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>WhatsApp Us</span>
                </a>
              )}
            </div>

            {/* Parcel Takeaway Badge */}
            <div className="mt-3 p-3 rounded-xl bg-[#E8DFD1] border border-[#CBB8A2] flex items-center justify-between gap-3 text-[#3B291A] font-sans text-left shadow-xs">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#3B291A] text-white flex items-center justify-center font-bold shrink-0">
                  <Package className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black uppercase tracking-wider text-[#2C1E14]">
                      Counter Parcel Pickup
                    </span>
                    <span className="text-[10px] px-2 py-0.2 rounded-full bg-[#D4C3AF] text-[#3B291A] font-bold">
                      Takeaway Order
                    </span>
                  </div>
                  <p className="text-[11px] text-[#6E4B2F]">
                    Freshly prepared parcel packaged for counter takeaway
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-[#D4C3AF] text-[#3B291A] shrink-0 hidden sm:inline">
                Parcel Mode
              </span>
            </div>
          </div>
        </div>

        {/* Filter / Search Bar */}
        <div className="p-4 bg-[#F5EFE6] border-b border-[#D9C4AC] space-y-3 font-sans">
          <div className="relative">
            <Search className="w-4 h-4 text-[#8C6B43] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search recipes..."
              className="w-full pl-9 pr-4 py-2 bg-white text-[#2C1E14] placeholder-[#A89178] text-xs rounded border border-[#D9C4AC] focus:border-[#8C6B43] outline-none"
            />
          </div>

          {/* Categories Bar */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1 rounded transition-colors font-medium cursor-pointer shrink-0 ${
                selectedCategory === 'all'
                  ? 'bg-[#6E4B2F] text-[#FFFDF9]'
                  : 'bg-white/80 text-[#6E4B2F] border border-[#D9C4AC] hover:bg-white'
              }`}
            >
              All Items
            </button>
            {activeCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1 rounded transition-colors font-medium cursor-pointer shrink-0 ${
                  selectedCategory === cat.id
                    ? 'bg-[#6E4B2F] text-[#FFFDF9]'
                    : 'bg-white/80 text-[#6E4B2F] border border-[#D9C4AC] hover:bg-white'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Classic Menu Content */}
        <div className="p-5 sm:p-7 space-y-8">
          {filteredItems.length === 0 ? (
            <div className="py-12 text-center text-[#8C6B43] font-serif italic">
              No dishes found matching your selection.
            </div>
          ) : selectedCategory === 'all' ? (
            activeCategories.map((cat) => {
              const catItems = itemsByCategory.get(cat.id) || [];
              if (catItems.length === 0) return null;

              return (
                <div key={cat.id} className="space-y-4">
                  <div className="text-center">
                    <h2 className="text-lg font-bold tracking-wider uppercase text-[#2C1E14] inline-block px-4 border-b border-[#C9B49C] pb-1">
                      {cat.name}
                    </h2>
                  </div>

                  <div className="space-y-3.5 divide-y divide-[#F0E6D8]">
                    {catItems.map((item) => (
                      <ClassicItemRow
                        key={item.id}
                        item={item}
                        currencySymbol={business.currencySymbol || '₹'}
                        quantity={getItemCartQuantity(item.id)}
                        onAddItem={handleAddItem}
                        onUpdateQuantity={handleUpdateQuantity}
                      />
                    ))}
                  </div>
                </div>
              );
            })
          ) : (
            <div className="space-y-3.5 divide-y divide-[#F0E6D8]">
              {filteredItems.map((item) => (
                <ClassicItemRow
                  key={item.id}
                  item={item}
                  currencySymbol={business.currencySymbol || '₹'}
                  quantity={getItemCartQuantity(item.id)}
                  onAddItem={handleAddItem}
                  onUpdateQuantity={handleUpdateQuantity}
                />
              ))}
            </div>
          )}
        </div>

        {/* Classic Footer */}
        <div className="p-6 text-center border-t border-[#D9C4AC] bg-[#FAF5EC] text-xs text-[#8C6B43] space-y-1">
          <p className="font-bold text-[#6E4B2F]">{business.name}</p>
          <p className="italic">Bon Appétit</p>
        </div>
      </div>

      {/* Sticky Cart Summary & WhatsApp Order Drawer */}
      <CartDrawer
        business={business}
        cartItems={cartItems}
        items={items}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        previewMode={previewMode}
        tenantType={tenantType}
        initialLocationNumber={initialLocationNumber}
      />
    </div>
  );
};

const ClassicItemRow: React.FC<{ 
  item: MenuItem; 
  currencySymbol: string; 
  quantity: number;
  onAddItem: (item: MenuItem, variant?: MenuItemVariant) => void;
  onUpdateQuantity: (itemId: string, delta: number) => void;
}> = ({ item, currencySymbol, quantity, onAddItem, onUpdateQuantity }) => {
  const [justAdded, setJustAdded] = useState(false);

  const defaultVariant = item.variants?.find((v) => v.isDefault) || item.variants?.[0];
  const [selectedVariant, setSelectedVariant] = useState<MenuItemVariant | undefined>(defaultVariant);

  useEffect(() => {
    if (item.variants && item.variants.length > 0) {
      setSelectedVariant(item.variants.find((v) => v.isDefault) || item.variants[0]);
    } else {
      setSelectedVariant(undefined);
    }
  }, [item.variants]);

  const activePrice = selectedVariant ? selectedVariant.price : item.price;

  const handleAdd = () => {
    if (!item.isAvailable) return;
    onAddItem(item, selectedVariant);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1000);
  };

  return (
    <div className={`pt-3 pb-2.5 ${!item.isAvailable ? 'opacity-50' : ''}`}>
      <div className="flex items-baseline justify-between gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="shrink-0">
            <DietBadge type={item.isVeg} size="sm" showLabel={false} />
          </span>
          <span className="font-serif font-bold text-sm text-[#2C1E14] leading-snug tracking-tight">
            {item.name}
          </span>
        </div>

        {/* Dot Leader Line */}
        <div className="grow border-b border-dotted border-[#C9B49C] mx-1.5 shrink min-w-[20px]" />

        {/* Price & ADD Button */}
        <div className="shrink-0 flex items-center gap-2">
          <span className="font-sans font-bold text-sm text-[#3D2B1F]">
            {currencySymbol}{activePrice}
          </span>

          {item.isAvailable && (
            <button
              type="button"
              onClick={handleAdd}
              className="px-3 py-1 rounded bg-[#6E4B2F] hover:bg-[#583921] active:scale-95 text-[#FFFDF9] font-sans font-bold text-xs transition-colors shadow-2xs cursor-pointer flex items-center gap-1"
            >
              {justAdded ? (
                <>
                  <Check className="w-3 h-3 text-[#FFFDF9]" />
                  <span>ADDED</span>
                </>
              ) : (
                <>
                  <Plus className="w-3 h-3 text-[#FFFDF9]" />
                  <span>ADD</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Variants/Sizes for Classic */}
      {item.variants && item.variants.length > 0 && (
        <div className="pl-5 pt-1.5 flex flex-wrap items-center gap-1.5">
          <span className="text-[10px] font-serif uppercase tracking-wider text-[#8C6B43]">Size:</span>
          {item.variants.map((v) => {
            const isSelected = selectedVariant?.id === v.id;
            return (
              <button
                key={v.id}
                type="button"
                onClick={() => setSelectedVariant(v)}
                className={`px-2 py-0.5 text-[11px] rounded border transition-all cursor-pointer font-sans ${
                  isSelected
                    ? 'bg-[#6E4B2F] text-white border-[#6E4B2F] font-bold shadow-2xs'
                    : 'bg-[#FDFBF7] text-[#6E4B2F] border-[#D9C4AC] hover:border-[#6E4B2F]'
                }`}
              >
                {v.name} ({currencySymbol}{v.price})
              </button>
            );
          })}
        </div>
      )}

      {item.description && (
        <p className="text-[11px] text-[#7A5C3E] italic pl-5 mt-1 line-clamp-2 font-serif">
          {item.description}
        </p>
      )}

      {quantity > 0 && (
        <div className="pl-5 pt-1 text-[11px] text-[#8C6B43] font-sans font-bold">
          ✓ {quantity} in cart
        </div>
      )}
    </div>
  );
};
