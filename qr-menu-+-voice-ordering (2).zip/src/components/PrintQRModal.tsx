import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Business } from '../types';
import { 
  X, 
  Printer, 
  Copy, 
  Check, 
  ExternalLink, 
  QrCode, 
  Sparkles, 
  Smartphone,
  MessageCircle,
  Store
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { createWhatsappDirectUrl } from '../utils/phone';
import { generateQrUrl } from '../utils/tenant';

interface PrintQRModalProps {
  isOpen: boolean;
  onClose: () => void;
  business: Business;
  onOpenCustomerView?: (businessId: string) => void;
}

export const PrintQRModal: React.FC<PrintQRModalProps> = ({
  isOpen,
  onClose,
  business,
  onOpenCustomerView,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  const permanentUrl = `${currentOrigin}/?shop=${encodeURIComponent(business.id)}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(permanentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/70 backdrop-blur-xs z-40 cursor-pointer"
        />

        {/* Modal Dialog */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative z-50 bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden text-stone-100 my-auto"
        >
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-stone-800 flex items-center justify-between bg-stone-900/90">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 text-amber-400 flex items-center justify-center font-bold">
                <QrCode className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                  <span>Print QR Code</span>
                  <span className="text-xs font-mono font-medium px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {business.name}
                  </span>
                </h3>
                <p className="text-xs text-stone-400">
                  Permanent QR code for tabletop stands, counter displays & flyers
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <div className="p-5 sm:p-6 space-y-6 max-h-[80vh] overflow-y-auto">
            {/* Guarantee Note */}
            <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-xs text-amber-200 flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong>Permanent QR Guarantee:</strong> Changing menu prices, adding dishes, or updating timings will never break this QR code. Once printed, it works forever.
              </div>
            </div>

            {/* Single Counter QR Standee Info */}
            <div className="p-3.5 bg-stone-950 rounded-2xl border border-stone-800 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black shrink-0">
                  <Store className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-white">
                    Counter QR Standee (Parcel & Takeaway)
                  </div>
                  <div className="text-[11px] text-stone-400">
                    Single counter QR code for customer scanning. Opens food menu directly with no logins or table prompts.
                  </div>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shrink-0">
                Frictionless
              </span>
            </div>

            {/* Printable Preview Card */}
            <div className="bg-gradient-to-b from-stone-950 to-stone-900 border-2 border-stone-800 p-6 sm:p-8 rounded-2xl text-center flex flex-col items-center shadow-lg">
              {business.logoUrl ? (
                <img
                  src={business.logoUrl}
                  alt={business.name}
                  referrerPolicy="no-referrer"
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-400/80 shadow-md mb-2.5"
                />
              ) : (
                <div className="w-14 h-14 rounded-2xl bg-amber-500 text-stone-950 font-black text-2xl flex items-center justify-center mb-2.5 shadow-md">
                  {business.name.charAt(0)}
                </div>
              )}

              <h2 className="text-xl sm:text-2xl font-black text-amber-400 tracking-tight">
                {business.name}
              </h2>
              <p className="text-xs sm:text-sm text-stone-300 mt-1 max-w-sm">
                {business.tagline || 'Scan to view our complete digital menu on your phone'}
              </p>

              {/* QR Center in Stand */}
              <div className="my-5 bg-white p-4 rounded-2xl shadow-xl inline-block border-4 border-amber-400">
                <QRCodeSVG
                  value={permanentUrl}
                  size={170}
                  level="H"
                  includeMargin={false}
                />
              </div>

              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-400 text-stone-950 font-black text-xs shadow-xs">
                <Smartphone className="w-3.5 h-3.5" />
                <span>Scan Camera • Instant Menu • Voice Ordering</span>
              </div>

              <div className="mt-4 pt-3 border-t border-stone-800/80 w-full flex flex-wrap items-center justify-center gap-3 text-[11px] text-stone-400">
                {(business.whatsappNumber || business.phone) && (
                  <a
                    href={createWhatsappDirectUrl(business.whatsappNumber || business.phone, business.name)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp Us</span>
                  </a>
                )}
                {business.address && (
                  <span className="truncate max-w-xs">{business.address}</span>
                )}
              </div>
            </div>

            {/* URL Copy Bar */}
            <div className="p-3 bg-stone-950 rounded-2xl border border-stone-800 space-y-1.5">
              <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider block">
                Permanent Customer URL
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={permanentUrl}
                  className="w-full bg-transparent text-xs font-mono text-stone-300 focus:outline-hidden select-all"
                />
                <button
                  type="button"
                  onClick={handleCopy}
                  className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white rounded-xl text-xs font-bold transition-colors shrink-0 flex items-center gap-1.5 cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-stone-400" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Footer Controls */}
          <div className="p-4 sm:p-5 bg-stone-950 border-t border-stone-800 flex flex-wrap items-center justify-between gap-3">
            {onOpenCustomerView && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenCustomerView(business.id);
                }}
                className="px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-2 cursor-pointer"
              >
                <ExternalLink className="w-4 h-4 text-amber-400" />
                <span>Test Live Menu</span>
              </button>
            )}

            <div className="flex items-center gap-2 ml-auto">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white rounded-xl text-xs font-medium transition-colors cursor-pointer"
              >
                Close
              </button>

              <button
                type="button"
                onClick={handlePrint}
                className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-xl text-xs font-black transition-colors flex items-center gap-2 shadow-md cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print QR Card</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
