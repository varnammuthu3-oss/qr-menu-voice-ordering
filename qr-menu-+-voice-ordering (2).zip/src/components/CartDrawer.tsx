import React, { useState } from 'react';
import { Business, CartItem, MenuItem } from '../types';
import { createWhatsappCartOrderUrl, generateKotMessage } from '../utils/phone';
import { supabase } from '../lib/supabase';
import { insertRestaurantOrder } from '../lib/orderService';
import { DietBadge } from './DietBadge';
import { OrderNotesInput } from './OrderNotesInput';
import { 
  ShoppingBag, 
  X, 
  Plus, 
  Minus, 
  Trash2, 
  MessageSquare, 
  MapPin, 
  ArrowRight,
  ChevronUp,
  Sparkles,
  ChefHat,
  AlertTriangle,
  AlertCircle,
  RefreshCw,
  CheckCircle2,
  Package,
  User,
  Phone,
  Clock,
  Calendar,
  Hash,
  Utensils,
  Hotel
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SubmissionError {
  message: string;
  missingField?: 'restaurant_id' | 'supabase' | 'cart';
  details?: string;
}

interface CartDrawerProps {
  business: Business;
  cart?: Map<string, number>;
  cartItems?: CartItem[];
  items?: MenuItem[];
  onUpdateQuantity: (cartItemIdOrItemId: string, delta: number) => void;
  onRemoveItem: (cartItemIdOrItemId: string) => void;
  onClearCart: () => void;
  previewMode?: boolean;
  tenantType?: 'restaurant' | 'guesthouse';
  initialLocationNumber?: string;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  business,
  cart,
  cartItems: propCartItems,
  items = [],
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  previewMode = false,
  tenantType = 'restaurant',
  initialLocationNumber,
}) => {
  const isTableService = business.businessType ? business.businessType === 'restaurant' : tenantType !== 'guesthouse';
  const isGuestHouse = !isTableService;
  const defaultLocationNumber = initialLocationNumber || (isTableService ? 'Table 1' : 'Room 101');

  const [isOpen, setIsOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [locationNumber, setLocationNumber] = useState(defaultLocationNumber);
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderSubmitted, setOrderSubmitted] = useState<any | null>(null);
  const [submitError, setSubmitError] = useState<SubmissionError | null>(null);

  // Derive consolidated list of items
  let effectiveCartItems: CartItem[] = [];

  if (propCartItems && propCartItems.length > 0) {
    effectiveCartItems = propCartItems.filter((ci) => ci.quantity > 0);
  } else if (cart) {
    const itemMap = new Map<string, MenuItem>(items.map((it) => [it.id, it]));
    cart.forEach((qty, itemId) => {
      if (qty > 0) {
        const item = itemMap.get(itemId);
        if (item) {
          effectiveCartItems.push({
            cartItemId: itemId,
            itemId: item.id,
            name: item.name,
            price: item.price || 0,
            unitPrice: item.price || 0,
            quantity: qty,
            item,
            selectedOptions: [],
            totalItemPrice: (item.price || 0) * qty,
          });
        }
      }
    });
  }

  const totalAmount = effectiveCartItems.reduce((acc, ci) => acc + (ci.totalItemPrice || (ci.unitPrice || ci.price || 0) * ci.quantity), 0);
  const totalCount = effectiveCartItems.reduce((acc, ci) => acc + ci.quantity, 0);

  const currencySymbol = business.currencySymbol || '₹';
  const ctaButtonText = 'Place Order (In-App Database)';

  const handleOrderSubmit = async () => {
    if (previewMode) return;
    setSubmitError(null);

    // 1. Validate that cart has items
    if (effectiveCartItems.length === 0) {
      setSubmitError({
        message: 'Your cart is empty. Please add at least one item before placing your order.',
        missingField: 'cart'
      });
      setIsOpen(true);
      return;
    }

    // 2. Validate restaurant_id with robust fallback
    const rawRestaurantId = business?.id || (business as any)?.restaurant_id || (business as any)?.businessId || 'kannayah';
    const restaurantId = typeof rawRestaurantId === 'string' ? rawRestaurantId.trim() : 'kannayah';

    setIsSubmitting(true);

    const now = new Date();
    const orderDate = now.toISOString().slice(0, 10);
    const orderTime = now.toTimeString().slice(0, 8);
    const finalLocation = locationNumber.trim() || defaultLocationNumber;

    const orderItems = effectiveCartItems.map((ci) => ({
      itemId: ci.itemId,
      name: ci.selectedVariant ? `${ci.item.name} (${ci.selectedVariant.name})` : (ci.name || ci.item.name),
      variantName: ci.selectedVariant?.name || null,
      quantity: ci.quantity,
      price: ci.price || ci.item.price || 0,
      unitPrice: ci.unitPrice || ci.price || ci.item.price || 0,
      isVeg: ci.item.isVeg,
      selectedOptions: ci.selectedOptions || [],
      customNote: ci.customNote || '',
      totalItemPrice: ci.totalItemPrice || (ci.unitPrice || ci.price || 0) * ci.quantity,
    }));

    // 3. Perform Supabase order insert with explicit error inspection
    try {
      const { data: sbData, error: sbError } = await supabase
        .from('orders')
        .insert({
          restaurant_id: restaurantId,
          table_number: finalLocation,
          items: orderItems,
          total_price: totalAmount,
          customer_name: customerName?.trim() || null,
          customer_phone: customerPhone?.trim() || null,
          customer_notes: notes?.trim() || null,
          alert_sound_type: 'church_bell',
          order_date: orderDate,
          order_time: orderTime,
          status: 'pending'
        })
        .select();

      if (sbError) {
        console.warn('[CartDrawer] Supabase non-blocking notice:', sbError);
      }
    } catch (sbException: any) {
      console.warn('[CartDrawer] Supabase connection notice:', sbException);
    }

    // 4. Save to local in-app restaurant orders store
    let localRecord: any = null;
    try {
      localRecord = await insertRestaurantOrder({
        restaurantId,
        tableNumber: finalLocation,
        customerName: customerName.trim() || undefined,
        customerPhone: customerPhone.trim() || undefined,
        customerNotes: notes,
        items: orderItems,
        totalPrice: totalAmount,
        alertSoundType: 'church_bell',
        orderDate,
        orderTime,
      });
    } catch (localErr) {
      console.warn('[CartDrawer] Local database insert notice:', localErr);
    }

    // 5. Trigger live merchant dashboard & audio bell via /api/orders
    try {
      const payload = {
        restaurantId,
        restaurant_id: restaurantId,
        tableNumber: finalLocation,
        restaurantName: business.name,
        restaurantAddress: [business.address, business.city].filter(Boolean).join(', '),
        currencySymbol,
        merchantPhone: business.whatsappNumber || business.phone,
        customerName: customerName.trim() || undefined,
        customerPhone: customerPhone.trim() || undefined,
        customerNotes: notes,
        items: orderItems,
        totalPrice: totalAmount,
        alertSoundType: 'church_bell',
        tenantType: isTableService ? 'restaurant' : 'guesthouse'
      };

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const data = await res.json();
        const finalOrder = data.order || {
          id: localRecord?.id || `ord_${Date.now()}`,
          orderId: data.orderId || localRecord?.orderId || 1,
          orderSerial: data.orderSerial || localRecord?.orderSerial || '#001',
          tableNumber: finalLocation,
          totalPrice: totalAmount,
          restaurant_id: restaurantId,
          orderDate,
          orderTime,
          customerName: customerName.trim() || 'Walk-in Customer',
          customerPhone: customerPhone.trim() || '',
          items: orderItems
        };
        setOrderSubmitted(finalOrder);
      } else {
        setOrderSubmitted({
          id: localRecord?.id || `ord_${Date.now()}`,
          orderId: localRecord?.orderId || 1,
          orderSerial: localRecord?.orderSerial || '#001',
          tableNumber: finalLocation,
          totalPrice: totalAmount,
          restaurant_id: restaurantId,
          orderDate,
          orderTime,
          customerName: customerName.trim() || 'Walk-in Customer',
          customerPhone: customerPhone.trim() || '',
          items: orderItems
        });
      }
    } catch (apiErr) {
      console.warn('[CartDrawer] /api/orders local dispatch notice:', apiErr);
      setOrderSubmitted({
        id: localRecord?.id || `ord_${Date.now()}`,
        orderId: localRecord?.orderId || 1,
        orderSerial: localRecord?.orderSerial || '#001',
        tableNumber: finalLocation,
        totalPrice: totalAmount,
        restaurant_id: restaurantId,
        orderDate,
        orderTime,
        customerName: customerName.trim() || 'Walk-in Customer',
        customerPhone: customerPhone.trim() || '',
        items: orderItems
      });
    }

    // 6. Clear cart and keep user in app with the confirmed KOT ticket (no WhatsApp redirect)
    onClearCart();
    setIsSubmitting(false);
  };

  if (totalCount === 0 && !orderSubmitted && !submitError) {
    return null;
  }

  return (
    <>
      {/* Floating Bottom Cart Bar */}
      <div 
        id="floating-cart-bar"
        className="fixed bottom-4 left-0 right-0 z-40 px-3 sm:px-4 max-w-lg md:max-w-xl lg:max-w-2xl mx-auto pointer-events-none"
      >
        {submitError && !isOpen && (
          <motion.div 
            id="floating-order-error-banner"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => setIsOpen(true)}
            className="mb-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-3.5 py-2.5 rounded-2xl shadow-xl flex items-center justify-between pointer-events-auto cursor-pointer border border-rose-400 transition"
          >
            <div className="flex items-center gap-2 min-w-0">
              <AlertTriangle className="w-4 h-4 text-amber-300 shrink-0" />
              <span className="truncate">{submitError.message}</span>
            </div>
            <span className="text-[11px] underline shrink-0 font-black ml-2">Resolve Error</span>
          </motion.div>
        )}

        <motion.div
          initial={{ y: 50, opacity: 0, scale: 0.96 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          exit={{ y: 50, opacity: 0 }}
          className="bg-stone-900 text-white rounded-2xl p-3 sm:p-3.5 shadow-2xl border border-stone-700/80 flex items-center justify-between gap-3 pointer-events-auto backdrop-blur-md cursor-pointer hover:bg-stone-850 transition-all"
          onClick={() => setIsOpen(true)}
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-bold relative shrink-0 shadow-xs">
              <ShoppingBag className="w-5 h-5" />
              <span className="absolute -top-1.5 -right-1.5 bg-rose-600 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-stone-900">
                {totalCount}
              </span>
            </div>
            <div className="min-w-0">
              <div className="text-xs text-stone-300 font-medium truncate">
                {totalCount} {totalCount === 1 ? 'item' : 'items'} in your order
              </div>
              <div className="text-base font-black text-white font-mono">
                {currencySymbol}{totalAmount}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="view-cart-btn"
              onClick={(e) => {
                e.stopPropagation();
                setIsOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm rounded-xl transition-colors shadow-xs cursor-pointer"
            >
              <span>View Order</span>
              <ChevronUp className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      </div>

      {/* Cart Drawer Modal */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-xs cursor-pointer"
            />

            {/* Modal Content */}
            <motion.div
              initial={{ y: '100%', opacity: 0.9 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0.9 }}
              transition={{ type: 'spring', damping: 26, stiffness: 280 }}
              className="relative w-full max-w-lg md:max-w-xl bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-stone-200 z-10 max-h-[90vh] flex flex-col overflow-hidden"
            >
              {/* Header */}
              <div className="px-5 py-4 border-b border-stone-100 flex items-center justify-between bg-stone-50/70">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
                    <ShoppingBag className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-stone-900 text-base leading-none">Your Order Summary</h3>
                    <p className="text-xs text-stone-500 mt-1">
                      {totalCount} {totalCount === 1 ? 'item' : 'items'} selected
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    id="cart-clear-all-btn"
                    onClick={onClearCart}
                    className="text-xs text-stone-400 hover:text-rose-600 font-medium px-2 py-1 rounded transition-colors cursor-pointer"
                  >
                    Clear All
                  </button>
                  <button
                    type="button"
                    id="cart-drawer-close-btn"
                    onClick={() => setIsOpen(false)}
                    aria-label="Close cart drawer"
                    className="w-8 h-8 rounded-full bg-stone-200/80 hover:bg-stone-300 flex items-center justify-center text-stone-700 transition-colors cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* In-Body Alert Banner */}
              {submitError && (
                <div className="px-5 py-3 bg-rose-50 border-b border-rose-200 flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-rose-900 leading-tight">
                      {submitError.message}
                    </p>
                    {submitError.details && (
                      <p className="text-[11px] text-rose-700 font-mono mt-0.5 truncate">
                        {submitError.details}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Modal Body: Unified scroll container so mobile users can always scroll to table grid */}
              <div className="flex-1 overflow-y-auto overscroll-contain divide-y divide-stone-100 min-h-0">
                {orderSubmitted ? (
                  <div className="p-5 sm:p-6 text-center space-y-4 my-auto">
                    <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner border border-emerald-200">
                      <CheckCircle2 className="w-8 h-8" />
                    </div>

                    <div>
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-black tracking-wide uppercase mb-1">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        Saved Directly to Database
                      </div>
                      <h3 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight">
                        Kitchen Order Ticket (KOT)
                      </h3>
                      <p className="text-xs text-stone-500 mt-0.5">
                        Order registered in kitchen system. Ringing live alert sound for staff.
                      </p>
                    </div>

                    {/* Official KOT Ticket Card */}
                    <div className="bg-stone-50 border border-stone-300 rounded-2xl p-4 sm:p-5 text-left space-y-3.5 max-w-sm mx-auto shadow-sm">
                      {/* Serial Number & Location Header */}
                      <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500 flex items-center gap-1">
                            <Hash className="w-3 h-3 text-amber-500" /> Serial No
                          </span>
                          <div className="text-2xl font-black text-amber-600 font-mono tracking-tight">
                            {orderSubmitted.orderSerial || `#${String(orderSubmitted.orderId || 1).padStart(3, '0')}`}
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500">
                            {isTableService ? 'Dining Table' : 'Room / Pickup'}
                          </span>
                          <div className="text-sm sm:text-base font-black text-stone-900 bg-stone-200/80 px-2.5 py-1 rounded-lg inline-block font-mono">
                            {orderSubmitted.tableNumber || locationNumber}
                          </div>
                        </div>
                      </div>

                      {/* Exact Date and Time */}
                      <div className="grid grid-cols-2 gap-2 text-xs py-1.5 border-b border-stone-200 text-stone-700 bg-white/70 px-2.5 rounded-lg">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-stone-400" />
                          <span className="text-stone-500">Date:</span>
                          <span className="font-bold text-stone-900 font-mono">{orderSubmitted.orderDate || new Date().toISOString().slice(0, 10)}</span>
                        </div>
                        <div className="flex items-center gap-1.5 justify-end">
                          <Clock className="w-3.5 h-3.5 text-stone-400" />
                          <span className="text-stone-500">Time:</span>
                          <span className="font-bold font-mono text-stone-900">{orderSubmitted.orderTime || new Date().toTimeString().slice(0, 8)}</span>
                        </div>
                      </div>

                      {/* Customer Contact (Name & Phone Number) */}
                      <div className="p-3 rounded-xl bg-white border border-stone-200 text-xs space-y-1.5">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400">Customer Contact</div>
                        <div className="flex items-center justify-between">
                          <span className="text-stone-500 flex items-center gap-1.5 font-medium">
                            <User className="w-3.5 h-3.5 text-stone-400" /> Name:
                          </span>
                          <span className="font-bold text-stone-900">
                            {orderSubmitted.customerName || customerName.trim() || 'Walk-in Customer'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-stone-500 flex items-center gap-1.5 font-medium">
                            <Phone className="w-3.5 h-3.5 text-stone-400" /> Phone:
                          </span>
                          <span className="font-bold font-mono text-stone-900">
                            {orderSubmitted.customerPhone || customerPhone.trim() || 'Not Provided'}
                          </span>
                        </div>
                      </div>

                      {/* Ordered Items List */}
                      {orderSubmitted.items && orderSubmitted.items.length > 0 && (
                        <div className="space-y-1 pt-1 border-t border-stone-200">
                          <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400">Ordered Items</div>
                          <div className="divide-y divide-stone-100 max-h-36 overflow-y-auto pr-1">
                            {orderSubmitted.items.map((item: any, idx: number) => (
                              <div key={idx} className="py-1.5 flex justify-between text-xs items-center">
                                <span className="text-stone-800 font-medium">
                                  <span className="font-bold text-amber-600 mr-1.5 font-mono">{item.quantity}x</span>
                                  {item.name}
                                </span>
                                <span className="font-mono font-bold text-stone-900">
                                  {currencySymbol}{(item.unitPrice || item.price || 0) * item.quantity}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Total */}
                      <div className="flex justify-between items-baseline pt-2.5 border-t border-stone-200">
                        <span className="text-xs font-bold text-stone-600">Total Order Amount:</span>
                        <span className="text-lg font-black text-emerald-600 font-mono">
                          {currencySymbol}{orderSubmitted.totalPrice || totalAmount}
                        </span>
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          setOrderSubmitted(null);
                          setIsOpen(false);
                        }}
                        className="w-full sm:w-auto px-8 py-3 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs sm:text-sm rounded-xl transition cursor-pointer shadow-md"
                      >
                        Done & Return to Menu
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    {/* Items List */}
                    <div className="px-5 py-3 divide-y divide-stone-100">
                  {effectiveCartItems.map((cartItem) => {
                    const itemKey = cartItem.cartItemId || cartItem.itemId || cartItem.item.id;
                    const itemLineTotal = cartItem.totalItemPrice || (cartItem.unitPrice || cartItem.price || cartItem.item.price || 0) * cartItem.quantity;

                    return (
                      <div key={itemKey} className="py-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 min-w-0 pr-2">
                            <div className="flex items-center gap-1.5">
                              <DietBadge type={cartItem.item.isVeg} size="sm" showLabel={false} />
                              <span className="font-bold text-sm text-stone-900 truncate">
                                {cartItem.name || cartItem.item.name}
                              </span>
                            </div>

                            {cartItem.selectedVariant && (
                              <div className="mt-1">
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 text-amber-900 border border-amber-200 text-[11px] font-semibold">
                                  Size: {cartItem.selectedVariant.name}
                                </span>
                              </div>
                            )}

                            <div className="text-xs text-stone-500 mt-0.5 font-medium">
                              {currencySymbol}{cartItem.unitPrice || cartItem.price || cartItem.item.price} each
                            </div>
                          </div>

                          {/* Quantity Stepper */}
                          <div className="flex items-center gap-2 shrink-0">
                            <div className="flex items-center bg-stone-100 rounded-lg p-0.5 border border-stone-200">
                              <button
                                type="button"
                                onClick={() => onUpdateQuantity(itemKey, -1)}
                                className="w-7 h-7 rounded-md bg-white hover:bg-stone-50 text-stone-700 flex items-center justify-center font-bold transition-colors shadow-2xs cursor-pointer"
                              >
                                {cartItem.quantity === 1 ? <Trash2 className="w-3.5 h-3.5 text-rose-500" /> : <Minus className="w-3.5 h-3.5" />}
                              </button>
                              <span className="w-7 text-center font-bold text-xs text-stone-900 font-mono">
                                {cartItem.quantity}
                              </span>
                              <button
                                type="button"
                                onClick={() => onUpdateQuantity(itemKey, 1)}
                                className="w-7 h-7 rounded-md bg-white hover:bg-stone-50 text-stone-700 flex items-center justify-center font-bold transition-colors shadow-2xs cursor-pointer"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            <div className="w-16 text-right font-black text-sm text-stone-900 font-mono">
                              {currencySymbol}{itemLineTotal}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Location & Customer Contact Details */}
                <div className="px-5 py-3.5 bg-stone-50 space-y-3">
                  {/* Context-aware Location: Table Service vs Room Service / Parcel */}
                  <div className="rounded-2xl bg-white border border-stone-200 p-3.5 shadow-2xs">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {isTableService ? (
                          <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-600 flex items-center justify-center font-bold">
                            <Utensils className="w-4 h-4" />
                          </div>
                        ) : (
                          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 flex items-center justify-center font-bold">
                            <Hotel className="w-4 h-4" />
                          </div>
                        )}
                        <div>
                          <div className="text-xs font-black text-stone-900 uppercase tracking-wider">
                            {isTableService ? 'Dining Table Number' : 'Room Number / Parcel Pickup'}
                          </div>
                          <p className="text-[11px] text-stone-500">
                            {isTableService ? 'Select your table for kitchen delivery' : 'Enter guest room or takeaway parcel'}
                          </p>
                        </div>
                      </div>

                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-stone-100 text-stone-700 border border-stone-200">
                        {isTableService ? 'Table Service' : 'Room / Parcel'}
                      </span>
                    </div>

                    {/* Quick Location Chips */}
                    <div className="flex flex-wrap gap-1.5 mb-2">
                      {isTableService ? (
                        ['Table 1', 'Table 2', 'Table 3', 'Table 4', 'Table 5', 'Table 6'].map((tbl) => (
                          <button
                            key={tbl}
                            type="button"
                            onClick={() => setLocationNumber(tbl)}
                            className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                              locationNumber === tbl
                                ? 'bg-amber-500 text-stone-950 shadow-xs'
                                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                            }`}
                          >
                            {tbl}
                          </button>
                        ))
                      ) : (
                        ['Room 101', 'Room 102', 'Room 103', 'Room 104', 'Counter Parcel Pickup'].map((loc) => (
                          <button
                            key={loc}
                            type="button"
                            onClick={() => setLocationNumber(loc)}
                            className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                              locationNumber === loc
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                            }`}
                          >
                            {loc}
                          </button>
                        ))
                      )}
                    </div>

                    <input
                      type="text"
                      value={locationNumber}
                      onChange={(e) => setLocationNumber(e.target.value)}
                      placeholder={isTableService ? 'e.g. Table 4 or Patio 2' : 'e.g. Room 204 or Takeaway Parcel'}
                      className="w-full text-xs px-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-stone-900 font-semibold focus:outline-hidden focus:border-amber-500"
                    />
                  </div>

                  {/* Customer Contact: Name & Phone Number */}
                  <div className="rounded-2xl bg-white border border-stone-200 p-3.5 shadow-2xs space-y-2">
                    <div className="text-[11px] font-black text-stone-700 uppercase tracking-wider flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-stone-400" />
                      <span>Customer Contact Details</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label 
                          htmlFor="cart-customer-name"
                          className="flex items-center gap-1 text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1"
                        >
                          <span>Customer Name</span>
                        </label>
                        <input
                          type="text"
                          id="cart-customer-name"
                          placeholder="e.g. Ramesh Kumar"
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-stone-900 font-medium focus:outline-hidden focus:border-amber-500 shadow-2xs"
                        />
                      </div>
                      <div>
                        <label 
                          htmlFor="cart-customer-phone"
                          className="flex items-center gap-1 text-[11px] font-bold text-stone-600 uppercase tracking-wider mb-1"
                        >
                          <Phone className="w-3 h-3 text-stone-500" />
                          <span>Phone Number</span>
                        </label>
                        <input
                          type="tel"
                          id="cart-customer-phone"
                          placeholder="e.g. +91 98450 12345"
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                          className="w-full text-xs px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-stone-900 font-medium focus:outline-hidden focus:border-amber-500 shadow-2xs"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Custom Instructions / Packaging Note Field */}
                  <OrderNotesInput
                    value={notes}
                    onChange={setNotes}
                    isGuestHouse={isGuestHouse}
                  />

                  {/* Property Address */}
                  {business.address && (
                    <div className="flex items-start gap-1.5 text-[11px] text-stone-500 bg-white/90 p-2 rounded-xl border border-stone-200/70">
                      <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                      <span className="truncate">{business.address}{business.city ? `, ${business.city}` : ''}</span>
                    </div>
                  )}
                </div>
                </>
                )}
              </div>

              {/* Footer / Total & Order Button */}
              <div className="p-5 bg-white border-t border-stone-200 space-y-3">
                {/* Error Alert Box in Footer */}
                {submitError && (
                  <div
                    id="order-submission-error-alert"
                    role="alert"
                    aria-live="assertive"
                    className="p-3.5 sm:p-4 rounded-2xl bg-rose-50 border-2 border-rose-400 text-rose-950 shadow-sm"
                  >
                    <div className="flex items-start gap-2.5 sm:gap-3">
                      <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-0.5">
                        <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-xs sm:text-sm font-black text-rose-900 uppercase tracking-wide">
                            {submitError.missingField === 'restaurant_id'
                              ? 'Missing Restaurant ID'
                              : submitError.missingField === 'supabase'
                              ? 'Database Notice'
                              : 'Order Submission Failed'}
                          </span>
                          <button
                            type="button"
                            id="dismiss-order-submission-error"
                            onClick={() => setSubmitError(null)}
                            className="text-rose-500 hover:text-rose-800 p-1 rounded-md transition-colors cursor-pointer"
                            aria-label="Dismiss error"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        
                        {/* Exact Error Message */}
                        <div className="mt-2 p-2.5 rounded-xl bg-white border border-rose-300 text-xs font-mono font-bold text-rose-950 break-words select-all shadow-2xs leading-relaxed">
                          {submitError.message}
                        </div>

                        {submitError.details && (
                          <p className="mt-1.5 text-[11px] text-rose-800 font-medium break-words">
                            {submitError.details}
                          </p>
                        )}

                        <div className="mt-2.5 flex items-center gap-2">
                          <button
                            type="button"
                            id="retry-order-submission-btn"
                            onClick={handleOrderSubmit}
                            disabled={isSubmitting}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-lg transition shadow-2xs cursor-pointer active:scale-95 disabled:opacity-50"
                          >
                            <RefreshCw className={`w-3.5 h-3.5 ${isSubmitting ? 'animate-spin' : ''}`} />
                            <span>Retry Submission</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex items-baseline justify-between">
                  <span className="text-sm font-bold text-stone-600">Total Order Amount:</span>
                  <span className="text-2xl font-black text-stone-950 font-mono">
                    {currencySymbol}{totalAmount}
                  </span>
                </div>

                {!previewMode ? (
                  <button
                    type="button"
                    id="cart-submit-order-btn"
                    onClick={handleOrderSubmit}
                    disabled={isSubmitting}
                    className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-2.5 transition-all shadow-md shadow-emerald-700/20 active:scale-[0.98] cursor-pointer disabled:opacity-75"
                  >
                    <ChefHat className="w-5 h-5" />
                    <span>{isSubmitting ? 'Saving Order to Kitchen Database...' : 'Confirm Order & Generate KOT'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled
                    className="w-full py-3.5 px-4 bg-emerald-600/70 text-white rounded-2xl font-bold text-sm sm:text-base flex items-center justify-center gap-2.5 cursor-not-allowed opacity-90"
                    title="In-app database ordering is active in live customer view"
                  >
                    <ChefHat className="w-5 h-5" />
                    <span>Confirm Order (Preview Mode)</span>
                  </button>
                )}

                <p className="text-[11px] text-center text-stone-400">
                  Direct in-app ordering generates sequential KOT (#001, #002) and triggers kitchen audio alerts.
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
