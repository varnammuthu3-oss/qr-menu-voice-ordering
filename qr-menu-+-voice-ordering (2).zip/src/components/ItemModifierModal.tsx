import React, { useState, useEffect } from 'react';
import { MenuItem, MenuItemVariant, FoodDietType } from '../types';
import { DietBadge } from './DietBadge';
import { 
  X, 
  Plus, 
  Minus, 
  Flame, 
  ChefHat, 
  Sparkles, 
  MessageSquare, 
  Check, 
  ShoppingBag
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface ModifierSelection {
  spiceLevel: string;
  prepStyle: string;
  addons: Array<{ name: string; price: number }>;
  kitchenNotes: string[];
  customNote: string;
  quantity: number;
  selectedVariant?: MenuItemVariant;
}

interface ItemModifierModalProps {
  isOpen: boolean;
  item: MenuItem | null;
  currencySymbol?: string;
  initialSelection?: Partial<ModifierSelection>;
  onClose: () => void;
  onConfirm: (customizedItem: {
    item: MenuItem;
    selectedVariant?: MenuItemVariant;
    selectedOptions: string[];
    customNote: string;
    quantity: number;
    unitPrice: number;
    totalItemPrice: number;
  }) => void;
}

const SPICE_OPTIONS = [
  { id: 'mild', label: 'Mild / Less Spicy', icon: '🌿' },
  { id: 'medium', label: 'Medium', icon: '🌶️', isDefault: true },
  { id: 'extra_hot', label: 'Extra Hot', icon: '🔥' },
];

const PREP_STYLES = [
  { id: 'soft', label: 'Soft / Half Cooked' },
  { id: 'normal', label: 'Normal', isDefault: true },
  { id: 'super_crispy', label: 'Super Crispy' },
  { id: 'less_oil', label: 'Less Oil' },
];

const ADDON_OPTIONS = [
  { id: 'extra_cheese', name: 'Extra Cheese', price: 30 },
  { id: 'double_butter', name: 'Double Butter', price: 20 },
  { id: 'extra_ghee', name: 'Extra Ghee', price: 25 },
  { id: 'extra_onions', name: 'Extra Onions', price: 10 },
  { id: 'sambar_dip', name: 'Extra Sambar / Chutney', price: 15 },
  { id: 'extra_nuts', name: 'Extra Nuts & Toppings', price: 25 },
];

const KITCHEN_TAGS = [
  'Make Gravy Thick',
  'Serve Piping Hot',
  'Chutney on the Side',
  'Extra Nuts',
  'No Garlic / Jain Option',
  'No Coriander',
  'Less Sugar / No Ice',
  'Crispy Edges'
];

export const ItemModifierModal: React.FC<ItemModifierModalProps> = ({
  isOpen,
  item,
  currencySymbol = '₹',
  initialSelection,
  onClose,
  onConfirm,
}) => {
  const [selectedVariant, setSelectedVariant] = useState<MenuItemVariant | undefined>(
    initialSelection?.selectedVariant || item?.variants?.find((v) => v.isDefault) || item?.variants?.[0]
  );
  const [spiceLevel, setSpiceLevel] = useState<string>('Medium');
  const [prepStyle, setPrepStyle] = useState<string>('Normal');
  const [selectedAddons, setSelectedAddons] = useState<Array<{ name: string; price: number }>>([]);
  const [selectedKitchenNotes, setSelectedKitchenNotes] = useState<string[]>([]);
  const [customNote, setCustomNote] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);

  // Reset state when opening a new item
  useEffect(() => {
    if (isOpen && item) {
      setSelectedVariant(initialSelection?.selectedVariant || item.variants?.find((v) => v.isDefault) || item.variants?.[0]);
      setSpiceLevel(initialSelection?.spiceLevel || 'Medium');
      setPrepStyle(initialSelection?.prepStyle || 'Normal');
      setSelectedAddons(initialSelection?.addons || []);
      setSelectedKitchenNotes(initialSelection?.kitchenNotes || []);
      setCustomNote(initialSelection?.customNote || '');
      setQuantity(initialSelection?.quantity || 1);
    }
  }, [isOpen, item, initialSelection]);

  if (!item) return null;

  const basePrice = selectedVariant ? selectedVariant.price : (item.price || 0);
  const addonsTotal = selectedAddons.reduce((sum, a) => sum + a.price, 0);
  const unitPrice = basePrice + addonsTotal;
  const totalItemPrice = unitPrice * quantity;

  // Toggle Addon
  const toggleAddon = (addon: { name: string; price: number }) => {
    setSelectedAddons((prev) => {
      const exists = prev.some((a) => a.name === addon.name);
      if (exists) {
        return prev.filter((a) => a.name !== addon.name);
      } else {
        return [...prev, addon];
      }
    });
  };

  // Toggle Kitchen Note Tag
  const toggleKitchenNote = (tag: string) => {
    setSelectedKitchenNotes((prev) => {
      if (prev.includes(tag)) {
        return prev.filter((t) => t !== tag);
      } else {
        return [...prev, tag];
      }
    });
  };

  const handleConfirm = () => {
    // Collect all selected formatted options
    const options: string[] = [];

    // Spice level (if not default)
    if (spiceLevel && spiceLevel !== 'Medium') {
      options.push(`Spice: ${spiceLevel}`);
    } else if (spiceLevel) {
      options.push(spiceLevel);
    }

    // Prep Style (if not Normal)
    if (prepStyle && prepStyle !== 'Normal') {
      options.push(prepStyle);
    }

    // Add-ons with price formatting
    selectedAddons.forEach((addon) => {
      options.push(`${addon.name} (+${currencySymbol}${addon.price})`);
    });

    // Kitchen tags
    selectedKitchenNotes.forEach((tag) => {
      options.push(tag);
    });

    onConfirm({
      item,
      selectedVariant,
      selectedOptions: options,
      customNote: customNote.trim(),
      quantity,
      unitPrice,
      totalItemPrice,
    });

    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/70 backdrop-blur-xs cursor-pointer"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ y: '100%', opacity: 0.9 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '100%', opacity: 0.9 }}
            transition={{ type: 'spring', damping: 28, stiffness: 300 }}
            className="relative w-full max-w-lg bg-stone-900 text-stone-100 rounded-t-3xl sm:rounded-3xl shadow-2xl border border-stone-800 z-10 max-h-[92vh] flex flex-col overflow-hidden"
          >
            {/* Header: Item summary & Close button */}
            <div className="p-4 sm:p-5 border-b border-stone-800 bg-stone-950/90 flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 min-w-0">
                {item.imageUrl ? (
                  <img
                    src={item.imageUrl}
                    alt={item.name}
                    className="w-14 h-14 rounded-2xl object-cover border border-stone-700 shadow-md shrink-0"
                  />
                ) : (
                  <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold shrink-0">
                    <ChefHat className="w-7 h-7" />
                  </div>
                )}

                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 mb-1">
                    <DietBadge type={item.isVeg} size="sm" showLabel={false} />
                    <h3 className="font-extrabold text-base sm:text-lg text-white leading-tight truncate">
                      {item.name}
                    </h3>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-black text-amber-400 text-sm">
                      {currencySymbol}{item.price}
                    </span>
                    {item.description && (
                      <span className="text-stone-400 text-xs truncate max-w-[200px]">
                        • {item.description}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <button
                type="button"
                id="modifier-modal-close-btn"
                onClick={onClose}
                aria-label="Close customization modal"
                className="w-9 h-9 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Customizer Form */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 text-xs">
              
              {/* Size / Variant Selector (if item has variants) */}
              {item.variants && item.variants.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="font-bold text-stone-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Select Size / Variant</span>
                    </label>
                    <span className="text-[10px] text-amber-400 font-mono font-bold">
                      {selectedVariant?.name}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    {item.variants.map((v) => {
                      const isSelected = selectedVariant?.id === v.id;
                      return (
                        <button
                          key={v.id}
                          type="button"
                          onClick={() => setSelectedVariant(v)}
                          className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-0.5 min-h-[50px] justify-center ${
                            isSelected
                              ? 'bg-amber-500 text-stone-950 border-amber-500 font-black ring-1 ring-amber-400 shadow-xs'
                              : 'bg-stone-800/60 hover:bg-stone-800 border-stone-700 text-stone-300'
                          }`}
                        >
                          <span className="text-xs font-bold leading-tight">{v.name}</span>
                          <span className={`text-[11px] font-mono ${isSelected ? 'text-stone-950 font-black' : 'text-amber-400'}`}>
                            {currencySymbol}{v.price}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* 1. Spice Level (Single-Select) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-stone-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-rose-400" />
                    <span>Spice Level</span>
                  </label>
                  <span className="text-[10px] text-stone-400">Select one</span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {SPICE_OPTIONS.map((opt) => {
                    const isSelected = spiceLevel === opt.label;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setSpiceLevel(opt.label)}
                        className={`p-2.5 rounded-xl border text-center font-bold text-xs transition-all cursor-pointer flex flex-col items-center gap-1 min-h-[44px] justify-center ${
                          isSelected
                            ? 'bg-rose-500/20 border-rose-500 text-rose-300 ring-1 ring-rose-500 shadow-xs'
                            : 'bg-stone-800/60 hover:bg-stone-800 border-stone-700 text-stone-300'
                        }`}
                      >
                        <span className="text-base">{opt.icon}</span>
                        <span className="leading-tight">{opt.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. Preparation Style (Single-Select) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-stone-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <ChefHat className="w-3.5 h-3.5 text-amber-400" />
                    <span>Preparation Style</span>
                  </label>
                  <span className="text-[10px] text-stone-400">Select one</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {PREP_STYLES.map((style) => {
                    const isSelected = prepStyle === style.label;
                    return (
                      <button
                        key={style.id}
                        type="button"
                        onClick={() => setPrepStyle(style.label)}
                        className={`p-2.5 rounded-xl border font-bold text-xs transition-all cursor-pointer text-center min-h-[44px] flex items-center justify-center ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-500 text-amber-300 ring-1 ring-amber-500 shadow-xs'
                            : 'bg-stone-800/60 hover:bg-stone-800 border-stone-700 text-stone-300'
                        }`}
                      >
                        <span>{style.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 3. Add-ons with Prices (Multi-Select) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-stone-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Add-ons (Optional)</span>
                  </label>
                  <span className="text-[10px] text-stone-400">Multi-select</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {ADDON_OPTIONS.map((addon) => {
                    const isSelected = selectedAddons.some((a) => a.name === addon.name);
                    return (
                      <button
                        key={addon.id}
                        type="button"
                        onClick={() => toggleAddon(addon)}
                        className={`p-2.5 px-3 rounded-xl border font-bold text-xs transition-all cursor-pointer flex items-center justify-between min-h-[44px] ${
                          isSelected
                            ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 ring-1 ring-emerald-500 shadow-xs'
                            : 'bg-stone-800/60 hover:bg-stone-800 border-stone-700 text-stone-300'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <div className={`w-4 h-4 rounded-md flex items-center justify-center text-[10px] ${
                            isSelected ? 'bg-emerald-500 text-stone-950 font-black' : 'border border-stone-600'
                          }`}>
                            {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                          </div>
                          <span>{addon.name}</span>
                        </div>
                        <span className="font-mono text-emerald-400 text-xs">
                          +{currencySymbol}{addon.price}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 4. Kitchen Quick Tags (Multi-Select) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-stone-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <ChefHat className="w-3.5 h-3.5 text-sky-400" />
                    <span>Kitchen Quick Tags</span>
                  </label>
                  <span className="text-[10px] text-stone-400">Multi-select</span>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {KITCHEN_TAGS.map((tag) => {
                    const isSelected = selectedKitchenNotes.includes(tag);
                    return (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => toggleKitchenNote(tag)}
                        className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer flex items-center gap-1.5 min-h-[38px] ${
                          isSelected
                            ? 'bg-sky-500/20 border-sky-400 text-sky-300 ring-1 ring-sky-500'
                            : 'bg-stone-800/70 hover:bg-stone-800 text-stone-300 border-stone-700'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3 text-sky-400 stroke-[3]" />}
                        <span>{tag}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 5. Special Instructions for Kitchen (Textarea) */}
              <div className="space-y-1.5">
                <label className="font-bold text-stone-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
                  <span>Special Instructions for Kitchen</span>
                </label>
                <textarea
                  id="kitchen-special-instructions-input"
                  rows={2}
                  value={customNote}
                  onChange={(e) => setCustomNote(e.target.value)}
                  placeholder="e.g. Extra spicy chutney on the side, serve piping hot, no coriander..."
                  className="w-full text-xs p-3 rounded-2xl bg-stone-950 border border-stone-700 text-stone-100 placeholder-stone-500 focus:outline-hidden focus:border-amber-400 focus:ring-1 focus:ring-amber-400 resize-none"
                />
              </div>

            </div>

            {/* Bottom Sticky Action Footer */}
            <div className="p-4 sm:p-5 border-t border-stone-800 bg-stone-950 flex items-center justify-between gap-3">
              {/* Quantity Stepper */}
              <div className="flex items-center bg-stone-800 rounded-2xl p-1 border border-stone-700 shrink-0">
                <button
                  type="button"
                  id="modifier-qty-minus-btn"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="w-9 h-9 rounded-xl bg-stone-700 hover:bg-stone-650 text-stone-200 flex items-center justify-center font-bold transition-colors cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-9 text-center font-black text-sm text-white font-mono">
                  {quantity}
                </span>
                <button
                  type="button"
                  id="modifier-qty-plus-btn"
                  onClick={() => setQuantity((q) => q + 1)}
                  className="w-9 h-9 rounded-xl bg-stone-700 hover:bg-stone-650 text-stone-200 flex items-center justify-center font-bold transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              {/* Add to Order Button */}
              <button
                type="button"
                id="modifier-confirm-add-btn"
                onClick={handleConfirm}
                className="flex-1 py-3.5 px-4 bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-2xl font-black text-sm flex items-center justify-between transition-all shadow-lg shadow-amber-500/20 active:scale-[0.98] cursor-pointer min-h-[48px]"
              >
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add to Order</span>
                </div>
                <span className="font-mono text-base font-black">
                  {currencySymbol}{totalItemPrice}
                </span>
              </button>
            </div>

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
