import React, { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Store, 
  Hotel, 
  Sparkles, 
  Check, 
  Database, 
  AlertCircle,
  ShieldCheck,
  ShieldAlert,
  KeyRound,
  RotateCcw,
  Smartphone,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { saveRestaurant } from '../utils/shopPersistence';
import { saveBusiness, checkIfBusinessIdExists } from '../services/db';
import { Business, StoredShop } from '../types';

export interface RegisterPropertyFormData {
  name: string;
  slug?: string;
  tables?: string[];
  features?: {
    enable_whatsapp_orders?: boolean;
    enable_table_selector?: boolean;
  };
  businessType?: 'restaurant' | 'guesthouse';
  phone?: string;
  whatsappNumber?: string;
  address?: string;
  city?: string;
  is_approved?: boolean;
}

interface RegisterPropertyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPropertyRegistered: (newBiz: Business, newShop: StoredShop) => void;
  isAdminMode?: boolean;
}

export const RegisterPropertyModal: React.FC<RegisterPropertyModalProps> = ({
  isOpen,
  onClose,
  onPropertyRegistered,
  isAdminMode = false,
}) => {
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [businessType, setBusinessType] = useState<'restaurant' | 'guesthouse'>('restaurant');
  const [tablesInput, setTablesInput] = useState('1, 2, 3, 4, 5');
  const [enableWhatsapp, setEnableWhatsapp] = useState(true);
  const [enableTableSelector, setEnableTableSelector] = useState(true);
  const [phone, setPhone] = useState('+91 98450 12345');
  const [whatsappNumber, setWhatsappNumber] = useState('+91 98450 12345');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Bengaluru');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [cloudError, setCloudError] = useState<string | null>(null);

  // 🛡️ BOT SPAM PROTECTION STATE
  // 1. Math CAPTCHA
  const [captchaNumA, setCaptchaNumA] = useState(7);
  const [captchaNumB, setCaptchaNumB] = useState(5);
  const [captchaAnswer, setCaptchaAnswer] = useState('');
  const [captchaError, setCaptchaError] = useState<string | null>(null);

  // 2. Invisible Honeypot Trap
  const [honeypotValue, setHoneypotValue] = useState('');

  // 3. Phone OTP Verification
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [enteredOtp, setEnteredOtp] = useState('');
  const [isOtpVerified, setIsOtpVerified] = useState(false);
  const [otpNotice, setOtpNotice] = useState<string | null>(null);
  const [otpError, setOtpError] = useState<string | null>(null);

  const generateCaptcha = () => {
    const a = Math.floor(Math.random() * 8) + 3; // 3 to 10
    const b = Math.floor(Math.random() * 8) + 2; // 2 to 9
    setCaptchaNumA(a);
    setCaptchaNumB(b);
    setCaptchaAnswer('');
    setCaptchaError(null);
  };

  useEffect(() => {
    if (isOpen) {
      generateCaptcha();
      setHoneypotValue('');
      setGeneratedOtp(null);
      setEnteredOtp('');
      setIsOtpVerified(false);
      setOtpNotice(null);
      setOtpError(null);
      setCloudError(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleNameChange = (val: string) => {
    setName(val);
    const generatedSlug = val
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
    setSlug(generatedSlug);
  };

  // Trigger Phone OTP Code
  const handleSendOtp = () => {
    const digitsOnly = phone.replace(/[^0-9]/g, '');
    if (digitsOnly.length < 10) {
      setOtpError('Please enter a valid mobile number with at least 10 digits before requesting OTP.');
      return;
    }
    const simulatedOtp = String(Math.floor(1000 + Math.random() * 9000));
    setGeneratedOtp(simulatedOtp);
    setOtpNotice(`📱 SMS Verification Code dispatched to ${phone}: [ ${simulatedOtp} ]`);
    setOtpError(null);
  };

  // Verify Phone OTP Code
  const handleVerifyOtp = () => {
    if (!generatedOtp) {
      setOtpError('Please request an OTP code first.');
      return;
    }
    if (enteredOtp.trim() === generatedOtp) {
      setIsOtpVerified(true);
      setOtpError(null);
      setOtpNotice('Mobile number verified successfully!');
    } else {
      setOtpError('Invalid OTP code. Please check and try again.');
    }
  };

  /**
   * Connect your "Register New Property" form to Supabase with is_approved set based on admin mode
   */
  async function handleRestaurantRegistration(formData: RegisterPropertyFormData) {
    const approvalStatus = isAdminMode ? true : false;
    const newShop: StoredShop = {
      id: formData.slug || formData.name.toLowerCase().replace(/\s+/g, '-'),
      name: formData.name,
      tables: formData.tables || ["1", "2", "3", "4", "5"],
      features: { 
        enable_whatsapp_orders: formData.features?.enable_whatsapp_orders ?? true, 
        enable_table_selector: formData.features?.enable_table_selector ?? true 
      },
      phone: formData.phone,
      whatsappNumber: formData.whatsappNumber,
      address: formData.address,
      city: formData.city,
      is_approved: approvalStatus
    };

    // Push directly to Supabase cloud database with approvalStatus
    const { data, error } = await supabase
      .from('restaurants')
      .insert([{
        id: newShop.id,
        name: newShop.name,
        tables: newShop.tables,
        features: newShop.features,
        phone: newShop.phone,
        whatsapp_number: newShop.whatsappNumber,
        address: newShop.address,
        city: newShop.city,
        business_type: formData.businessType || 'restaurant',
        is_approved: approvalStatus
      }]);

    if (error) {
      console.error("Error saving to cloud:", error.message);
      setCloudError(error.message);
    } else {
      if (isAdminMode) {
        console.log("Restaurant registered with is_approved: true via Admin Portal.");
      } else {
        alert("Restaurant registered online! Status: Pending Super-Admin Approval.");
      }
    }

    return { newShop, error, data };
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setCloudError(null);
    setCaptchaError(null);
    setOtpError(null);

    // Skip bot validation when in authorized Admin Mode
    if (!isAdminMode) {
      // 🛡️ BOT VALIDATION CHECK 1: Honeypot Trap
      if (honeypotValue.trim().length > 0) {
        console.warn('Bot submission trapped via honeypot field.');
        alert('Automated submission rejected. Bot signature detected.');
        return;
      }

      // 🛡️ BOT VALIDATION CHECK 2: Math CAPTCHA
      const expectedAnswer = captchaNumA + captchaNumB;
      if (parseInt(captchaAnswer.trim(), 10) !== expectedAnswer) {
        setCaptchaError(`Incorrect verification answer. What is ${captchaNumA} + ${captchaNumB}?`);
        generateCaptcha();
        return;
      }

      // 🛡️ BOT VALIDATION CHECK 3: Phone Number Validation
      const rawDigits = phone.replace(/[^0-9]/g, '');
      if (rawDigits.length < 10) {
        alert('Please provide a valid 10-digit phone number for authentication.');
        return;
      }

      // Optional warning if OTP not yet clicked
      if (!isOtpVerified && !generatedOtp) {
        const confirmProceed = window.confirm(
          'For enhanced spam protection, phone OTP verification is recommended. Click OK to auto-verify this registration or Cancel to verify with SMS code.'
        );
        if (!confirmProceed) return;
      }
    }

    const cleanName = name.trim();
    const cleanSlug = slug.trim().toLowerCase() || cleanName.toLowerCase().replace(/\s+/g, '-');

    if (!cleanName) {
      alert('Please enter a property or restaurant name.');
      return;
    }

    const parsedTables = tablesInput
      .split(/[,;\s]+/)
      .map(t => t.trim())
      .filter(Boolean);

    const targetApproval = isAdminMode ? true : false;

    const formData: RegisterPropertyFormData = {
      name: cleanName,
      slug: cleanSlug,
      tables: parsedTables.length > 0 ? parsedTables : ["1", "2", "3", "4", "5"],
      features: {
        enable_whatsapp_orders: enableWhatsapp,
        enable_table_selector: enableTableSelector,
      },
      businessType,
      phone: phone.trim(),
      whatsappNumber: whatsappNumber.trim(),
      address: address.trim(),
      city: city.trim(),
      is_approved: targetApproval
    };

    setIsSubmitting(true);
    try {
      // 1. Execute Supabase registration with targeted approval status
      const { newShop } = await handleRestaurantRegistration(formData);

      // 2. Persist into local PWA store with targeted approval status
      saveRestaurant(newShop);

      const newBiz: Business = {
        id: newShop.id,
        ownerUid: 'owner-master-' + Date.now(),
        name: newShop.name,
        businessType: businessType,
        tagline: businessType === 'guesthouse' ? 'Luxury Stay & In-Room Service' : 'Freshly prepared food & beverages',
        logoUrl: businessType === 'guesthouse'
          ? 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=200&auto=format&fit=crop&q=80'
          : 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=200&auto=format&fit=crop&q=80',
        coverUrl: businessType === 'guesthouse'
          ? 'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=800&auto=format&fit=crop&q=80'
          : 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=80',
        address: address.trim() || `${city}, India`,
        city: city.trim() || 'Bengaluru',
        phone: phone.trim() || '+91 98450 12345',
        whatsappNumber: whatsappNumber.trim() || '+91 98450 12345',
        openingHours: businessType === 'guesthouse' ? '24/7 Front Desk' : 'Mon - Sun: 7:00 AM – 10:30 PM',
        currencySymbol: '₹',
        tables: newShop.tables,
        features: newShop.features,
        isActive: true,
        status: 'active',
        subscriptionTier: 'enterprise',
        is_approved: targetApproval,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      try {
        await saveBusiness(newBiz);
      } catch (dbErr) {
        console.warn('saveBusiness fallback notice:', dbErr);
      }

      // 3. Notify parent to refresh admin fleet console view
      onPropertyRegistered(newBiz, newShop);
      onClose();
    } catch (err: any) {
      console.error('Registration flow exception:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto text-stone-100">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-gradient-to-tr from-purple-600 to-indigo-600 rounded-xl text-white">
              <Plus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-base text-white tracking-tight">Register New Property</h3>
              <div className="flex items-center gap-2 text-xs text-stone-400">
                <span>Multi-Tenant Cloud Sync</span>
                <span className="inline-flex items-center gap-1 text-[10px] font-mono px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  <Database className="w-2.5 h-2.5" /> Supabase Connected
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Approval Notice Banner */}
        {isAdminMode ? (
          <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
            <div>
              <p className="font-bold text-emerald-200 flex items-center gap-2">
                <span>Admin Direct Provisioning</span>
                <span className="text-[10px] font-mono bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/30">is_approved: true</span>
              </p>
              <p className="text-[11px] text-emerald-300/80 mt-0.5">
                Adding this property as Super Admin automatically sets <strong className="text-emerald-200 font-mono">is_approved: true</strong> and bypasses public OTP verification so owners can access dashboards right away.
              </p>
            </div>
          </div>
        ) : (
          <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-start gap-2.5">
            <Clock className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
            <div>
              <p className="font-bold text-amber-200">Admin Approval Workflow Enabled</p>
              <p className="text-[11px] text-amber-300/80 mt-0.5">
                New property registrations default to <strong className="text-amber-200">Pending Approval (is_approved: false)</strong>. The Super Admin must verify and toggle them active in the Master Fleet Console before guest checkout goes fully live.
              </p>
            </div>
          </div>
        )}

        {cloudError && (
          <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Cloud sync notice: {cloudError}</p>
              <p className="text-[11px] text-rose-200/80 mt-0.5">
                Local persistent storage and Firestore fallback will keep your restaurant fully active in the fleet console.
              </p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Invisible Honeypot Trap to Catch Spam Bots */}
          <input
            type="text"
            name="b_url_trap_honey"
            value={honeypotValue}
            onChange={(e) => setHoneypotValue(e.target.value)}
            style={{ display: 'none', position: 'absolute', opacity: 0, pointerEvents: 'none' }}
            tabIndex={-1}
            autoComplete="off"
          />

          {/* Property Name */}
          <div>
            <label className="block text-xs font-semibold text-stone-300 mb-1.5">
              Property / Restaurant Name *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="e.g. Kannayah Heritage Grand"
              className="w-full px-3.5 py-2.5 bg-stone-800/90 border border-stone-700 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
          </div>

          {/* Business Type Selector */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setBusinessType('restaurant')}
              className={`p-3 rounded-2xl border flex items-center gap-2.5 text-xs font-bold transition text-left cursor-pointer ${
                businessType === 'restaurant'
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                  : 'bg-stone-800/60 border-stone-700 text-stone-400 hover:border-stone-600'
              }`}
            >
              <Store className="w-4 h-4" />
              <div>
                <p className="text-white">Restaurant / Diner</p>
                <p className="text-[10px] text-stone-400 font-normal">Table dining & QR menu</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setBusinessType('guesthouse')}
              className={`p-3 rounded-2xl border flex items-center gap-2.5 text-xs font-bold transition text-left cursor-pointer ${
                businessType === 'guesthouse'
                  ? 'bg-sky-500/20 border-sky-500 text-sky-300'
                  : 'bg-stone-800/60 border-stone-700 text-stone-400 hover:border-stone-600'
              }`}
            >
              <Hotel className="w-4 h-4" />
              <div>
                <p className="text-white">Guest House / Hotel</p>
                <p className="text-[10px] text-stone-400 font-normal">Rooms & service SOP</p>
              </div>
            </button>
          </div>

          {/* URL Slug */}
          <div>
            <label className="block text-xs font-semibold text-stone-300 mb-1.5">
              Unique Property ID (URL Slug)
            </label>
            <div className="flex items-center">
              <span className="px-3.5 py-2.5 bg-stone-800 border border-r-0 border-stone-700 rounded-l-xl text-xs font-mono text-stone-400">
                /?shop=
              </span>
              <input
                type="text"
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                placeholder="kannayah-heritage-grand"
                className="w-full px-3.5 py-2.5 bg-stone-800/90 border border-stone-700 rounded-r-xl text-xs font-mono text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>
            <p className="text-[10px] text-stone-500 mt-1">
              Defaults to name slug if left blank.
            </p>
          </div>

          {/* Tables Configuration */}
          <div>
            <label className="block text-xs font-semibold text-stone-300 mb-1.5">
              Tables / Units List (comma-separated)
            </label>
            <input
              type="text"
              value={tablesInput}
              onChange={(e) => setTablesInput(e.target.value)}
              placeholder="1, 2, 3, 4, 5, VIP-1"
              className="w-full px-3.5 py-2.5 bg-stone-800/90 border border-stone-700 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
            />
            <p className="text-[10px] text-stone-500 mt-1">
              Default: ["1", "2", "3", "4", "5"]. These generate instant QR codes and guest selection pills.
            </p>
          </div>

          {/* Features Toggles */}
          <div className="p-3 rounded-2xl bg-stone-800/50 border border-stone-700 space-y-2.5">
            <span className="text-[11px] font-bold text-stone-300 uppercase tracking-wider block">
              Feature Flags
            </span>
            <label className="flex items-center gap-2.5 text-xs text-stone-300 cursor-pointer">
              <input
                type="checkbox"
                checked={enableWhatsapp}
                onChange={(e) => setEnableWhatsapp(e.target.checked)}
                className="rounded-md border-stone-700 text-purple-600 focus:ring-purple-500 w-4 h-4 bg-stone-800"
              />
              <span>Enable Direct WhatsApp Orders (<code>enable_whatsapp_orders</code>)</span>
            </label>
            <label className="flex items-center gap-2.5 text-xs text-stone-300 cursor-pointer">
              <input
                type="checkbox"
                checked={enableTableSelector}
                onChange={(e) => setEnableTableSelector(e.target.checked)}
                className="rounded-md border-stone-700 text-purple-600 focus:ring-purple-500 w-4 h-4 bg-stone-800"
              />
              <span>Enable Guest Table Selector (<code>enable_table_selector</code>)</span>
            </label>
          </div>

          {/* Contact Details */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">Phone Number *</label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+91 98450 12345"
                className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">City / Region</label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white focus:outline-hidden focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          {!isAdminMode ? (
            <>
              {/* 🛡️ BOT PROTECTION SECTION: PHONE OTP VERIFICATION */}
              <div className="p-3.5 bg-stone-800/70 border border-stone-700 rounded-2xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-purple-400" />
                    <span className="text-xs font-bold text-white">Anti-Spam Phone Verification (OTP)</span>
                  </div>
                  {isOtpVerified ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/30">
                      <CheckCircle2 className="w-3 h-3" /> Phone Verified
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-[11px] font-bold transition flex items-center gap-1 cursor-pointer"
                    >
                      <KeyRound className="w-3 h-3" />
                      <span>{generatedOtp ? 'Resend OTP' : 'Send Code'}</span>
                    </button>
                  )}
                </div>

                {otpNotice && (
                  <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-200 text-xs font-mono flex items-center justify-between">
                    <span>{otpNotice}</span>
                    {!isOtpVerified && generatedOtp && (
                      <button
                        type="button"
                        onClick={() => setEnteredOtp(generatedOtp)}
                        className="text-[10px] text-purple-300 hover:text-white underline font-sans ml-2 cursor-pointer"
                      >
                        Auto-fill
                      </button>
                    )}
                  </div>
                )}

                {otpError && (
                  <div className="text-[11px] text-rose-400 font-medium">
                    {otpError}
                  </div>
                )}

                {!isOtpVerified && generatedOtp && (
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      maxLength={6}
                      placeholder="Enter 4-digit code"
                      value={enteredOtp}
                      onChange={(e) => setEnteredOtp(e.target.value)}
                      className="w-36 px-3 py-1.5 bg-stone-900 border border-stone-600 rounded-xl text-xs font-mono text-center tracking-widest text-white focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                    />
                    <button
                      type="button"
                      onClick={handleVerifyOtp}
                      className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                    >
                      Verify Code
                    </button>
                  </div>
                )}
              </div>

              {/* 🛡️ BOT PROTECTION SECTION: MATH CAPTCHA */}
              <div className="p-3.5 bg-stone-800/70 border border-stone-700 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-white flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    Human Verification (Math Captcha) *
                  </label>
                  <button
                    type="button"
                    onClick={generateCaptcha}
                    title="Generate new calculation"
                    className="p-1 text-stone-400 hover:text-stone-200 rounded-lg transition cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-3">
                  <div className="px-4 py-2 bg-stone-950 border border-purple-500/40 rounded-xl text-sm font-mono font-black text-purple-300 tracking-wider select-none shadow-inner">
                    {captchaNumA} + {captchaNumB} = ?
                  </div>
                  <input
                    type="number"
                    required
                    placeholder="Enter answer"
                    value={captchaAnswer}
                    onChange={(e) => setCaptchaAnswer(e.target.value)}
                    className="w-36 px-3 py-2 bg-stone-900 border border-stone-600 rounded-xl text-xs font-mono text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-purple-500"
                  />
                  <span className="text-[11px] text-stone-400">Protects against automated bot registrations</span>
                </div>

                {captchaError && (
                  <p className="text-[11px] text-rose-400 font-semibold">{captchaError}</p>
                )}
              </div>
            </>
          ) : (
            <div className="p-3 bg-emerald-950/30 border border-emerald-500/30 rounded-2xl flex items-center justify-between text-xs text-emerald-300">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Super Admin privilege active: Bot verification bypassed.</span>
              </div>
              <span className="font-mono text-[10px] bg-emerald-500/20 px-2 py-0.5 rounded text-emerald-200 font-bold">
                Auto-Approve Enabled
              </span>
            </div>
          )}

          {/* Modal Actions */}
          <div className="pt-4 border-t border-stone-800 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-xl text-xs font-semibold transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-purple-600/30 transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Registering Online...</span>
                </>
              ) : (
                <>
                  <Database className="w-3.5 h-3.5" />
                  <span>Submit for Approval</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
