import React from 'react';
import { FoodDietType } from '../types';

interface DietBadgeProps {
  type: FoodDietType;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg' | string;
}

export const DietBadge: React.FC<DietBadgeProps> = ({ type, showLabel = false, size = 'md' }) => {
  const outerSize = size === 'sm' ? 'w-3.5 h-3.5' : size === 'lg' ? 'w-5 h-5' : 'w-4 h-4';
  const innerDot = size === 'sm' ? 'w-1.5 h-1.5' : size === 'lg' ? 'w-2.5 h-2.5' : 'w-2 h-2';

  if (type === 'veg') {
    return (
      <span className="inline-flex items-center gap-1.5" title="Pure Vegetarian">
        <span className={`${outerSize} rounded-xs border-2 border-emerald-600 flex items-center justify-center p-0.5 bg-emerald-50/80 shrink-0`}>
          <span className={`${innerDot} rounded-full bg-emerald-600`}></span>
        </span>
        {showLabel && <span className="text-xs font-semibold text-emerald-700">VEG</span>}
      </span>
    );
  }

  if (type === 'egg') {
    return (
      <span className="inline-flex items-center gap-1.5" title="Contains Egg">
        <span className={`${outerSize} rounded-xs border-2 border-amber-600 flex items-center justify-center p-0.5 bg-amber-50/80 shrink-0`}>
          <span className={`${innerDot} rounded-full bg-amber-600`}></span>
        </span>
        {showLabel && <span className="text-xs font-semibold text-amber-700">EGG</span>}
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5" title="Non-Vegetarian">
      <span className={`${outerSize} rounded-xs border-2 border-red-600 flex items-center justify-center p-0.5 bg-red-50/80 shrink-0`}>
        <span className={`${innerDot} rounded-xs bg-red-600 transform rotate-45 scale-75`}></span>
      </span>
      {showLabel && <span className="text-xs font-semibold text-red-700">NON-VEG</span>}
    </span>
  );
};
