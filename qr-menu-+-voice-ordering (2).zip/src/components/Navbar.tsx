import React, { useState, useRef, useEffect } from 'react';
import { 
  Search, 
  Bell, 
  User, 
  Menu, 
  X, 
  Sun, 
  Moon, 
  ChevronDown, 
  Store, 
  ShoppingBag, 
  BarChart3, 
  Settings, 
  Crown, 
  Shield, 
  UserCheck, 
  QrCode, 
  Check, 
  LogOut, 
  Utensils,
  Sparkles,
  Layers,
  Users
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Business, AppStaffRole } from '../types';
import { ROLE_CONFIGS } from '../lib/roleAccessControl';
import { PrintQRModal } from './PrintQRModal';

interface NavbarProps {
  currentView?: 'customer' | 'owner' | 'orders' | 'duty' | 'master_admin';
  onViewChange?: (view: 'customer' | 'owner' | 'orders' | 'duty' | 'master_admin') => void;
  businesses?: Business[];
  selectedBusinessId?: string;
  activeBusiness?: Business | null;
  onSelectBusiness?: (businessId: string) => void;
  onEditBusiness?: (businessId: string) => void;
  onDeleteBusiness?: (businessId: string) => void;
  onCreateNewBusiness?: () => void;
  onOpenAuthModal?: (mode?: 'login' | 'signup') => void;
  onOpenPartnerSignIn?: () => void;
  currentStaffRole?: AppStaffRole;
  staffName?: string;
  onOpenRoleSwitcher?: () => void;
  onSelectTenantView?: (tenantType: 'restaurant' | 'guesthouse', locationId: string, businessId?: string) => void;
  // Optional search callback
  onSearchChange?: (query: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView = 'customer',
  onViewChange = () => {},
  businesses = [],
  selectedBusinessId = 'laxmi-pizza',
  activeBusiness = null,
  onSelectBusiness = () => {},
  onSelectTenantView,
  onCreateNewBusiness = () => {},
  onOpenAuthModal,
  onOpenPartnerSignIn,
  currentStaffRole = 'owner',
  staffName,
  onOpenRoleSwitcher,
  onSearchChange,
}) => {
  // Navigation & Dropdown State
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState<boolean>(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSearchExpandedMobile, setIsSearchExpandedMobile] = useState<boolean>(false);
  const [isQRModalOpen, setIsQRModalOpen] = useState<boolean>(false);

  // Dropdown click-outside refs
  const profileDropdownRef = useRef<HTMLDivElement>(null);
  const notificationsDropdownRef = useRef<HTMLDivElement>(null);

  // Derive active business and role
  const currentBiz = activeBusiness || businesses.find((b) => b.id === selectedBusinessId) || businesses[0];
  const roleConfig = ROLE_CONFIGS[currentStaffRole] || ROLE_CONFIGS.owner;
  const effectiveStaffName = staffName || (
    currentStaffRole === 'owner' ? 'Owner / Admin' : 
    currentStaffRole === 'manager' ? 'Captain Priya' : 'Waiter Ramesh'
  );

  // Sample dynamic notifications
  const [notifications, setNotifications] = useState([
    { id: '1', title: 'New Table 05 Order', time: 'Just now', unread: true, type: 'order' },
    { id: '2', title: 'Room 102 Service Call', time: '5m ago', unread: true, type: 'service' },
    { id: '3', title: 'Menu sync completed', time: '20m ago', unread: false, type: 'system' }
  ]);

  const unreadCount = notifications.filter(n => n.unread).length;

  // Handle Search Input
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchQuery(val);
    if (onSearchChange) onSearchChange(val);
  };

  // Handle direct tenant preview switching
  const handleTenantClick = (e: React.MouseEvent, type: 'restaurant' | 'guesthouse', id: string, defaultBizId: string) => {
    e.preventDefault();
    setIsMobileMenuOpen(false);
    setIsProfileDropdownOpen(false);
    if (onSelectTenantView) {
      onSelectTenantView(type, id, defaultBizId);
    } else {
      onSelectBusiness(defaultBizId);
      onViewChange('customer');
      if (typeof window !== 'undefined') {
        const paramKey = type === 'guesthouse' ? 'room' : 'table';
        const newUrl = `?type=${type}&bizId=${defaultBizId}&${paramKey}=${id}`;
        window.history.pushState(null, '', newUrl);
      }
    }
  };

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        profileDropdownRef.current && 
        !profileDropdownRef.current.contains(event.target as Node)
      ) {
        setIsProfileDropdownOpen(false);
      }
      if (
        notificationsDropdownRef.current && 
        !notificationsDropdownRef.current.contains(event.target as Node)
      ) {
        setIsNotificationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Primary Center Navigation Items
  const navItems = [
    { key: 'customer', label: 'Home / Menu', icon: Utensils, active: currentView === 'customer' },
    { key: 'orders', label: 'Live Orders', icon: ShoppingBag, active: currentView === 'orders', badge: 'Live' },
    { key: 'duty', label: 'Staff Duty', icon: Users, active: currentView === 'duty' },
    { key: 'owner', label: 'Admin & Settings', icon: Settings, active: currentView === 'owner' }
  ];

  return (
    <>
      <header className="bg-stone-900 text-stone-100 border-b border-stone-800 sticky top-0 z-40 shadow-md">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-3 sm:gap-6">
          
          {/* ═══════════════════════════════════════════════════════════ */}
          {/* 1. LEFT: Hamburger Menu Icon & Brand Logo                   */}
          {/* ═══════════════════════════════════════════════════════════ */}
          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            {/* 3-Line Hamburger Menu Toggle (Visible on ALL Screen Sizes) */}
            <button
              type="button"
              id="navbar-hamburger-btn"
              aria-label={isMobileMenuOpen ? "Close navigation menu" : "Open navigation menu"}
              title="Navigation Menu"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`flex items-center justify-center p-2 rounded-xl transition-all focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer border ${
                isMobileMenuOpen
                  ? 'bg-amber-500 text-stone-950 border-amber-400 shadow-sm'
                  : 'text-stone-300 hover:text-white bg-stone-800/80 hover:bg-stone-800 border-stone-750'
              }`}
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </button>

            {/* Brand Logo & Title */}
            <div 
              onClick={() => onViewChange('customer')}
              className="flex items-center gap-2.5 cursor-pointer group"
            >
              {currentBiz?.logoUrl ? (
                <img
                  src={currentBiz.logoUrl}
                  alt={currentBiz.name || 'Brand Logo'}
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-xl object-cover border border-amber-500/40 shadow-xs group-hover:scale-105 transition-transform"
                />
              ) : (
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 text-stone-950 flex items-center justify-center font-black text-base shadow-sm group-hover:scale-105 transition-transform">
                  {currentBiz?.name ? currentBiz.name.charAt(0) : 'Q'}
                </div>
              )}

              <div className="flex flex-col">
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-sm sm:text-base tracking-tight text-white group-hover:text-amber-400 transition-colors truncate max-w-[150px] sm:max-w-[240px]">
                    {currentBiz ? currentBiz.name : 'QR Restaurant Hub'}
                  </span>
                  <span className="hidden xl:inline-block px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    POS
                  </span>
                </div>
                <span className="text-[11px] text-stone-400 font-mono hidden sm:block -mt-0.5">
                  {currentBiz?.city ? `${currentBiz.city} • Self-Service Portal` : 'Smart QR System'}
                </span>
              </div>
            </div>
          </div>

          {/* ═══════════════════════════════════════════════════════════ */}
          {/* 2. RIGHT: Search Bar, Notifications, Dark Mode & Profile    */}
          {/* ═══════════════════════════════════════════════════════════ */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            
            {/* Desktop Search Bar */}
            <div className="hidden lg:flex items-center relative">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 pointer-events-none" />
              <input
                id="navbar-desktop-search"
                type="text"
                value={searchQuery}
                onChange={handleSearch}
                placeholder="Search menu or orders..."
                className="w-44 xl:w-56 pl-9 pr-3 py-1.5 rounded-xl bg-stone-800/90 border border-stone-700 text-xs text-stone-100 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => { setSearchQuery(''); if (onSearchChange) onSearchChange(''); }}
                  className="absolute right-2 text-stone-400 hover:text-white text-xs"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Mobile Search Toggle Button */}
            <button
              type="button"
              id="navbar-mobile-search-toggle"
              aria-label="Toggle mobile search"
              onClick={() => setIsSearchExpandedMobile(!isSearchExpandedMobile)}
              className="lg:hidden p-2 rounded-xl text-stone-300 hover:text-white hover:bg-stone-800 transition-colors"
            >
              <Search className="w-4 h-4 text-amber-400" />
            </button>

            {/* Dark Mode Toggle Switch */}
            <button
              type="button"
              id="navbar-darkmode-toggle"
              aria-label="Toggle Dark Mode"
              onClick={() => setIsDarkMode(!isDarkMode)}
              title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
              className="p-2 rounded-xl text-stone-300 hover:text-amber-400 hover:bg-stone-800 transition-colors cursor-pointer"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Super Admin Console Quick Switcher */}
            <button
              type="button"
              id="navbar-super-admin-btn"
              title="Open Platform Super-Admin Console (/admin/super-dashboard)"
              onClick={() => {
                onViewChange('master_admin');
                if (typeof window !== 'undefined') {
                  window.history.pushState(null, '', '/admin/super-dashboard');
                }
              }}
              className={`hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                currentView === 'master_admin'
                  ? 'bg-purple-600 text-white border-purple-400 shadow-sm'
                  : 'bg-purple-950/40 hover:bg-purple-900/50 text-purple-300 border-purple-500/30'
              }`}
            >
              <Crown className="w-3.5 h-3.5 text-purple-300" />
              <span>Super-Admin</span>
            </button>

            {/* Partner Sign In Button (Supabase Passwordless OTP) */}
            {onOpenPartnerSignIn && (
              <button
                type="button"
                id="navbar-partner-signin-btn"
                title="Restaurant Partner Sign In (Passwordless Supabase OTP)"
                onClick={onOpenPartnerSignIn}
                className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-950/50 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95"
              >
                <Store className="w-3.5 h-3.5 text-emerald-400" />
                <span>Partner Login</span>
              </button>
            )}

            {/* Restaurant Onboarding Button */}
            <button
              type="button"
              id="navbar-onboard-restaurant-btn"
              title="Onboard New Restaurant (Instant AI Menu Extraction & Counter QR)"
              onClick={onCreateNewBusiness}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-black text-xs transition-all cursor-pointer shadow-xs active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5 text-stone-950" />
              <span className="hidden sm:inline">+ Onboard Restaurant</span>
              <span className="sm:hidden">+ Onboard</span>
            </button>

            {/* QR Quick Print Button */}
            <button
              type="button"
              id="navbar-qr-modal-btn"
              onClick={() => setIsQRModalOpen(true)}
              title="Print Table / Room QR Codes"
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 text-xs font-bold transition-colors cursor-pointer"
            >
              <QrCode className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden md:inline">QR Stand</span>
            </button>

            {/* Notification Bell Dropdown */}
            <div className="relative" ref={notificationsDropdownRef}>
              <button
                type="button"
                id="navbar-notifications-btn"
                aria-label="View notifications"
                onClick={() => {
                  setIsNotificationsOpen(!isNotificationsOpen);
                  setIsProfileDropdownOpen(false);
                }}
                className="relative p-2 rounded-xl text-stone-300 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-amber-500 rounded-full ring-2 ring-stone-900 animate-pulse" />
                )}
              </button>

              {/* Notifications Dropdown Panel */}
              <AnimatePresence>
                {isNotificationsOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 mt-2 w-80 rounded-2xl bg-stone-900 border border-stone-800 shadow-2xl p-3 z-50 text-xs"
                  >
                    <div className="flex items-center justify-between pb-2 mb-2 border-b border-stone-800">
                      <div className="flex items-center gap-2">
                        <Bell className="w-4 h-4 text-amber-400" />
                        <span className="font-bold text-white">Notifications</span>
                      </div>
                      {unreadCount > 0 && (
                        <button
                          type="button"
                          onClick={() => setNotifications(notifications.map(n => ({ ...n, unread: false })))}
                          className="text-[11px] text-amber-400 hover:underline cursor-pointer"
                        >
                          Mark all read
                        </button>
                      )}
                    </div>

                    <div className="space-y-1.5 max-h-60 overflow-y-auto">
                      {notifications.map((n) => (
                        <div
                          key={n.id}
                          className={`p-2.5 rounded-xl transition-colors ${
                            n.unread ? 'bg-stone-800/90 text-white font-medium border border-amber-500/20' : 'bg-stone-900/50 text-stone-400'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold">{n.title}</span>
                            <span className="text-[10px] text-stone-500">{n.time}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* User Profile Avatar Menu Dropdown */}
            <div className="relative" ref={profileDropdownRef}>
              <button
                type="button"
                id="navbar-user-avatar-btn"
                aria-label="User account menu"
                onClick={() => {
                  setIsProfileDropdownOpen(!isProfileDropdownOpen);
                  setIsNotificationsOpen(false);
                }}
                className="flex items-center gap-2 p-1 sm:px-2.5 sm:py-1 rounded-xl hover:bg-stone-800 transition-colors cursor-pointer border border-transparent hover:border-stone-700"
              >
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shadow-xs ${
                  currentStaffRole === 'owner' ? 'bg-amber-500 text-stone-950' :
                  currentStaffRole === 'manager' ? 'bg-sky-500 text-stone-950' : 'bg-emerald-500 text-stone-950'
                }`}>
                  {currentStaffRole === 'owner' ? <Crown className="w-4 h-4" /> :
                   currentStaffRole === 'manager' ? <Shield className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                </div>

                <div className="hidden sm:flex flex-col text-left">
                  <span className="text-xs font-bold text-white truncate max-w-[90px]">
                    {effectiveStaffName}
                  </span>
                  <span className="text-[10px] text-amber-400 capitalize font-mono -mt-0.5">
                    {currentStaffRole}
                  </span>
                </div>

                <ChevronDown className="w-3.5 h-3.5 text-stone-400 hidden sm:block" />
              </button>

              {/* Profile Dropdown Menu */}
              <AnimatePresence>
                {isProfileDropdownOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 mt-2 w-64 rounded-2xl bg-stone-900 border border-stone-800 shadow-2xl p-2 z-50 text-xs"
                  >
                    {/* User Info Header */}
                    <div className="p-3 bg-stone-950/60 rounded-xl mb-1 border border-stone-800/80">
                      <div className="font-bold text-white text-sm">{effectiveStaffName}</div>
                      <div className="text-[11px] text-stone-400 font-mono flex items-center gap-1.5 mt-0.5">
                        <span className="inline-block w-2 h-2 rounded-full bg-emerald-400" />
                        Role: <span className="text-amber-400 font-bold uppercase">{currentStaffRole}</span>
                      </div>
                    </div>

                    {/* Super Admin Link */}
                    <button
                      type="button"
                      onClick={() => {
                        setIsProfileDropdownOpen(false);
                        onViewChange('master_admin');
                        if (typeof window !== 'undefined') {
                          window.history.pushState(null, '', '/admin/super-dashboard');
                        }
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 transition-colors text-left font-bold cursor-pointer my-1"
                    >
                      <Crown className="w-4 h-4 text-purple-400" />
                      <div className="flex flex-col">
                        <span>Super-Admin Fleet Console</span>
                        <span className="text-[10px] text-purple-400/80 font-normal">/admin/super-dashboard</span>
                      </div>
                    </button>

                    {/* Restaurant Partner Sign In (Supabase OTP) */}
                    {onOpenPartnerSignIn && (
                      <button
                        type="button"
                        id="navbar-dropdown-partner-signin"
                        onClick={() => {
                          setIsProfileDropdownOpen(false);
                          onOpenPartnerSignIn();
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 border border-emerald-500/30 transition-colors text-left font-bold cursor-pointer my-1"
                      >
                        <Store className="w-4 h-4 text-emerald-400" />
                        <div className="flex flex-col">
                          <span>Restaurant Partner Sign In</span>
                          <span className="text-[10px] text-stone-400 font-normal">Passwordless Supabase OTP</span>
                        </div>
                      </button>
                    )}

                    {/* Sign In / Business Auth Trigger */}
                    {onOpenAuthModal && (
                      <button
                        type="button"
                        id="navbar-open-auth-btn"
                        onClick={() => {
                          setIsProfileDropdownOpen(false);
                          onOpenAuthModal('login');
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-amber-300 hover:bg-amber-500/10 hover:text-amber-200 transition-colors text-left font-bold cursor-pointer"
                      >
                        <UserCheck className="w-4 h-4 text-amber-400" />
                        <span>Sign In / Switch Account</span>
                      </button>
                    )}

                    {/* Switch Role Trigger */}
                    {onOpenRoleSwitcher && (
                      <button
                        type="button"
                        onClick={() => {
                          setIsProfileDropdownOpen(false);
                          onOpenRoleSwitcher();
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-stone-200 hover:bg-stone-800 hover:text-amber-400 transition-colors text-left font-medium cursor-pointer"
                      >
                        <Shield className="w-4 h-4 text-amber-400" />
                        <span>Switch Staff Role (Owner / Captain)</span>
                      </button>
                    )}

                    {/* Quick Link to Restaurant Switcher / New Outlet */}
                    <button
                      type="button"
                      onClick={() => {
                        setIsProfileDropdownOpen(false);
                        if (onOpenAuthModal) {
                          onOpenAuthModal('signup');
                        } else {
                          onCreateNewBusiness();
                        }
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-stone-200 hover:bg-stone-800 hover:text-amber-400 transition-colors text-left font-medium cursor-pointer"
                    >
                      <Store className="w-4 h-4 text-amber-400" />
                      <span>Register New Property (Restaurant/Hotel)</span>
                    </button>

                    <div className="h-px bg-stone-800 my-1" />

                    {/* Mode Quick Links */}
                    <a
                      href="/?type=restaurant&bizId=city-diner&table=05"
                      onClick={(e) => handleTenantClick(e, 'restaurant', '05', 'city-diner')}
                      className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-stone-300 hover:bg-stone-800 hover:text-amber-300 text-[11px] cursor-pointer"
                    >
                      <span>🍽️ Preview as Restaurant (Table 05)</span>
                    </a>
                    <a
                      href="/?type=guesthouse&bizId=green-villa-guesthouse&room=102"
                      onClick={(e) => handleTenantClick(e, 'guesthouse', '102', 'green-villa-guesthouse')}
                      className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-stone-300 hover:bg-stone-800 hover:text-emerald-300 text-[11px] cursor-pointer"
                    >
                      <span>🏨 Preview as Guest House (Room 102)</span>
                    </a>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* ═══════════════════════════════════════════════════════════ */}
        {/* MOBILE SEARCH BAR EXPANSION                                  */}
        {/* ═══════════════════════════════════════════════════════════ */}
        <AnimatePresence>
          {isSearchExpandedMobile && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="lg:hidden px-3 pb-3 border-b border-stone-800 overflow-hidden"
            >
              <div className="relative">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={handleSearch}
                  placeholder="Search menu or orders..."
                  className="w-full pl-9 pr-8 py-2 rounded-xl bg-stone-800 border border-stone-700 text-xs text-white placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => { setSearchQuery(''); if (onSearchChange) onSearchChange(''); }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* 4. MOBILE DRAWER / OVERLAY MENU                                */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            {/* Backdrop Overlay (Universal on all screen sizes) */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/75 backdrop-blur-xs z-50 transition-opacity"
            />

            {/* Slide-out Drawer (Universal on all screen sizes) */}
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="fixed top-0 bottom-0 left-0 w-[300px] sm:w-[340px] bg-stone-900 border-r border-stone-800 z-50 flex flex-col p-4 sm:p-5 shadow-2xl overflow-y-auto"
            >
              {/* Drawer Header */}
              <div className="flex items-center justify-between pb-4 border-b border-stone-800">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-black text-sm">
                    {currentBiz?.name ? currentBiz.name.charAt(0) : 'Q'}
                  </div>
                  <div>
                    <h2 className="font-extrabold text-sm text-white truncate max-w-[150px]">
                      {currentBiz?.name || 'QR Menu Hub'}
                    </h2>
                    <span className="text-[10px] text-stone-400 font-mono">
                      {currentStaffRole.toUpperCase()} Active
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Navigation Links List */}
              <div className="py-4 space-y-1.5 flex-1">
                <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 px-3 mb-2">
                  Navigation
                </div>
                {navItems.map((item) => {
                  const Icon = item.icon || Utensils;
                  return (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => {
                        onViewChange(item.key as any);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold transition-colors ${
                        item.active
                          ? 'bg-amber-500 text-stone-950'
                          : 'text-stone-300 hover:bg-stone-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </div>
                      {item.badge && (
                        <span className="px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}

                {/* Super Admin Mobile Entry */}
                <button
                  type="button"
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onViewChange('master_admin');
                    if (typeof window !== 'undefined') {
                      window.history.pushState(null, '', '/admin/super-dashboard');
                    }
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-purple-950/60 to-stone-900 border border-purple-500/30 text-purple-300 text-xs font-bold transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <Crown className="w-4 h-4 text-purple-400" />
                    <span>Platform Super-Admin View</span>
                  </div>
                  <span className="px-1.5 py-0.5 text-[9px] font-mono font-black uppercase rounded bg-purple-500/30 text-purple-200">
                    Fleet Console
                  </span>
                </button>

                {/* Restaurant Fast Onboarding Mobile Entry */}
                <button
                  type="button"
                  id="mobile-onboard-restaurant-btn"
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onCreateNewBusiness();
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 text-stone-950 text-xs font-black shadow-md transition-all cursor-pointer active:scale-95"
                >
                  <div className="flex items-center gap-2.5">
                    <Sparkles className="w-4 h-4 text-stone-950" />
                    <span>+ Onboard New Restaurant</span>
                  </div>
                  <span className="px-1.5 py-0.5 text-[9px] font-mono font-black uppercase rounded bg-stone-950/20 text-stone-950">
                    AI Menu
                  </span>
                </button>

                {/* Partner Sign In Mobile Entry */}
                {onOpenPartnerSignIn && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onOpenPartnerSignIn();
                    }}
                    className="w-full flex items-center justify-between p-3 rounded-2xl bg-gradient-to-r from-emerald-950/60 to-stone-900 border border-emerald-500/30 text-emerald-300 text-xs font-bold transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5">
                      <Store className="w-4 h-4 text-emerald-400" />
                      <span>Restaurant Partner Sign In</span>
                    </div>
                    <span className="px-1.5 py-0.5 text-[9px] font-mono font-black uppercase rounded bg-emerald-500/30 text-emerald-200">
                      OTP Login
                    </span>
                  </button>
                )}

                {/* Sign In / Register Mobile Entry */}
                {onOpenAuthModal && (
                  <div className="grid grid-cols-2 gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        onOpenAuthModal('login');
                      }}
                      className="p-2.5 rounded-xl bg-stone-800 hover:bg-stone-750 text-amber-300 border border-amber-500/30 text-xs font-bold text-center transition cursor-pointer"
                    >
                      Sign In
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        onOpenAuthModal('signup');
                      }}
                      className="p-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-black text-center transition cursor-pointer"
                    >
                      + Register
                    </button>
                  </div>
                )}

                {/* Quick Testing Modes */}
                <div className="pt-4 border-t border-stone-800 mt-4 space-y-2">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 px-3">
                    Tenant Testing Links
                  </div>
                  <a
                    href="/?type=restaurant&bizId=city-diner&table=05"
                    onClick={(e) => handleTenantClick(e, 'restaurant', '05', 'city-diner')}
                    className="block p-2.5 rounded-xl bg-stone-800/80 hover:bg-stone-800 border border-stone-750 text-left transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                      <Utensils className="w-3.5 h-3.5 text-amber-400" />
                      <span>🍽️ Restaurant View (Table 05)</span>
                    </div>
                  </a>
                  <a
                    href="/?type=guesthouse&bizId=green-villa-guesthouse&room=102"
                    onClick={(e) => handleTenantClick(e, 'guesthouse', '102', 'green-villa-guesthouse')}
                    className="block p-2.5 rounded-xl bg-stone-800/80 hover:bg-stone-800 border border-stone-750 text-left transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                      <Store className="w-3.5 h-3.5 text-emerald-400" />
                      <span>🏨 Guest House View (Room 102)</span>
                    </div>
                  </a>
                </div>
              </div>

              {/* Drawer Footer Actions */}
              <div className="pt-3 border-t border-stone-800 space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    setIsQRModalOpen(true);
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-200 text-xs font-bold border border-stone-700"
                >
                  <QrCode className="w-4 h-4 text-amber-400" />
                  <span>Print QR Codes</span>
                </button>

                {onOpenRoleSwitcher && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onOpenRoleSwitcher();
                    }}
                    className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs font-bold"
                  >
                    <Shield className="w-4 h-4 text-amber-400" />
                    <span>Switch Role: {effectiveStaffName}</span>
                  </button>
                )}
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* QR Code Stand & Stickers Modal */}
      {currentBiz && (
        <PrintQRModal
          isOpen={isQRModalOpen}
          onClose={() => setIsQRModalOpen(false)}
          business={currentBiz}
        />
      )}
    </>
  );
};
export default Navbar;
