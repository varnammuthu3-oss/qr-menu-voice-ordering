import React, { useState, useEffect } from 'react';
import { Business } from '../types';
import { saveBusiness, checkIfBusinessIdExists } from '../services/db';
import { X, Plus, Store, Sparkles, AlertCircle, Database, ShieldCheck, RotateCcw, Clock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { saveRestaurant } from '../utils/shopPersistence';

interface NewBusinessModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBusinessCreated: (newBiz: Business) => void;
}

export const NewBusinessModal: React.FC<NewBusinessModalProps> = ({
  isOpen,
  onClose,
  onBusinessCreated,
}) => {
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [phone, setPhone] = useState('+91 ');
  const [whatsappNumber, setWhatsappNumber] = useState('+91 ');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Bengaluru');
  const [openingHours, setOpeningHours] = useState('Mon - Sun: 7:00 AM – 10:30 PM');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Anti-bot state
  const [captchaNumA, setCaptchaNumA] = useState(6);
  const [captchaNumB, setCaptchaNumB] = useState(4);
  const [captchaAnswer, setCaptchaAnswer] = useState('');
  const [honeypot, setHoneypot] = useState('');

  const refreshCaptcha = () => {
    setCaptchaNumA(Math.floor(Math.random() * 8) + 2);
    setCaptchaNumB(Math.floor(Math.random() * 7) + 3);
    setCaptchaAnswer('');
  };

  useEffect(() => {
    if (isOpen) {
      refreshCaptcha();
      setHoneypot('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleNameChange = (val: string) => {
    setName(val);
    setErrorMessage(null);
    // Auto generate clean slug
    const generatedSlug = val
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
    setSlug(generatedSlug);
  };

  // Connect your "Register New Property" form to Supabase
  async function handleRestaurantRegistration(formData: {
    name: string;
    slug?: string;
    tables?: string[];
    features?: { enable_whatsapp_orders: boolean; enable_table_selector: boolean };
  }) {
    const newShop = {
      id: formData.slug || formData.name.toLowerCase().replace(/\s+/g, '-'),
      name: formData.name,
      tables: formData.tables || ["1", "2", "3", "4", "5"],
      features: { enable_whatsapp_orders: true, enable_table_selector: true },
      is_approved: false // Prompt 3: Default is_approved = false
    };

    // Push directly to Supabase cloud database with is_approved: false
    const { data, error } = await supabase
      .from('restaurants')
      .insert([{
        ...newShop,
        is_approved: false
      }]);

    if (error) {
      console.error("Error saving to cloud:", error.message);
    } else {
      console.log("Restaurant registered online with is_approved: false");
    }

    return { newShop, error, data };
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setErrorMessage(null);

    // Bot trap check
    if (honeypot.trim().length > 0) {
      setErrorMessage('Automated submission rejected.');
      return;
    }

    // Math CAPTCHA check
    if (parseInt(captchaAnswer.trim(), 10) !== captchaNumA + captchaNumB) {
      setErrorMessage(`Incorrect verification answer. What is ${captchaNumA} + ${captchaNumB}?`);
      refreshCaptcha();
      return;
    }

    const cleanName = name.trim();
    const cleanSlug = slug.trim().toLowerCase();

    if (!cleanName) {
      setErrorMessage('Please enter a restaurant name.');
      return;
    }
    if (!cleanSlug) {
      setErrorMessage('Please enter a valid URL slug / ID.');
      return;
    }

    setIsSubmitting(true);
    try {
      // Check if duplicate ID exists
      const exists = await checkIfBusinessIdExists(cleanSlug);
      if (exists) {
        setErrorMessage(`A restaurant with ID "${cleanSlug}" already exists. Please choose a different name or URL slug.`);
        setIsSubmitting(false);
        return;
      }

      // 1. Push to Supabase with is_approved: false
      const { newShop } = await handleRestaurantRegistration({
        name: cleanName,
        slug: cleanSlug,
        tables: ["1", "2", "3", "4", "5"],
        features: { enable_whatsapp_orders: true, enable_table_selector: true },
      });

      // 2. Persist to PWA local storage with is_approved: false
      saveRestaurant(newShop);

      const newBiz: Business = {
        id: cleanSlug,
        ownerUid: 'owner-created-' + Date.now(),
        name: cleanName,
        tagline: 'Freshly prepared food & beverages',
        logoUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=200&auto=format&fit=crop&q=80',
        coverUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=80',
        address: address.trim() || `${city}, India`,
        city: city.trim(),
        phone: phone.trim(),
        whatsappNumber: whatsappNumber.trim(),
        openingHours: openingHours.trim(),
        currencySymbol: '₹',
        tables: newShop.tables,
        features: newShop.features,
        isActive: true,
        is_approved: false, // Prompt 3: Default is_approved = false
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      // saveBusiness writes to local cache + Firestore seamlessly
      await saveBusiness(newBiz);
      onBusinessCreated(newBiz);
      onClose();
    } catch (err: any) {
      console.error('Failed to create new business:', err);
      // Safe fallback creation
      const fallbackBiz: Business = {
        id: cleanSlug,
        ownerUid: 'owner-created-' + Date.now(),
        name: cleanName,
        tagline: 'Freshly prepared food & beverages',
        logoUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=200&auto=format&fit=crop&q=80',
        coverUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=80',
        address: address.trim() || `${city}, India`,
        city: city.trim(),
        phone: phone.trim(),
        whatsappNumber: whatsappNumber.trim(),
        openingHours: openingHours.trim(),
        currencySymbol: '₹',
        isActive: true,
        is_approved: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      onBusinessCreated(fallbackBiz);
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-amber-600" />
            <h3 className="font-bold text-base text-stone-900">Create New Restaurant</h3>
          </div>
          <button onClick={onClose} className="text-stone-400 hover:text-stone-700 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Approval Notice */}
        <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-center gap-2">
          <Clock className="w-4 h-4 shrink-0 text-amber-600" />
          <span>New properties register with status <strong className="font-semibold">Pending Approval (is_approved: false)</strong> until verified by Master Admin.</span>
        </div>

        {errorMessage && (
          <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Honeypot */}
          <input
            type="text"
            name="site_url_trap"
            value={honeypot}
            onChange={(e) => setHoneypot(e.target.value)}
            style={{ display: 'none', position: 'absolute', opacity: 0, pointerEvents: 'none' }}
            tabIndex={-1}
            autoComplete="off"
          />

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              Restaurant Name *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="e.g. Royal Grand Restaurant"
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">
              URL Slug / Business ID *
            </label>
            <input
              type="text"
              required
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
              placeholder="e.g. royal-grand-restaurant"
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-mono text-stone-800 focus:outline-hidden focus:border-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">Phone Number *</label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                WhatsApp Number *
              </label>
              <input
                type="text"
                required
                value={whatsappNumber}
                onChange={(e) => setWhatsappNumber(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700 mb-1">Address *</label>
            <input
              type="text"
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. 5th Main Road, Jayanagar 4th Block"
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">City</label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Opening Hours
              </label>
              <input
                type="text"
                value={openingHours}
                onChange={(e) => setOpeningHours(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
              />
            </div>
          </div>

          {/* Math CAPTCHA Anti-bot */}
          <div className="p-3 bg-stone-50 border border-stone-200 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                Anti-Bot Math Verification *
              </label>
              <button
                type="button"
                onClick={refreshCaptcha}
                className="text-stone-400 hover:text-stone-600 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="flex items-center gap-3">
              <div className="px-3 py-1.5 bg-stone-200 border border-stone-300 rounded-lg text-xs font-mono font-bold text-stone-800">
                {captchaNumA} + {captchaNumB} = ?
              </div>
              <input
                type="number"
                required
                placeholder="Answer"
                value={captchaAnswer}
                onChange={(e) => setCaptchaAnswer(e.target.value)}
                className="w-28 px-3 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-mono text-stone-800 focus:outline-hidden focus:border-amber-500"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-stone-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? 'Submitting...' : 'Register Property'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
