import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Mail, KeyRound, CheckCircle2, AlertCircle, Loader2, ArrowRight, X, ShieldCheck, RefreshCw, LogOut, Store } from 'lucide-react';
import { Business } from '../types';

interface PartnerSignInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (userEmail: string) => void;
  currentBusiness?: Business | null;
}

export const PartnerSignInModal: React.FC<PartnerSignInModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  currentBusiness
}) => {
  const [step, setStep] = useState<'email' | 'otp' | 'success'>('email');
  const [email, setEmail] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [currentSessionUser, setCurrentSessionUser] = useState<string | null>(null);
  const [resendCooldown, setResendCooldown] = useState(0);

  // Check existing Supabase session on open
  useEffect(() => {
    if (!isOpen) return;

    // Reset temporary states
    setErrorMessage(null);
    setSuccessMessage(null);
    setIsLoading(false);

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user?.email) {
        setCurrentSessionUser(session.user.email);
      } else {
        const stored = typeof window !== 'undefined' ? localStorage.getItem('restaurant_partner_email') : null;
        if (stored) setCurrentSessionUser(stored);
      }
    }).catch(err => {
      console.warn('Could not fetch Supabase session:', err);
    });
  }, [isOpen]);

  // Resend cooldown timer
  useEffect(() => {
    if (resendCooldown <= 0) return;
    const timer = setTimeout(() => setResendCooldown(c => c - 1), 1000);
    return () => clearTimeout(timer);
  }, [resendCooldown]);

  if (!isOpen) return null;

  // 1. Send OTP code via Supabase
  const handleSendOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);

    const cleanEmail = email.trim();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setErrorMessage('Please enter a valid restaurant email address.');
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOtp({
        email: cleanEmail,
      });

      if (error) {
        setErrorMessage(`Error sending code: ${error.message}`);
      } else {
        setSuccessMessage(`Verification code sent to ${cleanEmail}`);
        setStep('otp');
        setResendCooldown(45);
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Network error while contacting Supabase Auth.');
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Verify 6-digit OTP code via Supabase
  const handleVerifyOtp = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);

    const cleanCode = otpCode.trim();
    if (!cleanCode || cleanCode.length !== 6) {
      setErrorMessage('Please enter the 6-digit verification code.');
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase.auth.verifyOtp({
        email: email.trim(),
        token: cleanCode,
        type: 'email',
      });

      if (error) {
        setErrorMessage(`Invalid code: ${error.message}`);
      } else {
        const verifiedEmail = email.trim();
        setCurrentSessionUser(verifiedEmail);
        setStep('success');

        if (typeof window !== 'undefined') {
          localStorage.setItem('restaurant_partner_email', verifiedEmail);
          localStorage.setItem('qr_menu_staff_role', 'owner');
          localStorage.setItem('qr_menu_staff_name', `${verifiedEmail.split('@')[0]} (Partner Owner)`);
        }

        setTimeout(() => {
          if (onSuccess) {
            onSuccess(verifiedEmail);
          }
          onClose();
        }, 1200);
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Verification failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Sign out handler
  const handleSignOut = async () => {
    setIsLoading(true);
    try {
      await supabase.auth.signOut();
      setCurrentSessionUser(null);
      if (typeof window !== 'undefined') {
        localStorage.removeItem('restaurant_partner_email');
      }
      setStep('email');
      setEmail('');
      setOtpCode('');
      setSuccessMessage('Successfully signed out.');
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to sign out.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div 
      id="partner-signin-backdrop"
      className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="partner-signin-card"
        className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-md p-6 sm:p-7 text-white shadow-2xl relative overflow-hidden"
      >
        {/* Decorative Top Accent */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 via-teal-400 to-amber-500" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-stone-400 hover:text-white hover:bg-stone-800 transition cursor-pointer"
          title="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-5">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <Store className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-black text-white tracking-tight">Restaurant Partner Sign In</h2>
          </div>
          <p className="text-xs text-stone-400">
            Secure passwordless login for your PWA dashboard.
          </p>

          {/* Supabase connection indicator */}
          <div className="mt-2.5 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-stone-800/80 border border-stone-700/60 text-[11px] text-stone-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-stone-400">Supabase Auth:</span>
            <span className="font-mono text-emerald-300 font-semibold truncate max-w-[190px]">gbrkjyhyrmdtwdakpghm</span>
          </div>
        </div>

        {/* Existing Session Notification */}
        {currentSessionUser && step === 'email' && (
          <div className="mb-4 p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl text-xs space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-300 font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Active Partner Session</span>
              </div>
              <button
                type="button"
                onClick={handleSignOut}
                disabled={isLoading}
                className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer"
              >
                <LogOut className="w-3 h-3" />
                <span>Sign Out</span>
              </button>
            </div>
            <p className="text-stone-300 text-[11px]">
              Currently signed in as <strong className="text-white font-mono">{currentSessionUser}</strong>
            </p>
            <button
              type="button"
              onClick={() => {
                if (onSuccess) onSuccess(currentSessionUser);
                onClose();
              }}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>Continue to Restaurant Dashboard</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Error Alert */}
        {errorMessage && (
          <div className="mb-4 p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span className="break-words">{errorMessage}</span>
          </div>
        )}

        {/* STEP 1: Enter Email Form */}
        {step === 'email' && !currentSessionUser && (
          <form id="email-step" onSubmit={handleSendOtp} className="space-y-4">
            <div>
              <label 
                htmlFor="email-input" 
                className="block text-xs font-semibold text-stone-300 mb-1.5"
              >
                Restaurant Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-500 absolute left-3 top-3" />
                <input
                  type="email"
                  id="email-input"
                  required
                  placeholder="name@restaurant.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isLoading}
                  className="w-full bg-stone-800 border border-stone-700 rounded-xl pl-9 pr-3 py-2.5 text-sm text-white placeholder-stone-500 focus:outline-hidden focus:border-emerald-500 transition"
                />
              </div>
              <p className="text-[11px] text-stone-400 mt-1">
                We'll email you a one-time 6-digit login code. No password required.
              </p>
            </div>

            <button
              type="submit"
              disabled={isLoading || !email.trim()}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-xl text-sm transition shadow-lg shadow-emerald-900/30 flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Sending Login Code...</span>
                </>
              ) : (
                <>
                  <span>Send Login Code</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* STEP 2: Enter 6-Digit Code Form */}
        {step === 'otp' && (
          <form id="otp-step" onSubmit={handleVerifyOtp} className="space-y-4">
            <div className="p-3 bg-stone-800/60 border border-stone-700/50 rounded-2xl">
              <div className="flex items-center justify-between text-xs">
                <span className="text-stone-400">Code sent to:</span>
                <button
                  type="button"
                  onClick={() => {
                    setStep('email');
                    setErrorMessage(null);
                  }}
                  className="text-amber-400 hover:text-amber-300 text-[11px] font-semibold cursor-pointer underline"
                >
                  Change Email
                </button>
              </div>
              <p className="text-sm font-bold text-white mt-0.5 truncate">{email}</p>
            </div>

            <div>
              <label 
                htmlFor="otp-input" 
                className="block text-xs font-semibold text-stone-300 mb-1.5"
              >
                Enter the 6-digit verification code sent to your inbox:
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-stone-500 absolute left-3 top-3" />
                <input
                  type="text"
                  id="otp-input"
                  required
                  maxLength={6}
                  autoFocus
                  placeholder="123456"
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value.replace(/[^0-9]/g, ''))}
                  disabled={isLoading}
                  className="w-full bg-stone-800 border border-stone-700 rounded-xl pl-9 pr-3 py-2.5 text-center text-xl font-mono tracking-widest text-white placeholder-stone-600 focus:outline-hidden focus:border-sky-500 transition font-bold"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || otpCode.trim().length !== 6}
              className="w-full py-3 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white font-bold rounded-xl text-sm transition shadow-lg shadow-sky-900/30 flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying Code...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>Verify & Login</span>
                </>
              )}
            </button>

            {/* Resend Action */}
            <div className="flex items-center justify-between text-xs text-stone-400 pt-1">
              <span>Didn't receive the email?</span>
              <button
                type="button"
                disabled={resendCooldown > 0 || isLoading}
                onClick={() => handleSendOtp()}
                className="text-emerald-400 hover:text-emerald-300 font-semibold disabled:text-stone-600 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1"
              >
                <RefreshCw className={`w-3 h-3 ${isLoading ? 'animate-spin' : ''}`} />
                <span>{resendCooldown > 0 ? `Resend in ${resendCooldown}s` : 'Resend Code'}</span>
              </button>
            </div>
          </form>
        )}

        {/* STEP 3: Success State */}
        {step === 'success' && (
          <div className="py-6 text-center space-y-3">
            <div className="w-14 h-14 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-2xl flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white">Login Successful!</h3>
            <p className="text-xs text-stone-300">
              Welcome to your restaurant platform. Loading merchant dashboard...
            </p>
          </div>
        )}

        {/* Footer info */}
        <div className="mt-5 pt-3 border-t border-stone-800 text-center">
          <button
            type="button"
            onClick={onClose}
            className="text-xs text-stone-400 hover:text-stone-200 transition cursor-pointer"
          >
            Cancel and Return
          </button>
        </div>
      </div>
    </div>
  );
};
