import React, { useState, useEffect } from 'react';
import { Business, MenuCategory, MenuItem, FoodDietType, MenuStyle } from '../types';
import { QRCodeView } from './QRCodeView';
import { DietBadge } from './DietBadge';
import { MenuPhotoExtractor } from './MenuPhotoExtractor';
import { MenuStyleSelector } from './MenuStyleSelector';
import { AdminDashboard } from './AdminDashboard';
import { StaffDutyRoster } from './StaffDutyRoster';
import { sanitizeWhatsappNumber } from '../utils/phone';
import { 
  Building2, 
  UtensilsCrossed, 
  QrCode, 
  Layers, 
  Plus, 
  Edit3, 
  Trash2, 
  Check, 
  X, 
  Eye, 
  Save, 
  Sparkles,
  Camera,
  Phone,
  MessageSquare,
  Clock,
  MapPin,
  Lock,
  Unlock,
  AlertCircle,
  ToggleLeft,
  ToggleRight,
  HelpCircle,
  Mic,
  Cpu,
  ReceiptText,
  Palette,
  BarChart3,
  Hotel,
  Users
} from 'lucide-react';
import { 
  saveBusiness, 
  saveCategory, 
  deleteCategory, 
  saveMenuItem, 
  deleteMenuItem, 
  toggleItemAvailability 
} from '../services/db';

export type OwnerTabType = 'analytics' | 'duty-roster' | 'overview' | 'menu' | 'photo-menu' | 'style' | 'categories' | 'qr' | 'future-architecture';

interface OwnerDashboardProps {
  business: Business;
  categories: MenuCategory[];
  items: MenuItem[];
  initialTab?: OwnerTabType;
  onOpenCustomerView: (businessId: string) => void;
  onRefresh: (updatedBusiness?: Business) => void;
}

export const OwnerDashboard: React.FC<OwnerDashboardProps> = ({
  business,
  categories,
  items,
  initialTab = 'overview',
  onOpenCustomerView,
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState<OwnerTabType>(initialTab);
  const [photoMenuToast, setPhotoMenuToast] = useState<string | null>(null);

  // Sync tab if initialTab changes
  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // Business profile form state
  const [bizForm, setBizForm] = useState<Business>({ ...business });
  const [isSavingBiz, setIsSavingBiz] = useState(false);
  const [bizSaveSuccess, setBizSaveSuccess] = useState(false);

  // Keep form state synchronized when business prop updates from Firestore
  useEffect(() => {
    setBizForm({ ...business });
  }, [business.id, business.name, business.phone, business.whatsappNumber, business.whatsappGroupUrl, business.ownerEmail, business.address, business.openingHours, business.tagline, business.logoUrl, business.locationMapUrl, business.currencySymbol, business.isActive, business.menuStyle]);

  // Category modal / editing state
  const [editingCategory, setEditingCategory] = useState<MenuCategory | null>(null);
  const [isNewCategory, setIsNewCategory] = useState(false);

  // Item modal / editing state
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [isNewItem, setIsNewItem] = useState(false);

  // Category filter for the menu table
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');

  // Handle saving business profile
  const handleSaveBusiness = async (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsSavingBiz(true);
    try {
      const sanitizedWhatsapp = bizForm.whatsappNumber ? sanitizeWhatsappNumber(bizForm.whatsappNumber) : '';
      const payload: Business = {
        ...bizForm,
        whatsappNumber: sanitizedWhatsapp ? `+${sanitizedWhatsapp}` : bizForm.whatsappNumber,
        id: business.id, // Strictly ensure active business_id is preserved
        updatedAt: new Date().toISOString(),
      };
      await saveBusiness(payload);
      setBizForm(payload);
      setBizSaveSuccess(true);
      setTimeout(() => setBizSaveSuccess(false), 2500);
      onRefresh(payload);
    } catch (err) {
      console.error('Failed to save business profile:', err);
      setPhotoMenuToast('Failed to save business profile. Please check connection.');
    } finally {
      setIsSavingBiz(false);
    }
  };

  // Handle Category CRUD
  const handleSaveCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory) return;
    try {
      await saveCategory(editingCategory);
      setEditingCategory(null);
      onRefresh();
    } catch (err) {
      console.error('Failed to save category:', err);
      setPhotoMenuToast('Failed to save category. Please try again.');
    }
  };

  const handleDeleteCategory = async (categoryId: string) => {
    try {
      await deleteCategory(business.id, categoryId);
      onRefresh();
    } catch (err) {
      console.error('Failed to delete category:', err);
      setPhotoMenuToast('Failed to delete category.');
    }
  };

  // Handle Item CRUD
  const handleSaveItemSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;
    try {
      await saveMenuItem(editingItem);
      setEditingItem(null);
      onRefresh();
    } catch (err) {
      console.error('Failed to save menu item:', err);
      setPhotoMenuToast('Failed to save menu item.');
    }
  };

  const handleDeleteItem = async (itemId: string) => {
    try {
      await deleteMenuItem(business.id, itemId);
      onRefresh();
    } catch (err) {
      console.error('Failed to delete item:', err);
      setPhotoMenuToast('Failed to delete item.');
    }
  };

  const handleToggleAvailability = async (item: MenuItem) => {
    try {
      await toggleItemAvailability(business.id, item.id, !item.isAvailable);
      onRefresh();
    } catch (err) {
      console.error('Failed to toggle availability:', err);
    }
  };

  // Sorted items
  const sortedItems = [...items]
    .filter(i => selectedCategoryFilter === 'all' || i.categoryId === selectedCategoryFilter)
    .sort((a, b) => a.displayOrder - b.displayOrder);

  return (
    <div id="owner-dashboard" className="max-w-6xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
      
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-md bg-stone-900 text-amber-400 font-mono text-[11px] font-bold uppercase tracking-wider">
              Owner Area
            </span>
            <span className="text-xs text-stone-500 font-medium">Business ID: {business.id}</span>
          </div>
          <h1 className="text-2xl font-black text-stone-900 tracking-tight mt-1">{business.name}</h1>
          <p className="text-xs text-stone-500">Live cloud-synchronized business & menu control</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="view-live-menu-btn"
            onClick={() => onOpenCustomerView(business.id)}
            className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs rounded-xl shadow-xs transition-colors"
          >
            <Eye className="w-4 h-4" />
            View Live Customer Menu
          </button>
        </div>
      </div>

      {/* Toast Notification */}
      {photoMenuToast && (
        <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center justify-between shadow-sm animate-fade-in">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>{photoMenuToast}</span>
          </div>
          <button onClick={() => setPhotoMenuToast(null)} className="text-emerald-700 hover:text-emerald-900">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-stone-200 pb-2 overflow-x-auto no-scrollbar">
        <button
          id="tab-analytics"
          onClick={() => setActiveTab('analytics')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            activeTab === 'analytics'
              ? 'bg-amber-500 text-stone-950 font-black shadow-xs'
              : 'text-stone-700 bg-amber-50/80 hover:bg-amber-100/80 border border-amber-200/80'
          }`}
        >
          <BarChart3 className="w-4 h-4 text-amber-600" /> Executive Analytics & KPIs
        </button>

        {/* Conditional Duty Roster Tab based on businessType */}
        <button
          id="tab-duty-roster"
          onClick={() => setActiveTab('duty-roster')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            activeTab === 'duty-roster'
              ? (business.businessType === 'guesthouse' ? 'bg-emerald-600 text-white font-black shadow-xs' : 'bg-amber-500 text-stone-950 font-black shadow-xs')
              : 'text-stone-700 bg-stone-100 hover:bg-stone-200 border border-stone-300'
          }`}
        >
          {business.businessType === 'guesthouse' ? (
            <>
              <Hotel className="w-4 h-4 text-emerald-600" />
              <span>Guest House & Hotel Duty Roster</span>
            </>
          ) : (
            <>
              <Users className="w-4 h-4 text-amber-600" />
              <span>Kitchen & Table Floor Duty Roster</span>
            </>
          )}
        </button>

        <button
          id="tab-overview"
          onClick={() => setActiveTab('overview')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
            activeTab === 'overview'
              ? 'bg-stone-900 text-white'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Building2 className="w-4 h-4" /> Business Profile
        </button>

        <button
          id="tab-menu"
          onClick={() => setActiveTab('menu')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
            activeTab === 'menu'
              ? 'bg-stone-900 text-white'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <UtensilsCrossed className="w-4 h-4" /> Menu Items ({items.length})
        </button>

        <button
          id="tab-photo-menu"
          onClick={() => setActiveTab('photo-menu')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
            activeTab === 'photo-menu'
              ? 'bg-amber-500 text-stone-950 font-black shadow-xs'
              : 'text-stone-700 bg-amber-50/80 hover:bg-amber-100/80 border border-amber-200/80'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-600" /> Create Menu from Photo
        </button>

        <button
          id="tab-style"
          onClick={() => setActiveTab('style')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
            activeTab === 'style'
              ? 'bg-stone-900 text-white'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Palette className="w-4 h-4 text-amber-500" /> Menu Style ({(business.menuStyle || 'classic').toUpperCase()})
        </button>

        <button
          id="tab-categories"
          onClick={() => setActiveTab('categories')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
            activeTab === 'categories'
              ? 'bg-stone-900 text-white'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Layers className="w-4 h-4" /> Categories ({categories.length})
        </button>

        <button
          id="tab-qr"
          onClick={() => setActiveTab('qr')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
            activeTab === 'qr'
              ? 'bg-stone-900 text-white'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <QrCode className="w-4 h-4 text-amber-500" /> Permanent QR Code
        </button>

        <button
          id="tab-future-architecture"
          onClick={() => setActiveTab('future-architecture')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
            activeTab === 'future-architecture'
              ? 'bg-amber-500 text-stone-950'
              : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Sparkles className="w-4 h-4" /> Phase 2 Architecture
        </button>
      </div>

      {/* TAB 0: EXECUTIVE ADMIN DASHBOARD */}
      {activeTab === 'analytics' && (
        <div id="analytics-tab-content" className="space-y-6 pb-[120px]">
          <AdminDashboard 
            business={business}
            brandName={business.name || 'Gourmet POS & Analytics'} 
            onBackToApp={() => setActiveTab('overview')} 
          />
        </div>
      )}

      {/* TAB: DUTY ROSTER (HOTEL OR RESTAURANT) */}
      {activeTab === 'duty-roster' && (
        <div id="duty-roster-tab-content" className="space-y-6 pb-[120px]">
          <StaffDutyRoster 
            business={business}
            onOpenLiveDashboard={() => onOpenCustomerView(business.id)}
          />
        </div>
      )}

      {/* TAB 1: BUSINESS OVERVIEW & PROFILE SETTINGS */}
      {activeTab === 'overview' && (
        <div id="overview-tab-content" className="space-y-6 pb-[120px]">
          <form id="owner-business-form" onSubmit={handleSaveBusiness} className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-6">
            <div className="flex items-center justify-between border-b border-stone-100 pb-4">
              <div>
                <h3 className="font-bold text-base text-stone-900">Business Details</h3>
                <p className="text-xs text-stone-500">Visible to customers when they scan your QR code</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-stone-600">Active Status:</span>
                <button
                  type="button"
                  onClick={() => setBizForm({ ...bizForm, isActive: !bizForm.isActive })}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${
                    bizForm.isActive
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-stone-200 text-stone-600'
                  }`}
                >
                  {bizForm.isActive ? 'Active (Open)' : 'Inactive (Closed)'}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Business Name *</label>
                <input
                  type="text"
                  required
                  value={bizForm.name || ''}
                  onChange={(e) => setBizForm({ ...bizForm, name: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Tagline / Specialties (Optional)</label>
                <input
                  type="text"
                  value={bizForm.tagline || ''}
                  onChange={(e) => setBizForm({ ...bizForm, tagline: e.target.value })}
                  placeholder="e.g. Pure Ghee Sweets & Crispy Dosas"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Phone Number *</label>
                <input
                  type="text"
                  required
                  value={bizForm.phone || ''}
                  onChange={(e) => setBizForm({ ...bizForm, phone: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">WhatsApp Number * (for Customer Inquiries)</label>
                <input
                  type="text"
                  required
                  value={bizForm.whatsappNumber || ''}
                  onChange={(e) => setBizForm({ ...bizForm, whatsappNumber: e.target.value })}
                  onBlur={(e) => {
                    const val = e.target.value.trim();
                    if (val) {
                      const clean = sanitizeWhatsappNumber(val);
                      setBizForm((prev) => ({ ...prev, whatsappNumber: `+${clean}` }));
                    }
                  }}
                  placeholder="+919876543210"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                />
                <p className="text-[10px] text-stone-400 mt-1">Leading zeros are automatically stripped and country code (+91) formatted.</p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Owner Email Address</label>
                <input
                  type="email"
                  value={bizForm.ownerEmail || ''}
                  onChange={(e) => setBizForm({ ...bizForm, ownerEmail: e.target.value })}
                  placeholder="owner@restaurant.com"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Designated WhatsApp Group Link (Optional)</label>
                <input
                  type="text"
                  value={bizForm.whatsappGroupUrl || ''}
                  onChange={(e) => setBizForm({ ...bizForm, whatsappGroupUrl: e.target.value })}
                  placeholder="https://chat.whatsapp.com/..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 focus:bg-white font-mono"
                />
                <p className="text-[10px] text-stone-400 mt-1">If configured, customer counter orders route into this group chat.</p>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-stone-700 mb-1">Full Address *</label>
                <input
                  type="text"
                  required
                  value={bizForm.address || ''}
                  onChange={(e) => setBizForm({ ...bizForm, address: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Opening Hours *</label>
                <input
                  type="text"
                  required
                  value={bizForm.openingHours || ''}
                  onChange={(e) => setBizForm({ ...bizForm, openingHours: e.target.value })}
                  placeholder="Mon - Sun: 7:00 AM – 11:00 PM"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Currency Symbol</label>
                <input
                  type="text"
                  value={bizForm.currencySymbol || '₹'}
                  onChange={(e) => setBizForm({ ...bizForm, currencySymbol: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Logo / Profile Photo URL (Optional)</label>
                <input
                  type="text"
                  value={bizForm.logoUrl || ''}
                  onChange={(e) => setBizForm({ ...bizForm, logoUrl: e.target.value })}
                  placeholder="https://... (or leave blank)"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Google Maps Link (Optional)</label>
                <input
                  type="text"
                  value={bizForm.locationMapUrl || ''}
                  onChange={(e) => setBizForm({ ...bizForm, locationMapUrl: e.target.value })}
                  placeholder="https://maps.google.com/... (or leave blank)"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 focus:bg-white"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-stone-100 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                {bizSaveSuccess ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold animate-fade-in">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    Profile saved & synchronized successfully!
                  </span>
                ) : (
                  <span className="text-xs text-stone-400">
                    Last updated: {business.updatedAt ? new Date(business.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ', ' + new Date(business.updatedAt).toLocaleDateString() : 'Just now'}
                  </span>
                )}
              </div>

              <button
                id="save-biz-btn"
                type="submit"
                disabled={isSavingBiz}
                className="hidden sm:flex items-center justify-center gap-2 px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded-xl text-xs font-bold transition-all shadow-sm active:scale-98 disabled:opacity-50 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                {isSavingBiz ? 'Saving to Firestore...' : 'Save / Update Profile'}
              </button>
            </div>
          </form>

          {/* Sticky / Fixed Bottom Floating Save Bar for Mobile & Quick Access */}
          <div className="fixed bottom-0 left-0 right-0 z-40 bg-stone-900/95 backdrop-blur-md border-t border-stone-800 p-3 sm:hidden shadow-2xl">
            <div className="max-w-md mx-auto flex items-center justify-between gap-3">
              <div className="min-w-0 flex-1">
                {bizSaveSuccess ? (
                  <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Saved!
                  </span>
                ) : (
                  <p className="text-[11px] text-stone-300 truncate">
                    Tap to save your restaurant profile
                  </p>
                )}
              </div>
              <button
                id="sticky-mobile-save-btn"
                type="submit"
                form="owner-business-form"
                disabled={isSavingBiz}
                className="flex items-center justify-center gap-1.5 px-5 py-2.5 bg-amber-500 hover:bg-amber-400 active:scale-95 text-stone-950 rounded-xl text-xs font-extrabold shadow-md transition-all shrink-0 cursor-pointer disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                {isSavingBiz ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MENU ITEMS */}
      {activeTab === 'menu' && (
        <div id="menu-tab-content" className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
            <div className="flex items-center gap-2 overflow-x-auto">
              <span className="text-xs font-semibold text-stone-500">Filter Category:</span>
              <select
                value={selectedCategoryFilter}
                onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                className="px-3 py-1.5 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden font-medium"
              >
                <option value="all">All Categories ({items.length})</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="photo-menu-cta-btn"
                onClick={() => setActiveTab('photo-menu')}
                className="flex items-center justify-center gap-1.5 px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded-xl text-xs font-black transition-colors shadow-xs"
              >
                <Sparkles className="w-4 h-4" /> Create Menu from Photo
              </button>

              <button
                id="add-item-btn"
                onClick={() => {
                  setIsNewItem(true);
                  setEditingItem({
                    id: `item-${Date.now()}`,
                    businessId: business.id,
                    categoryId: categories[0]?.id || 'default',
                    name: '',
                    description: '',
                    price: 0,
                    imageUrl: '',
                    isVeg: 'veg',
                    isAvailable: true,
                    displayOrder: items.length + 1,
                    tags: [],
                  });
                }}
                className="flex items-center justify-center gap-1.5 px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
              >
                <Plus className="w-4 h-4" /> Add Item
              </button>
            </div>
          </div>

          {/* Items Table / Cards */}
          <div className="bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-xs">
            {sortedItems.length === 0 ? (
              <div className="p-12 text-center text-stone-500 text-xs">
                No menu items found in this selection. Click "Add Menu Item" above to add your first dish.
              </div>
            ) : (
              <div className="divide-y divide-stone-100">
                {sortedItems.map((item) => {
                  const cat = categories.find((c) => c.id === item.categoryId);
                  return (
                    <div
                      key={item.id}
                      className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-stone-50/70 transition-colors"
                    >
                      <div className="flex items-start gap-3">
                        {item.imageUrl ? (
                          <img
                            src={item.imageUrl}
                            alt={item.name}
                            className="w-14 h-14 rounded-xl object-cover border border-stone-200 bg-stone-100 shrink-0"
                          />
                        ) : (
                          <div className="w-14 h-14 rounded-xl bg-stone-100 border border-stone-200 flex items-center justify-center shrink-0">
                            <UtensilsCrossed className="w-6 h-6 text-stone-400" />
                          </div>
                        )}

                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <DietBadge type={item.isVeg} />
                            <h4 className="font-bold text-sm text-stone-900">{item.name}</h4>
                            <span className="px-2 py-0.5 rounded-full bg-stone-100 text-stone-600 text-[10px] font-medium">
                              {cat?.name || 'Unassigned'}
                            </span>
                          </div>

                          {item.description && (
                            <p className="text-xs text-stone-500 line-clamp-1 max-w-lg">
                              {item.description}
                            </p>
                          )}

                          <div className="text-xs font-extrabold text-stone-900">
                            {business.currencySymbol}{item.price}
                          </div>
                        </div>
                      </div>

                      {/* Right controls: Availability toggle, Edit, Delete */}
                      <div className="flex items-center gap-3 self-end sm:self-center">
                        <button
                          type="button"
                          onClick={() => handleToggleAvailability(item)}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                            item.isAvailable
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                              : 'bg-stone-200 text-stone-600 hover:bg-stone-300'
                          }`}
                          title="Click to toggle availability"
                        >
                          <span
                            className={`w-2 h-2 rounded-full ${
                              item.isAvailable ? 'bg-emerald-600' : 'bg-stone-400'
                            }`}
                          />
                          {item.isAvailable ? 'In Stock' : 'Sold Out'}
                        </button>

                        <button
                          onClick={() => {
                            setIsNewItem(false);
                            setEditingItem({ ...item });
                          }}
                          className="p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
                          title="Edit Item"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleDeleteItem(item.id)}
                          className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB: CREATE MENU FROM PHOTO */}
      {activeTab === 'photo-menu' && (
        <div id="photo-menu-tab-content" className="space-y-6">
          <MenuPhotoExtractor
            business={business}
            existingCategories={categories}
            existingItems={items}
            onCancel={() => setActiveTab('menu')}
            onSuccess={(summary) => {
              const styleName = summary.selectedStyle ? ` using the ${summary.selectedStyle.toUpperCase()} style` : '';
              setPhotoMenuToast(`Successfully saved ${summary.addedItemsCount} dishes across ${summary.addedCategoriesCount} categories to your live menu${styleName}!`);
              setActiveTab('menu');
              onRefresh();
              setTimeout(() => {
                setPhotoMenuToast(null);
              }, 5000);
            }}
          />
        </div>
      )}

      {/* TAB: MENU STYLE SELECTOR */}
      {activeTab === 'style' && (
        <div id="style-tab-content" className="space-y-6">
          <div className="bg-white border border-stone-200 rounded-2xl p-4 sm:p-6 shadow-xs">
            <MenuStyleSelector
              business={business}
              categories={categories}
              items={items}
              currentStyle={business.menuStyle || 'classic'}
              onSelectStyle={async (newStyle: MenuStyle) => {
                try {
                  const updatedBiz = { ...business, menuStyle: newStyle };
                  await saveBusiness(updatedBiz);
                  setPhotoMenuToast(`Menu style changed to ${newStyle.toUpperCase()}! Your live QR menu was updated instantly.`);
                  onRefresh(updatedBiz);
                  setTimeout(() => {
                    setPhotoMenuToast(null);
                  }, 5000);
                } catch (err) {
                  console.error('Failed to update menu style:', err);
                  setPhotoMenuToast('Failed to update menu style. Please try again.');
                }
              }}
            />
          </div>
        </div>
      )}

      {/* TAB 3: CATEGORIES */}
      {activeTab === 'categories' && (
        <div id="categories-tab-content" className="space-y-6">
          <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
            <div>
              <h3 className="font-bold text-sm text-stone-900">Menu Categories</h3>
              <p className="text-xs text-stone-500">Organize your dishes into sections</p>
            </div>
            <button
              id="add-category-btn"
              onClick={() => {
                setIsNewCategory(true);
                setEditingCategory({
                  id: `cat-${Date.now()}`,
                  businessId: business.id,
                  name: '',
                  description: '',
                  displayOrder: categories.length + 1,
                  isActive: true,
                });
              }}
              className="flex items-center gap-1.5 px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4" /> Add Category
            </button>
          </div>

          <div className="bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-xs divide-y divide-stone-100">
            {categories.length === 0 ? (
              <div className="p-8 text-center text-xs text-stone-500">
                No categories created yet.
              </div>
            ) : (
              categories.map((cat) => {
                const count = items.filter((i) => i.categoryId === cat.id).length;
                return (
                  <div
                    key={cat.id}
                    className="p-4 flex items-center justify-between gap-4 hover:bg-stone-50/70 transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-md bg-stone-100 text-stone-600 font-mono text-xs flex items-center justify-center font-bold">
                          {cat.displayOrder}
                        </span>
                        <h4 className="font-bold text-sm text-stone-900">{cat.name}</h4>
                        <span className="px-2 py-0.5 rounded-full bg-stone-100 text-stone-600 text-[10px]">
                          {count} {count === 1 ? 'item' : 'items'}
                        </span>
                      </div>
                      {cat.description && (
                        <p className="text-xs text-stone-500 mt-1 pl-8">{cat.description}</p>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setIsNewCategory(false);
                          setEditingCategory({ ...cat });
                        }}
                        className="p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteCategory(cat.id)}
                        className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* TAB 4: PERMANENT QR CODE */}
      {activeTab === 'qr' && (
        <QRCodeView business={business} onPreviewCustomerPage={onOpenCustomerView} />
      )}

      {/* TAB 5: PREPARED ARCHITECTURE FOR FUTURE EXPANSIONS */}
      {activeTab === 'future-architecture' && (
        <div id="architecture-tab-content" className="space-y-6">
          <div className="bg-amber-50/90 border border-amber-200 rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-6 h-6 text-amber-600" />
              <div>
                <h3 className="font-extrabold text-base text-amber-950">
                  Phase 2 Architecture Ready
                </h3>
                <p className="text-xs text-amber-800">
                  Data model, Firestore security rules, and component routes are architected to seamlessly plug into the following upcoming capabilities in Phase 2:
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
              <div className="bg-white/80 border border-amber-200/80 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
                  <Mic className="w-4 h-4 text-amber-600" />
                  <span>Customer Voice Ordering</span>
                </div>
                <p className="text-[11px] text-stone-600 leading-relaxed">
                  Speech-to-text listener supporting multilingual Indian accents (Hindi, Hinglish, Tamil, Telugu, Kannada, Bengali) to match spoken dishes directly with menu IDs.
                </p>
                <span className="inline-block px-2 py-0.5 bg-amber-100 text-amber-900 text-[10px] font-bold rounded-md">
                  Phase 2 Feature
                </span>
              </div>

              <div className="bg-white/80 border border-amber-200/80 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
                  <Cpu className="w-4 h-4 text-amber-600" />
                  <span>AI Menu Photo Extraction</span>
                </div>
                <p className="text-[11px] text-stone-600 leading-relaxed">
                  Upload a photo of a printed paper menu; Gemini AI parses items, categories, and prices directly into structured database items.
                </p>
                <span className="inline-block px-2 py-0.5 bg-amber-100 text-amber-900 text-[10px] font-bold rounded-md">
                  Phase 2 Feature
                </span>
              </div>

              <div className="bg-white/80 border border-amber-200/80 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
                  <QrCode className="w-4 h-4 text-amber-600" />
                  <span>Table QR Numbers</span>
                </div>
                <p className="text-[11px] text-stone-600 leading-relaxed">
                  Parameterized URL routing (<code>/b/:businessId?table=5</code>) enabling customers to submit orders directly attached to their specific table or takeaway counter.
                </p>
                <span className="inline-block px-2 py-0.5 bg-amber-100 text-amber-900 text-[10px] font-bold rounded-md">
                  Phase 2 Feature
                </span>
              </div>

              <div className="bg-white/80 border border-amber-200/80 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-stone-900">
                  <ReceiptText className="w-4 h-4 text-amber-600" />
                  <span>Kitchen & Cash Counter KDS</span>
                </div>
                <p className="text-[11px] text-stone-600 leading-relaxed">
                  Real-time ticket screen for kitchen chefs and cash-counter operators showing pending order items, table numbers, and statuses (Cooking / Ready / Served).
                </p>
                <span className="inline-block px-2 py-0.5 bg-amber-100 text-amber-900 text-[10px] font-bold rounded-md">
                  Phase 2 Feature
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Edit/Add Menu Item */}
      {editingItem && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-bold text-base text-stone-900">
                {isNewItem ? 'Add New Menu Item' : 'Edit Menu Item'}
              </h3>
              <button
                onClick={() => setEditingItem(null)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveItemSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Item Name *</label>
                <input
                  type="text"
                  required
                  value={editingItem.name}
                  onChange={(e) => setEditingItem({ ...editingItem, name: e.target.value })}
                  placeholder="e.g. Masala Dosa"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Category *</label>
                  <select
                    value={editingItem.categoryId}
                    onChange={(e) => setEditingItem({ ...editingItem, categoryId: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Price (₹) *</label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="1"
                    value={editingItem.price}
                    onChange={(e) =>
                      setEditingItem({ ...editingItem, price: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Dietary Classification *</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingItem({ ...editingItem, isVeg: 'veg' })}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 ${
                      editingItem.isVeg === 'veg'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                        : 'border-stone-200 bg-stone-50 text-stone-600'
                    }`}
                  >
                    <DietBadge type="veg" /> Veg
                  </button>

                  <button
                    type="button"
                    onClick={() => setEditingItem({ ...editingItem, isVeg: 'non-veg' })}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 ${
                      editingItem.isVeg === 'non-veg'
                        ? 'border-red-600 bg-red-50 text-red-800'
                        : 'border-stone-200 bg-stone-50 text-stone-600'
                    }`}
                  >
                    <DietBadge type="non-veg" /> Non-Veg
                  </button>

                  <button
                    type="button"
                    onClick={() => setEditingItem({ ...editingItem, isVeg: 'egg' })}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 ${
                      editingItem.isVeg === 'egg'
                        ? 'border-amber-600 bg-amber-50 text-amber-800'
                        : 'border-stone-200 bg-stone-50 text-stone-600'
                    }`}
                  >
                    <DietBadge type="egg" /> Egg
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={editingItem.description || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, description: e.target.value })}
                  placeholder="Ingredients, preparation style or serving quantity"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Dish Image URL</label>
                <input
                  type="url"
                  value={editingItem.imageUrl || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, imageUrl: e.target.value })}
                  placeholder="https://..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingItem.isAvailable}
                    onChange={(e) =>
                      setEditingItem({ ...editingItem, isAvailable: e.target.checked })
                    }
                    className="w-4 h-4 text-emerald-600 rounded border-stone-300"
                  />
                  <span className="text-xs font-semibold text-stone-700">Currently in Stock (Available)</span>
                </label>
              </div>

              <div className="pt-4 border-t border-stone-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  id="save-item-modal-btn"
                  type="submit"
                  className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold"
                >
                  Save Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Edit/Add Category */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-bold text-base text-stone-900">
                {isNewCategory ? 'Add Category' : 'Edit Category'}
              </h3>
              <button
                onClick={() => setEditingCategory(null)}
                className="text-stone-400 hover:text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCategorySubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Category Name *</label>
                <input
                  type="text"
                  required
                  value={editingCategory.name}
                  onChange={(e) =>
                    setEditingCategory({ ...editingCategory, name: e.target.value })
                  }
                  placeholder="e.g. South Indian Breakfast"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Description</label>
                <input
                  type="text"
                  value={editingCategory.description || ''}
                  onChange={(e) =>
                    setEditingCategory({ ...editingCategory, description: e.target.value })
                  }
                  placeholder="Brief tagline for this category"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Display Order</label>
                <input
                  type="number"
                  min="1"
                  value={editingCategory.displayOrder}
                  onChange={(e) =>
                    setEditingCategory({
                      ...editingCategory,
                      displayOrder: parseInt(e.target.value, 10) || 1,
                    })
                  }
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-hidden focus:border-amber-500"
                />
              </div>

              <div className="pt-4 border-t border-stone-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingCategory(null)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  id="save-category-modal-btn"
                  type="submit"
                  className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold"
                >
                  Save Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
