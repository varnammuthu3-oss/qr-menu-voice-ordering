import React, { useState, useEffect, useRef } from 'react';
import { alertSoundEngine } from '../utils/audioAlertEngine';
import { StaffAllocation, TableDutyState, AppStaffRole, Business, DutySession } from '../types';
import { ROLE_CONFIGS, getStoredStaffRole, getStoredStaffName } from '../lib/roleAccessControl';
import { 
  fetchStaffAllocations, 
  buildTableDutyGrid, 
  formatStaffDutyAlert, 
  saveStaffAllocation 
} from '../lib/staffAllocationService';
import {
  subscribeToDutySessions,
  shouldPlayAlertForStaff,
  getMyStoredDutySessionId
} from '../lib/dutySessionService';
import { 
  BellRing, 
  Volume2, 
  VolumeX, 
  Volume1, 
  Check, 
  X, 
  CheckCircle2, 
  RefreshCw, 
  ExternalLink, 
  Play, 
  Sparkles, 
  MessageSquare, 
  QrCode, 
  Utensils, 
  Users, 
  Grid3X3, 
  ListOrdered, 
  UserCheck,
  Crown,
  Shield,
  DollarSign,
  Lock,
  Eye,
  FileText,
  Printer,
  Hash,
  Calendar,
  Clock,
  Phone,
  User
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface OrderItem {
  name: string;
  variantName?: string;
  quantity: number;
  price: number;
  unitPrice?: number;
  isVeg?: string;
  selectedOptions?: string[];
  customNote?: string;
  totalItemPrice?: number;
}

interface LiveOrder {
  id: string;
  restaurantId?: string;
  orderId?: number;
  orderSerial?: string;
  orderDate?: string;
  orderTime?: string;
  customerName?: string;
  customerPhone?: string;
  tableNumber: string;
  assignedStaffName?: string; // e.g. "Waiter Ramesh"
  items: OrderItem[];
  totalPrice: number;
  merchantPhone?: string;
  alertSoundType?: 'ringtone' | 'church_bell';
  customerNotes?: string;
  restaurantName?: string;
  restaurantAddress?: string;
  currencySymbol?: string;
  formattedSummary?: string;
  createdAt: string;
  status: 'pending' | 'accepted' | 'completed' | 'cancelled';
  whatsappStatus?: 'sent' | 'failed' | 'not_configured' | 'pending';
}

interface WhatsAppStatus {
  status: 'disconnected' | 'connecting' | 'qr_ready' | 'connected';
  qrCodeDataUrl: string | null;
  pairedUser: string | null;
  connected: boolean;
}

interface MerchantOrderDashboardProps {
  business?: Business;
  currentStaffRole?: AppStaffRole;
  staffName?: string;
  onOpenRoleSwitcher?: () => void;
}

export const MerchantOrderDashboard: React.FC<MerchantOrderDashboardProps> = ({
  business,
  currentStaffRole: propRole,
  staffName: propName,
  onOpenRoleSwitcher,
}) => {
  const isGuestHouse = business ? (business.businessType === 'guesthouse' || business.id.includes('guesthouse') || business.id.includes('hotel')) : false;
  const staffRole: AppStaffRole = propRole || getStoredStaffRole() || 'owner';
  const effectiveStaffName = propName || getStoredStaffName() || (staffRole === 'owner' ? 'Owner / Admin' : staffRole === 'manager' ? (isGuestHouse ? 'Front Desk Anita' : 'Captain Priya') : (isGuestHouse ? 'Ravi Kumar (Room Service)' : 'Waiter Ramesh'));
  const rolePermissions = ROLE_CONFIGS[staffRole].permissions;

  const [orders, setOrders] = useState<LiveOrder[]>([]);
  const [staffAllocations, setStaffAllocations] = useState<StaffAllocation[]>([]);
  const [dutySessions, setDutySessions] = useState<DutySession[]>([]);
  const [tableGrid, setTableGrid] = useState<TableDutyState[]>([]);
  const [activeDashboardTab, setActiveDashboardTab] = useState<'feed' | 'grid'>('feed');
  const [selectedTableDetails, setSelectedTableDetails] = useState<TableDutyState | null>(null);
  const [reassignModalTable, setReassignModalTable] = useState<string | null>(null);
  const [reassignStaffInput, setReassignStaffInput] = useState<string>(isGuestHouse ? 'Anita Sharma' : 'Waiter Ramesh');
  const [waiterFilterOnlyMine, setWaiterFilterOnlyMine] = useState<boolean>(staffRole === 'waiter');

  const [waStatus, setWaStatus] = useState<WhatsAppStatus>({
    status: 'disconnected',
    qrCodeDataUrl: null,
    pairedUser: null,
    connected: false
  });
  const [selectedSoundType, setSelectedSoundType] = useState<'church_bell' | 'ringtone'>('church_bell');
  const [volume, setVolume] = useState<number>(85);
  const [isAlarmActive, setIsAlarmActive] = useState<boolean>(false);
  const [activeRingingOrder, setActiveRingingOrder] = useState<LiveOrder | null>(null);
  const [showQRModal, setShowQRModal] = useState<boolean>(false);
  const [audioUnlocked, setAudioUnlocked] = useState<boolean>(false);
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'accepted' | 'completed'>('all');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [inspectKotOrder, setInspectKotOrder] = useState<LiveOrder | null>(null);

  const eventSourceRef = useRef<EventSource | null>(null);
  const dutySessionsRef = useRef<DutySession[]>(dutySessions);
  const staffRoleRef = useRef<AppStaffRole>(staffRole);
  const effectiveStaffNameRef = useRef<string>(effectiveStaffName);
  const waiterFilterOnlyMineRef = useRef<boolean>(waiterFilterOnlyMine);

  useEffect(() => {
    dutySessionsRef.current = dutySessions;
  }, [dutySessions]);

  useEffect(() => {
    staffRoleRef.current = staffRole;
  }, [staffRole]);

  useEffect(() => {
    effectiveStaffNameRef.current = effectiveStaffName;
  }, [effectiveStaffName]);

  useEffect(() => {
    waiterFilterOnlyMineRef.current = waiterFilterOnlyMine;
  }, [waiterFilterOnlyMine]);

  const restaurantId = business?.id || (isGuestHouse ? 'green-valley-guesthouse' : 'sri-murugan-tiffin-center');
  const todayStr = new Date().toISOString().slice(0, 10);

  // Subscribe to Duty Sessions in real-time
  useEffect(() => {
    const unsubscribe = subscribeToDutySessions(restaurantId, (sessions) => {
      setDutySessions(sessions);
    });
    return () => unsubscribe();
  }, [restaurantId]);

  // Load Staff Allocations
  const loadStaffDutyData = async () => {
    try {
      const data = await fetchStaffAllocations(restaurantId, todayStr);
      setStaffAllocations(data);
    } catch (err) {
      console.warn('Error loading staff allocations:', err);
    }
  };

  useEffect(() => {
    loadStaffDutyData();
  }, [restaurantId]);

  // Update Live Table/Room Duty Grid whenever orders or staff allocations change
  useEffect(() => {
    const customUnits = isGuestHouse 
      ? ['101', '102', '103', '104', '105', '106', '201', '202', '203', '204', 'Suite-A', 'Suite-B', 'VIP-Lounge', 'Poolside', 'Gym', 'Banquet-Hall']
      : ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', 'VIP-1', 'VIP-2', 'Garden-1', 'Terrace-A'];
    const grid = buildTableDutyGrid(restaurantId, staffAllocations, orders, isGuestHouse ? 16 : 12, customUnits);
    setTableGrid(grid);
  }, [orders, staffAllocations, restaurantId, isGuestHouse]);

  // Set sound volume
  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    alertSoundEngine.setVolume(newVol / 100);
  };

  // Unlock audio context with user gesture
  const unlockAudio = () => {
    setAudioUnlocked(true);
    alertSoundEngine.setVolume(volume / 100);
  };

  // Sound Previews
  const previewChurchBell = () => {
    unlockAudio();
    alertSoundEngine.playChurchBell(440, 2.5);
  };

  const previewRingtone = () => {
    unlockAudio();
    alertSoundEngine.playRingtoneBurst();
  };

  const silenceAlarm = () => {
    alertSoundEngine.stopAlert();
    setIsAlarmActive(false);
    setActiveRingingOrder(null);
  };

  // Fetch initial WhatsApp status
  const fetchWhatsAppStatus = async () => {
    try {
      const res = await fetch('/api/whatsapp/status');
      if (res.ok) {
        const data = await res.json();
        setWaStatus(data);
      }
    } catch (e) {
      console.warn('Error fetching WhatsApp status:', e);
    }
  };

  // Reconnect WhatsApp
  const handleReconnectWhatsApp = async () => {
    try {
      await fetch('/api/whatsapp/connect', { method: 'POST' });
      fetchWhatsAppStatus();
    } catch (e) {
      console.error(e);
    }
  };

  // Reset WhatsApp Session (new QR)
  const handleResetWhatsApp = async () => {
    try {
      await fetch('/api/whatsapp/reset', { method: 'POST' });
      fetchWhatsAppStatus();
    } catch (e) {
      console.error(e);
    }
  };

  // Update order status
  const updateOrderStatus = async (orderId: string, newStatus: LiveOrder['status']) => {
    try {
      if (activeRingingOrder?.id === orderId || newStatus === 'accepted') {
        silenceAlarm();
      }
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
      }
    } catch (e) {
      console.error('Error updating status:', e);
    }
  };

  // Simulate Table or Room Order with Real-Time Service Matching
  const simulateTestOrder = async (overrideTable?: string, tenantType: 'restaurant' | 'guesthouse' = 'restaurant') => {
    setIsSimulating(true);
    unlockAudio();
    try {
      const isGH = tenantType === 'guesthouse';
      const targetLocation = overrideTable || (isGH ? '102' : '05');
      
      const payload = isGH ? {
        restaurantId: 'green-villa-guesthouse',
        tableNumber: `Room ${targetLocation}`,
        restaurantName: 'Green Villa Guest House',
        restaurantAddress: '45 Lakeview Hill Road, Ooty',
        currencySymbol: '₹',
        alertSoundType: selectedSoundType,
        customerName: 'Ananya Roy',
        customerPhone: '+91 98451 22334',
        items: [
          { 
            name: 'Ginger Tea', 
            quantity: 1, 
            price: 50, 
            unitPrice: 50,
            isVeg: 'veg',
            totalItemPrice: 50
          },
          { 
            name: 'Extra Fresh Towel', 
            quantity: 1, 
            price: 0, 
            unitPrice: 0,
            isVeg: 'veg',
            totalItemPrice: 0
          }
        ],
        totalPrice: 50,
        customerNotes: 'Please deliver to Room 102.'
      } : {
        restaurantId: 'city-diner',
        tableNumber: `Table ${targetLocation}`,
        restaurantName: 'City Diner',
        restaurantAddress: '124 Food Street, Bangalore',
        currencySymbol: '₹',
        alertSoundType: selectedSoundType,
        customerName: 'Vikram Mehta',
        customerPhone: '+91 98765 43210',
        items: [
          { 
            name: 'Masala Dosa', 
            quantity: 1, 
            price: 120, 
            unitPrice: 120,
            isVeg: 'veg',
            totalItemPrice: 120
          }
        ],
        totalPrice: 120,
        customerNotes: 'Please expedite.'
      };

      await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } catch (err) {
      console.error('Failed to simulate order:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  // Quick reassign waiter for a table
  const handleQuickReassign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reassignModalTable || !reassignStaffInput.trim()) return;

    try {
      const existing = staffAllocations.find(a => a.staffName.toLowerCase() === reassignStaffInput.trim().toLowerCase());
      const currentTables = existing ? existing.assignedTables : [];
      const updatedTables = Array.from(new Set([...currentTables, reassignModalTable]));

      await saveStaffAllocation({
        id: existing?.id,
        restaurantId,
        staffName: reassignStaffInput.trim(),
        role: existing?.role || 'waiter',
        shiftDate: todayStr,
        assignedTables: updatedTables,
        isActive: true
      });

      await loadStaffDutyData();
      setReassignModalTable(null);
    } catch (err) {
      console.error(err);
      alert('Failed to reassign table.');
    }
  };

  // Setup Server-Sent Events (SSE) stream
  useEffect(() => {
    fetchWhatsAppStatus();

    const es = new EventSource('/api/orders/events');
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);

        if (payload.type === 'INIT') {
          if (payload.orders) setOrders(payload.orders);
          if (payload.waStatus) setWaStatus(payload.waStatus);
        } else if (payload.type === 'WA_STATUS') {
          if (payload.waStatus) setWaStatus(payload.waStatus);
        } else if (payload.type === 'NEW_ORDER') {
          const newOrd: LiveOrder = payload.order;
          setOrders(prev => [newOrd, ...prev.filter(o => o.id !== newOrd.id)]);
          
          // Role-Based Real-Time Alert Dispatch Check:
          // Audio alert sounds only on the device of the staff member assigned to that specific room/table
          const currentStaffRole = staffRoleRef.current;
          const currentStaffName = effectiveStaffNameRef.current;
          const currentDutySessions = dutySessionsRef.current;
          const currentFilterMine = waiterFilterOnlyMineRef.current;

          const dispatchCheck = shouldPlayAlertForStaff({
            targetLocation: newOrd.tableNumber,
            staffRole: currentStaffRole,
            myStaffName: currentStaffName,
            activeDutySessions: currentDutySessions,
            isOnlyAssignedFilterEnabled: currentFilterMine || (currentStaffRole !== 'owner' && currentStaffRole !== 'manager' && currentStaffRole !== 'master_admin')
          });

          if (dispatchCheck.shouldAlert) {
            const soundChoice = newOrd.alertSoundType || selectedSoundType;
            alertSoundEngine.startContinuousAlert(soundChoice);
            setIsAlarmActive(true);
            setActiveRingingOrder(newOrd);
          } else {
            console.log(`[Alert Filtered] Notification for ${newOrd.tableNumber} dispatched to ${dispatchCheck.assignedStaffName || 'unassigned staff'} (muted on this device)`);
          }
        } else if (payload.type === 'ORDER_UPDATED') {
          const updated: LiveOrder = payload.order;
          setOrders(prev => prev.map(o => o.id === updated.id ? updated : o));
          if (activeRingingOrder?.id === updated.id && updated.status !== 'pending') {
            silenceAlarm();
          }
        }
      } catch (err) {
        console.error('Error handling SSE event:', err);
      }
    };

    es.onerror = () => {
      // Auto-reconnect handled by browser
    };

    return () => {
      es.close();
      alertSoundEngine.stopAlert();
    };
  }, [selectedSoundType]);

  const filteredOrders = orders.filter(o => {
    if (filterStatus === 'all') return true;
    return o.status === filterStatus;
  });

  const pendingCount = orders.filter(o => o.status === 'pending').length;
  const activeTablesCount = tableGrid.filter(t => t.activeOrdersCount > 0).length;

  // Financial Daily Calculations
  const dailyTotalRevenue = orders.reduce((acc, o) => acc + (o.status !== 'cancelled' ? o.totalPrice : 0), 0);
  const dailyCompletedOrders = orders.filter(o => o.status === 'completed').length;
  const avgTicketSize = orders.length > 0 ? Math.round(dailyTotalRevenue / orders.length) : 0;

  // Filter orders for waiters if enabled
  const myAssignedTables = staffAllocations
    .filter(a => a.staffName.toLowerCase() === effectiveStaffName.toLowerCase())
    .flatMap(a => a.assignedTables);

  const displayedOrders = filteredOrders.filter(o => {
    if (staffRole === 'waiter' && waiterFilterOnlyMine && myAssignedTables.length > 0) {
      return myAssignedTables.includes(o.tableNumber);
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Role Persona & Permission Status Banner */}
        <div className="p-3.5 sm:p-4 bg-stone-900/90 border border-stone-800 rounded-3xl flex flex-wrap items-center justify-between gap-3 shadow-md">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-2xl flex items-center justify-center font-black ${
              staffRole === 'owner' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
              staffRole === 'manager' ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30' :
              'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
            }`}>
              {staffRole === 'owner' ? (
                <Crown className="w-5 h-5" />
              ) : staffRole === 'manager' ? (
                <Shield className="w-5 h-5" />
              ) : (
                <UserCheck className="w-5 h-5" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-sm text-white">{effectiveStaffName}</span>
                <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold uppercase ${
                  staffRole === 'owner' ? 'bg-amber-500/20 text-amber-300' :
                  staffRole === 'manager' ? 'bg-sky-500/20 text-sky-300' :
                  'bg-emerald-500/20 text-emerald-300'
                }`}>
                  {ROLE_CONFIGS[staffRole].title}
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                {staffRole === 'owner' && 'Full permissions: Daily financial revenue totals, staff duty reports, and system settings.'}
                {staffRole === 'manager' && 'Captain permissions: View all table orders, assign waiters to tables, and mute audio alerts. Financial totals restricted.'}
                {staffRole === 'waiter' && 'Waiter permissions: Real-time table ringing alerts, item fulfillment, and instant table mute.'}
              </p>
            </div>
          </div>

          {onOpenRoleSwitcher && (
            <button
              type="button"
              onClick={onOpenRoleSwitcher}
              className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white rounded-xl text-xs font-bold border border-stone-700 transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <span>Switch Role</span>
            </button>
          )}
        </div>

        {/* Audio Context Banner if not interacted */}
        {!audioUnlocked && (
          <div className="p-3 bg-amber-500/15 border border-amber-500/30 rounded-2xl flex items-center justify-between gap-3 text-xs sm:text-sm text-amber-200">
            <div className="flex items-center gap-2">
              <Volume2 className="w-5 h-5 text-amber-400 shrink-0" />
              <span>Click anywhere or test a tone to activate sound alarms for incoming table orders.</span>
            </div>
            <button
              type="button"
              onClick={unlockAudio}
              className="px-3 py-1.5 bg-amber-500 text-stone-950 font-bold rounded-xl hover:bg-amber-400 transition-colors shrink-0 cursor-pointer"
            >
              Enable Audio
            </button>
          </div>
        )}

        {/* 🚨 Real-Time Owner Notification: Assigned Waiter Alert Banner */}
        <AnimatePresence>
          {isAlarmActive && activeRingingOrder && (
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: -20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: -20 }}
              className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-rose-600 via-amber-600 to-red-600 shadow-2xl shadow-rose-900/50 border-2 border-amber-300 flex flex-col md:flex-row items-center justify-between gap-5 animate-pulse"
            >
              <div className="flex items-center gap-4 text-white">
                <div className="w-14 h-14 rounded-2xl bg-white text-rose-600 flex items-center justify-center font-black shrink-0 shadow-xl">
                  <BellRing className="w-8 h-8 animate-bounce" />
                </div>
                <div>
                  {/* Explicit User Requirement Format */}
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="px-3 py-1 rounded-full bg-white text-stone-950 text-xs font-black uppercase tracking-wider shadow-xs">
                      🚨 NEW ORDER RECEIVED
                    </span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-black/30 text-amber-200 text-xs font-mono font-bold">
                      {activeRingingOrder.formattedSummary || `Order #${activeRingingOrder.orderId || 1} | Time: ${activeRingingOrder.orderTime || 'Now'}`}
                    </span>
                  </div>

                  <h2 className="text-xl sm:text-2xl font-black text-white drop-shadow-sm">
                    {formatStaffDutyAlert(activeRingingOrder.tableNumber, activeRingingOrder.assignedStaffName)}
                  </h2>

                  <div className="flex items-center gap-3 text-xs sm:text-sm text-stone-100 mt-1 font-semibold">
                    <span>🪑 Table {activeRingingOrder.tableNumber}</span>
                    <span>•</span>
                    <span className="text-amber-200">👤 {activeRingingOrder.assignedStaffName ? `Assigned: ${activeRingingOrder.assignedStaffName}` : 'Unassigned Table'}</span>
                    <span>•</span>
                    <span className="font-bold text-white">{activeRingingOrder.items.length} Items ({activeRingingOrder.currencySymbol || '₹'}{activeRingingOrder.totalPrice})</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2.5 w-full md:w-auto">
                {rolePermissions.canMuteAudioAlerts && (
                  <button
                    type="button"
                    onClick={silenceAlarm}
                    className="flex-1 md:flex-none px-4 py-3 bg-white/20 hover:bg-white/30 text-white font-bold rounded-2xl transition-colors flex items-center justify-center gap-2 text-xs sm:text-sm border border-white/30 cursor-pointer"
                  >
                    <VolumeX className="w-4 h-4" />
                    <span>Silence Ring</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => updateOrderStatus(activeRingingOrder.id, 'accepted')}
                  className="flex-1 md:flex-none px-6 py-3.5 bg-white text-stone-950 font-black rounded-2xl hover:bg-stone-100 transition-all shadow-xl flex items-center justify-center gap-2 text-sm sm:text-base cursor-pointer"
                >
                  <Check className="w-5 h-5 text-emerald-600 stroke-[3]" />
                  <span>Accept Order</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Top Header & Metrics Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          
          {/* Main Controls Card */}
          <div className="lg:col-span-2 p-5 bg-stone-900/90 rounded-3xl border border-stone-800 flex flex-col justify-between shadow-lg">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-black">
                    <BellRing className="w-4 h-4" />
                  </div>
                  <h1 className="text-xl sm:text-2xl font-black text-white">
                    {staffRole === 'owner' ? 'Owner Order & Financial Dashboard' : staffRole === 'manager' ? 'Captain Order & Table Duty Console' : 'Waiter Service & Order Console'}
                  </h1>
                </div>
                <p className="text-xs sm:text-sm text-stone-400 mt-1.5">
                  Real-time waiter duty matching, continuous audio alarms, and live multi-device synchronization.
                </p>
              </div>

              {/* Quick Simulation Triggers */}
              <div className="flex flex-wrap items-center gap-2">
                <a
                  href="/staff-dashboard.html"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-2 bg-stone-800 hover:bg-stone-700 text-amber-300 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 border border-amber-500/30"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
                  <span>5-Device Sync View</span>
                </a>

                {/* Table 05 -> Restaurant Quick Simulator */}
                <button
                  type="button"
                  disabled={isSimulating}
                  onClick={() => simulateTestOrder('05', 'restaurant')}
                  title="Simulate Table 05 (Restaurant Order)"
                  className="px-3 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-black text-xs rounded-xl transition-all flex items-center gap-1.5 shadow-md cursor-pointer active:scale-95 disabled:opacity-50"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Test Table 05</span>
                </button>

                {/* Room 102 -> Guest House Quick Simulator */}
                <button
                  type="button"
                  disabled={isSimulating}
                  onClick={() => simulateTestOrder('102', 'guesthouse')}
                  title="Simulate Room 102 (Guest House Request)"
                  className="px-3 py-2 bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-black text-xs rounded-xl transition-all flex items-center gap-1.5 shadow-md cursor-pointer active:scale-95 disabled:opacity-50"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Test Room 102</span>
                </button>
              </div>
            </div>

            {/* Audio Alert Settings */}
            <div className="mt-5 pt-4 border-t border-stone-800 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">Alert Tone:</span>
                <div className="inline-flex rounded-xl bg-stone-800 p-1 border border-stone-700">
                  <button
                    type="button"
                    onClick={() => setSelectedSoundType('church_bell')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                      selectedSoundType === 'church_bell'
                        ? 'bg-amber-500 text-stone-950 shadow-xs'
                        : 'text-stone-300 hover:text-white'
                    }`}
                  >
                    🔔 Church Bell
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedSoundType('ringtone')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                      selectedSoundType === 'ringtone'
                        ? 'bg-amber-500 text-stone-950 shadow-xs'
                        : 'text-stone-300 hover:text-white'
                    }`}
                  >
                    🎵 Ringtone
                  </button>
                </div>
              </div>

              {/* Sound Previews & Volume */}
              <div className="flex items-center gap-3">
                {rolePermissions.canMuteAudioAlerts && (
                  <button
                    type="button"
                    onClick={silenceAlarm}
                    className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 border border-stone-700 text-xs text-stone-200 font-medium rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                    <span>Mute Audio</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={selectedSoundType === 'church_bell' ? previewChurchBell : previewRingtone}
                  className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 border border-stone-700 text-xs text-stone-200 font-medium rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 text-amber-400" />
                  <span>Test Audio</span>
                </button>

                <div className="flex items-center gap-1.5 bg-stone-800/80 px-2.5 py-1.5 rounded-xl border border-stone-700">
                  <Volume1 className="w-4 h-4 text-stone-400" />
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={volume}
                    onChange={(e) => handleVolumeChange(Number(e.target.value))}
                    className="w-16 accent-amber-500 cursor-pointer h-1.5 bg-stone-700 rounded-lg"
                  />
                  <span className="text-[11px] font-mono text-stone-400 w-6 text-right">{volume}%</span>
                </div>
              </div>
            </div>
          </div>

          {/* RBAC Financial Daily Totals & Duty Stats Card */}
          <div className="p-5 bg-stone-900/90 rounded-3xl border border-stone-800 flex flex-col justify-between shadow-lg">
            <div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {rolePermissions.canViewFinancialTotals ? (
                    <DollarSign className="w-4 h-4 text-amber-400" />
                  ) : (
                    <Lock className="w-4 h-4 text-sky-400" />
                  )}
                  <h3 className="font-bold text-sm text-stone-200">
                    {rolePermissions.canViewFinancialTotals ? 'Daily Financial Totals' : 'Financial Privacy Guard'}
                  </h3>
                </div>
                
                <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                  rolePermissions.canViewFinancialTotals
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-stone-800 text-stone-400 border border-stone-700'
                }`}>
                  {rolePermissions.canViewFinancialTotals ? '👑 Owner Access' : '🔒 Owner Only'}
                </span>
              </div>

              {rolePermissions.canViewFinancialTotals ? (
                /* Full Financial Details for Owner */
                <div className="mt-3 space-y-2 text-xs text-stone-300">
                  <div className="p-3 bg-stone-950 rounded-2xl border border-stone-800 flex items-center justify-between">
                    <span className="text-stone-400 font-medium">Daily Gross Revenue:</span>
                    <span className="text-base font-black font-mono text-emerald-400">
                      ₹{dailyTotalRevenue.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between px-1">
                    <span className="text-stone-400">Total Orders Today:</span>
                    <span className="font-bold font-mono text-white">{orders.length} orders</span>
                  </div>
                  <div className="flex items-center justify-between px-1">
                    <span className="text-stone-400">Avg Ticket Size:</span>
                    <span className="font-bold font-mono text-amber-400">₹{avgTicketSize} / order</span>
                  </div>
                </div>
              ) : (
                /* Redacted/Masked Financial Notice for Captain / Waiter */
                <div className="mt-3 p-3 bg-stone-950/80 rounded-2xl border border-stone-800/80 text-xs text-stone-400 space-y-2">
                  <p className="text-[11px] leading-relaxed">
                    Financial daily order totals and gross billing metrics are restricted to <strong className="text-white">Owner / Admin</strong> role.
                  </p>
                  <div className="flex items-center gap-1.5 text-sky-300 font-medium text-[11px]">
                    <Check className="w-3.5 h-3.5 text-sky-400" />
                    <span>You have full view of all table orders & table duty assignments.</span>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-stone-800 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setShowQRModal(true)}
                className="flex-1 py-2 px-3 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <QrCode className="w-3.5 h-3.5" />
                <span>{waStatus.status === 'connected' ? 'WhatsApp Connected' : 'Pair WhatsApp'}</span>
              </button>

              <button
                type="button"
                onClick={loadStaffDutyData}
                title="Refresh Staff Roster"
                className="p-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-xl border border-stone-700 transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>

        {/* View Mode Tabs: Live Table Grid vs Orders Feed */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-2">
            <div className="bg-stone-900 p-1 rounded-2xl border border-stone-800 flex items-center gap-1">
              <button
                type="button"
                onClick={() => setActiveDashboardTab('feed')}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
                  activeDashboardTab === 'feed'
                    ? 'bg-amber-500 text-stone-950 shadow-md'
                    : 'text-stone-400 hover:text-white'
                }`}
              >
                <ListOrdered className="w-3.5 h-3.5" />
                <span>Orders Feed ({orders.length})</span>
                {pendingCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[10px] font-mono animate-pulse">
                    {pendingCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setActiveDashboardTab('grid')}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
                  activeDashboardTab === 'grid'
                    ? 'bg-amber-500 text-stone-950 shadow-md'
                    : 'text-stone-400 hover:text-white'
                }`}
              >
                <Grid3X3 className="w-3.5 h-3.5" />
                <span>Live Table Grid (Staff Duty)</span>
                <span className="px-1.5 py-0.2 rounded-full bg-stone-800 text-stone-300 text-[10px] font-mono">
                  {tableGrid.length}
                </span>
              </button>
            </div>

            {/* Filter Pills for Feed Mode */}
            {activeDashboardTab === 'feed' && (
              <div className="hidden sm:flex items-center gap-1.5 pl-2">
                {staffRole === 'waiter' && myAssignedTables.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setWaiterFilterOnlyMine(!waiterFilterOnlyMine)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                      waiterFilterOnlyMine
                        ? 'bg-emerald-500 text-stone-950 font-black shadow-xs'
                        : 'bg-stone-900 text-stone-300 border border-stone-800 hover:text-white'
                    }`}
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>My Tables Only ({myAssignedTables.join(', ')})</span>
                  </button>
                )}

                {(['all', 'pending', 'accepted', 'completed'] as const).map((tab) => {
                  const count = tab === 'all' 
                    ? displayedOrders.length 
                    : displayedOrders.filter(o => o.status === tab).length;

                  return (
                    <button
                      key={tab}
                      type="button"
                      onClick={() => setFilterStatus(tab)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all capitalize flex items-center gap-1 cursor-pointer ${
                        filterStatus === tab
                          ? 'bg-white text-stone-950'
                          : 'bg-stone-900 text-stone-400 hover:text-white border border-stone-800'
                      }`}
                    >
                      <span>{tab}</span>
                      <span className="text-[10px] opacity-70">({count})</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="text-xs text-stone-400 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span className="font-mono text-[11px]">Supabase & WebSocket Synced</span>
          </div>
        </div>

        {/* ═══════════════════════════════════════════════════════════════ */}
        {/* VIEW 1: LIVE TABLE GRID (STAFF ALLOCATION & DUTY VIEW)        */}
        {/* ═══════════════════════════════════════════════════════════════ */}
        {activeDashboardTab === 'grid' && (
          <div className="space-y-4">
            <div className="p-4 bg-stone-900/80 border border-stone-800 rounded-3xl flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-4">
                <span className="font-bold text-stone-400 uppercase tracking-wider">Status Legend:</span>
                <span className="flex items-center gap-1.5 text-stone-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" /> Ringing Alert
                </span>
                <span className="flex items-center gap-1.5 text-stone-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-400" /> Pending Food
                </span>
                <span className="flex items-center gap-1.5 text-stone-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" /> Active Dining
                </span>
                <span className="flex items-center gap-1.5 text-stone-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-stone-600" /> Available / Idle
                </span>
              </div>

              <div className="text-stone-400 text-xs">
                Click any table card to view active items or reassign waiter.
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
              {tableGrid.map((table) => {
                const isRinging = table.status === 'ringing';
                const hasOrders = table.activeOrdersCount > 0;
                const isUnassigned = !table.assignedStaffName;

                return (
                  <motion.div
                    key={table.tableNumber}
                    layout
                    whileHover={{ scale: 1.02 }}
                    className={`p-4 rounded-3xl border transition-all flex flex-col justify-between relative cursor-pointer ${
                      isRinging
                        ? 'bg-gradient-to-br from-rose-950 via-stone-900 to-amber-950 border-rose-500 shadow-xl shadow-rose-900/40 ring-2 ring-rose-400 animate-pulse'
                        : hasOrders
                        ? 'bg-stone-900 border-amber-500/60 shadow-md shadow-amber-500/10'
                        : 'bg-stone-900/60 border-stone-800 hover:border-stone-700'
                    }`}
                    onClick={() => setSelectedTableDetails(table)}
                  >
                    {/* Header: Table Number & Status Pill */}
                    <div>
                      <div className="flex items-start justify-between gap-1 mb-2">
                        <div className="flex items-center gap-1.5">
                          <span className="px-2.5 py-1 rounded-xl bg-stone-800 text-white font-black text-xs sm:text-sm font-mono border border-stone-700">
                            T{table.tableNumber}
                          </span>
                        </div>

                        <span className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider ${
                          isRinging
                            ? 'bg-rose-500 text-white animate-bounce'
                            : hasOrders
                            ? 'bg-amber-400/20 text-amber-300 border border-amber-400/30'
                            : 'bg-stone-800 text-stone-400'
                        }`}>
                          {table.status}
                        </span>
                      </div>

                      {/* Waiter Assigned Badge */}
                      <div className="my-2 p-2 rounded-xl bg-stone-950/80 border border-stone-800">
                        <div className="text-[10px] text-stone-500 uppercase font-bold tracking-wider">
                          Serving Staff
                        </div>
                        <div className="flex items-center gap-1 mt-0.5">
                          <UserCheck className={`w-3.5 h-3.5 shrink-0 ${isUnassigned ? 'text-amber-500' : 'text-emerald-400'}`} />
                          <span className={`text-xs font-black truncate ${isUnassigned ? 'text-amber-400' : 'text-stone-100'}`}>
                            {table.assignedStaffName || 'Unassigned'}
                          </span>
                        </div>
                        {table.assignedStaff?.role && (
                          <div className="text-[9px] font-mono text-stone-500 uppercase">
                            Role: {table.assignedStaff.role}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Active Order Summary & Footer */}
                    <div className="pt-2 border-t border-stone-800/80 mt-2 space-y-1.5">
                      <div className="flex items-center justify-between text-xs font-mono">
                        <span className="text-stone-400">Active Orders:</span>
                        <span className={`font-bold ${hasOrders ? 'text-amber-400' : 'text-stone-500'}`}>
                          {table.activeOrdersCount}
                        </span>
                      </div>

                      {hasOrders && (
                        <div className="flex items-center justify-between text-xs font-mono">
                          <span className="text-stone-400">Total Tab:</span>
                          <span className="font-black text-white">
                            ₹{table.totalBillAmount}
                          </span>
                        </div>
                      )}

                      <div className="pt-1 flex items-center justify-between gap-1">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            simulateTestOrder(table.tableNumber);
                          }}
                          className="flex-1 py-1 px-1.5 bg-stone-800 hover:bg-stone-700 text-amber-300 text-[10px] font-bold rounded-lg transition-colors text-center"
                          title="Simulate order at this table"
                        >
                          + Order
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setReassignModalTable(table.tableNumber);
                          }}
                          className="py-1 px-2 bg-stone-800 hover:bg-stone-700 text-stone-300 text-[10px] font-bold rounded-lg transition-colors"
                          title="Reassign Waiter"
                        >
                          Duty
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {/* ═══════════════════════════════════════════════════════════════ */}
        {/* VIEW 2: ORDERS FEED                                           */}
        {/* ═══════════════════════════════════════════════════════════════ */}
        {activeDashboardTab === 'feed' && (
          <div>
            {displayedOrders.length === 0 ? (
              <div className="p-12 text-center bg-stone-900/40 rounded-3xl border border-stone-800/80 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-stone-800 text-stone-500 flex items-center justify-center mx-auto">
                  <Utensils className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-stone-300 text-base">No Orders in this filter</h3>
                <p className="text-xs text-stone-500 max-w-sm mx-auto">
                  Incoming orders automatically map to assigned waiters (e.g. Table 2 ➜ Waiter Ramesh) with instantaneous alerts.
                </p>
                <button
                  type="button"
                  onClick={() => simulateTestOrder('2')}
                  className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-amber-400 text-xs font-bold rounded-xl border border-stone-700 inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Simulate Table 2 (Waiter Ramesh)</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {displayedOrders.map((order) => {
                  const isPending = order.status === 'pending';
                  const currency = order.currencySymbol || '₹';

                  return (
                    <motion.div
                      key={order.id}
                      layout
                      className={`p-5 rounded-3xl border transition-all flex flex-col justify-between shadow-sm ${
                        isPending
                          ? 'bg-stone-900 border-amber-500/60 shadow-xl shadow-amber-500/10 ring-1 ring-amber-500/30'
                          : order.status === 'accepted'
                          ? 'bg-stone-900/90 border-emerald-500/40'
                          : 'bg-stone-900/50 border-stone-800 opacity-75'
                      }`}
                    >
                      <div>
                        {/* Multi-Tenant & Waiter Duty Alert Line */}
                        <div className="mb-3 px-3 py-2 bg-stone-950/90 border border-stone-800 rounded-2xl flex flex-col gap-1">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-mono font-bold text-amber-400">
                              {order.formattedSummary || `Order #${order.orderId || 1} | Table ${order.tableNumber}`}
                            </span>
                            <span className="text-[10px] text-stone-500 font-mono">
                              {order.restaurantId ? `@${order.restaurantId}` : ''}
                            </span>
                          </div>

                          {/* Duty Assignment Banner */}
                          <div className="flex items-center gap-1.5 text-xs text-stone-300 font-medium">
                            <UserCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                            <span>
                              {order.assignedStaffName ? (
                                <>Serving Staff: <strong className="text-white">{order.assignedStaffName}</strong></>
                              ) : (
                                <span className="text-stone-500">Unassigned Staff</span>
                              )}
                            </span>
                          </div>
                        </div>

                        {/* Header */}
                        <div className="flex items-start justify-between gap-2 pb-3 border-b border-stone-800">
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              {/* Sequential Order Serial Number */}
                              <span className="px-2.5 py-0.5 rounded-lg font-black text-xs bg-amber-400 text-stone-950 font-mono tracking-tight shadow-2xs">
                                {order.orderSerial || `#${String(order.orderId || 1).padStart(3, '0')}`}
                              </span>

                              {/* Specific Table or Room number based on context */}
                              <span className={`px-2.5 py-0.5 rounded-lg font-black text-xs ${
                                order.tableNumber.toLowerCase().includes('room')
                                  ? 'bg-emerald-500 text-stone-950'
                                  : order.tableNumber.toLowerCase().includes('parcel')
                                  ? 'bg-amber-600 text-white'
                                  : 'bg-stone-700 text-stone-100'
                              }`}>
                                {order.tableNumber.toUpperCase().startsWith('ROOM') || order.tableNumber.toUpperCase().startsWith('TABLE')
                                  ? order.tableNumber.toUpperCase()
                                  : `TABLE ${order.tableNumber}`}
                              </span>
                            </div>

                            {/* Exact Date and Time */}
                            <div className="text-[11px] text-stone-400 mt-1.5 flex items-center gap-3 font-mono">
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3 text-stone-500" />
                                {order.orderDate || new Date(order.createdAt).toISOString().slice(0, 10)}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3 text-stone-500" />
                                {order.orderTime || new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                              </span>
                            </div>
                          </div>

                          <div className="flex flex-col items-end gap-1.5">
                            <span className={`px-2.5 py-1 rounded-xl text-[11px] font-bold uppercase tracking-wider ${
                              isPending
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
                                : order.status === 'accepted'
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : 'bg-stone-800 text-stone-400'
                            }`}>
                              {order.status}
                            </span>
                            <button
                              type="button"
                              onClick={() => setInspectKotOrder(order)}
                              className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold text-amber-400 bg-stone-800 hover:bg-stone-750 border border-stone-700 rounded-md transition cursor-pointer"
                              title="View and Print Kitchen Order Ticket"
                            >
                              <FileText className="w-3 h-3" />
                              <span>KOT Ticket</span>
                            </button>
                          </div>
                        </div>

                        {/* Customer Contact (Name & Phone Number) */}
                        <div className="my-2.5 p-2.5 rounded-xl bg-stone-950/80 border border-stone-800/80 text-xs space-y-1">
                          <div className="text-[10px] font-bold uppercase tracking-wider text-stone-500 flex items-center justify-between">
                            <span>Customer Contact</span>
                            <span className="text-amber-500/80 font-mono text-[9px]">DIRECT DB</span>
                          </div>
                          <div className="flex items-center justify-between text-stone-300">
                            <span className="flex items-center gap-1 text-stone-400">
                              <User className="w-3 h-3 text-stone-500" /> Name:
                            </span>
                            <span className="font-bold text-white">
                              {order.customerName || 'Walk-in Customer'}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-stone-300">
                            <span className="flex items-center gap-1 text-stone-400">
                              <Phone className="w-3 h-3 text-stone-500" /> Phone:
                            </span>
                            <span className="font-mono text-stone-300">
                              {order.customerPhone || 'Not provided'}
                            </span>
                          </div>
                        </div>

                        {/* Items List */}
                        <div className="py-3 space-y-2 divide-y divide-stone-800/60">
                          {order.items.map((item, idx) => {
                            const itemTotal = item.totalItemPrice !== undefined ? item.totalItemPrice : ((item.unitPrice || item.price) * item.quantity);
                            const customText = item.customNote?.trim() || (item.selectedOptions && item.selectedOptions.length > 0 ? item.selectedOptions.join(', ') : '');
                            return (
                              <div key={idx} className={idx > 0 ? 'pt-2 space-y-0.5' : 'space-y-0.5'}>
                                <div className="flex items-center justify-between text-xs">
                                  <div className="flex items-center gap-1.5 min-w-0 pr-2">
                                    <span className="font-bold text-amber-400">{item.quantity}x</span>
                                    <span className="text-stone-100 font-bold uppercase tracking-wide truncate">{item.name}</span>
                                    {item.variantName && !item.name.includes(item.variantName) && (
                                      <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded border border-amber-500/30 font-bold shrink-0">
                                        {item.variantName}
                                      </span>
                                    )}
                                  </div>
                                  <span className="font-mono text-stone-300 font-bold shrink-0">
                                    {currency}{itemTotal}
                                  </span>
                                </div>

                                {/* Customisation text cleanly formatted directly underneath */}
                                {customText && (
                                  <div className="pl-5 text-[11px] text-amber-300 font-medium italic">
                                    • Customisation: &quot;{customText}&quot;
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>

                        {/* Customer Notes */}
                        {order.customerNotes && (
                          <div className="p-2.5 bg-stone-800/80 rounded-xl border border-stone-700/60 text-xs text-stone-300 my-2">
                            <span className="font-bold text-amber-400 text-[10px] block uppercase tracking-wider mb-0.5">
                              Special Note:
                            </span>
                            {order.customerNotes}
                          </div>
                        )}
                      </div>

                      {/* Footer & Actions */}
                      <div className="pt-3 border-t border-stone-800 space-y-3 mt-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-stone-400">Total Bill:</span>
                          <span className="text-lg font-black text-white font-mono">
                            {currency}{order.totalPrice}
                          </span>
                        </div>

                        {/* Status Actions */}
                        <div className="flex items-center gap-2">
                          {isPending ? (
                            <>
                              <button
                                type="button"
                                onClick={() => updateOrderStatus(order.id, 'accepted')}
                                className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                              >
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                                <span>Accept Order</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => updateOrderStatus(order.id, 'cancelled')}
                                className="py-2 px-2.5 bg-stone-800 hover:bg-rose-950 text-stone-400 hover:text-rose-400 text-xs font-bold rounded-xl border border-stone-700 transition-colors cursor-pointer"
                                title="Cancel Order"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </>
                          ) : order.status === 'accepted' ? (
                            <button
                              type="button"
                              onClick={() => updateOrderStatus(order.id, 'completed')}
                              className="w-full py-2 px-3 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold rounded-xl border border-stone-700 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Mark as Completed</span>
                            </button>
                          ) : (
                            <div className="text-[11px] text-stone-500 italic text-center w-full">
                              Order completed
                            </div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Modal: Quick Reassign Waiter for Table */}
        <AnimatePresence>
          {reassignModalTable && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setReassignModalTable(null)}
                className="fixed inset-0 bg-black/80 backdrop-blur-xs"
              />

              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="relative w-full max-w-md bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-2xl z-10 space-y-4"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-black text-xs">
                      T{reassignModalTable}
                    </div>
                    <h3 className="font-bold text-white text-base">Reassign Table {reassignModalTable} Duty</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setReassignModalTable(null)}
                    className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 flex items-center justify-center text-stone-400 hover:text-white cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <form onSubmit={handleQuickReassign} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-2">
                      Select Staff Member for {isGuestHouse ? 'Room / Area' : 'Table'} {reassignModalTable}
                    </label>
                    <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                      {(isGuestHouse ? [
                        { name: 'Anita Sharma', role: 'Front Desk / Reception' },
                        { name: 'Lakshmi Devi', role: 'Housekeeping & Linen' },
                        { name: 'Ravi Kumar', role: 'Room Service' },
                        { name: 'Kiran Das', role: 'Coffee Shop / Bar' },
                        { name: 'Manoj Singh', role: 'Bell Boy / Concierge' },
                        { name: 'Sunil Verma', role: 'Facilities & Recreation' },
                        { name: 'Arun Patel', role: 'Maintenance' },
                      ] : [
                        { name: 'Chef Anbu', role: 'Head Chef / Kitchen Staff' },
                        { name: 'Waiter Ramesh', role: 'Table Waiter / Captain' },
                        { name: 'Captain Priya', role: 'Table Waiter / Captain' },
                        { name: 'Waiter Suresh', role: 'Table Waiter / Captain' },
                        { name: 'Sundar', role: 'Cashier / Billing Counter' },
                        { name: 'Karthik', role: 'Delivery / Runner' }
                      ]).map((staffItem) => (
                        <button
                          key={staffItem.name}
                          type="button"
                          onClick={() => setReassignStaffInput(staffItem.name)}
                          className={`w-full p-2.5 rounded-2xl border text-left flex items-center justify-between transition-colors cursor-pointer ${
                            reassignStaffInput === staffItem.name
                              ? isGuestHouse ? 'bg-sky-500/20 border-sky-500 text-sky-300 font-bold' : 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                              : 'bg-stone-800 border-stone-700 text-stone-300 hover:bg-stone-750'
                          }`}
                        >
                          <div className="flex flex-col">
                            <span className="text-xs font-bold">{staffItem.name}</span>
                            <span className="text-[10px] text-stone-400">{staffItem.role}</span>
                          </div>
                          {reassignStaffInput === staffItem.name && <Check className={`w-4 h-4 ${isGuestHouse ? 'text-sky-400' : 'text-amber-400'}`} />}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-1">
                      Or Custom Staff Name:
                    </label>
                    <input
                      type="text"
                      placeholder={isGuestHouse ? "e.g. Anita Sharma" : "e.g. Waiter Ramesh"}
                      value={reassignStaffInput}
                      onChange={(e) => setReassignStaffInput(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-xs text-white focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setReassignModalTable(null)}
                      className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-xl text-xs font-bold cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className={`px-5 py-2 font-black rounded-xl text-xs shadow-md cursor-pointer ${
                        isGuestHouse ? 'bg-sky-400 hover:bg-sky-300 text-stone-950' : 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                      }`}
                    >
                      Confirm Allocation
                    </button>
                  </div>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Modal: Table Active Orders Details */}
        <AnimatePresence>
          {selectedTableDetails && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSelectedTableDetails(null)}
                className="fixed inset-0 bg-black/80 backdrop-blur-xs"
              />

              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="relative w-full max-w-lg bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-2xl z-10 space-y-4"
              >
                <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1 bg-amber-500 text-stone-950 font-black text-sm rounded-xl">
                        Table {selectedTableDetails.tableNumber}
                      </span>
                      <h3 className="font-bold text-white text-base">Live Table Overview</h3>
                    </div>
                    <p className="text-xs text-stone-400 mt-1">
                      Assigned Waiter: <strong className="text-amber-400">{selectedTableDetails.assignedStaffName || 'None'}</strong>
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedTableDetails(null)}
                    className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 flex items-center justify-center text-stone-400 hover:text-white cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Table Orders List */}
                <div className="space-y-3 max-h-[60vh] overflow-y-auto">
                  {orders.filter(o => o.tableNumber === selectedTableDetails.tableNumber).length === 0 ? (
                    <div className="p-8 text-center bg-stone-950/50 rounded-2xl border border-dashed border-stone-800 text-stone-400 text-xs">
                      No active orders on Table {selectedTableDetails.tableNumber} right now.
                    </div>
                  ) : (
                    orders
                      .filter(o => o.tableNumber === selectedTableDetails.tableNumber)
                      .map((ord) => (
                        <div key={ord.id} className="p-4 bg-stone-950/80 border border-stone-800 rounded-2xl space-y-2.5">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="px-2 py-0.5 rounded-md bg-amber-400 text-stone-950 text-[11px] font-black font-mono">
                                {ord.orderSerial || `#${String(ord.orderId || 1).padStart(3, '0')}`}
                              </span>
                              <span className="text-xs font-mono font-medium text-stone-400">
                                {ord.orderDate || new Date(ord.createdAt).toISOString().slice(0, 10)} {ord.orderTime || ''}
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => setInspectKotOrder(ord)}
                                className="px-2 py-0.5 rounded bg-stone-800 hover:bg-stone-700 text-amber-300 text-[10px] font-bold border border-stone-700 flex items-center gap-1 cursor-pointer"
                              >
                                <FileText className="w-3 h-3" />
                                <span>KOT</span>
                              </button>
                              <span className="px-2 py-0.5 rounded-md bg-stone-800 text-[10px] font-bold uppercase text-stone-300">
                                {ord.status}
                              </span>
                            </div>
                          </div>

                          {/* Customer Contact */}
                          <div className="text-[11px] text-stone-400 bg-stone-900/60 p-2 rounded-lg flex items-center justify-between">
                            <span>Customer: <strong className="text-stone-200">{ord.customerName || 'Walk-in'}</strong></span>
                            <span className="font-mono">{ord.customerPhone || 'No Phone'}</span>
                          </div>

                          <div className="space-y-1.5 text-xs divide-y divide-stone-800/60">
                            {ord.items.map((it, i) => {
                              const itTotal = it.totalItemPrice !== undefined ? it.totalItemPrice : ((it.unitPrice || it.price) * it.quantity);
                              const customText = it.customNote?.trim() || (it.selectedOptions && it.selectedOptions.length > 0 ? it.selectedOptions.join(', ') : '');
                              return (
                                <div key={i} className={i > 0 ? 'pt-1.5 space-y-0.5' : 'space-y-0.5'}>
                                  <div className="flex items-center justify-between text-stone-200">
                                    <span className="font-bold uppercase tracking-wide">{it.quantity}x {it.name}</span>
                                    <span className="font-mono font-bold text-amber-300">₹{itTotal}</span>
                                  </div>

                                  {customText && (
                                    <div className="pl-4 text-[11px] text-amber-300 font-medium italic">
                                      • Customisation: &quot;{customText}&quot;
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>

                          <div className="pt-2 border-t border-stone-800 flex items-center justify-between font-mono text-xs font-bold text-white">
                            <span>Subtotal:</span>
                            <span>₹{ord.totalPrice}</span>
                          </div>
                        </div>
                      ))
                  )}
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => {
                      simulateTestOrder(selectedTableDetails.tableNumber);
                      setSelectedTableDetails(null);
                    }}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-black rounded-xl text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Place Test Order at Table {selectedTableDetails.tableNumber}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedTableDetails(null)}
                    className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* WhatsApp QR Pairing Modal */}
        <AnimatePresence>
          {showQRModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowQRModal(false)}
                className="fixed inset-0 bg-black/80 backdrop-blur-xs"
              />

              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="relative w-full max-w-md bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-2xl z-10 space-y-4"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-emerald-500 text-stone-950 flex items-center justify-center font-bold">
                      <QrCode className="w-4 h-4" />
                    </div>
                    <h3 className="font-bold text-white text-base">WhatsApp Device Pairing</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowQRModal(false)}
                    className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 flex items-center justify-center text-stone-400 hover:text-white cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {waStatus.status === 'connected' ? (
                  <div className="p-6 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl text-center space-y-3">
                    <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                      <Check className="w-6 h-6 stroke-[3]" />
                    </div>
                    <h4 className="font-bold text-white text-base">WhatsApp Connected!</h4>
                    <p className="text-xs text-emerald-300 font-mono">
                      Linked Device: +{waStatus.pairedUser}
                    </p>
                    <p className="text-xs text-stone-400">
                      Your orders will automatically trigger native WhatsApp messages to your phone without any paid cloud gateway fees.
                    </p>

                    <button
                      type="button"
                      onClick={handleResetWhatsApp}
                      className="px-4 py-2 bg-stone-800 hover:bg-rose-900/60 text-rose-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                    >
                      Unlink & Re-scan New QR
                    </button>
                  </div>
                ) : waStatus.qrCodeDataUrl ? (
                  <div className="space-y-4 text-center">
                    <div className="p-4 bg-white rounded-2xl inline-block shadow-lg mx-auto">
                      <img
                        src={waStatus.qrCodeDataUrl}
                        alt="WhatsApp Pairing QR"
                        className="w-56 h-56 mx-auto"
                      />
                    </div>

                    <div className="text-left bg-stone-800/60 p-3.5 rounded-xl border border-stone-700/60 text-xs text-stone-300 space-y-1.5">
                      <p className="font-bold text-white">How to link:</p>
                      <p>1. Open WhatsApp on your phone.</p>
                      <p>2. Tap <strong>Settings</strong> or <strong>Menu</strong> ➜ <strong>Linked Devices</strong>.</p>
                      <p>3. Tap <strong>Link a Device</strong> and point your camera at this QR code.</p>
                    </div>

                    <div className="flex items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={handleResetWhatsApp}
                        className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-medium rounded-xl border border-stone-700 flex items-center gap-1.5 cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Regenerate QR</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="p-8 text-center space-y-3">
                    <RefreshCw className="w-8 h-8 text-amber-400 animate-spin mx-auto" />
                    <p className="text-sm font-bold text-stone-200">Initializing WhatsApp Engine...</p>
                    <p className="text-xs text-stone-400">Please wait while the WebSocket connection generates a fresh pairing QR code.</p>
                  </div>
                )}
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Modal: Official KOT Ticket View / Print */}
        <AnimatePresence>
          {inspectKotOrder && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="relative w-full max-w-md bg-stone-900 border border-stone-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
              >
                {/* Header bar */}
                <div className="p-4 bg-stone-950 border-b border-stone-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-amber-400 text-stone-950 flex items-center justify-center font-black">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">Kitchen Order Ticket (KOT)</h3>
                      <p className="text-[11px] text-stone-400 font-mono">
                        {inspectKotOrder.orderSerial || `#${String(inspectKotOrder.orderId || 1).padStart(3, '0')}`}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold rounded-xl border border-stone-700 flex items-center gap-1.5 transition cursor-pointer"
                      title="Print KOT Ticket"
                    >
                      <Printer className="w-3.5 h-3.5 text-amber-400" />
                      <span>Print</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setInspectKotOrder(null)}
                      className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 flex items-center justify-center text-stone-400 hover:text-white cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Thermal Ticket Container */}
                <div className="p-5 overflow-y-auto bg-stone-900">
                  <div className="bg-[#FAF9F5] text-stone-950 p-6 rounded-2xl shadow-inner border border-stone-300 font-mono text-xs space-y-4">
                    {/* Header */}
                    <div className="text-center border-b-2 border-dashed border-stone-400 pb-4">
                      <h2 className="text-base font-black uppercase tracking-wider text-stone-900">
                        {inspectKotOrder.restaurantName || 'RESTAURANT KITCHEN'}
                      </h2>
                      <div className="text-[10px] text-stone-600 mt-0.5">
                        {inspectKotOrder.restaurantAddress || 'Direct Order Management Engine'}
                      </div>
                      <div className="mt-2 inline-block px-3 py-1 bg-stone-950 text-amber-400 text-xs font-black rounded-sm uppercase tracking-widest">
                        *** KITCHEN ORDER TICKET (KOT) ***
                      </div>
                    </div>

                    {/* Metadata Grid: 4 Core Requirements */}
                    <div className="grid grid-cols-2 gap-2 text-xs border-b-2 border-dashed border-stone-400 pb-3">
                      {/* 1. Sequential Order Serial Number */}
                      <div className="col-span-2 flex items-center justify-between bg-stone-200/80 p-2 rounded">
                        <span className="font-bold uppercase text-[11px] text-stone-700">Order Serial No:</span>
                        <span className="text-base font-black text-stone-950 font-mono">
                          {inspectKotOrder.orderSerial || `#${String(inspectKotOrder.orderId || 1).padStart(3, '0')}`}
                        </span>
                      </div>

                      {/* 2. Specific Table / Room Number */}
                      <div className="col-span-2 flex items-center justify-between bg-stone-100 p-2 rounded border border-stone-300">
                        <span className="font-bold uppercase text-[11px] text-stone-700">Service Location:</span>
                        <span className="text-sm font-black text-stone-950 uppercase">
                          {inspectKotOrder.tableNumber.toUpperCase().startsWith('ROOM') || inspectKotOrder.tableNumber.toUpperCase().startsWith('TABLE')
                            ? inspectKotOrder.tableNumber.toUpperCase()
                            : `TABLE ${inspectKotOrder.tableNumber}`}
                        </span>
                      </div>

                      {/* 3. Exact Date and Time */}
                      <div className="space-y-0.5">
                        <span className="text-[10px] uppercase font-bold text-stone-600 block">Date:</span>
                        <span className="font-bold text-stone-900">
                          {inspectKotOrder.orderDate || new Date(inspectKotOrder.createdAt).toISOString().slice(0, 10)}
                        </span>
                      </div>
                      <div className="space-y-0.5 text-right">
                        <span className="text-[10px] uppercase font-bold text-stone-600 block">Time:</span>
                        <span className="font-bold text-stone-900">
                          {inspectKotOrder.orderTime || new Date(inspectKotOrder.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </span>
                      </div>

                      {/* 4. Customer Contact (Name & Phone Number) */}
                      <div className="col-span-2 pt-2 border-t border-dotted border-stone-300 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] uppercase font-bold text-stone-600">Customer:</span>
                          <span className="font-bold text-stone-900">{inspectKotOrder.customerName || 'Walk-in Customer'}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] uppercase font-bold text-stone-600">Phone:</span>
                          <span className="font-bold text-stone-900 font-mono">{inspectKotOrder.customerPhone || 'Not provided'}</span>
                        </div>
                        {inspectKotOrder.assignedStaffName && (
                          <div className="flex items-center justify-between text-stone-600">
                            <span className="text-[10px] uppercase font-bold">Assigned Staff:</span>
                            <span className="font-semibold">{inspectKotOrder.assignedStaffName}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Order Items */}
                    <div className="space-y-2 border-b-2 border-dashed border-stone-400 pb-3">
                      <div className="flex items-center justify-between text-[11px] font-black uppercase text-stone-600 border-b border-stone-300 pb-1">
                        <span>ITEM / QTY</span>
                        <span>PRICE</span>
                      </div>

                      {inspectKotOrder.items.map((item, idx) => {
                        const itTotal = item.totalItemPrice !== undefined ? item.totalItemPrice : ((item.unitPrice || item.price) * item.quantity);
                        const customText = item.customNote?.trim() || (item.selectedOptions && item.selectedOptions.length > 0 ? item.selectedOptions.join(', ') : '');
                        return (
                          <div key={idx} className="space-y-0.5">
                            <div className="flex items-baseline justify-between font-bold">
                              <span className="text-xs">
                                {item.quantity} x {item.name}
                                {item.variantName ? ` (${item.variantName})` : ''}
                              </span>
                              <span>{inspectKotOrder.currencySymbol || '₹'}{itTotal}</span>
                            </div>
                            {customText && (
                              <div className="text-[11px] text-amber-800 italic pl-3">
                                ** NOTE: {customText}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Customer Notes */}
                    {inspectKotOrder.customerNotes && (
                      <div className="p-2 bg-amber-100/70 border border-amber-300 rounded text-[11px] text-amber-950 font-sans">
                        <span className="font-bold block uppercase text-[10px]">Kitchen Note:</span>
                        {inspectKotOrder.customerNotes}
                      </div>
                    )}

                    {/* Total */}
                    <div className="flex items-center justify-between text-sm font-black pt-1">
                      <span>TOTAL BILL:</span>
                      <span className="text-base font-mono">
                        {inspectKotOrder.currencySymbol || '₹'}{inspectKotOrder.totalPrice}
                      </span>
                    </div>

                    <div className="text-center text-[10px] text-stone-500 pt-2 border-t border-dashed border-stone-300">
                      --- END OF ORDER TICKET ---
                    </div>
                  </div>
                </div>

                {/* Footer action */}
                <div className="p-4 bg-stone-950 border-t border-stone-800 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setInspectKotOrder(null)}
                    className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="px-5 py-2 bg-amber-400 hover:bg-amber-300 text-stone-950 font-black rounded-xl text-xs flex items-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print Kitchen Slip</span>
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
};
