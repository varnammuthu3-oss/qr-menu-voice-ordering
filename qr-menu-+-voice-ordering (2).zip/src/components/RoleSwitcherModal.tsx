import React, { useState } from 'react';
import { AppStaffRole, StaffRoleConfig } from '../types';
import { ROLE_CONFIGS, saveStoredStaffRole } from '../lib/roleAccessControl';
import { 
  Crown, 
  Shield, 
  UserCheck, 
  Check, 
  X, 
  Sparkles, 
  Lock, 
  Eye, 
  VolumeX, 
  Users, 
  DollarSign, 
  FileText, 
  ArrowRight,
  Utensils
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface RoleSwitcherModalProps {
  isOpen: boolean;
  onClose?: () => void;
  currentRole: AppStaffRole | null;
  staffName?: string;
  onSelectRole: (role: AppStaffRole, staffName: string) => void;
  isInitialStartup?: boolean;
}

export const RoleSwitcherModal: React.FC<RoleSwitcherModalProps> = ({
  isOpen,
  onClose,
  currentRole,
  staffName: propStaffName,
  onSelectRole,
  isInitialStartup = false,
}) => {
  const [selectedRole, setSelectedRole] = useState<AppStaffRole>(currentRole || 'owner');
  const [staffName, setStaffName] = useState<string>(() => {
    if (propStaffName) return propStaffName;
    if (typeof window !== 'undefined') {
      const savedName = localStorage.getItem('restaurant_staff_name');
      if (savedName) return savedName;
    }
    return selectedRole === 'owner' ? 'Owner / Admin' : selectedRole === 'manager' ? 'Captain Priya' : 'Waiter Ramesh';
  });
  const [rememberPreference, setRememberPreference] = useState<boolean>(true);

  if (!isOpen) return null;

  const handleRoleClick = (role: AppStaffRole) => {
    setSelectedRole(role);
    if (role === 'owner') setStaffName('Owner / Admin');
    else if (role === 'manager') setStaffName('Captain Priya');
    else if (role === 'waiter') setStaffName('Waiter Ramesh');
  };

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    const finalName = staffName.trim() || ROLE_CONFIGS[selectedRole].title;
    if (rememberPreference) {
      saveStoredStaffRole(selectedRole, finalName);
    }
    onSelectRole(selectedRole, finalName);
    if (onClose) onClose();
  };

  const activeConfig = ROLE_CONFIGS[selectedRole];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={() => {
          if (!isInitialStartup && onClose) onClose();
        }}
        className="fixed inset-0 bg-stone-950/85 backdrop-blur-md"
      />

      {/* Modal Container */}
      <motion.div
        initial={{ scale: 0.94, opacity: 0, y: 15 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.94, opacity: 0, y: 15 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="relative w-full max-w-3xl bg-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-7 shadow-2xl z-10 space-y-6 my-auto text-stone-100 max-h-[92vh] flex flex-col justify-between overflow-y-auto"
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-stone-800 pb-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-bold mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Staff Login & Role Access Control</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {isInitialStartup ? 'Select Your Working Role' : 'Switch Staff Persona & Permissions'}
            </h2>
            <p className="text-xs sm:text-sm text-stone-400 mt-1">
              Choose your role to grant customized permissions, live alert scopes, and duty management controls.
            </p>
          </div>

          {!isInitialStartup && onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-2xl bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* 1. ROLE CHOOSER UI SELECTOR [ Owner / Admin ] | [ Captain / Manager ] | [ Waiter ] */}
        <div className="space-y-4">
          <label className="block text-xs font-bold uppercase tracking-wider text-stone-400">
            Choose Staff Access Level:
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Owner / Admin */}
            <button
              type="button"
              onClick={() => handleRoleClick('owner')}
              className={`relative p-4 rounded-2xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
                selectedRole === 'owner'
                  ? 'bg-amber-500/15 border-amber-400 ring-2 ring-amber-400/40 shadow-lg shadow-amber-500/10'
                  : 'bg-stone-850/60 border-stone-800 hover:border-stone-700 hover:bg-stone-800/80'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-black">
                  <Crown className="w-5 h-5" />
                </div>
                {selectedRole === 'owner' && (
                  <span className="w-6 h-6 rounded-full bg-amber-400 text-stone-950 flex items-center justify-center text-xs font-black">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </span>
                )}
              </div>

              <div className="mt-3">
                <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300">
                  Full Access
                </span>
                <h3 className="font-black text-white text-base mt-1.5">Owner / Admin</h3>
                <p className="text-[11px] text-stone-400 mt-1 line-clamp-2">
                  Full financials, daily revenue, staff roster, and system controls.
                </p>
              </div>
            </button>

            {/* Captain / Manager */}
            <button
              type="button"
              onClick={() => handleRoleClick('manager')}
              className={`relative p-4 rounded-2xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
                selectedRole === 'manager'
                  ? 'bg-sky-500/15 border-sky-400 ring-2 ring-sky-400/40 shadow-lg shadow-sky-500/10'
                  : 'bg-stone-850/60 border-stone-800 hover:border-stone-700 hover:bg-stone-800/80'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-black">
                  <Shield className="w-5 h-5" />
                </div>
                {selectedRole === 'manager' && (
                  <span className="w-6 h-6 rounded-full bg-sky-400 text-stone-950 flex items-center justify-center text-xs font-black">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </span>
                )}
              </div>

              <div className="mt-3">
                <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-md bg-sky-500/20 text-sky-300">
                  Supervisor
                </span>
                <h3 className="font-black text-white text-base mt-1.5">Captain / Manager</h3>
                <p className="text-[11px] text-stone-400 mt-1 line-clamp-2">
                  View all table orders, assign waiters to tables, and mute audio alerts.
                </p>
              </div>
            </button>

            {/* Waiter */}
            <button
              type="button"
              onClick={() => handleRoleClick('waiter')}
              className={`relative p-4 rounded-2xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
                selectedRole === 'waiter'
                  ? 'bg-emerald-500/15 border-emerald-400 ring-2 ring-emerald-400/40 shadow-lg shadow-emerald-500/10'
                  : 'bg-stone-850/60 border-stone-800 hover:border-stone-700 hover:bg-stone-800/80'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black">
                  <UserCheck className="w-5 h-5" />
                </div>
                {selectedRole === 'waiter' && (
                  <span className="w-6 h-6 rounded-full bg-emerald-400 text-stone-950 flex items-center justify-center text-xs font-black">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </span>
                )}
              </div>

              <div className="mt-3">
                <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300">
                  Floor Service
                </span>
                <h3 className="font-black text-white text-base mt-1.5">Waiter</h3>
                <p className="text-[11px] text-stone-400 mt-1 line-clamp-2">
                  Table order alerts, food preparation status, and table-level service.
                </p>
              </div>
            </button>
          </div>
        </div>

        {/* 2. DYNAMIC PERMISSIONS MATRIX PREVIEW FOR CHOSEN ROLE */}
        <div className="p-4 sm:p-5 rounded-2xl bg-stone-950 border border-stone-800/90 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">
              Granted Permissions for <strong className="text-white">{activeConfig.title}</strong>:
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-mono font-bold ${
              selectedRole === 'owner' ? 'bg-amber-500/20 text-amber-300' :
              selectedRole === 'manager' ? 'bg-sky-500/20 text-sky-300' :
              'bg-emerald-500/20 text-emerald-300'
            }`}>
              {activeConfig.badge}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            {/* View all table orders */}
            <div className="flex items-center gap-2 p-2 rounded-xl bg-stone-900 border border-stone-850">
              <Eye className={`w-4 h-4 shrink-0 ${activeConfig.permissions.canViewAllOrders ? 'text-emerald-400' : 'text-stone-500'}`} />
              <span className={activeConfig.permissions.canViewAllOrders ? 'text-stone-200' : 'text-stone-500'}>
                View all table orders: <strong>{activeConfig.permissions.canViewAllOrders ? 'Granted' : 'Assigned Tables Only'}</strong>
              </span>
            </div>

            {/* Assign Waiters to Tables */}
            <div className="flex items-center gap-2 p-2 rounded-xl bg-stone-900 border border-stone-850">
              <Users className={`w-4 h-4 shrink-0 ${activeConfig.permissions.canAssignWaiters ? 'text-emerald-400' : 'text-stone-500'}`} />
              <span className={activeConfig.permissions.canAssignWaiters ? 'text-stone-200' : 'text-stone-500'}>
                Assign waiters to tables: <strong>{activeConfig.permissions.canAssignWaiters ? 'Granted' : 'Restricted'}</strong>
              </span>
            </div>

            {/* Mute Audio Alerts */}
            <div className="flex items-center gap-2 p-2 rounded-xl bg-stone-900 border border-stone-850">
              <VolumeX className={`w-4 h-4 shrink-0 ${activeConfig.permissions.canMuteAudioAlerts ? 'text-emerald-400' : 'text-stone-500'}`} />
              <span className={activeConfig.permissions.canMuteAudioAlerts ? 'text-stone-200' : 'text-stone-500'}>
                Mute audio alerts: <strong>{activeConfig.permissions.canMuteAudioAlerts ? 'Granted' : 'Restricted'}</strong>
              </span>
            </div>

            {/* Financial Daily Totals */}
            <div className="flex items-center gap-2 p-2 rounded-xl bg-stone-900 border border-stone-850">
              {activeConfig.permissions.canViewFinancialTotals ? (
                <DollarSign className="w-4 h-4 shrink-0 text-emerald-400" />
              ) : (
                <Lock className="w-4 h-4 shrink-0 text-amber-500" />
              )}
              <span className={activeConfig.permissions.canViewFinancialTotals ? 'text-stone-200' : 'text-stone-500'}>
                Financial daily totals: <strong>{activeConfig.permissions.canViewFinancialTotals ? 'Granted (Full Access)' : 'Hidden / Owner Only'}</strong>
              </span>
            </div>

            {/* Staff Duty Reports */}
            <div className="flex items-center gap-2 p-2 rounded-xl bg-stone-900 border border-stone-850 sm:col-span-2">
              <FileText className={`w-4 h-4 shrink-0 ${activeConfig.permissions.canViewStaffDutyReports ? 'text-emerald-400' : 'text-stone-500'}`} />
              <span className={activeConfig.permissions.canViewStaffDutyReports ? 'text-stone-200' : 'text-stone-500'}>
                Staff duty & shift reports: <strong>{activeConfig.permissions.canViewStaffDutyReports ? 'Granted' : 'Restricted to Managers & Owners'}</strong>
              </span>
            </div>
          </div>
        </div>

        {/* 3. STAFF NAME & STORAGE PERSISTENCE */}
        <form onSubmit={handleConfirm} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-400 mb-1">
                Your Staff Name / Badge Tag:
              </label>
              <input
                type="text"
                value={staffName}
                onChange={(e) => setStaffName(e.target.value)}
                placeholder="e.g. Waiter Ramesh, Captain Priya"
                className="w-full px-3.5 py-2.5 bg-stone-800 border border-stone-700 rounded-xl text-xs sm:text-sm text-white focus:outline-hidden focus:border-amber-500 font-medium"
                required
              />
            </div>

            <div className="flex flex-col justify-end">
              <label className="flex items-center gap-2 p-2.5 bg-stone-800/80 rounded-xl border border-stone-750 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberPreference}
                  onChange={(e) => setRememberPreference(e.target.checked)}
                  className="w-4 h-4 rounded-md accent-amber-500 cursor-pointer"
                />
                <span className="text-xs text-stone-300">
                  Save role in local storage (<code className="text-amber-300 font-mono text-[11px]">localStorage</code>)
                </span>
              </label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-stone-800 flex items-center justify-between gap-3">
            {!isInitialStartup && onClose ? (
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-300 font-bold rounded-xl text-xs transition-colors cursor-pointer"
              >
                Cancel
              </button>
            ) : (
              <div className="text-xs text-stone-500 flex items-center gap-1.5">
                <Utensils className="w-3.5 h-3.5 text-amber-500" />
                <span>Sri Murugan Tiffin Center Staff Portal</span>
              </div>
            )}

            <button
              type="submit"
              className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-stone-950 font-black rounded-xl text-xs sm:text-sm shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-all cursor-pointer transform active:scale-95"
            >
              <span>Launch as {activeConfig.title}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
