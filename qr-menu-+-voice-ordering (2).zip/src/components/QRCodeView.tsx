import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Business } from '../types';
import { Copy, Check, ExternalLink, Printer, QrCode, Sparkles, AlertCircle, MessageCircle, Utensils, Hotel } from 'lucide-react';
import { createWhatsappDirectUrl } from '../utils/phone';
import { generateQrUrl } from '../utils/tenant';

interface QRCodeViewProps {
  business: Business;
  onPreviewCustomerPage: (businessId: string) => void;
}

export const QRCodeView: React.FC<QRCodeViewProps> = ({ business, onPreviewCustomerPage }) => {
  const [copied, setCopied] = useState(false);
  const isGuestHouse = business.businessType === 'guesthouse';
  const [unitNumber, setUnitNumber] = useState<string>(isGuestHouse ? '102' : '05');

  // The permanent URL locked strictly to business type and unit ID
  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  const permanentUrl = generateQrUrl({
    businessId: business.id,
    businessType: isGuestHouse ? 'guesthouse' : 'restaurant',
    unitNumber: unitNumber || (isGuestHouse ? '102' : '05'),
    origin: currentOrigin,
  });

  const handleCopy = () => {
    navigator.clipboard.writeText(permanentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div id="qr-code-section" className="space-y-6">
      {/* Permanent URL Guarantee Banner */}
      <div className="bg-amber-50/80 border border-amber-200/80 rounded-xl p-4 text-sm text-amber-900 flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <h4 className="font-semibold text-amber-950">Permanent QR Code Guarantee</h4>
          <p className="mt-1 text-amber-800 text-xs sm:text-sm leading-relaxed">
            This QR code strictly locks to this <strong>{isGuestHouse ? 'Guest House Room' : 'Restaurant Table'}</strong>. You can update menu items, change prices, or modify business hours anytime in the future — <strong>your printed QR codes will never need to be reprinted</strong>.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: QR Code & Link Controls */}
        <div className="lg:col-span-5 bg-white border border-stone-200 rounded-2xl p-6 shadow-xs flex flex-col items-center text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-stone-100 text-stone-700 text-xs font-semibold rounded-full mb-3">
            <QrCode className="w-3.5 h-3.5 text-amber-500" /> {isGuestHouse ? '🏨 Room QR Code' : '🍽️ Table QR Code'}
          </div>

          {/* Unit Number Selector */}
          <div className="w-full mb-4 p-3 bg-stone-50 border border-stone-200 rounded-xl flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-stone-700 font-bold">
              {isGuestHouse ? <Hotel className="w-4 h-4 text-emerald-600" /> : <Utensils className="w-4 h-4 text-amber-600" />}
              <span>{isGuestHouse ? 'Room Number:' : 'Table Number:'}</span>
            </div>
            <input
              type="text"
              value={unitNumber}
              onChange={(e) => setUnitNumber(e.target.value)}
              placeholder={isGuestHouse ? '102' : '05'}
              className="w-20 px-2.5 py-1 text-center font-mono font-bold bg-white border border-stone-300 rounded-lg text-stone-900 focus:outline-hidden focus:border-amber-500 text-xs"
            />
          </div>

          {/* Explicit Business Header Above QR Frame */}
          <div className="mb-4">
            <h2 className="text-xl font-black text-stone-900 tracking-tight">{business.name}</h2>
            {business.tagline && (
              <p className="text-xs text-stone-500 italic mt-0.5 max-w-xs">{business.tagline}</p>
            )}
          </div>

          {/* QR Container */}
          <div className="bg-white p-5 rounded-2xl border-2 border-stone-900 shadow-sm inline-block">
            <QRCodeSVG
              value={permanentUrl}
              size={200}
              level="H"
              includeMargin={true}
              imageSettings={business.logoUrl ? {
                src: business.logoUrl,
                x: undefined,
                y: undefined,
                height: 38,
                width: 38,
                excavate: true,
              } : undefined}
            />
          </div>

          <p className="text-xs text-stone-500 max-w-xs mt-3 truncate">{business.address}</p>

          {/* URL box */}
          <div className="w-full mt-6 bg-stone-50 border border-stone-200 rounded-xl p-3 text-left">
            <label className="block text-[11px] font-semibold text-stone-400 uppercase tracking-wider mb-1">
              Permanent Customer URL ({isGuestHouse ? 'Room Locked' : 'Table Locked'})
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={permanentUrl}
                className="w-full bg-transparent text-xs font-mono text-stone-800 focus:outline-hidden select-all"
              />
              <button
                id="copy-qr-url-btn"
                onClick={handleCopy}
                className="p-1.5 rounded-lg hover:bg-stone-200 text-stone-600 transition-colors shrink-0"
                title="Copy Permanent Link"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-2 gap-2.5 w-full mt-4">
            <button
              id="preview-menu-btn"
              onClick={() => {
                window.location.href = permanentUrl;
              }}
              className="w-full flex items-center justify-center gap-1.5 px-3 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-semibold transition-colors shadow-xs cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              Open Menu
            </button>
            <button
              id="print-qr-btn"
              onClick={handlePrint}
              className="w-full flex items-center justify-center gap-1.5 px-3 py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold transition-colors shadow-xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              Print QR Card
            </button>
          </div>
        </div>

        {/* Right Column: Print-Ready Table Stand Display Card Preview */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-stone-900 text-sm">Table Tent / Counter Stand Preview</h4>
            <span className="text-xs text-stone-500">Ready to laminate & display</span>
          </div>

          {/* Printable Stand Template */}
          <div className="bg-gradient-to-b from-stone-900 to-stone-950 text-white p-8 rounded-2xl border border-stone-800 shadow-md text-center flex flex-col items-center">
            {business?.logoUrl ? (
              <img
                src={business.logoUrl}
                alt={business?.name || 'Restaurant'}
                className="w-16 h-16 rounded-full object-cover border-2 border-amber-400/80 shadow-md mb-3"
              />
            ) : (
              <div className="w-16 h-16 rounded-full bg-amber-500 text-stone-950 font-black text-2xl flex items-center justify-center mb-3">
                {(business?.name || 'R').charAt(0)}
              </div>
            )}

            <h2 className="text-xl font-extrabold tracking-tight text-amber-400">{business.name}</h2>
            <p className="text-stone-300 text-xs mt-1 max-w-sm">{business.tagline || 'Scan to view our complete digital menu on your phone'}</p>

            {/* QR Center in Stand */}
            <div className="my-6 bg-white p-4 rounded-xl shadow-lg inline-block border-4 border-amber-400">
              <QRCodeSVG
                value={permanentUrl}
                size={160}
                level="H"
                includeMargin={false}
              />
            </div>

            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-400 text-stone-950 font-bold text-xs">
              <QrCode className="w-3.5 h-3.5" /> Scan for {isGuestHouse ? `Room ${unitNumber || '102'}` : `Table ${unitNumber || '05'}`}
            </div>

            <p className="text-[11px] text-stone-400 mt-4">
              Instant access • No app download required • Updated daily
            </p>
            {(business.whatsappNumber || business.phone) && (
              <div className="mt-3">
                <a
                  href={createWhatsappDirectUrl(business.whatsappNumber || business.phone, business.name)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/40 text-xs font-semibold transition-all cursor-pointer shadow-xs"
                >
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WhatsApp Us</span>
                </a>
              </div>
            )}
          </div>

          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs text-stone-600 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-stone-400 shrink-0" />
            <span>Click <strong>Print QR Card</strong> above to print tabletop stickers or counter displays.</span>
          </div>
        </div>
      </div>
    </div>
  );
};

