import React, { useState } from 'react';
import { Business, MenuCategory, MenuItem, MenuStyle } from '../types';
import { ClassicMenuTemplate } from './templates/ClassicMenuTemplate';
import { ModernMenuTemplate } from './templates/ModernMenuTemplate';
import { MinimalMenuTemplate } from './templates/MinimalMenuTemplate';
import { Sparkles, Check, ChevronRight, Eye, Layout, Palette, ArrowLeft } from 'lucide-react';

interface MenuStyleSelectorProps {
  business: Business;
  categories: MenuCategory[];
  items: MenuItem[];
  currentStyle?: MenuStyle;
  onSelectStyle: (style: MenuStyle) => void;
  onCancel?: () => void;
  isSaving?: boolean;
}

export const MenuStyleSelector: React.FC<MenuStyleSelectorProps> = ({
  business,
  categories,
  items,
  currentStyle = 'classic',
  onSelectStyle,
  onCancel,
  isSaving = false,
}) => {
  const [selectedStyle, setSelectedStyle] = useState<MenuStyle>(currentStyle || 'classic');
  const [activeTabPreview, setActiveTabPreview] = useState<MenuStyle>(currentStyle || 'classic');

  // Prepare a nice sample of categories & items (max 2 categories & 4 items each) for realistic preview
  const previewCategories = categories.length > 0 ? categories.slice(0, 3) : [
    { id: 'cat-1', businessId: business.id, name: 'Main Course', displayOrder: 1, isActive: true },
    { id: 'cat-2', businessId: business.id, name: 'Beverages & Desserts', displayOrder: 2, isActive: true },
  ];

  const previewCategoryIds = new Set(previewCategories.map((c) => c.id));
  const previewItems = items.length > 0
    ? items.filter((i) => previewCategoryIds.has(i.categoryId)).slice(0, 6)
    : [
        {
          id: 'prev-1',
          businessId: business.id,
          categoryId: previewCategories[0]?.id || 'cat-1',
          name: 'Special Butter Paneer Masala',
          description: 'Cottage cheese cubes simmered in a velvety tomato and cashew nut gravy',
          price: 240,
          isVeg: 'veg' as const,
          isAvailable: true,
          displayOrder: 1,
        },
        {
          id: 'prev-2',
          businessId: business.id,
          categoryId: previewCategories[0]?.id || 'cat-1',
          name: 'Garlic Butter Naan',
          description: 'Fresh clay-oven baked flatbread topped with toasted garlic and butter',
          price: 60,
          isVeg: 'veg' as const,
          isAvailable: true,
          displayOrder: 2,
        },
        {
          id: 'prev-3',
          businessId: business.id,
          categoryId: previewCategories[1]?.id || 'cat-2',
          name: 'Special Filter Kaapi',
          description: 'Freshly brewed South Indian chicory blend with frothy whole milk',
          price: 35,
          isVeg: 'veg' as const,
          isAvailable: true,
          displayOrder: 3,
        }
      ];

  const styleOptions: {
    id: MenuStyle;
    title: string;
    badge: string;
    tagline: string;
    buttonLabel: string;
    characteristics: string[];
    bgPreviewClass: string;
    borderClass: string;
    accentColor: string;
  }[] = [
    {
      id: 'classic',
      title: 'OPTION 1 — CLASSIC',
      badge: 'Traditional & Heritage',
      tagline: 'Elegant restaurant-style layout with refined typography & dot-leader pricing',
      buttonLabel: 'Choose Classic',
      characteristics: [
        'Elegant restaurant-style layout',
        'Clean typography & serif accents',
        'Traditional category headings',
        'Item name & price clearly separated',
        'Optional small item descriptions',
        'Strong readability on mobile'
      ],
      bgPreviewClass: 'bg-[#FAF7F2]',
      borderClass: 'border-[#D8C7B0]',
      accentColor: '#8C6B43',
    },
    {
      id: 'modern',
      title: 'OPTION 2 — MODERN',
      badge: 'Contemporary & Visual',
      tagline: 'Contemporary card-based layout with prominent pricing & mobile-first spacing',
      buttonLabel: 'Choose Modern',
      characteristics: [
        'Contemporary card-based layout',
        'Attractive category sections',
        'Large clear item names',
        'Price displayed prominently',
        'Rounded cards and modern spacing',
        'Mobile-first appearance'
      ],
      bgPreviewClass: 'bg-stone-100',
      borderClass: 'border-amber-400',
      accentColor: '#F59E0B',
    },
    {
      id: 'minimal',
      title: 'OPTION 3 — SIMPLE / MINIMAL',
      badge: 'Fast & High Density',
      tagline: 'Very clean menu with minimal decoration & instant lightning-fast scanning',
      buttonLabel: 'Choose Minimal',
      characteristics: [
        'Very clean menu with zero clutter',
        'Minimal decoration & fast loading',
        'Excellent high-contrast readability',
        'Category headings with clear separators',
        'Item name, description and price arranged neatly',
        'Ideal for cafés, small hotels & roadside food'
      ],
      bgPreviewClass: 'bg-white',
      borderClass: 'border-stone-900',
      accentColor: '#1C1917',
    },
  ];

  return (
    <div id="choose-menu-style-screen" className="space-y-6">
      
      {/* Screen Title & Header */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-black uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Step 2: Choose Customer Experience</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-stone-900 tracking-tight">
              Choose Your Menu Style
            </h1>
            <p className="text-xs sm:text-sm text-stone-600 mt-1 max-w-xl">
              Select how your extracted dishes will appear to customers when they scan your QR code. 
              The original appearance of the photographed menu is replaced with a clean, professional digital design.
            </p>
          </div>

          {onCancel && (
            <button
              onClick={onCancel}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl transition-colors shrink-0 self-start sm:self-auto"
            >
              <ArrowLeft className="w-4 h-4" /> Back to Review
            </button>
          )}
        </div>

        {/* Live Data Note */}
        <div className="mt-4 p-3 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-600 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>
              Previews below are rendered using your <strong>{items.length} extracted dishes</strong> across <strong>{categories.length} categories</strong>.
            </span>
          </div>
          <span className="text-[11px] text-stone-400 font-medium">
            URL & QR code remain unchanged when you switch styles.
          </span>
        </div>
      </div>

      {/* 3 Interactive Style Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {styleOptions.map((opt) => {
          const isSelected = selectedStyle === opt.id;
          return (
            <div
              key={opt.id}
              id={`style-card-${opt.id}`}
              className={`flex flex-col bg-white rounded-2xl border-2 transition-all overflow-hidden ${
                isSelected
                  ? 'border-amber-500 shadow-md ring-2 ring-amber-500/20'
                  : 'border-stone-200 shadow-xs hover:border-stone-300'
              }`}
            >
              {/* Header Info */}
              <div className="p-4 border-b border-stone-100 flex-1">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <span className="text-[10px] font-black uppercase tracking-wider text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                    {opt.badge}
                  </span>
                  {isSelected && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      <Check className="w-3 h-3" /> Active Choice
                    </span>
                  )}
                </div>

                <h3 className="text-base font-black text-stone-900 mt-1">
                  {opt.title}
                </h3>
                <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                  {opt.tagline}
                </p>

                {/* Bullets */}
                <ul className="mt-3 space-y-1.5 text-xs text-stone-600">
                  {opt.characteristics.map((c, idx) => (
                    <li key={idx} className="flex items-start gap-1.5 text-[11px] leading-tight">
                      <Check className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <span>{c}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Realistic Mockup Window */}
              <div className="p-3 bg-stone-50 border-t border-stone-100">
                <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                  <span>Realistic Live Preview</span>
                  <button
                    type="button"
                    onClick={() => setActiveTabPreview(opt.id)}
                    className="text-amber-700 hover:underline flex items-center gap-0.5"
                  >
                    <Eye className="w-3 h-3" /> Expand
                  </button>
                </div>

                {/* Scaled-down Mini Device Screen Container */}
                <div className="h-64 rounded-xl border border-stone-300 overflow-y-auto bg-white relative shadow-inner p-1">
                  {opt.id === 'classic' && (
                    <ClassicMenuTemplate
                      business={business}
                      categories={previewCategories}
                      items={previewItems}
                      previewMode={true}
                    />
                  )}
                  {opt.id === 'modern' && (
                    <ModernMenuTemplate
                      business={business}
                      categories={previewCategories}
                      items={previewItems}
                      previewMode={true}
                    />
                  )}
                  {opt.id === 'minimal' && (
                    <MinimalMenuTemplate
                      business={business}
                      categories={previewCategories}
                      items={previewItems}
                      previewMode={true}
                    />
                  )}
                </div>
              </div>

              {/* Action Button */}
              <div className="p-4 bg-white border-t border-stone-100">
                <button
                  id={`choose-${opt.id}-btn`}
                  type="button"
                  disabled={isSaving}
                  onClick={() => {
                    setSelectedStyle(opt.id);
                    onSelectStyle(opt.id);
                  }}
                  className={`w-full py-2.5 px-4 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all ${
                    isSelected
                      ? 'bg-amber-500 hover:bg-amber-600 text-stone-950 shadow-xs ring-1 ring-amber-600'
                      : 'bg-stone-900 hover:bg-stone-800 text-white'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{opt.buttonLabel}</span>
                  <ChevronRight className="w-4 h-4 ml-auto" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Expanded Interactive Full Preview Drawer / Box */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-stone-900 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="text-[11px] font-bold text-amber-400 uppercase tracking-widest">
              Live Phone Simulation
            </div>
            <h2 className="text-base font-bold text-white">
              Simulating: {activeTabPreview === 'classic' ? 'Option 1 (Classic)' : activeTabPreview === 'modern' ? 'Option 2 (Modern)' : 'Option 3 (Minimal)'}
            </h2>
          </div>

          <div className="flex items-center gap-1.5 bg-stone-800 p-1 rounded-xl">
            <button
              onClick={() => setActiveTabPreview('classic')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                activeTabPreview === 'classic' ? 'bg-amber-500 text-stone-950' : 'text-stone-300 hover:text-white'
              }`}
            >
              Classic
            </button>
            <button
              onClick={() => setActiveTabPreview('modern')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                activeTabPreview === 'modern' ? 'bg-amber-500 text-stone-950' : 'text-stone-300 hover:text-white'
              }`}
            >
              Modern
            </button>
            <button
              onClick={() => setActiveTabPreview('minimal')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                activeTabPreview === 'minimal' ? 'bg-amber-500 text-stone-950' : 'text-stone-300 hover:text-white'
              }`}
            >
              Minimal
            </button>
          </div>
        </div>

        {/* Realistic Mobile Viewport Frame */}
        <div className="p-4 sm:p-8 bg-stone-100 flex items-center justify-center">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-xl border-4 border-stone-800 overflow-hidden min-h-[500px] max-h-[650px] overflow-y-auto">
            {activeTabPreview === 'classic' && (
              <ClassicMenuTemplate
                business={business}
                categories={categories}
                items={items}
                previewMode={true}
              />
            )}
            {activeTabPreview === 'modern' && (
              <ModernMenuTemplate
                business={business}
                categories={categories}
                items={items}
                previewMode={true}
              />
            )}
            {activeTabPreview === 'minimal' && (
              <MinimalMenuTemplate
                business={business}
                categories={categories}
                items={items}
                previewMode={true}
              />
            )}
          </div>
        </div>

        {/* Bottom CTA for Active Preview */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between flex-wrap gap-3">
          <div className="text-xs text-stone-600">
            Current simulated view: <strong>{activeTabPreview.toUpperCase()}</strong>
          </div>
          <button
            onClick={() => {
              setSelectedStyle(activeTabPreview);
              onSelectStyle(activeTabPreview);
            }}
            disabled={isSaving}
            className="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-stone-950 font-black text-xs rounded-xl shadow-xs inline-flex items-center gap-2 transition-transform active:scale-95"
          >
            <Check className="w-4 h-4" />
            <span>Apply {activeTabPreview.toUpperCase()} to Live Menu</span>
          </button>
        </div>
      </div>

    </div>
  );
};
