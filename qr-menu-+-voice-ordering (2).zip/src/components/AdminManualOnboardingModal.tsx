import React, { useState } from 'react';
import { 
  X, 
  Store, 
  Hotel, 
  Sparkles, 
  Check, 
  Database, 
  ShieldCheck, 
  Zap, 
  Copy, 
  CheckCircle2, 
  ArrowRight, 
  Mail, 
  Phone, 
  MapPin, 
  Layers, 
  UtensilsCrossed, 
  Loader2,
  ExternalLink
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { saveRestaurant } from '../utils/shopPersistence';
import { saveBusiness, saveLocalMenuCache } from '../services/db';
import { Business, StoredShop, TenantType, TenantSubscriptionTier, MenuCategory, MenuItem } from '../types';

interface AdminManualOnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newBiz: Business, newShop: StoredShop) => void;
  onLaunchDashboard?: (bizId: string, targetView: 'owner' | 'orders' | 'customer') => void;
}

export const AdminManualOnboardingModal: React.FC<AdminManualOnboardingModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  onLaunchDashboard
}) => {
  // Form state
  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [ownerEmail, setOwnerEmail] = useState('');
  const [phone, setPhone] = useState('+91 98450 12345');
  const [whatsappNumber, setWhatsappNumber] = useState('+91 98450 12345');
  const [businessType, setBusinessType] = useState<TenantType>('restaurant');
  const [city, setCity] = useState('Bengaluru');
  const [address, setAddress] = useState('100 Feet Road, Indiranagar');
  const [tableCountPreset, setTableCountPreset] = useState<'5' | '10' | '15' | 'custom'>('10');
  const [tablesInput, setTablesInput] = useState('01, 02, 03, 04, 05, 06, 07, 08, 09, 10');
  const [subscriptionTier, setSubscriptionTier] = useState<TenantSubscriptionTier>('pro');
  const [enableWhatsapp, setEnableWhatsapp] = useState(true);
  const [enableTableSelector, setEnableTableSelector] = useState(true);
  const [seedStarterMenu, setSeedStarterMenu] = useState(true);

  // Flow state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorNotice, setErrorNotice] = useState<string | null>(null);
  const [createdBiz, setCreatedBiz] = useState<Business | null>(null);
  const [createdShop, setCreatedShop] = useState<StoredShop | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  // Auto-generate clean slug from restaurant name
  const handleNameChange = (val: string) => {
    setName(val);
    setErrorNotice(null);
    const generated = val
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
    setSlug(generated);
    if (!ownerEmail && val.trim().length > 2) {
      setOwnerEmail(`owner@${generated || 'restaurant'}.com`);
    }
  };

  const handleTablePresetChange = (preset: '5' | '10' | '15' | 'custom') => {
    setTableCountPreset(preset);
    if (preset === '5') {
      setTablesInput('01, 02, 03, 04, 05');
    } else if (preset === '10') {
      setTablesInput('01, 02, 03, 04, 05, 06, 07, 08, 09, 10');
    } else if (preset === '15') {
      setTablesInput('01, 02, 03, 04, 05, 06, 07, 08, 09, 10, VIP-1, VIP-2, Terrace-1, Terrace-2, Garden');
    }
  };

  // Execute Direct Manual Onboarding
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorNotice(null);

    const cleanName = name.trim();
    if (!cleanName) {
      setErrorNotice('Please provide a restaurant or property name.');
      return;
    }

    const cleanSlug = slug.trim().toLowerCase() || cleanName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const cleanEmail = ownerEmail.trim() || `partner@${cleanSlug}.com`;
    const cleanPhone = phone.trim() || '+91 98450 12345';
    const cleanWhatsapp = whatsappNumber.trim() || cleanPhone;
    const cleanCity = city.trim() || 'Bengaluru';
    const cleanAddress = address.trim() || `${cleanCity}, India`;

    const parsedTables = tablesInput
      .split(/[,;\s]+/)
      .map(t => t.trim())
      .filter(Boolean);
    const finalTables = parsedTables.length > 0 ? parsedTables : ['01', '02', '03', '04', '05'];

    setIsSubmitting(true);

    try {
      // 1. Build persistent shop record with is_approved: TRUE
      const newShop: StoredShop = {
        id: cleanSlug,
        name: cleanName,
        tables: finalTables,
        features: {
          enable_whatsapp_orders: enableWhatsapp,
          enable_table_selector: enableTableSelector,
          enable_bluetooth_speaker_alerts: true,
          enable_kpi_reports: true,
        },
        phone: cleanPhone,
        whatsappNumber: cleanWhatsapp,
        address: cleanAddress,
        city: cleanCity,
        is_approved: true, // CRITICAL: Admin onboarding explicitly sets true
        isApproved: true,
      };

      // 2. Build Business record with is_approved: TRUE
      const newBiz: Business = {
        id: cleanSlug,
        ownerUid: `admin-onboarded-${cleanSlug}`,
        name: cleanName,
        businessType: businessType,
        tagline: businessType === 'guesthouse'
          ? 'Luxury Boutique Stay, Room Dining & 24/7 Concierge'
          : 'Fresh Authentic Flavours & Quick QR Ordering',
        logoUrl: businessType === 'guesthouse'
          ? 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=200&auto=format&fit=crop&q=80'
          : 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=200&auto=format&fit=crop&q=80',
        coverUrl: businessType === 'guesthouse'
          ? 'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=800&auto=format&fit=crop&q=80'
          : 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=80',
        address: cleanAddress,
        city: cleanCity,
        phone: cleanPhone,
        whatsappNumber: cleanWhatsapp,
        openingHours: businessType === 'guesthouse' ? '24/7 Front Desk' : 'Mon - Sun: 7:00 AM – 11:00 PM',
        currencySymbol: '₹',
        tables: finalTables,
        features: newShop.features,
        isActive: true,
        status: 'active',
        subscriptionTier: subscriptionTier,
        is_approved: true, // CRITICAL: Admin onboarding explicitly sets true
        isApproved: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      // 3. Push to Supabase Cloud Database with is_approved: TRUE
      try {
        await supabase.from('restaurants').upsert([{
          id: newShop.id,
          name: newShop.name,
          tables: newShop.tables,
          features: newShop.features,
          phone: newShop.phone,
          whatsapp_number: newShop.whatsappNumber,
          address: newShop.address,
          city: newShop.city,
          business_type: businessType,
          is_approved: true, // Auto-approved by admin
          status: 'active',
          owner_email: cleanEmail,
          created_at: new Date().toISOString(),
        }], { onConflict: 'id' });
      } catch (sbErr) {
        console.warn('Supabase cloud push notice (will fallback gracefully to local persistent store):', sbErr);
      }

      // 4. Register to Server Fleet API with is_approved: TRUE
      try {
        await fetch('/api/master-admin/onboard-restaurant', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: newBiz.id,
            name: newBiz.name,
            businessType: newBiz.businessType,
            tagline: newBiz.tagline,
            city: newBiz.city,
            phone: newBiz.phone,
            whatsappNumber: newBiz.whatsappNumber,
            address: newBiz.address,
            subscriptionTier: newBiz.subscriptionTier,
            tables: newBiz.tables,
            features: newBiz.features,
            ownerEmail: cleanEmail,
            is_approved: true,
          }),
        });
      } catch (srvErr) {
        console.warn('Server fleet registration fallback notice:', srvErr);
      }

      // 5. Save to local PWA stores (Local storage & Firestore)
      saveRestaurant(newShop);
      await saveBusiness(newBiz);

      // 6. Optional Starter Menu Seeding
      if (seedStarterMenu) {
        const starterCategories: MenuCategory[] = [
          { id: `cat-${cleanSlug}-1`, businessId: cleanSlug, name: 'South Indian Specials', description: 'Freshly prepared traditional favourites', displayOrder: 1, isActive: true },
          { id: `cat-${cleanSlug}-2`, businessId: cleanSlug, name: 'Beverages & Coffee', description: 'Refreshing hot & cold drinks', displayOrder: 2, isActive: true },
          { id: `cat-${cleanSlug}-3`, businessId: cleanSlug, name: 'Quick Bites & Snacks', description: 'Fresh, crispy and delicious snacks', displayOrder: 3, isActive: true },
        ];

        const starterItems: MenuItem[] = [
          {
            id: `itm-${cleanSlug}-1`,
            businessId: cleanSlug,
            categoryId: `cat-${cleanSlug}-1`,
            name: 'Ghee Podi Masala Dosa',
            description: 'Crisp golden crepe layered with spiced roasted lentils powder and potato masala',
            price: 120,
            isVeg: 'veg',
            imageUrl: 'https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=600&auto=format&fit=crop&q=80',
            isAvailable: true,
            displayOrder: 1,
          },
          {
            id: `itm-${cleanSlug}-2`,
            businessId: cleanSlug,
            categoryId: `cat-${cleanSlug}-1`,
            name: 'Steamed Idli Platter (3 Pcs)',
            description: 'Soft and pillowy rice cakes served with hot sambar and coconut chutneys',
            price: 80,
            isVeg: 'veg',
            imageUrl: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=600&auto=format&fit=crop&q=80',
            isAvailable: true,
            displayOrder: 2,
          },
          {
            id: `itm-${cleanSlug}-3`,
            businessId: cleanSlug,
            categoryId: `cat-${cleanSlug}-2`,
            name: 'Degree Filter Coffee',
            description: 'Rich decoction brewed with fresh chicory blend and frothy milk',
            price: 45,
            isVeg: 'veg',
            imageUrl: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&auto=format&fit=crop&q=80',
            isAvailable: true,
            displayOrder: 1,
          },
          {
            id: `itm-${cleanSlug}-4`,
            businessId: cleanSlug,
            categoryId: `cat-${cleanSlug}-3`,
            name: 'Crispy Medu Vada (2 Pcs)',
            description: 'Golden fried lentil donuts with crispy crust and fluffy center',
            price: 70,
            isVeg: 'veg',
            imageUrl: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=600&auto=format&fit=crop&q=80',
            isAvailable: true,
            displayOrder: 1,
          }
        ];

        saveLocalMenuCache(cleanSlug, starterCategories, starterItems);
      }

      // 7. Store credentials in localStorage so the owner account is instantly recognized
      if (typeof window !== 'undefined') {
        localStorage.setItem('restaurant_partner_email', cleanEmail);
        localStorage.setItem('qr_menu_staff_role', 'owner');
        localStorage.setItem('qr_menu_staff_name', `${cleanName} (Owner)`);
      }

      setCreatedBiz(newBiz);
      setCreatedShop(newShop);
      onSuccess(newBiz, newShop);
    } catch (err: any) {
      console.error('Error during manual restaurant onboarding:', err);
      setErrorNotice(err?.message || 'An unexpected error occurred while onboarding restaurant.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyDirectLink = () => {
    if (!createdBiz) return;
    const url = `${window.location.origin}/?shop=${createdBiz.id}#b/${createdBiz.id}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-2xl w-full p-6 sm:p-7 shadow-2xl space-y-5 max-h-[92vh] overflow-y-auto text-stone-100 relative">
        
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-start gap-3 border-b border-stone-800 pb-4 pr-8">
          <div className="p-3 bg-gradient-to-tr from-emerald-600 to-teal-500 rounded-2xl text-white shadow-lg shadow-emerald-600/30 shrink-0">
            <Zap className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h2 className="text-lg font-black text-white tracking-tight">Manual Restaurant Onboarding</h2>
              <span className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                <Check className="w-3 h-3" /> is_approved: true
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                <ShieldCheck className="w-3 h-3" /> Admin Super-Privilege
              </span>
            </div>
            <p className="text-xs text-stone-400 leading-relaxed">
              Directly provisions an approved restaurant account. Bypasses public email/phone OTP verification so owners can launch and access their dashboards right away.
            </p>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* SUCCESS SCREEN UPON COMPLETION */}
        {/* ------------------------------------------------------------- */}
        {createdBiz && createdShop ? (
          <div className="space-y-5 py-2">
            <div className="p-4 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400 mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h3 className="text-base font-black text-emerald-300">
                "{createdBiz.name}" Successfully Onboarded!
              </h3>
              <p className="text-xs text-stone-300 max-w-lg mx-auto">
                The restaurant account is automatically created with <strong className="text-emerald-400 font-mono">is_approved: true</strong>. Public OTP verification is bypassed — all dashboards and order stations are unlocked right now.
              </p>
            </div>

            {/* Direct Access Details Box */}
            <div className="bg-stone-800/80 rounded-2xl p-4 border border-stone-700/60 space-y-3 text-xs">
              <div className="text-[11px] font-bold uppercase tracking-wider text-stone-400">Account Credentials & Access</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-stone-300">
                <div className="p-2.5 bg-stone-900 rounded-xl border border-stone-800">
                  <span className="text-[10px] text-stone-500 block uppercase">Restaurant ID (Slug)</span>
                  <span className="font-mono font-bold text-amber-400 text-xs">{createdBiz.id}</span>
                </div>
                <div className="p-2.5 bg-stone-900 rounded-xl border border-stone-800">
                  <span className="text-[10px] text-stone-500 block uppercase">Owner Email</span>
                  <span className="font-bold text-white text-xs truncate block">{ownerEmail || `partner@${createdBiz.id}.com`}</span>
                </div>
                <div className="p-2.5 bg-stone-900 rounded-xl border border-stone-800">
                  <span className="text-[10px] text-stone-500 block uppercase">Approval Status</span>
                  <span className="font-bold text-emerald-400 text-xs flex items-center gap-1">
                    <Check className="w-3 h-3" /> Approved (is_approved: true)
                  </span>
                </div>
                <div className="p-2.5 bg-stone-900 rounded-xl border border-stone-800">
                  <span className="text-[10px] text-stone-500 block uppercase">Active Tables</span>
                  <span className="font-bold text-white text-xs">{createdBiz.tables?.length || 5} Tables</span>
                </div>
              </div>

              {/* Direct Link Copier */}
              <div className="pt-1 flex items-center gap-2">
                <div className="flex-1 bg-stone-900 px-3 py-2 rounded-xl border border-stone-800 font-mono text-[11px] text-stone-400 truncate">
                  {typeof window !== 'undefined' ? `${window.location.origin}/?shop=${createdBiz.id}#b/${createdBiz.id}` : `/?shop=${createdBiz.id}`}
                </div>
                <button
                  type="button"
                  onClick={handleCopyDirectLink}
                  className="px-3 py-2 bg-stone-700 hover:bg-stone-600 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedLink ? 'Copied!' : 'Copy Direct Link'}</span>
                </button>
              </div>
            </div>

            {/* Instant Actions (No OTP required) */}
            <div className="space-y-2 pt-2">
              <div className="text-xs font-bold text-stone-400 uppercase tracking-wider">
                Instant Dashboard Launch (Bypass Public OTP)
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    if (onLaunchDashboard) onLaunchDashboard(createdBiz.id, 'owner');
                  }}
                  className="p-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-black shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 cursor-pointer transition active:scale-95"
                >
                  <Layers className="w-4 h-4" />
                  <span>Launch Menu Admin</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    if (onLaunchDashboard) onLaunchDashboard(createdBiz.id, 'orders');
                  }}
                  className="p-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 cursor-pointer transition active:scale-95"
                >
                  <Zap className="w-4 h-4 text-amber-300" />
                  <span>Live Orders Station</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    if (onLaunchDashboard) onLaunchDashboard(createdBiz.id, 'customer');
                  }}
                  className="p-3 bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 rounded-xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition"
                >
                  <ExternalLink className="w-4 h-4 text-sky-400" />
                  <span>Customer QR View</span>
                </button>
              </div>
            </div>

            <div className="pt-2 border-t border-stone-800 flex justify-end">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-bold rounded-xl cursor-pointer"
              >
                Back to Fleet Console
              </button>
            </div>
          </div>
        ) : (
          /* ------------------------------------------------------------- */
          /* ONBOARDING FORM */
          /* ------------------------------------------------------------- */
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {errorNotice && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                <span>{errorNotice}</span>
              </div>
            )}

            {/* Basic Info Section */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-[11px] font-bold uppercase text-stone-400 mb-1">
                  Restaurant / Property Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Royal Chettinad Spices"
                  value={name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-medium"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-stone-400 mb-1">
                  Custom URL Slug / ID *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="royal-chettinad-spices"
                    value={slug}
                    onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                    className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-amber-400 font-mono placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Email & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div>
                <label className="block text-[11px] font-bold uppercase text-stone-400 mb-1 flex items-center gap-1">
                  <Mail className="w-3 h-3 text-stone-400" />
                  <span>Owner / Partner Email</span>
                </label>
                <input
                  type="email"
                  placeholder="owner@restaurant.com"
                  value={ownerEmail}
                  onChange={(e) => setOwnerEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-stone-400 mb-1 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-stone-400" />
                  <span>Phone Number</span>
                </label>
                <input
                  type="text"
                  placeholder="+91 98450 12345"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-stone-400 mb-1 flex items-center gap-1">
                  <span>WhatsApp Dispatch</span>
                </label>
                <input
                  type="text"
                  placeholder="+91 98450 12345"
                  value={whatsappNumber}
                  onChange={(e) => setWhatsappNumber(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 font-mono"
                />
              </div>
            </div>

            {/* Property Type & Location */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div>
                <label className="block text-[11px] font-bold uppercase text-stone-400 mb-1">
                  Property Archetype
                </label>
                <select
                  value={businessType}
                  onChange={(e) => setBusinessType(e.target.value as TenantType)}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white focus:outline-hidden cursor-pointer"
                >
                  <option value="restaurant">🍽️ Restaurant / Cafe / Bistro</option>
                  <option value="guesthouse">🏨 Guest House / Hotel</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-stone-400 mb-1">
                  City
                </label>
                <input
                  type="text"
                  placeholder="Bengaluru"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-stone-400 mb-1">
                  Subscription Tier
                </label>
                <select
                  value={subscriptionTier}
                  onChange={(e) => setSubscriptionTier(e.target.value as TenantSubscriptionTier)}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-purple-300 font-bold focus:outline-hidden cursor-pointer"
                >
                  <option value="starter">Starter Plan (Up to 10 tables)</option>
                  <option value="pro">Pro Plan (Unlimited + WhatsApp)</option>
                  <option value="enterprise">Enterprise Fleet License</option>
                </select>
              </div>
            </div>

            {/* Address */}
            <div>
              <label className="block text-[11px] font-bold uppercase text-stone-400 mb-1 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-stone-400" />
                <span>Physical Address</span>
              </label>
              <input
                type="text"
                placeholder="Shop No. 4, 100 Feet Road, Indiranagar"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder-stone-500 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Tables / Units Setup */}
            <div className="p-3 bg-stone-800/60 border border-stone-700/60 rounded-2xl space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold uppercase text-stone-300">
                  Tables or Room Numbers Configuration
                </label>
                <div className="flex items-center gap-1">
                  {(['5', '10', '15'] as const).map((cnt) => (
                    <button
                      key={cnt}
                      type="button"
                      onClick={() => handleTablePresetChange(cnt)}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition ${
                        tableCountPreset === cnt
                          ? 'bg-emerald-600 text-white'
                          : 'bg-stone-700 text-stone-400 hover:text-white'
                      }`}
                    >
                      {cnt} Tables
                    </button>
                  ))}
                </div>
              </div>
              <input
                type="text"
                value={tablesInput}
                onChange={(e) => {
                  setTablesInput(e.target.value);
                  setTableCountPreset('custom');
                }}
                className="w-full px-3 py-2 bg-stone-900 border border-stone-700 rounded-xl text-amber-300 font-mono text-xs focus:outline-hidden"
                placeholder="01, 02, 03, 04, 05..."
              />
              <span className="text-[10px] text-stone-400 block">
                Comma-separated identifiers (e.g., 01, 02, 03, VIP-1, Terrace-A). QR codes are generated for each table instantly.
              </span>
            </div>

            {/* Features & Starter Menu */}
            <div className="p-3 bg-stone-800/40 border border-stone-700/40 rounded-2xl space-y-2">
              <div className="text-[11px] font-bold uppercase text-stone-400">Pre-Configured Automation</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <label className="flex items-center gap-2 p-2 bg-stone-900 rounded-xl border border-stone-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableWhatsapp}
                    onChange={(e) => setEnableWhatsapp(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 bg-stone-800 border-stone-700"
                  />
                  <span>WhatsApp Order Dispatch ($0 Cost)</span>
                </label>

                <label className="flex items-center gap-2 p-2 bg-stone-900 rounded-xl border border-stone-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableTableSelector}
                    onChange={(e) => setEnableTableSelector(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 bg-stone-800 border-stone-700"
                  />
                  <span>Table Number QR Selector</span>
                </label>

                <label className="flex items-center gap-2 p-2 bg-stone-900 rounded-xl border border-stone-800 cursor-pointer sm:col-span-2">
                  <input
                    type="checkbox"
                    checked={seedStarterMenu}
                    onChange={(e) => setSeedStarterMenu(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 bg-stone-800 border-stone-700"
                  />
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Auto-seed starter Indian menu (Dosas, Filter Coffee, Idlis & Vadas)</span>
                  </div>
                </label>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-3 border-t border-stone-800 flex items-center justify-between">
              <div className="text-[11px] text-emerald-400 font-medium flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Automatically sets <strong className="font-mono">is_approved: true</strong></span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 bg-stone-800 hover:bg-stone-750 text-stone-300 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white rounded-xl text-xs font-black transition shadow-lg shadow-emerald-600/30 flex items-center gap-2 cursor-pointer disabled:opacity-50 active:scale-95"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Onboarding Restaurant...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 text-amber-300" />
                      <span>Onboard & Auto-Approve</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
