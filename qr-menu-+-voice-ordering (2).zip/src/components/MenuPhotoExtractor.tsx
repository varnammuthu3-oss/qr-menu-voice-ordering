import React, { useState, useRef, useEffect } from 'react';
import { 
  Camera, 
  Upload, 
  Sparkles, 
  Trash2, 
  Plus, 
  AlertTriangle, 
  CheckCircle2, 
  X, 
  ChevronRight, 
  Edit3, 
  RefreshCw, 
  ArrowLeft,
  FileText,
  AlertCircle,
  HelpCircle,
  Check,
  Layers,
  ShoppingBag,
  Mic,
  MicOff,
  Volume2,
  Send,
  MessageSquarePlus
} from 'lucide-react';
import { Business, MenuCategory, MenuItem, ExtractedCategory, ExtractedMenuItem, FoodDietType, MenuStyle } from '../types';
import { optimizeMenuImage, OptimizedImage, formatFileSize } from '../utils/imageOptimizer';
import { applyExtractedMenu } from '../services/db';
import { DietBadge } from './DietBadge';
import { MenuStyleSelector } from './MenuStyleSelector';

interface MenuPhotoExtractorProps {
  business: Business;
  existingCategories: MenuCategory[];
  existingItems: MenuItem[];
  onSuccess: (summary: { addedCategoriesCount: number; addedItemsCount: number; selectedStyle?: MenuStyle }) => void;
  onCancel: () => void;
}

type WorkflowStep = 'upload' | 'extracting' | 'review' | 'choose-style' | 'saving' | 'error';

export const MenuPhotoExtractor: React.FC<MenuPhotoExtractorProps> = ({
  business,
  existingCategories,
  existingItems,
  onSuccess,
  onCancel,
}) => {
  const [step, setStep] = useState<WorkflowStep>('upload');
  
  // Uploaded and optimized images
  const [images, setImages] = useState<OptimizedImage[]>([]);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Extracted Data for Review
  const [extractedCategories, setExtractedCategories] = useState<ExtractedCategory[]>([]);
  const [extractedItems, setExtractedItems] = useState<ExtractedMenuItem[]>([]);
  const [confidenceNote, setConfidenceNote] = useState<string>('');

  // Voice Correction States
  const [isListening, setIsListening] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [isProcessingVoice, setIsProcessingVoice] = useState(false);
  const [voiceSuccessToast, setVoiceSuccessToast] = useState<string | null>(null);
  const [voiceManualInput, setVoiceManualInput] = useState('');
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  // Selected filter in review screen
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');
  const [filterNeedsReviewOnly, setFilterNeedsReviewOnly] = useState(false);

  // Inline Category Creation State (Replaces window.prompt for iframe safety)
  const [isAddingCategoryInline, setIsAddingCategoryInline] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');

  // Review screen validation banner (Replaces window.alert for iframe safety)
  const [reviewValidationError, setReviewValidationError] = useState<string | null>(null);

  // Save mode: 'append' (safe add) vs 'replace' (fresh menu)
  const [saveMode, setSaveMode] = useState<'append' | 'replace'>('append');

  // Input refs for file upload / camera capture
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Handle incoming files from file picker or camera
  const handleFilesSelected = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    
    setIsOptimizing(true);
    setErrorMessage(null);
    setReviewValidationError(null);
    // Clear previous extraction state so old items do not linger when uploading a new batch
    setExtractedCategories([]);
    setExtractedItems([]);
    setConfidenceNote('');

    const newOptimized: OptimizedImage[] = [];

    try {
      for (let i = 0; i < fileList.length; i++) {
        const file = fileList[i];
        if (!file.type.startsWith('image/')) continue;
        const optimized = await optimizeMenuImage(file);
        newOptimized.push(optimized);
      }

      // Replace with new images on fresh upload session
      setImages(newOptimized);
    } catch (err: any) {
      console.error('Error processing images:', err);
      setErrorMessage('Could not process image file. Please try a standard JPEG or PNG photo.');
    } finally {
      setIsOptimizing(false);
    }
  };

  // Remove single page thumbnail
  const handleRemoveImage = (id: string) => {
    setImages(prev => prev.filter(img => img.id !== id));
  };

  // Clear all images
  const handleClearAllImages = () => {
    setImages([]);
    setExtractedCategories([]);
    setExtractedItems([]);
    setErrorMessage(null);
    setReviewValidationError(null);
  };

  // Trigger server-side AI extraction
  const handleStartExtraction = async (e?: React.MouseEvent | React.FormEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }

    if (images.length === 0) {
      setErrorMessage('Please take or upload at least one menu photo first.');
      return;
    }

    // Reset existing extracted items before starting fresh extraction
    setExtractedCategories([]);
    setExtractedItems([]);
    setStep('extracting');
    setErrorMessage(null);
    setReviewValidationError(null);

    try {
      const payloadImages = images.map((img, idx) => {
        const cleanBase64 = img.base64Data.includes(',') ? img.base64Data.split(',')[1] : img.base64Data;
        const approxKb = Math.round((cleanBase64.length * 3) / 4 / 1024);
        console.log(`[Client MenuPhotoExtractor] Preparing image #${idx + 1}: ${img.id || 'photo'}, mime: ${img.mimeType}, size: ~${approxKb} KB`);
        return {
          base64Data: img.base64Data,
          mimeType: img.mimeType
        };
      });

      const payload = {
        images: payloadImages
      };

      console.log(`[Client MenuPhotoExtractor] Dispatching /api/extract-menu with ${payloadImages.length} image(s)...`);

      const res = await fetch('/api/extract-menu', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      let data: any = null;
      const contentType = res.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        data = await res.json().catch(() => null);
      } else {
        const textResp = await res.text().catch(() => '');
        console.error('Non-JSON server response received:', textResp);
      }

      if (!res.ok) {
        const errorMsg = data?.error || (res.status === 503 ? 'AI models are momentarily experiencing high demand. Please try again in a few moments.' : 'Menu could not be analyzed. Please check image clarity and try again.');
        console.error('API Extraction Error:', errorMsg, data);
        setErrorMessage(errorMsg);
        setExtractedCategories([]);
        setExtractedItems([]);
        setStep('error');
        return;
      }

      if (!data) {
        const errorMsg = 'Server returned an invalid response. Please try again.';
        console.error('Empty data in response:', errorMsg);
        setErrorMessage(errorMsg);
        setExtractedCategories([]);
        setExtractedItems([]);
        setStep('error');
        return;
      }

      if (data.warning && (!data.items || data.items.length === 0)) {
        const warnMsg = data.warning;
        console.warn('API Extraction Warning:', warnMsg);
        setErrorMessage(warnMsg);
        setExtractedCategories(data.categories || []);
        setExtractedItems(data.items || []);
        setStep('error');
        return;
      }

      if (!data.items || data.items.length === 0) {
        const noItemsMsg = 'No menu items could be detected in the photograph. Please try a clearer, higher-contrast picture, or add dishes manually.';
        console.warn('API Extraction Empty Result:', noItemsMsg);
        setErrorMessage(noItemsMsg);
        setExtractedCategories([]);
        setExtractedItems([]);
        setStep('error');
        return;
      }

      const receivedCategories: ExtractedCategory[] = Array.isArray(data.categories) ? data.categories : [];
      const receivedItems: ExtractedMenuItem[] = Array.isArray(data.items) ? data.items : [];

      setExtractedCategories(receivedCategories);
      setExtractedItems(receivedItems);
      setConfidenceNote(data.confidenceNote || '');

      // Directly apply & save to active business live menu, then auto-navigate back to Owner Menu Editor
      setStep('saving');
      try {
        const currentStyle: MenuStyle = business.menuStyle || 'classic';
        const saveResult = await applyExtractedMenu(
          business.id,
          receivedCategories,
          receivedItems,
          saveMode,
          existingCategories,
          existingItems,
          currentStyle
        );

        onSuccess({
          ...saveResult,
          selectedStyle: currentStyle
        });
      } catch (saveErr: any) {
        console.error('Automatic menu save failed, falling back to review screen:', saveErr);
        setStep('review');
      }
    } catch (err: any) {
      console.error('API Extraction Request Exception:', err);
      const errMsg = err?.message || 'Image processing encountered an issue. Please try another photograph or enter dishes manually.';
      setErrorMessage(errMsg);
      setExtractedCategories([]);
      setExtractedItems([]);
      setStep('error');
    }
  };

  // Editable item handlers
  const handleUpdateItem = (tempId: string, updates: Partial<ExtractedMenuItem>) => {
    setExtractedItems(prev => prev.map(item => {
      if (item.tempId === tempId) {
        const updated = { ...item, ...updates };
        // If price and name are valid and user edited it, clear review warning unless specified
        if (updates.price !== undefined && updates.price !== null && updates.price > 0 && item.needsReview) {
          updated.needsReview = false;
        }
        return updated;
      }
      return item;
    }));
  };

  const handleDeleteItem = (tempId: string) => {
    setExtractedItems(prev => prev.filter(item => item.tempId !== tempId));
  };

  const handleAddNewItem = (categoryName?: string) => {
    const targetCategory = categoryName || (extractedCategories[0]?.name || 'General');
    const newItem: ExtractedMenuItem = {
      tempId: `custom_${Date.now()}`,
      categoryName: targetCategory,
      name: '',
      description: '',
      price: null,
      isVeg: 'veg',
      isAvailable: true,
      needsReview: true,
      reviewReason: 'Newly added manually'
    };
    setExtractedItems(prev => [...prev, newItem]);
  };

  const handleSaveNewCategory = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = newCategoryName.trim();
    if (!clean) {
      setIsAddingCategoryInline(false);
      return;
    }
    if (!extractedCategories.some(c => c.name.toLowerCase() === clean.toLowerCase())) {
      setExtractedCategories(prev => [...prev, { name: clean }]);
      setActiveCategoryFilter(clean);
    }
    setNewCategoryName('');
    setIsAddingCategoryInline(false);
  };

  // Execute Voice / Text Correction using Gemini AI
  const executeVoiceCorrection = async (transcript: string) => {
    if (!transcript || !transcript.trim()) return;
    setIsProcessingVoice(true);
    setVoiceError(null);
    try {
      const res = await fetch('/api/correct-menu-voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          voiceTranscript: transcript,
          currentCategories: extractedCategories,
          currentItems: extractedItems,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to process voice command.');
      }

      if (data.categories && Array.isArray(data.categories)) {
        setExtractedCategories(data.categories);
      }
      if (data.items && Array.isArray(data.items)) {
        setExtractedItems(data.items);
      }

      setVoiceSuccessToast(data.summary || 'Voice correction applied successfully!');
      setVoiceTranscript('');
      setVoiceManualInput('');
      setTimeout(() => {
        setVoiceSuccessToast(null);
      }, 5000);
    } catch (err: any) {
      console.error('Voice correction error:', err);
      setVoiceError(err.message || 'Could not apply voice correction. Please try again.');
    } finally {
      setIsProcessingVoice(false);
    }
  };

  // Start / Stop Browser Speech Recognition
  const toggleSpeechRecognition = () => {
    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // ignore
        }
      }
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setVoiceError('Speech recognition is not supported in this browser environment. You can type your voice command in the box.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-IN';
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;
      recognition.continuous = false;

      recognition.onstart = () => {
        setIsListening(true);
        setVoiceError(null);
        setVoiceTranscript('');
      };

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = 0; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        setVoiceTranscript(currentTranscript);
        if (event.results[0].isFinal) {
          setIsListening(false);
          executeVoiceCorrection(currentTranscript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
          setVoiceError('Microphone permission was denied. Please allow microphone access or type your correction below.');
        } else if (event.error !== 'no-speech') {
          setVoiceError(`Voice input: ${event.error}. You can type your command directly.`);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      console.error('Failed to start speech recognition:', err);
      setIsListening(false);
      setVoiceError('Could not access microphone. Please type your correction below.');
    }
  };

  // Clean up speech recognition on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // ignore
        }
      }
    };
  }, []);

  // Validate and proceed to Style Selection screen
  const handleProceedToStyleSelection = () => {
    if (extractedItems.length === 0) {
      setReviewValidationError('Your menu has no items to save. Please add or extract at least one item.');
      return;
    }

    // Check if any items have empty names
    const invalidItems = extractedItems.filter(i => !i.name.trim());
    if (invalidItems.length > 0) {
      setReviewValidationError('Please provide a name for all dishes or delete empty rows before proceeding.');
      return;
    }

    setReviewValidationError(null);
    setStep('choose-style');
  };

  // Save confirmed menu and selected style to Firestore
  const handleApplyChosenStyle = async (chosenStyle: MenuStyle) => {
    setStep('saving');
    try {
      const result = await applyExtractedMenu(
        business.id,
        extractedCategories,
        extractedItems,
        saveMode,
        existingCategories,
        existingItems,
        chosenStyle
      );

      onSuccess({
        ...result,
        selectedStyle: chosenStyle
      });
    } catch (err: any) {
      console.error('Failed to save menu:', err);
      setReviewValidationError('Failed to save menu to database. Please check your internet connection and retry.');
      setStep('review');
    }
  };

  // Prepare categories & items for live style preview
  const previewCategories: MenuCategory[] = extractedCategories.map((c, idx) => ({
    id: `cat_prev_${idx}`,
    businessId: business.id,
    name: c.name,
    description: c.description,
    displayOrder: idx + 1,
    isActive: true,
  }));

  const previewItems: MenuItem[] = extractedItems.map((item, idx) => {
    const matchedCat = previewCategories.find(c => c.name.toLowerCase() === item.categoryName.toLowerCase()) || previewCategories[0];
    return {
      id: item.tempId || `item_prev_${idx}`,
      businessId: business.id,
      categoryId: matchedCat?.id || 'cat_prev_0',
      name: item.name || 'Delicious Dish',
      description: item.description,
      price: item.price ?? 0,
      isVeg: item.isVeg,
      isAvailable: item.isAvailable,
      displayOrder: idx + 1,
    };
  });

  // Calculated stats for review screen
  const totalItemsCount = extractedItems.length;
  const itemsNeedingReviewCount = extractedItems.filter(i => i.needsReview).length;
  const filteredItems = extractedItems.filter(item => {
    if (filterNeedsReviewOnly && !item.needsReview) return false;
    if (activeCategoryFilter !== 'all' && item.categoryName !== activeCategoryFilter) return false;
    return true;
  });

  return (
    <div id="menu-photo-extractor" className="bg-white border border-stone-200 rounded-2xl shadow-xs overflow-hidden">
      
      {/* Header Banner */}
      <div className="bg-stone-900 text-white p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-500/20 text-amber-400 font-mono text-[11px] font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              AI Menu Digitizer
            </span>
            <span className="text-xs text-stone-400">Low Cost Free Tier • Zero Image Storage</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight mt-1 text-white">
            Create Menu from Photo
          </h2>
          <p className="text-xs text-stone-300 mt-0.5">
            Turn handwritten cards, paper menus, boards, or multi-page pamphlets into an organized digital QR menu.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {step === 'review' && (
            <button
              id="back-to-photos-btn"
              onClick={() => setStep('upload')}
              className="flex items-center gap-1 px-3 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xl transition-colors"
            >
              <ArrowLeft className="w-4 h-4" /> Change Photos
            </button>
          )}
          <button
            id="close-extractor-btn"
            onClick={onCancel}
            className="p-2 text-stone-400 hover:text-white hover:bg-stone-800 rounded-xl transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* STEP 1: UPLOAD & MULTI-PAGE PHOTO SELECTION */}
      {(step === 'upload' || step === 'error') && (
        <div className="p-5 sm:p-7 space-y-6">

          {/* Error Message banner if failed */}
          {errorMessage && (
            <div id="menu-extraction-error-alert" className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 flex items-start justify-between gap-3 shadow-xs">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <p className="font-bold text-sm text-rose-950">Extraction Failed</p>
                  <p className="text-rose-900 leading-relaxed font-medium">{errorMessage}</p>
                  <p className="text-rose-700 text-[11px]">Tip: Ensure the paper is well-lit, lay it flat, and avoid strong glare on laminated surfaces or camera blur.</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setErrorMessage(null)}
                className="text-rose-400 hover:text-rose-700 p-1 rounded-lg hover:bg-rose-100 transition-colors"
                title="Dismiss error"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Instructions Box */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 bg-stone-50 rounded-xl border border-stone-200 text-xs text-stone-700">
            <div className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0">1</span>
              <div>
                <strong className="text-stone-900 block font-semibold">Snap or Upload</strong>
                Supports handwritten, printed, blackboard, or multiple pages.
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0">2</span>
              <div>
                <strong className="text-stone-900 block font-semibold">Client-Side Compression</strong>
                Images are optimized in-browser. No bulky original photos stored.
              </div>
            </div>
            <div className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center font-bold text-[10px] shrink-0">3</span>
              <div>
                <strong className="text-stone-900 block font-semibold">Review Before Saving</strong>
                Verify extracted items & prices safely before updating your live menu.
              </div>
            </div>
          </div>

          {/* Two Primary Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Take Photo Button (Mobile Camera trigger) */}
            <button
              id="take-photo-btn"
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className="flex flex-col items-center justify-center p-6 rounded-2xl border-2 border-dashed border-amber-400 bg-amber-50/50 hover:bg-amber-50 text-stone-900 transition-all text-center group cursor-pointer"
            >
              <div className="w-12 h-12 rounded-2xl bg-amber-500 text-stone-950 flex items-center justify-center mb-3 shadow-xs group-hover:scale-105 transition-transform">
                <Camera className="w-6 h-6" />
              </div>
              <span className="font-bold text-sm text-stone-900">Take Photo</span>
              <span className="text-xs text-stone-600 mt-1">Use phone camera to photograph menu page</span>
            </button>

            {/* Upload Photo Button */}
            <button
              id="upload-photo-btn"
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex flex-col items-center justify-center p-6 rounded-2xl border-2 border-dashed border-stone-300 bg-stone-50 hover:bg-stone-100 text-stone-900 transition-all text-center group cursor-pointer"
            >
              <div className="w-12 h-12 rounded-2xl bg-stone-900 text-white flex items-center justify-center mb-3 shadow-xs group-hover:scale-105 transition-transform">
                <Upload className="w-6 h-6" />
              </div>
              <span className="font-bold text-sm text-stone-900">Upload Menu Photo</span>
              <span className="text-xs text-stone-600 mt-1">Select one or multiple photos from device</span>
            </button>

            {/* Hidden Input Elements */}
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={(e) => handleFilesSelected(e.target.files)}
            />
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => handleFilesSelected(e.target.files)}
            />
          </div>

          {/* Loading indicator during image compression */}
          {isOptimizing && (
            <div className="flex items-center justify-center gap-2 p-4 text-xs font-semibold text-stone-600 bg-stone-100 rounded-xl animate-pulse">
              <RefreshCw className="w-4 h-4 animate-spin text-amber-600" />
              Optimizing and compressing menu photograph(s)...
            </div>
          )}

          {/* Selected Pages Gallery */}
          {images.length > 0 && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-stone-700 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-amber-600" />
                  Selected Menu Pages ({images.length})
                </h3>
                <button
                  type="button"
                  onClick={handleClearAllImages}
                  className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Clear All
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {images.map((img, idx) => (
                  <div 
                    key={img.id}
                    className="group relative rounded-xl border border-stone-200 bg-stone-50 overflow-hidden shadow-2xs"
                  >
                    <img 
                      src={img.previewUrl} 
                      alt={`Menu Page ${idx + 1}`}
                      className="w-full h-36 object-cover object-center"
                    />
                    
                    {/* Page Number Badge */}
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-stone-900/80 text-white font-mono text-[10px] font-bold backdrop-blur-xs">
                      Page {idx + 1}
                    </div>

                    {/* Remove button */}
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(img.id)}
                      className="absolute top-2 right-2 p-1 rounded-md bg-rose-600 text-white shadow-xs hover:bg-rose-700 transition-colors"
                      title="Remove this page"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>

                    {/* File Size details */}
                    <div className="p-2 bg-white text-[10px] text-stone-600 border-t border-stone-100 flex items-center justify-between">
                      <span className="truncate max-w-[80px] font-medium">{img.originalName}</span>
                      <span className="text-stone-400">{formatFileSize(img.optimizedSize)}</span>
                    </div>
                  </div>
                ))}

                {/* Add More Pages Button */}
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="h-36 rounded-xl border-2 border-dashed border-stone-300 hover:border-amber-500 hover:bg-amber-50/40 flex flex-col items-center justify-center text-stone-600 hover:text-stone-900 transition-colors"
                >
                  <Plus className="w-6 h-6 mb-1 text-stone-400" />
                  <span className="text-xs font-bold">Add Another Page</span>
                </button>
              </div>
            </div>
          )}

          {/* Explicit AI Extraction Trigger Button */}
          <div className="pt-4 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-xs text-stone-500">
              {images.length === 0 ? (
                'Upload at least one page to begin extraction'
              ) : (
                `Ready to analyze ${images.length} menu page${images.length > 1 ? 's' : ''}`
              )}
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2.5 border border-stone-300 text-stone-700 hover:bg-stone-100 rounded-xl text-xs font-bold transition-colors w-full sm:w-auto"
              >
                Cancel
              </button>

              <button
                id="start-ai-extraction-btn"
                type="button"
                disabled={images.length === 0 || isOptimizing}
                onClick={handleStartExtraction}
                className="flex items-center justify-center gap-2 px-6 py-2.5 bg-amber-500 hover:bg-amber-600 disabled:bg-stone-300 text-stone-950 disabled:text-stone-500 font-black text-xs rounded-xl shadow-xs transition-all w-full sm:w-auto cursor-pointer disabled:cursor-not-allowed"
              >
                <Sparkles className="w-4 h-4" />
                Extract Menu with AI
              </button>
            </div>
          </div>

        </div>
      )}

      {/* STEP 2: EXTRACTION IN PROGRESS */}
      {step === 'extracting' && (
        <div id="extraction-loading-indicator" className="p-12 text-center space-y-6">
          <div className="relative inline-flex items-center justify-center">
            <div className="w-20 h-20 rounded-full bg-amber-100 animate-ping opacity-75" />
            <div className="absolute w-16 h-16 rounded-full bg-amber-500 text-stone-950 flex items-center justify-center shadow-md">
              <Sparkles className="w-8 h-8 animate-spin" />
            </div>
          </div>

          <div className="space-y-2 max-w-md mx-auto">
            <h3 className="text-xl font-black text-stone-900">
              Extracting menu items...
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Reading dish names, prices, categories, and dietary tags using Gemini AI Vision. Please wait while your items are analyzed and imported...
            </p>
          </div>

          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-stone-100 text-stone-700 text-xs font-mono">
            <span>Processing {images.length} page image{images.length > 1 ? 's' : ''}</span>
          </div>
        </div>
      )}

      {/* STEP 3: REVIEW & EDIT SCREEN ("Review Extracted Menu") */}
      {step === 'review' && (
        <div className="p-4 sm:p-6 space-y-6">
          
          {/* Summary & Review Banner */}
          <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-stone-900">Review Extracted Menu</span>
                <span className="px-2 py-0.5 rounded-full bg-amber-200 text-stone-900 text-xs font-bold">
                  {totalItemsCount} items detected
                </span>
                {itemsNeedingReviewCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 text-xs font-bold flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" />
                    {itemsNeedingReviewCount} need attention
                  </span>
                )}
              </div>
              <p className="text-xs text-stone-600 mt-1">
                {confidenceNote || 'Check dishes and prices below. You can edit names, prices, categories, or delete items by typing or using your microphone.'}
              </p>
            </div>

            {/* Fast Filter Toggle for items needing attention */}
            {itemsNeedingReviewCount > 0 && (
              <button
                type="button"
                onClick={() => setFilterNeedsReviewOnly(!filterNeedsReviewOnly)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                  filterNeedsReviewOnly
                    ? 'bg-rose-600 text-white'
                    : 'bg-white border border-stone-300 text-stone-700 hover:bg-stone-50'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                {filterNeedsReviewOnly ? 'Show All Items' : `Show ${itemsNeedingReviewCount} Flagged Items`}
              </button>
            )}
          </div>

          {/* VOICE CORRECTIONS ASSISTANT BAR */}
          <div className="p-4 rounded-2xl bg-stone-900 text-white border border-stone-800 space-y-3 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl flex items-center justify-center transition-colors ${
                  isListening ? 'bg-rose-600 animate-pulse text-white' : 'bg-amber-500 text-stone-950'
                }`}>
                  {isListening ? <Mic className="w-5 h-5 animate-bounce" /> : <Mic className="w-5 h-5" />}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                      Voice Corrections via Microphone
                    </h4>
                    <span className="px-2 py-0.5 rounded-md bg-stone-800 text-[10px] font-mono text-amber-400">
                      Speech + AI
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-400">
                    Click the microphone and speak any correction (prices, names, diet type, add/delete dishes).
                  </p>
                </div>
              </div>

              {/* Microphone Toggle Button */}
              <button
                id="voice-correction-mic-btn"
                type="button"
                onClick={toggleSpeechRecognition}
                disabled={isProcessingVoice}
                className={`flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer ${
                  isListening
                    ? 'bg-rose-600 hover:bg-rose-700 text-white ring-4 ring-rose-500/30'
                    : isProcessingVoice
                    ? 'bg-stone-700 text-stone-400 cursor-not-allowed'
                    : 'bg-amber-500 hover:bg-amber-400 text-stone-950 shadow-xs'
                }`}
              >
                {isListening ? (
                  <>
                    <MicOff className="w-4 h-4" />
                    <span>Stop Listening</span>
                  </>
                ) : isProcessingVoice ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    <span>Applying Voice Fix...</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4" />
                    <span>Tap to Speak Correction</span>
                  </>
                )}
              </button>
            </div>

            {/* Listening Status & Live Transcript */}
            {isListening && (
              <div className="p-3 bg-stone-800/90 border border-stone-700 rounded-xl flex items-center justify-between gap-3 text-xs animate-in fade-in">
                <div className="flex items-center gap-2 text-stone-300">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping shrink-0" />
                  <span className="font-semibold text-rose-400">Listening...</span>
                  <span className="italic text-white">
                    {voiceTranscript || 'Say e.g., "Change Masala Dosa price to 90" or "Make Biryani non-veg"'}
                  </span>
                </div>
                {voiceTranscript && (
                  <button
                    type="button"
                    onClick={() => {
                      if (recognitionRef.current) recognitionRef.current.stop();
                      setIsListening(false);
                      executeVoiceCorrection(voiceTranscript);
                    }}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] rounded-lg transition-colors whitespace-nowrap"
                  >
                    Apply Now
                  </button>
                )}
              </div>
            )}

            {/* Voice Success Toast / Notification */}
            {voiceSuccessToast && (
              <div className="p-3 bg-emerald-950/80 border border-emerald-700 text-emerald-200 rounded-xl flex items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{voiceSuccessToast}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setVoiceSuccessToast(null)}
                  className="text-emerald-400 hover:text-white p-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Voice Error Notification */}
            {voiceError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-200 rounded-xl flex items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{voiceError}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setVoiceError(null)}
                  className="text-rose-400 hover:text-white p-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Voice Command Quick Input / Type Alternative */}
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                executeVoiceCorrection(voiceManualInput);
              }}
              className="flex items-center gap-2 pt-1"
            >
              <div className="relative flex-1">
                <input
                  type="text"
                  value={voiceManualInput}
                  onChange={(e) => setVoiceManualInput(e.target.value)}
                  placeholder="Or type voice command (e.g., 'Change Paneer Butter Masala price to 180' or 'Delete Cold Coffee')..."
                  className="w-full bg-stone-800/90 text-stone-100 placeholder-stone-400 text-xs px-3 py-2 rounded-xl border border-stone-700 focus:outline-hidden focus:border-amber-500"
                />
              </div>
              <button
                type="submit"
                disabled={!voiceManualInput.trim() || isProcessingVoice}
                className="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 disabled:opacity-50 text-stone-200 hover:text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Apply</span>
              </button>
            </form>

            {/* Quick Example Pills */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1 text-[11px] text-stone-400">
              <span className="text-stone-500 font-semibold">Try speaking:</span>
              {[
                'Set price of first dish to ₹80',
                'Change Masala Dosa to ₹90',
                'Make Chicken Biryani non-veg',
                'Add Garlic Naan 60 in Breads',
                'Delete Cold Drink'
              ].map((ex) => (
                <button
                  key={ex}
                  type="button"
                  onClick={() => {
                    setVoiceManualInput(ex);
                    executeVoiceCorrection(ex);
                  }}
                  className="px-2 py-0.5 rounded-md bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white border border-stone-700 transition-colors"
                >
                  "{ex}"
                </button>
              ))}
            </div>
          </div>

          {/* Category Filter Pills & Add Category Action */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            <button
              type="button"
              onClick={() => setActiveCategoryFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${
                activeCategoryFilter === 'all'
                  ? 'bg-stone-900 text-white'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              All Categories ({extractedItems.length})
            </button>

            {extractedCategories.map(cat => {
              const count = extractedItems.filter(i => i.categoryName === cat.name).length;
              return (
                <button
                  key={cat.name}
                  type="button"
                  onClick={() => setActiveCategoryFilter(cat.name)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${
                    activeCategoryFilter === cat.name
                      ? 'bg-stone-900 text-white'
                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                  }`}
                >
                  {cat.name} ({count})
                </button>
              );
            })}

            {isAddingCategoryInline ? (
              <form 
                onSubmit={handleSaveNewCategory}
                className="flex items-center gap-1 bg-amber-50 p-1 rounded-xl border border-amber-300"
              >
                <input
                  type="text"
                  autoFocus
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  placeholder="Category name..."
                  className="px-2 py-0.5 text-xs rounded-lg bg-white border border-stone-300 text-stone-900 focus:outline-hidden focus:border-amber-500 w-32"
                />
                <button
                  type="submit"
                  className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold"
                >
                  Save
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsAddingCategoryInline(false);
                    setNewCategoryName('');
                  }}
                  className="px-1.5 py-1 text-stone-500 hover:text-stone-800 text-[11px]"
                >
                  ✕
                </button>
              </form>
            ) : (
              <button
                type="button"
                onClick={() => setIsAddingCategoryInline(true)}
                className="px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap bg-amber-100 text-stone-900 hover:bg-amber-200 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Add Category
              </button>
            )}
          </div>

          {/* Review Validation Error Banner */}
          {reviewValidationError && (
            <div className="p-3 bg-rose-50 border border-rose-300 text-rose-800 rounded-xl flex items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{reviewValidationError}</span>
              </div>
              <button
                type="button"
                onClick={() => setReviewValidationError(null)}
                className="text-rose-500 hover:text-rose-800 p-1"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Items Table / Cards for Mobile */}
          <div className="space-y-3">
            {filteredItems.length === 0 ? (
              <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200 text-xs text-stone-500">
                No items match this filter.
              </div>
            ) : (
              filteredItems.map((item, idx) => (
                <div 
                  key={item.tempId}
                  className={`p-3.5 sm:p-4 rounded-xl border transition-all ${
                    item.needsReview
                      ? 'bg-amber-50/40 border-amber-300 ring-1 ring-amber-300/50'
                      : 'bg-white border-stone-200 hover:border-stone-300'
                  }`}
                >
                  {/* Needs review warning tag */}
                  {item.needsReview && (
                    <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-800 bg-amber-100 px-2.5 py-1 rounded-md mb-2.5 w-fit">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                      <span>{item.reviewReason || 'Please verify price or spelling for this item'}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                    
                    {/* Diet Toggle & Name */}
                    <div className="sm:col-span-5 flex items-center gap-2">
                      {/* Veg / Non-Veg / Egg selector */}
                      <button
                        type="button"
                        title="Click to cycle Diet tag (Veg / Non-Veg / Egg)"
                        onClick={() => {
                          const nextType: FoodDietType = 
                            item.isVeg === 'veg' ? 'non-veg' : item.isVeg === 'non-veg' ? 'egg' : 'veg';
                          handleUpdateItem(item.tempId, { isVeg: nextType });
                        }}
                        className="shrink-0 p-1 rounded-md hover:bg-stone-100 transition-colors"
                      >
                        <DietBadge type={item.isVeg} size="sm" showLabel={false} />
                      </button>

                      <div className="flex-1 min-w-0">
                        <input
                          type="text"
                          value={item.name}
                          placeholder="Dish name..."
                          onChange={(e) => handleUpdateItem(item.tempId, { name: e.target.value })}
                          className="w-full text-xs sm:text-sm font-bold text-stone-900 bg-transparent border-b border-transparent hover:border-stone-300 focus:border-amber-500 focus:bg-amber-50/30 focus:outline-hidden px-1 py-0.5 rounded-xs"
                        />
                        <input
                          type="text"
                          value={item.description || ''}
                          placeholder="Description or notes (optional)..."
                          onChange={(e) => handleUpdateItem(item.tempId, { description: e.target.value })}
                          className="w-full text-[11px] text-stone-500 bg-transparent border-b border-transparent hover:border-stone-300 focus:border-amber-500 focus:outline-hidden px-1 py-0.5 rounded-xs"
                        />
                      </div>
                    </div>

                    {/* Category Selector */}
                    <div className="sm:col-span-3">
                      <label className="text-[10px] text-stone-400 uppercase font-semibold block sm:hidden">Category</label>
                      <select
                        value={item.categoryName}
                        onChange={(e) => handleUpdateItem(item.tempId, { categoryName: e.target.value })}
                        className="w-full text-xs font-semibold text-stone-800 bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-1.5 focus:border-amber-500 focus:outline-hidden"
                      >
                        {extractedCategories.map(cat => (
                          <option key={cat.name} value={cat.name}>{cat.name}</option>
                        ))}
                      </select>
                    </div>

                    {/* Price Input */}
                    <div className="sm:col-span-2">
                      <label className="text-[10px] text-stone-400 uppercase font-semibold block sm:hidden">Price</label>
                      <div className="relative flex items-center">
                        <span className="absolute left-2 text-xs font-bold text-stone-500">₹</span>
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={item.price === null ? '' : item.price}
                          placeholder="0"
                          onChange={(e) => {
                            const val = e.target.value === '' ? null : Number(e.target.value);
                            handleUpdateItem(item.tempId, { price: val });
                          }}
                          className={`w-full pl-6 pr-2 py-1.5 text-xs font-black rounded-lg border focus:outline-hidden ${
                            item.price === null
                              ? 'bg-rose-50 border-rose-300 text-rose-900 focus:border-rose-500'
                              : 'bg-stone-50 border-stone-200 text-stone-900 focus:border-amber-500'
                          }`}
                        />
                      </div>
                    </div>

                    {/* Actions: Delete & Availability Toggle */}
                    <div className="sm:col-span-2 flex items-center justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => handleUpdateItem(item.tempId, { isAvailable: !item.isAvailable })}
                        className={`text-[10px] font-bold px-2 py-1 rounded-md transition-colors ${
                          item.isAvailable
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-stone-200 text-stone-600'
                        }`}
                      >
                        {item.isAvailable ? 'In Stock' : 'Sold Out'}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDeleteItem(item.tempId)}
                        className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                        title="Delete item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                  </div>
                </div>
              ))
            )}
          </div>

          {/* Add Item Button */}
          <div className="flex justify-start">
            <button
              type="button"
              onClick={() => handleAddNewItem(activeCategoryFilter !== 'all' ? activeCategoryFilter : undefined)}
              className="flex items-center gap-1.5 px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold rounded-xl transition-colors"
            >
              <Plus className="w-4 h-4" /> Add Missing Dish
            </button>
          </div>

          {/* CONFIRMATION & SAVING MODE OPTIONS */}
          <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-4">
            <div>
              <label className="text-xs font-bold text-stone-900 block mb-1">
                How should this extracted menu be saved?
              </label>
              <p className="text-[11px] text-stone-500">
                Your live customer menu is safe until you explicitly click "Confirm & Save Menu".
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label 
                className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                  saveMode === 'append'
                    ? 'bg-white border-amber-500 ring-2 ring-amber-500/20'
                    : 'bg-stone-100/60 border-stone-200 hover:bg-white'
                }`}
              >
                <input
                  type="radio"
                  name="saveMode"
                  value="append"
                  checked={saveMode === 'append'}
                  onChange={() => setSaveMode('append')}
                  className="mt-0.5 text-amber-600 focus:ring-amber-500"
                />
                <div className="text-xs">
                  <span className="font-bold text-stone-900 block">Add to current menu</span>
                  <span className="text-stone-500 text-[11px]">
                    Keeps existing {existingItems.length} items and appends new extracted categories & items.
                  </span>
                </div>
              </label>

              <label 
                className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                  saveMode === 'replace'
                    ? 'bg-white border-rose-500 ring-2 ring-rose-500/20'
                    : 'bg-stone-100/60 border-stone-200 hover:bg-white'
                }`}
              >
                <input
                  type="radio"
                  name="saveMode"
                  value="replace"
                  checked={saveMode === 'replace'}
                  onChange={() => setSaveMode('replace')}
                  className="mt-0.5 text-rose-600 focus:ring-rose-500"
                />
                <div className="text-xs">
                  <span className="font-bold text-rose-900 block">Replace entire menu</span>
                  <span className="text-stone-500 text-[11px]">
                    Cleans and replaces all current items with this new freshly extracted menu.
                  </span>
                </div>
              </label>
            </div>

            {/* Bottom Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
              <button
                type="button"
                onClick={() => setStep('upload')}
                className="px-4 py-2.5 border border-stone-300 text-stone-700 hover:bg-stone-100 rounded-xl text-xs font-bold transition-colors w-full sm:w-auto"
              >
                ← Back to Photos
              </button>

              <button
                id="confirm-and-save-menu-btn"
                type="button"
                onClick={handleProceedToStyleSelection}
                className="flex items-center justify-center gap-2 px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-stone-950 font-black text-xs rounded-xl shadow-xs transition-all w-full sm:w-auto"
              >
                <Sparkles className="w-4 h-4" />
                Confirm & Choose Menu Style ({extractedItems.length} Items)
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      )}

      {/* STEP 4: CHOOSE MENU STYLE SCREEN */}
      {step === 'choose-style' && (
        <div className="p-4 sm:p-6 bg-stone-50/50">
          <MenuStyleSelector
            business={business}
            categories={previewCategories}
            items={previewItems}
            currentStyle={business.menuStyle || 'classic'}
            onSelectStyle={handleApplyChosenStyle}
            onCancel={() => setStep('review')}
          />
        </div>
      )}

      {/* STEP 5: SAVING STATE */}
      {step === 'saving' && (
        <div className="p-12 text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto animate-spin">
            <RefreshCw className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-stone-900">Synchronizing Menu to Cloud Database...</h3>
            <p className="text-xs text-stone-500">Updating Firestore live menu items and categories.</p>
          </div>
        </div>
      )}

    </div>
  );
};
