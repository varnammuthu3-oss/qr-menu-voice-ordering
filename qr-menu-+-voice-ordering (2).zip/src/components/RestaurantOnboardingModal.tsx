import React, { useState, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { 
  X, 
  Store, 
  Sparkles, 
  Upload, 
  FileText, 
  Image as ImageIcon, 
  MessageSquare, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft,
  Plus, 
  Trash2, 
  Copy, 
  Printer, 
  ExternalLink, 
  AlertCircle, 
  HelpCircle,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  QrCode,
  MapPin,
  Mail,
  Phone,
  Layers,
  Sparkle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Business, ExtractedCategory, ExtractedMenuItem } from '../types';
import { saveBusiness, applyExtractedMenu } from '../services/db';
import { saveRestaurant } from '../utils/shopPersistence';
import { extractMenuWithAI, parseMenuTextOffline, PRESET_SAMPLE_MENUS } from '../utils/menuExtractor';
import { generateKotMessage } from '../utils/phone';

interface RestaurantOnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOnboardingComplete: (newBusiness: Business) => void;
}

type OnboardingStep = 'details' | 'menu' | 'success';

export const RestaurantOnboardingModal: React.FC<RestaurantOnboardingModalProps> = ({
  isOpen,
  onClose,
  onOnboardingComplete,
}) => {
  // Step navigation
  const [currentStep, setCurrentStep] = useState<OnboardingStep>('details');

  // Step 1: Restaurant Details
  const [storeName, setStoreName] = useState('');
  const [ownerEmail, setOwnerEmail] = useState('varnammuthu3@gmail.com');
  const [whatsappDestination, setWhatsappDestination] = useState('+91 ');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Bengaluru');
  const [currencySymbol, setCurrencySymbol] = useState('₹');
  const [tagline, setTagline] = useState('');
  const [businessType, setBusinessType] = useState<'restaurant' | 'guesthouse'>('restaurant');
  const [menuDisplayMode, setMenuDisplayMode] = useState<'photo' | 'text'>('photo');

  // Step 2: Menu Extraction State
  const [menuInputMode, setMenuInputMode] = useState<'upload' | 'text' | 'preset'>('upload');
  const [uploadedImages, setUploadedImages] = useState<{ base64Data: string; mimeType: string; name: string }[]>([]);
  const [rawMenuText, setRawMenuText] = useState('');
  const [isExtracting, setIsExtracting] = useState(false);
  const [extractionNote, setExtractionNote] = useState<string | null>(null);
  const [extractionError, setExtractionError] = useState<string | null>(null);
  const [showPromptDetails, setShowPromptDetails] = useState(false);

  // Extracted items & categories list (editable by owner)
  const [extractedCategories, setExtractedCategories] = useState<ExtractedCategory[]>([]);
  const [extractedItems, setExtractedItems] = useState<ExtractedMenuItem[]>([]);

  // Step 3: Created Business & QR Code
  const [createdBusiness, setCreatedBusiness] = useState<Business | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [testKOTPreviewOpen, setTestKOTPreviewOpen] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Generate clean slug from store name
  const generatedSlug = storeName
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '') || `shop-${Date.now().toString(36)}`;

  // Handle Photo File Upload
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setExtractionError(null);
    const newImgs: { base64Data: string; mimeType: string; name: string }[] = [];

    Array.from(files).forEach((file) => {
      const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
      if (!file.type.startsWith('image/') && !isPdf) return;
      const reader = new FileReader();
      reader.onload = () => {
        const base64Data = reader.result as string;
        newImgs.push({
          base64Data,
          mimeType: isPdf ? 'application/pdf' : (file.type || 'image/jpeg'),
          name: file.name
        });
        if (newImgs.length === files.length) {
          setUploadedImages((prev) => [...prev, ...newImgs]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // Handle Document Upload (.txt, .csv, markdown)
  const handleDocUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setExtractionError(null);
    const reader = new FileReader();
    reader.onload = () => {
      const content = reader.result as string;
      setRawMenuText(content);
      setMenuInputMode('text');
    };
    reader.readAsText(file);
  };

  // Run Automated Menu Extraction
  const handleRunExtraction = async () => {
    setExtractionError(null);
    setIsExtracting(true);
    setExtractionNote(null);

    try {
      if (menuInputMode === 'upload' && uploadedImages.length > 0) {
        // AI Image Vision Extraction
        const result = await extractMenuWithAI({
          images: uploadedImages,
          text: rawMenuText
        });
        setExtractedCategories(result.categories);
        setExtractedItems(result.items);
        setExtractionNote(result.confidenceNote || `Successfully digitized ${result.items.length} dishes from menu photos.`);
      } else if (rawMenuText.trim().length > 0) {
        // AI or Rule-Based Text Extraction
        const result = await extractMenuWithAI({
          text: rawMenuText
        });
        setExtractedCategories(result.categories);
        setExtractedItems(result.items);
        setExtractionNote(result.confidenceNote || `Digitized ${result.items.length} dishes across ${result.categories.length} categories.`);
      } else {
        // Fallback to quick preset if nothing provided
        handleLoadPreset('southIndian');
      }
    } catch (err: any) {
      console.warn('[RestaurantOnboarding] Extraction fallback:', err);
      // Fallback: rule-based offline parser if text was entered
      if (rawMenuText.trim().length > 0) {
        const offlineResult = parseMenuTextOffline(rawMenuText);
        setExtractedCategories(offlineResult.categories);
        setExtractedItems(offlineResult.items);
        setExtractionNote(offlineResult.confidenceNote || 'Extracted items using offline static parser.');
      } else {
        setExtractionError(err?.message || 'Could not parse menu. Please try pasting menu text or picking a starter preset.');
      }
    } finally {
      setIsExtracting(false);
    }
  };

  // Load a pre-built sample menu
  const handleLoadPreset = (key: keyof typeof PRESET_SAMPLE_MENUS) => {
    const preset = PRESET_SAMPLE_MENUS[key];
    setRawMenuText(preset.text);
    const parsed = parseMenuTextOffline(preset.text);
    setExtractedCategories(parsed.categories);
    setExtractedItems(parsed.items);
    setExtractionNote(`Loaded ${parsed.items.length} starter dishes from "${preset.name}". You can customize prices and names below.`);
    setExtractionError(null);
  };

  // Add a new blank item to extracted list
  const handleAddNewItem = () => {
    const catName = extractedCategories[0]?.name || 'Specials';
    const newItem: ExtractedMenuItem = {
      tempId: `manual_${Date.now()}`,
      categoryName: catName,
      name: 'New Dish',
      description: 'Freshly prepared',
      price: 50,
      isVeg: 'veg',
      isAvailable: true,
      needsReview: false
    };
    setExtractedItems((prev) => [...prev, newItem]);
  };

  // Update item field in extracted list
  const handleUpdateItem = (index: number, updates: Partial<ExtractedMenuItem>) => {
    setExtractedItems((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], ...updates };
      return next;
    });
  };

  // Delete item from extracted list
  const handleDeleteItem = (index: number) => {
    setExtractedItems((prev) => prev.filter((_, i) => i !== index));
  };

  // Final Onboarding Submit & Instant Launch
  const handleFinalSubmit = async () => {
    if (!storeName.trim()) {
      alert('Please enter your restaurant or shop name.');
      setCurrentStep('details');
      return;
    }

    setIsSaving(true);
    try {
      const now = new Date().toISOString();
      const isGroupUrl = whatsappDestination.includes('chat.whatsapp.com');
      const cleanPhone = whatsappDestination.replace(/[^0-9]/g, '');

      // Create new business record
      const newBusiness: Business = {
        id: generatedSlug,
        ownerUid: `owner_${Date.now()}`,
        name: storeName.trim(),
        ownerEmail: ownerEmail.trim() || undefined,
        whatsappGroupUrl: isGroupUrl ? whatsappDestination.trim() : undefined,
        phone: cleanPhone ? `+${cleanPhone}` : '+919845012345',
        whatsappNumber: whatsappDestination.trim() || '+919845012345',
        address: address.trim() || 'Counter Pickup Station',
        city: city.trim() || 'Bengaluru',
        currencySymbol: currencySymbol.trim() || '₹',
        tagline: tagline.trim() || 'Freshly made counter parcels & tiffin',
        description: `Owner: ${ownerEmail.trim()} • Type: ${businessType === 'restaurant' ? 'Table Service' : 'Room Service / Parcel Pickup'}`,
        openingHours: 'Mon - Sun: 7:00 AM – 10:30 PM',
        businessType: businessType,
        menuStyle: menuDisplayMode === 'text' ? 'minimal' : 'classic',
        menuDisplayMode: menuDisplayMode,
        isActive: true,
        is_approved: true,
        isApproved: true,
        status: 'active',
        subscriptionTier: 'starter',
        features: {
          enable_whatsapp_orders: false,
          enable_table_selector: businessType === 'restaurant',
          enable_visual_menu: menuDisplayMode === 'photo',
          enable_visual_menu_images: menuDisplayMode === 'photo'
        },
        createdAt: now,
        updatedAt: now
      };

      // 1. Save to local storage for instant offline availability
      saveRestaurant({
        id: newBusiness.id,
        name: newBusiness.name,
        tables: businessType === 'restaurant'
          ? ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
          : ['101', '102', '103', '104', 'Parcel Pickup'],
        features: {
          enable_whatsapp_orders: false,
          enable_table_selector: businessType === 'restaurant',
          enable_visual_menu: menuDisplayMode === 'photo',
          enable_visual_menu_images: menuDisplayMode === 'photo'
        },
        phone: newBusiness.phone,
        whatsappNumber: newBusiness.whatsappNumber,
        address: newBusiness.address,
        city: newBusiness.city,
        is_approved: true
      });

      // 2. Save business to Firestore / local cache
      await saveBusiness(newBusiness);

      // 3. Save extracted menu items
      const finalCats = extractedCategories.length > 0 
        ? extractedCategories 
        : [{ name: 'Chef Specials' }];
      
      const finalItems = extractedItems.length > 0
        ? extractedItems
        : [
            {
              tempId: 'default_1',
              categoryName: 'Chef Specials',
              name: 'House Special Parcel Combo',
              description: 'Authentic preparation packed hot and fresh for takeaway',
              price: 120,
              isVeg: 'veg' as const,
              isAvailable: true,
              needsReview: false
            }
          ];

      await applyExtractedMenu(
        newBusiness.id,
        finalCats,
        finalItems,
        'replace',
        [],
        []
      );

      setCreatedBusiness(newBusiness);
      setCurrentStep('success');
    } catch (err: any) {
      console.error('[RestaurantOnboarding] Failed to complete onboarding:', err);
      alert('Encountered an issue saving the restaurant: ' + (err?.message || 'Please try again.'));
    } finally {
      setIsSaving(false);
    }
  };

  const originUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const counterQrUrl = createdBusiness ? `${originUrl}/?shop=${encodeURIComponent(createdBusiness.id)}` : '';

  const handleCopyLink = () => {
    if (!counterQrUrl) return;
    navigator.clipboard.writeText(counterQrUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-stone-950/80 backdrop-blur-xs z-40 cursor-pointer"
        />

        {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 15 }}
          transition={{ type: 'spring', damping: 26, stiffness: 320 }}
          className="relative z-50 bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-2xl sm:max-w-3xl shadow-2xl overflow-hidden text-stone-100 my-auto flex flex-col max-h-[92vh]"
        >
          {/* Header */}
          <div className="px-5 py-4 border-b border-stone-800 flex items-center justify-between bg-stone-900/95 sticky top-0 z-20">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-black">
                <Store className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                  <span>Restaurant Fast Onboarding</span>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Static-Friendly PWA
                  </span>
                </h2>
                <p className="text-xs text-stone-400">
                  AI menu extraction & direct WhatsApp group counter QR code
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
              aria-label="Close onboarding modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Stepper Progress Bar */}
          <div className="px-5 py-2.5 bg-stone-950/70 border-b border-stone-800/80 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[11px] ${
                currentStep === 'details' ? 'bg-amber-500 text-stone-950 ring-2 ring-amber-500/40' : 'bg-emerald-500 text-stone-950'
              }`}>
                {currentStep === 'details' ? '1' : '✓'}
              </span>
              <span className={currentStep === 'details' ? 'font-bold text-amber-300' : 'text-stone-400'}>
                Store & WhatsApp
              </span>
            </div>
            
            <div className="w-8 h-px bg-stone-800 hidden sm:block" />

            <div className="flex items-center gap-2">
              <span className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[11px] ${
                currentStep === 'menu' ? 'bg-amber-500 text-stone-950 ring-2 ring-amber-500/40' : 
                currentStep === 'success' ? 'bg-emerald-500 text-stone-950' : 'bg-stone-800 text-stone-400'
              }`}>
                {currentStep === 'success' ? '✓' : '2'}
              </span>
              <span className={currentStep === 'menu' ? 'font-bold text-amber-300' : 'text-stone-400'}>
                Automated Menu
              </span>
            </div>

            <div className="w-8 h-px bg-stone-800 hidden sm:block" />

            <div className="flex items-center gap-2">
              <span className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-[11px] ${
                currentStep === 'success' ? 'bg-emerald-500 text-stone-950 ring-2 ring-emerald-500/40' : 'bg-stone-800 text-stone-400'
              }`}>
                3
              </span>
              <span className={currentStep === 'success' ? 'font-bold text-emerald-400' : 'text-stone-400'}>
                Counter QR Standee
              </span>
            </div>
          </div>

          {/* Scrollable Content Body */}
          <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-6">

            {/* ═════════════════════════════════════════════════════════ */}
            {/* STEP 1: STORE & WHATSAPP ROUTING DETAILS                  */}
            {/* ═════════════════════════════════════════════════════════ */}
            {currentStep === 'details' && (
              <div className="space-y-4">
                <div className="bg-stone-800/40 p-4 rounded-2xl border border-stone-700/60 flex items-start gap-3">
                  <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
                    <Store className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-sm">Friction-Free Restaurant Setup</h3>
                    <p className="text-xs text-stone-400 mt-0.5 leading-relaxed">
                      Enter your store details and designated WhatsApp number or group link. All incoming customer parcel orders will route straight to your counter kitchen without complex logins or POS hardware.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Store Name */}
                  <div className="space-y-1.5 sm:col-span-2">
                    <label className="text-xs font-bold text-stone-300 flex items-center justify-between">
                      <span>Restaurant / Store Name <span className="text-amber-400">*</span></span>
                      {storeName && (
                        <span className="text-[10px] font-mono text-stone-500 truncate">
                          ID: {generatedSlug}
                        </span>
                      )}
                    </label>
                    <input
                      type="text"
                      required
                      value={storeName}
                      onChange={(e) => setStoreName(e.target.value)}
                      placeholder="e.g. Kannayah Delicacies"
                      className="w-full px-3.5 py-2.5 bg-stone-800/90 border border-stone-700 rounded-xl text-sm text-white placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all font-semibold"
                    />
                  </div>

                  {/* Business Type: Table Service vs Room Service / Parcel Pickup */}
                  <div className="space-y-1.5 sm:col-span-2">
                    <label className="text-xs font-bold text-stone-300 flex items-center justify-between">
                      <span>Business Service Type <span className="text-amber-400">*</span></span>
                      <span className="text-[10px] text-stone-400">Controls order context & tickets</span>
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <button
                        type="button"
                        onClick={() => setBusinessType('restaurant')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          businessType === 'restaurant'
                            ? 'bg-amber-500/10 border-amber-500 text-white'
                            : 'bg-stone-900 border-stone-700 text-stone-400 hover:border-stone-600 hover:text-stone-300'
                        }`}
                      >
                        <div className="font-bold text-xs text-white flex items-center justify-between">
                          <span>Table Service</span>
                          {businessType === 'restaurant' && (
                            <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-bold">Selected</span>
                          )}
                        </div>
                        <p className="text-[11px] text-stone-400 mt-0.5">Dine-in dining tables, waiter duties & table KOTs.</p>
                      </button>

                      <button
                        type="button"
                        onClick={() => setBusinessType('guesthouse')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          businessType === 'guesthouse'
                            ? 'bg-amber-500/10 border-amber-500 text-white'
                            : 'bg-stone-900 border-stone-700 text-stone-400 hover:border-stone-600 hover:text-stone-300'
                        }`}
                      >
                        <div className="font-bold text-xs text-white flex items-center justify-between">
                          <span>Room Service / Parcel Pickup</span>
                          {businessType === 'guesthouse' && (
                            <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-bold">Selected</span>
                          )}
                        </div>
                        <p className="text-[11px] text-stone-400 mt-0.5">Hotel room delivery & takeaway parcel pickup.</p>
                      </button>
                    </div>
                  </div>

                  {/* Menu Presentation Toggle */}
                  <div className="space-y-1.5 sm:col-span-2">
                    <label className="text-xs font-bold text-stone-300 flex items-center justify-between">
                      <span>Menu Display Style <span className="text-amber-400">*</span></span>
                      <span className="text-[10px] text-stone-400">Catalog layout</span>
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <button
                        type="button"
                        onClick={() => setMenuDisplayMode('photo')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          menuDisplayMode === 'photo'
                            ? 'bg-amber-500/10 border-amber-500 text-white'
                            : 'bg-stone-900 border-stone-700 text-stone-400 hover:border-stone-600 hover:text-stone-300'
                        }`}
                      >
                        <div className="font-bold text-xs text-white flex items-center justify-between">
                          <span>Rich Image Cards</span>
                          {menuDisplayMode === 'photo' && (
                            <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-bold">Default</span>
                          )}
                        </div>
                        <p className="text-[11px] text-stone-400 mt-0.5">Vibrant dish photos, badges & card design.</p>
                      </button>

                      <button
                        type="button"
                        onClick={() => setMenuDisplayMode('text')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          menuDisplayMode === 'text'
                            ? 'bg-amber-500/10 border-amber-500 text-white'
                            : 'bg-stone-900 border-stone-700 text-stone-400 hover:border-stone-600 hover:text-stone-300'
                        }`}
                      >
                        <div className="font-bold text-xs text-white flex items-center justify-between">
                          <span>Text-Only Clean List</span>
                          {menuDisplayMode === 'text' && (
                            <span className="text-[9px] bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded font-bold">Minimal</span>
                          )}
                        </div>
                        <p className="text-[11px] text-stone-400 mt-0.5">Clean text list, ultra-fast & zero image clutter.</p>
                      </button>
                    </div>
                  </div>

                  {/* Owner Email */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-stone-300 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-stone-400" />
                      <span>Owner Email Address <span className="text-amber-400">*</span></span>
                    </label>
                    <input
                      type="email"
                      required
                      value={ownerEmail}
                      onChange={(e) => setOwnerEmail(e.target.value)}
                      placeholder="owner@restaurant.com"
                      className="w-full px-3.5 py-2.5 bg-stone-800/90 border border-stone-700 rounded-xl text-sm text-white placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                    />
                  </div>

                  {/* WhatsApp Number or Group Link */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-stone-300 flex items-center gap-1.5">
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                      <span>WhatsApp Number or Group Link <span className="text-emerald-400">*</span></span>
                    </label>
                    <input
                      type="text"
                      required
                      value={whatsappDestination}
                      onChange={(e) => setWhatsappDestination(e.target.value)}
                      placeholder="+91 98450 12345 or https://chat.whatsapp.com/..."
                      className="w-full px-3.5 py-2.5 bg-stone-800/90 border border-stone-700 rounded-xl text-sm text-white placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-mono"
                    />
                    <p className="text-[10px] text-stone-400">
                      Supports direct phone numbers (e.g. +91...) or WhatsApp Group invite links (chat.whatsapp.com/...)
                    </p>
                  </div>

                  {/* City */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-stone-300 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-stone-400" />
                      <span>City / Town</span>
                    </label>
                    <input
                      type="text"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="e.g. Madurai, Bengaluru, Chennai"
                      className="w-full px-3.5 py-2.5 bg-stone-800/90 border border-stone-700 rounded-xl text-sm text-white placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                    />
                  </div>

                  {/* Currency Symbol */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-stone-300">
                      <span>Currency Symbol</span>
                    </label>
                    <input
                      type="text"
                      value={currencySymbol}
                      onChange={(e) => setCurrencySymbol(e.target.value)}
                      placeholder="₹"
                      className="w-full px-3.5 py-2.5 bg-stone-800/90 border border-stone-700 rounded-xl text-sm text-white placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all font-bold font-mono"
                    />
                  </div>

                  {/* Address / Landmark */}
                  <div className="space-y-1.5 sm:col-span-2">
                    <label className="text-xs font-bold text-stone-300">
                      <span>Counter Address / Landmark</span>
                    </label>
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="e.g. 14 Gandhi Road, Opposite Central Bus Stand"
                      className="w-full px-3.5 py-2.5 bg-stone-800/90 border border-stone-700 rounded-xl text-sm text-white placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                    />
                  </div>

                  {/* Tagline / Specialties */}
                  <div className="space-y-1.5 sm:col-span-2">
                    <label className="text-xs font-bold text-stone-300">
                      <span>Cuisine / Tagline</span>
                    </label>
                    <input
                      type="text"
                      value={tagline}
                      onChange={(e) => setTagline(e.target.value)}
                      placeholder="e.g. Authentic South Indian Crispy Dosas & Filter Coffee"
                      className="w-full px-3.5 py-2.5 bg-stone-800/90 border border-stone-700 rounded-xl text-sm text-white placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                    />
                  </div>
                </div>

                <div className="pt-3 flex justify-end">
                  <button
                    type="button"
                    disabled={!storeName.trim() || !ownerEmail.trim()}
                    onClick={() => setCurrentStep('menu')}
                    className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-sm shadow-md transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <span>Proceed to Menu Extraction</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* ═════════════════════════════════════════════════════════ */}
            {/* STEP 2: AUTOMATED MENU EXTRACTION (AI & PROMPTS)         */}
            {/* ═════════════════════════════════════════════════════════ */}
            {currentStep === 'menu' && (
              <div className="space-y-5">
                
                {/* Method Selector Tabs */}
                <div className="flex rounded-xl bg-stone-950 p-1 border border-stone-800 text-xs font-bold">
                  <button
                    type="button"
                    onClick={() => setMenuInputMode('upload')}
                    className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      menuInputMode === 'upload' ? 'bg-amber-500 text-stone-950 shadow-xs' : 'text-stone-400 hover:text-white'
                    }`}
                  >
                    <ImageIcon className="w-4 h-4" />
                    <span>Upload Menu Photos</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setMenuInputMode('text')}
                    className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      menuInputMode === 'text' ? 'bg-amber-500 text-stone-950 shadow-xs' : 'text-stone-400 hover:text-white'
                    }`}
                  >
                    <FileText className="w-4 h-4" />
                    <span>Paste / Type Menu Text</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setMenuInputMode('preset')}
                    className={`flex-1 py-2 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      menuInputMode === 'preset' ? 'bg-amber-500 text-stone-950 shadow-xs' : 'text-stone-400 hover:text-white'
                    }`}
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Instant Starter Menus</span>
                  </button>
                </div>

                {/* Sub-view: Photo Upload */}
                {menuInputMode === 'upload' && (
                  <div className="space-y-3">
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-stone-700 hover:border-amber-500/80 rounded-2xl p-6 text-center cursor-pointer bg-stone-950/40 hover:bg-stone-800/30 transition-all group"
                    >
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*,application/pdf,.pdf"
                        multiple
                        className="hidden"
                        onChange={handlePhotoUpload}
                      />
                      <div className="w-12 h-12 rounded-2xl bg-amber-500/10 group-hover:bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-3 transition-colors">
                        <Upload className="w-6 h-6" />
                      </div>
                      <p className="text-sm font-bold text-white">Click or Drag & Drop Menu Photos or PDFs</p>
                      <p className="text-xs text-stone-400 mt-1">
                        Upload photos or PDF menus (JPG, PNG, PDF). Gemini Vision will parse all categories & prices.
                      </p>
                    </div>

                    {uploadedImages.length > 0 && (
                      <div className="flex flex-wrap gap-2 pt-1">
                        {uploadedImages.map((img, i) => (
                          <div key={i} className="flex items-center gap-2 bg-stone-800 px-3 py-1.5 rounded-xl border border-stone-700 text-xs">
                            <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
                            <span className="truncate max-w-[140px] text-stone-200">{img.name}</span>
                            <button
                              type="button"
                              onClick={() => setUploadedImages(prev => prev.filter((_, idx) => idx !== i))}
                              className="text-stone-400 hover:text-rose-400"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Sub-view: Paste Text / Upload Document */}
                {menuInputMode === 'text' && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-stone-300">
                        Paste Raw Menu Text or Dish Names with Prices:
                      </label>
                      <button
                        type="button"
                        onClick={() => docInputRef.current?.click()}
                        className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 cursor-pointer"
                      >
                        <Upload className="w-3 h-3" />
                        <span>Upload .txt or .csv file</span>
                      </button>
                      <input
                        ref={docInputRef}
                        type="file"
                        accept=".txt,.csv,.md"
                        className="hidden"
                        onChange={handleDocUpload}
                      />
                    </div>
                    <textarea
                      rows={6}
                      value={rawMenuText}
                      onChange={(e) => setRawMenuText(e.target.value)}
                      placeholder={`[Breakfast & Tiffin]
Masala Dosa - 70
Idli (2 pcs) - 35
Medu Vada - 30
Filter Coffee - 25

[Beverages]
Masala Chai - 20
Sweet Lassi - 40`}
                      className="w-full px-3.5 py-2.5 bg-stone-950 border border-stone-700 rounded-xl text-xs text-white placeholder-stone-600 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono leading-relaxed"
                    />
                  </div>
                )}

                {/* Sub-view: Preset Templates */}
                {menuInputMode === 'preset' && (
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {Object.entries(PRESET_SAMPLE_MENUS).map(([key, p]) => (
                      <button
                        key={key}
                        type="button"
                        onClick={() => handleLoadPreset(key as any)}
                        className="p-3.5 rounded-xl bg-stone-950/80 hover:bg-stone-800/80 border border-stone-800 hover:border-amber-500/50 text-left transition-all cursor-pointer group"
                      >
                        <div className="flex items-center gap-2 font-bold text-white text-xs group-hover:text-amber-300">
                          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                          <span>{p.name}</span>
                        </div>
                        <p className="text-[11px] text-stone-400 mt-1 line-clamp-2 font-mono">
                          {p.text.split('\n').slice(0, 3).join(', ')}
                        </p>
                        <span className="inline-block mt-2 text-[10px] text-amber-400 font-bold underline">
                          Load This Menu
                        </span>
                      </button>
                    ))}
                  </div>
                )}

                {/* AI Prompt Transparency Drawer */}
                <div className="bg-stone-950/60 rounded-xl border border-stone-800/80 overflow-hidden text-xs">
                  <button
                    type="button"
                    onClick={() => setShowPromptDetails(!showPromptDetails)}
                    className="w-full px-3.5 py-2 flex items-center justify-between text-stone-400 hover:text-white transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-1.5 font-mono text-[11px]">
                      <Sparkles className="w-3 h-3 text-amber-400" />
                      <span>AI Prompt Structure & Extraction Logic (Gemini 3.8 Flash)</span>
                    </span>
                    {showPromptDetails ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  {showPromptDetails && (
                    <div className="p-3.5 pt-1 text-[11px] text-stone-300 space-y-1.5 border-t border-stone-800/50 font-mono bg-stone-900/40">
                      <p className="text-amber-300 font-bold">Extraction Prompt Instructions:</p>
                      <p>• Scans menu titles, section headers, prices (handles ₹, $, numbers, dot-leaders).</p>
                      <p>• Detects dietary labels (Veg, Non-Veg, Egg) via culinary keywords and icons.</p>
                      <p>• Organizes into structured JSON: categoryName, name, price, description, isVeg.</p>
                      <p>• Automatic offline fallback if server or internet is unavailable.</p>
                    </div>
                  )}
                </div>

                {/* Extraction Run Trigger Button */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <button
                    type="button"
                    disabled={isExtracting || (menuInputMode === 'upload' && uploadedImages.length === 0 && !rawMenuText.trim())}
                    onClick={handleRunExtraction}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs shadow-sm transition-all cursor-pointer disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isExtracting ? 'animate-spin' : ''}`} />
                    <span>{isExtracting ? 'Extracting Menu with AI...' : 'Run Automated AI Extraction'}</span>
                  </button>

                  {extractedItems.length > 0 && (
                    <button
                      type="button"
                      onClick={handleAddNewItem}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-200 text-xs font-bold border border-stone-700 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5 text-amber-400" />
                      <span>Add Dish Manually</span>
                    </button>
                  )}
                </div>

                {/* Extraction Error Notice */}
                {extractionError && (
                  <div className="p-3 bg-rose-950/40 border border-rose-500/40 rounded-xl text-rose-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{extractionError}</span>
                  </div>
                )}

                {/* Extraction Success Note */}
                {extractionNote && (
                  <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{extractionNote}</span>
                  </div>
                )}

                {/* ═════════════════════════════════════════════════════ */}
                {/* EDITABLE GENERATED ITEMS GRID                          */}
                {/* ═════════════════════════════════════════════════════ */}
                {extractedItems.length > 0 && (
                  <div className="space-y-3 pt-2">
                    <div className="flex items-center justify-between border-b border-stone-800 pb-2">
                      <span className="text-xs font-black uppercase tracking-wider text-amber-400">
                        Generated Items ({extractedItems.length} Dishes)
                      </span>
                      <span className="text-[11px] text-stone-400">
                        Review & edit prices before publishing
                      </span>
                    </div>

                    <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                      {extractedItems.map((item, idx) => (
                        <div 
                          key={item.tempId || idx}
                          className="p-3 bg-stone-950/80 rounded-xl border border-stone-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs hover:border-stone-700 transition"
                        >
                          <div className="flex items-center gap-2.5 flex-1 min-w-0">
                            {/* Veg / Non-Veg Toggle Badge */}
                            <button
                              type="button"
                              title="Click to toggle Veg / Non-Veg"
                              onClick={() => handleUpdateItem(idx, { isVeg: item.isVeg === 'veg' ? 'non-veg' : 'veg' })}
                              className={`w-4 h-4 rounded-sm border flex items-center justify-center shrink-0 cursor-pointer ${
                                item.isVeg === 'veg' ? 'border-emerald-500' : 'border-rose-500'
                              }`}
                            >
                              <div className={`w-2 h-2 rounded-full ${
                                item.isVeg === 'veg' ? 'bg-emerald-500' : 'bg-rose-500'
                              }`} />
                            </button>

                            <div className="flex-1 min-w-0">
                              <input
                                type="text"
                                value={item.name}
                                onChange={(e) => handleUpdateItem(idx, { name: e.target.value })}
                                className="w-full font-bold text-white bg-transparent border-b border-transparent focus:border-amber-500 focus:outline-none"
                              />
                              <input
                                type="text"
                                value={item.description || ''}
                                placeholder="Description (optional)"
                                onChange={(e) => handleUpdateItem(idx, { description: e.target.value })}
                                className="w-full text-[11px] text-stone-400 bg-transparent border-b border-transparent focus:border-stone-600 focus:outline-none"
                              />
                            </div>
                          </div>

                          <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                            {/* Category Tag */}
                            <input
                              type="text"
                              value={item.categoryName}
                              onChange={(e) => handleUpdateItem(idx, { categoryName: e.target.value })}
                              className="w-24 px-2 py-1 rounded-lg bg-stone-900 border border-stone-700 text-[10px] text-stone-300 font-mono text-center"
                            />

                            {/* Price */}
                            <div className="flex items-center gap-1 bg-stone-900 border border-stone-700 px-2 py-1 rounded-lg">
                              <span className="text-stone-400 font-bold">{currencySymbol}</span>
                              <input
                                type="number"
                                value={item.price ?? 50}
                                onChange={(e) => handleUpdateItem(idx, { price: parseFloat(e.target.value) || 0 })}
                                className="w-14 font-mono font-bold text-white text-right bg-transparent focus:outline-none"
                              />
                            </div>

                            {/* Delete */}
                            <button
                              type="button"
                              onClick={() => handleDeleteItem(idx)}
                              className="p-1 text-stone-500 hover:text-rose-400 cursor-pointer"
                              title="Delete Item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Actions Bottom Bar */}
                <div className="pt-4 border-t border-stone-800 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setCurrentStep('details')}
                    className="inline-flex items-center gap-1.5 text-xs text-stone-400 hover:text-white cursor-pointer font-bold"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back to Details</span>
                  </button>

                  <button
                    type="button"
                    disabled={isSaving || (extractedItems.length === 0 && !rawMenuText.trim())}
                    onClick={handleFinalSubmit}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-md transition-all cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>{isSaving ? 'Publishing Restaurant & Menu...' : 'Launch Restaurant & Generate Counter QR'}</span>
                  </button>
                </div>
              </div>
            )}

            {/* ═════════════════════════════════════════════════════════ */}
            {/* STEP 3: UNIQUE COUNTER QR CODE & LAUNCH SUCCESS           */}
            {/* ═════════════════════════════════════════════════════════ */}
            {currentStep === 'success' && createdBusiness && (
              <div className="space-y-6 text-center">
                
                {/* Success Banner */}
                <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 mb-1 border border-emerald-500/30">
                  <CheckCircle2 className="w-8 h-8" />
                </div>

                <div>
                  <h3 className="text-xl font-black text-white">
                    {createdBusiness.name} is Live!
                  </h3>
                  <p className="text-xs text-stone-400 mt-1">
                    Your digital parcel menu has been generated. Scan the counter QR code to place orders directly to your WhatsApp group.
                  </p>
                </div>

                {/* Printable Acrylic Counter Standee Preview Card */}
                <div 
                  id="printable-counter-standee"
                  className="max-w-sm mx-auto bg-white text-stone-950 p-6 rounded-3xl shadow-2xl border-4 border-stone-900 text-center space-y-4"
                >
                  <div className="space-y-1">
                    <div className="inline-block px-2.5 py-0.5 rounded-full bg-stone-900 text-white text-[10px] font-black tracking-wider uppercase">
                      Counter Pickup Standee
                    </div>
                    <h4 className="text-lg font-black text-stone-900 uppercase tracking-tight">
                      {createdBusiness.name}
                    </h4>
                    <p className="text-[11px] text-stone-500 font-medium">
                      {createdBusiness.city} • Fresh Counter Parcels
                    </p>
                  </div>

                  {/* QR Code SVG */}
                  <div className="p-3 bg-stone-50 rounded-2xl border-2 border-stone-200 inline-block shadow-inner">
                    <QRCodeSVG
                      value={counterQrUrl}
                      size={180}
                      level="H"
                      includeMargin={false}
                    />
                  </div>

                  <div className="space-y-1">
                    <p className="text-xs font-black text-stone-900 flex items-center justify-center gap-1.5">
                      <Store className="w-3.5 h-3.5 text-emerald-600" />
                      <span>SCAN TO VIEW MENU & ORDER</span>
                    </p>
                    <p className="text-[10px] text-stone-500">
                      Direct WhatsApp Kitchen Dispatch • No App Required
                    </p>
                  </div>

                  <div className="pt-2 border-t border-stone-200 text-[10px] font-mono text-stone-600">
                    Routing: <span className="font-bold">{createdBusiness.whatsappGroupUrl || createdBusiness.whatsappNumber}</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md mx-auto pt-2">
                  <button
                    type="button"
                    onClick={handlePrint}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-750 text-white text-xs font-bold border border-stone-700 transition cursor-pointer shadow-xs"
                  >
                    <Printer className="w-4 h-4 text-amber-400" />
                    <span>Print Counter Standee</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-750 text-white text-xs font-bold border border-stone-700 transition cursor-pointer shadow-xs"
                  >
                    <Copy className="w-4 h-4 text-amber-400" />
                    <span>{copiedLink ? 'Copied Link!' : 'Copy Menu URL'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setTestKOTPreviewOpen(!testKOTPreviewOpen)}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-200 text-xs font-bold border border-stone-700 transition cursor-pointer sm:col-span-2"
                  >
                    <MessageSquare className="w-4 h-4 text-emerald-400" />
                    <span>{testKOTPreviewOpen ? 'Hide WhatsApp KOT Preview' : 'Preview WhatsApp KOT Ticket'}</span>
                  </button>
                </div>

                {/* Sample KOT Message Preview */}
                {testKOTPreviewOpen && (
                  <div className="max-w-md mx-auto p-3.5 bg-stone-950 rounded-2xl border border-stone-800 text-left font-mono text-xs text-stone-300 whitespace-pre-wrap leading-relaxed shadow-inner">
                    {generateKotMessage(
                      createdBusiness.name,
                      [
                        {
                          item: { name: extractedItems[0]?.name || 'Special Dosa', price: extractedItems[0]?.price || 70, isVeg: 'veg' },
                          quantity: 2,
                          unitPrice: extractedItems[0]?.price || 70,
                          totalItemPrice: (extractedItems[0]?.price || 70) * 2
                        }
                      ],
                      {
                        tableNumber: 'Parcel',
                        customerName: 'Customer Test',
                        customerPhone: '+91 98450 12345',
                        notes: 'Please pack sambar separately'
                      }
                    )}
                  </div>
                )}

                {/* Primary Launch Action */}
                <div className="pt-3">
                  <button
                    type="button"
                    onClick={() => {
                      onOnboardingComplete(createdBusiness);
                      onClose();
                    }}
                    className="w-full max-w-md mx-auto py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-700/20 cursor-pointer"
                  >
                    <span>Open My Customer Menu Now</span>
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
