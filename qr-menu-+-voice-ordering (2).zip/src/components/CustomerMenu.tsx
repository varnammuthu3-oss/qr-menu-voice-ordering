import React, { useState, useEffect, useMemo } from 'react';
import { Business, MenuCategory, MenuItem } from '../types';
import { ClassicMenuTemplate } from './templates/ClassicMenuTemplate';
import { ModernMenuTemplate } from './templates/ModernMenuTemplate';
import { MinimalMenuTemplate } from './templates/MinimalMenuTemplate';
import { VisualMenuTemplate } from './templates/VisualMenuTemplate';
import { filterCategoriesForTenant, filterItemsForTenant } from '../utils/tenant';
import { FileText, Image as ImageIcon, LayoutList } from 'lucide-react';

interface CustomerMenuProps {
  business: Business;
  categories: MenuCategory[];
  items: MenuItem[];
  onOpenOwnerDashboard?: () => void;
  tenantType?: 'restaurant' | 'guesthouse';
  initialLocationNumber?: string;
}

export const CustomerMenu: React.FC<CustomerMenuProps> = ({
  business,
  categories,
  items,
  onOpenOwnerDashboard,
  tenantType = 'restaurant',
  initialLocationNumber,
}) => {
  const style = business.menuStyle || 'classic';

  // Initialize displayMode from business.menuDisplayMode or feature flags
  const initialMode = (business.menuDisplayMode === 'photo' || business.features?.enable_visual_menu) ? 'photo' : 'text';
  const [displayMode, setDisplayMode] = useState<'text' | 'photo'>(initialMode);

  useEffect(() => {
    if (business.menuDisplayMode) {
      setDisplayMode(business.menuDisplayMode);
    }
  }, [business.menuDisplayMode]);

  // Strictly filter categories and items based on tenant mode
  const filteredCategories = useMemo(() => {
    return filterCategoriesForTenant(categories, tenantType);
  }, [categories, tenantType]);

  const filteredItems = useMemo(() => {
    return filterItemsForTenant(items, categories, tenantType);
  }, [items, categories, tenantType]);

  const renderActiveTemplate = () => {
    if (displayMode === 'photo') {
      return (
        <VisualMenuTemplate
          business={business}
          categories={filteredCategories}
          items={filteredItems}
          onOpenOwnerDashboard={onOpenOwnerDashboard}
          tenantType={tenantType}
          initialLocationNumber={initialLocationNumber}
        />
      );
    }

    if (style === 'modern') {
      return (
        <ModernMenuTemplate
          business={business}
          categories={filteredCategories}
          items={filteredItems}
          onOpenOwnerDashboard={onOpenOwnerDashboard}
          tenantType={tenantType}
          initialLocationNumber={initialLocationNumber}
        />
      );
    }

    if (style === 'minimal') {
      return (
        <MinimalMenuTemplate
          business={business}
          categories={filteredCategories}
          items={filteredItems}
          onOpenOwnerDashboard={onOpenOwnerDashboard}
          tenantType={tenantType}
          initialLocationNumber={initialLocationNumber}
        />
      );
    }

    // Default to Classic text-only menu
    return (
      <ClassicMenuTemplate
        business={business}
        categories={filteredCategories}
        items={filteredItems}
        onOpenOwnerDashboard={onOpenOwnerDashboard}
        tenantType={tenantType}
        initialLocationNumber={initialLocationNumber}
      />
    );
  };

  return (
    <div className="relative min-h-screen">
      {/* Top Floating / Sticky Vendor & Customer Menu Display Mode Switcher */}
      <div className="sticky top-0 z-40 bg-stone-950/90 backdrop-blur-md border-b border-stone-800/80 px-4 py-2 flex items-center justify-between text-xs shadow-sm">
        <div className="flex items-center gap-2">
          <LayoutList className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-semibold text-stone-300 hidden sm:inline">Display Mode:</span>
          <span className="text-[10px] text-stone-400 uppercase font-mono tracking-wider">
            {displayMode === 'text' ? 'Clean Text List' : 'Rich Image Cards'}
          </span>
        </div>

        <div className="flex items-center bg-stone-900 p-0.5 rounded-xl border border-stone-800">
          <button
            type="button"
            onClick={() => setDisplayMode('text')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              displayMode === 'text'
                ? 'bg-amber-400 text-stone-950 shadow-sm'
                : 'text-stone-400 hover:text-stone-200'
            }`}
            title="Clean text list layout"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Text Menu</span>
          </button>
          <button
            type="button"
            onClick={() => setDisplayMode('photo')}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              displayMode === 'photo'
                ? 'bg-amber-400 text-stone-950 shadow-sm'
                : 'text-stone-400 hover:text-stone-200'
            }`}
            title="Rich image cards layout"
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Photo Menu</span>
          </button>
        </div>
      </div>

      {/* Render selected template */}
      {renderActiveTemplate()}
    </div>
  );
};


