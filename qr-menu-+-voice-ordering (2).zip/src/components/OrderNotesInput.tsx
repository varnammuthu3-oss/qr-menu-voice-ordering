import React from 'react';
import { ChefHat, X, Sparkles } from 'lucide-react';

interface OrderNotesInputProps {
  value: string;
  onChange: (value: string) => void;
  isGuestHouse?: boolean;
  className?: string;
}

const QUICK_SUGGESTIONS_RESTAURANT = [
  { label: '🌶️ Extra spicy', text: 'Make it extra spicy' },
  { label: '🌿 Mild / Less spicy', text: 'Mild spicy, less chili' },
  { label: '🧅 No onions', text: 'No onions' },
  { label: '🫒 Less oil', text: 'Less oil' },
  { label: '🥣 Sauce on side', text: 'Sauce on the side' },
  { label: '🥜 Peanut allergy', text: 'Allergic to peanuts' },
  { label: '🧂 Less salt', text: 'Less salt' },
];

const QUICK_SUGGESTIONS_GUESTHOUSE = [
  { label: '🔔 Call before delivery', text: 'Please call before delivering to room' },
  { label: '🚪 Leave at door', text: 'Leave order outside the room door' },
  { label: '🥛 Extra water', text: 'Please bring extra drinking water' },
  { label: '🍴 Extra cutlery', text: 'Please include extra plates & cutlery' },
];

export const OrderNotesInput: React.FC<OrderNotesInputProps> = ({
  value,
  onChange,
  isGuestHouse = false,
  className = '',
}) => {
  const suggestions = isGuestHouse ? QUICK_SUGGESTIONS_GUESTHOUSE : QUICK_SUGGESTIONS_RESTAURANT;

  const handleToggleSuggestion = (suggestionText: string) => {
    const current = value.trim();
    if (!current) {
      onChange(suggestionText);
      return;
    }

    // If already contains the text, remove it
    const parts = current.split(',').map((p) => p.trim()).filter(Boolean);
    const existsIndex = parts.findIndex((p) => p.toLowerCase() === suggestionText.toLowerCase());

    if (existsIndex >= 0) {
      parts.splice(existsIndex, 1);
      onChange(parts.join(', '));
    } else {
      onChange([...parts, suggestionText].join(', '));
    }
  };

  const isSelected = (suggestionText: string) => {
    return value.toLowerCase().includes(suggestionText.toLowerCase());
  };

  return (
    <div className={`space-y-2 ${className}`}>
      {/* Header Label */}
      <div className="flex items-center justify-between">
        <label 
          htmlFor="cart-order-notes-textarea" 
          className="flex items-center gap-1.5 text-xs font-bold text-stone-700 select-none"
        >
          <ChefHat className="w-3.5 h-3.5 text-amber-600" />
          <span>Special Instructions / Order Note</span>
          <span className="text-[10px] text-stone-400 font-normal">(Optional)</span>
        </label>

        {value && (
          <button
            type="button"
            onClick={() => onChange('')}
            className="text-[11px] text-stone-400 hover:text-rose-600 font-medium flex items-center gap-0.5 transition-colors cursor-pointer"
          >
            <X className="w-3 h-3" />
            <span>Clear</span>
          </button>
        )}
      </div>

      {/* Main Textarea Area */}
      <div className="relative">
        <textarea
          id="cart-order-notes-textarea"
          name="orderNotes"
          rows={2}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Special Instructions (e.g., Make it extra spicy, no onions, less oil, allergic to peanuts)"
          className="w-full text-xs px-3.5 py-2.5 rounded-2xl bg-white border border-stone-200 text-stone-800 placeholder-stone-400 focus:outline-hidden focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all resize-none shadow-2xs leading-relaxed"
          maxLength={300}
        />
        {value.length > 0 && (
          <div className="absolute bottom-2 right-3 text-[10px] font-mono text-stone-400 select-none pointer-events-none">
            {value.length}/300
          </div>
        )}
      </div>

      {/* Quick Tap Suggestion Chips */}
      <div className="space-y-1">
        <div className="flex items-center gap-1 text-[10px] font-semibold text-stone-400 uppercase tracking-wider">
          <Sparkles className="w-3 h-3 text-amber-500" />
          <span>Quick preferences:</span>
        </div>
        <div className="flex flex-wrap gap-1.5 pt-0.5">
          {suggestions.map((sug) => {
            const active = isSelected(sug.text);
            return (
              <button
                key={sug.label}
                type="button"
                onClick={() => handleToggleSuggestion(sug.text)}
                className={`px-2.5 py-1 rounded-xl text-[11px] font-medium transition-all cursor-pointer select-none border ${
                  active
                    ? 'bg-amber-500/15 border-amber-500/60 text-amber-900 font-bold shadow-2xs'
                    : 'bg-stone-100 hover:bg-stone-200/80 border-stone-200/70 text-stone-600'
                }`}
              >
                {sug.label}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
