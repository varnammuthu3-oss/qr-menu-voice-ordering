import React, { useState, useEffect, useMemo } from 'react';
import { 
  Business, 
  AppStaffRole, 
  StaffRole, 
  DutySession,
  DutyRoleMetadata,
  getDutyRolesForTenant,
  GUESTHOUSE_DUTY_ROLES,
  RESTAURANT_DUTY_ROLES 
} from '../types';
import { 
  subscribeToDutySessions, 
  checkInStaffSession, 
  checkOutStaffSession, 
  computeManagerDutyOverview,
  getMyStoredDutySessionId,
  shouldPlayAlertForStaff
} from '../lib/dutySessionService';
import { alertSoundEngine } from '../utils/audioAlertEngine';
import { 
  Users, 
  UserCheck, 
  UserPlus, 
  LogOut, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  Building, 
  BedDouble, 
  UtensilsCrossed, 
  Hotel, 
  Sparkles, 
  Utensils, 
  Coffee, 
  Briefcase, 
  Dumbbell, 
  Wrench, 
  ChefHat, 
  CreditCard, 
  Bike, 
  Phone, 
  Clock, 
  Layers, 
  BellRing, 
  Volume2, 
  VolumeX, 
  RefreshCw, 
  Check, 
  ChevronRight, 
  Info, 
  Filter,
  Shield,
  Crown,
  Play,
  ArrowRight,
  Flame,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface StaffDutyRosterProps {
  business: Business;
  onOpenLiveDashboard?: () => void;
  currentStaffRole?: AppStaffRole;
  staffName?: string;
  onOpenRoleSwitcher?: () => void;
}

// Preset rosters for quick selection
const GUESTHOUSE_PRESET_STAFF = [
  { name: 'Anita Sharma', role: 'front_desk' as StaffRole, phone: '+91 98450 11001', defaultUnits: ['101', '102', '103', '104', '105', '106'], notes: 'Front Desk & Concierge' },
  { name: 'Lakshmi Devi', role: 'housekeeping' as StaffRole, phone: '+91 98450 11002', defaultUnits: ['101', '102', '103'], notes: 'Floor 1 Deep Clean & Bed Linen' },
  { name: 'Meena Kumari', role: 'housekeeping' as StaffRole, phone: '+91 98450 11009', defaultUnits: ['201', '202', '203', '204'], notes: 'Floor 2 Towels & Restocking' },
  { name: 'Ravi Kumar', role: 'room_service' as StaffRole, phone: '+91 98450 11003', defaultUnits: ['101', '102', '103', '104', '105'], notes: 'In-Room Dining Trays & Express Service' },
  { name: 'Kiran Das', role: 'coffee_bar' as StaffRole, phone: '+91 98450 11004', defaultUnits: ['101', '102', '103', '104', '105', '106', 'VIP-Lounge'], notes: 'Artisan Barista & Mocktails' },
  { name: 'Manoj Singh', role: 'bellboy' as StaffRole, phone: '+91 98450 11005', defaultUnits: ['101', '102', '103', '104', '105', '106'], notes: 'Baggage Assistance & Cabs' },
  { name: 'Sunil Verma', role: 'facilities' as StaffRole, phone: '+91 98450 11006', defaultUnits: ['Gym', 'Poolside', 'Banquet-Hall'], notes: 'Gym, Swimming Pool & Banquet' },
  { name: 'Arun Patel', role: 'maintenance' as StaffRole, phone: '+91 98450 11007', defaultUnits: ['101', '102', '103', '104', '105', '106'], notes: 'AC, Plumbing & Electrical Maintenance' },
];

const RESTAURANT_PRESET_STAFF = [
  { name: 'Chef Anbu', role: 'head_chef' as StaffRole, phone: '+91 98450 22001', defaultUnits: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'], notes: 'Kitchen Lead & Expediter' },
  { name: 'Waiter Ramesh', role: 'waiter' as StaffRole, phone: '+91 98450 11223', defaultUnits: ['01', '02', '03', '04', '05'], notes: 'Front dining section' },
  { name: 'Captain Priya', role: 'waiter' as StaffRole, phone: '+91 98450 44556', defaultUnits: ['06', '07', '08', '09', '10'], notes: 'Center dining & family booths' },
  { name: 'Waiter Suresh', role: 'waiter' as StaffRole, phone: '+91 98450 77889', defaultUnits: ['11', '12', 'VIP-1', 'VIP-2'], notes: 'VIP & Terrace tables' },
  { name: 'Sundar', role: 'cashier' as StaffRole, phone: '+91 98450 22003', defaultUnits: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'], notes: 'POS Billing & Cash Desk' },
  { name: 'Karthik', role: 'runner' as StaffRole, phone: '+91 98450 22004', defaultUnits: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'], notes: 'Hot food runner & parcel dispatch' },
];

// All possible room units for guest house
const GUESTHOUSE_UNITS = [
  '101', '102', '103', '104', '105', '106', 
  '201', '202', '203', '204', 
  'Suite-A', 'Suite-B', 'VIP-Lounge', 'Poolside', 'Gym', 'Banquet-Hall'
];

// All possible table units for restaurant
const RESTAURANT_UNITS = [
  '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', 'VIP-1', 'VIP-2', 'Garden-1', 'Terrace-A'
];

export const StaffDutyRoster: React.FC<StaffDutyRosterProps> = ({
  business,
  onOpenLiveDashboard,
  currentStaffRole = 'manager',
  staffName = 'Duty Manager',
  onOpenRoleSwitcher
}) => {
  const isGuestHouse = business.businessType === 'guesthouse' || business.id === 'green-villa-guesthouse' || business.id.includes('guesthouse') || business.id.includes('hotel');
  const availableDutyRoles = useMemo(() => getDutyRolesForTenant(isGuestHouse ? 'guesthouse' : 'restaurant'), [isGuestHouse]);
  const allAvailableUnits = useMemo(() => isGuestHouse ? GUESTHOUSE_UNITS : RESTAURANT_UNITS, [isGuestHouse]);
  const presetStaffList = isGuestHouse ? GUESTHOUSE_PRESET_STAFF : RESTAURANT_PRESET_STAFF;

  // Active duty sessions state from Firestore/Local
  const [dutySessions, setDutySessions] = useState<DutySession[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'checkin' | 'roster' | 'overview' | 'dispatch_test'>('checkin');

  // Check-In Form State
  const [selectedStaffName, setSelectedStaffName] = useState<string>('');
  const [customNameInput, setCustomNameInput] = useState<string>('');
  const [selectedRole, setSelectedRole] = useState<StaffRole>(isGuestHouse ? 'housekeeping' : 'waiter');
  const [assignedUnits, setAssignedUnits] = useState<string[]>([]);
  const [staffPhone, setStaffPhone] = useState<string>('');
  const [shiftNotes, setShiftNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [checkInSuccessMessage, setCheckInSuccessMessage] = useState<string | null>(null);

  // Quick Assign Modal for Manager Overview
  const [quickAssignTargetUnit, setQuickAssignTargetUnit] = useState<string | null>(null);
  const [quickAssignStaffName, setQuickAssignStaffName] = useState<string>('');

  // Audio Dispatch Alert Test State
  const [testAlertLocation, setTestAlertLocation] = useState<string>(isGuestHouse ? '102' : '05');
  const [testDispatchLog, setTestDispatchLog] = useState<{ time: string; text: string; didRing: boolean }[]>([]);
  const [onlyAssignedFilter, setOnlyAssignedFilter] = useState<boolean>(true);

  // My checked in session on this device
  const [mySessionId, setMySessionId] = useState<string | null>(getMyStoredDutySessionId());

  // Subscribe to real-time duty sessions
  useEffect(() => {
    setIsLoading(true);
    const unsubscribe = subscribeToDutySessions(business.id, (sessions) => {
      setDutySessions(sessions);
      setIsLoading(false);
    });
    return () => unsubscribe();
  }, [business.id]);

  // Compute manager overview
  const managerOverview = useMemo(() => {
    return computeManagerDutyOverview(dutySessions, allAvailableUnits);
  }, [dutySessions, allAvailableUnits]);

  // Find my active session if any
  const myActiveSession = useMemo(() => {
    return dutySessions.find(s => s.id === mySessionId && s.status === 'active') ||
           dutySessions.find(s => s.status === 'active' && s.staffName.toLowerCase() === staffName.toLowerCase());
  }, [dutySessions, mySessionId, staffName]);

  // Handle selecting a preset staff member
  const handleSelectPreset = (preset: typeof presetStaffList[0]) => {
    setSelectedStaffName(preset.name);
    setCustomNameInput('');
    setSelectedRole(preset.role);
    setStaffPhone(preset.phone || '');
    setShiftNotes(preset.notes || '');
    setAssignedUnits(preset.defaultUnits || []);
  };

  // Toggle unit selection in check-in form
  const toggleUnitSelection = (unit: string) => {
    setAssignedUnits(prev => 
      prev.includes(unit) ? prev.filter(u => u !== unit) : [...prev, unit]
    );
  };

  // Unit section shortcuts
  const selectAllUnits = () => setAssignedUnits([...allAvailableUnits]);
  const clearAllUnits = () => setAssignedUnits([]);
  const selectFloor1 = () => {
    const floor1 = isGuestHouse 
      ? ['101', '102', '103', '104', '105', '106']
      : ['01', '02', '03', '04', '05', '06'];
    setAssignedUnits(floor1);
  };
  const selectFloor2 = () => {
    const floor2 = isGuestHouse 
      ? ['201', '202', '203', '204']
      : ['07', '08', '09', '10', '11', '12'];
    setAssignedUnits(floor2);
  };
  const selectSuitesOrVIP = () => {
    const special = isGuestHouse 
      ? ['Suite-A', 'Suite-B', 'VIP-Lounge', 'Poolside', 'Gym', 'Banquet-Hall']
      : ['VIP-1', 'VIP-2', 'Garden-1', 'Terrace-A'];
    setAssignedUnits(special);
  };

  // 1. Submit Self-Service Check-In Flow
  const handleCheckInSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalStaffName = customNameInput.trim() || selectedStaffName.trim();
    if (!finalStaffName) {
      alert('Please select or enter a staff member name.');
      return;
    }
    if (assignedUnits.length === 0) {
      alert(`Please select at least one active ${isGuestHouse ? 'room' : 'table'} unit.`);
      return;
    }

    setIsSubmitting(true);
    try {
      const newSession = await checkInStaffSession({
        businessId: business.id,
        staffName: finalStaffName,
        role: selectedRole,
        assignedTables: assignedUnits,
        phone: staffPhone,
        notes: shiftNotes
      });

      setMySessionId(newSession.id);
      setCheckInSuccessMessage(`🎉 ${finalStaffName} successfully checked-in to Duty on ${assignedUnits.length} ${isGuestHouse ? 'rooms' : 'tables'}!`);
      
      // Auto switch to roster tab to show the active session
      setTimeout(() => {
        setCheckInSuccessMessage(null);
        setActiveTab('roster');
      }, 1500);

    } catch (err) {
      console.error('Check-In failed:', err);
      alert('Could not complete check-in. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // 3. Staff Check-Out & End Shift
  const handleCheckOut = async (sessionId: string, memberName: string) => {
    if (!window.confirm(`Are you sure you want to Check-Out ${memberName} and end their shift?`)) {
      return;
    }
    try {
      await checkOutStaffSession(business.id, sessionId);
      if (mySessionId === sessionId) {
        setMySessionId(null);
      }
    } catch (err) {
      console.error('Check-out error:', err);
      alert('Could not complete check-out.');
    }
  };

  // Quick Assign from Manager Floor View
  const handleQuickAssignSubmit = async () => {
    if (!quickAssignTargetUnit || !quickAssignStaffName.trim()) return;
    try {
      await checkInStaffSession({
        businessId: business.id,
        staffName: quickAssignStaffName.trim(),
        role: isGuestHouse ? 'housekeeping' : 'waiter',
        assignedTables: [quickAssignTargetUnit],
        notes: `Quick-assigned to ${isGuestHouse ? 'Room' : 'Table'} ${quickAssignTargetUnit}`
      });
      setQuickAssignTargetUnit(null);
      setQuickAssignStaffName('');
    } catch (e) {
      console.error(e);
    }
  };

  // 2. Role-Based Real-Time Alert Dispatch Simulator
  const triggerSimulatedDispatch = (locationNum: string, alertKind: 'food_order' | 'housekeeping' = 'food_order') => {
    const effectiveName = myActiveSession?.staffName || staffName;
    const effectiveRole = myActiveSession?.role || currentStaffRole;

    const dispatchResult = shouldPlayAlertForStaff({
      targetLocation: locationNum,
      staffRole: effectiveRole,
      myStaffName: effectiveName,
      activeDutySessions: dutySessions,
      alertType: alertKind,
      isOnlyAssignedFilterEnabled: onlyAssignedFilter
    });

    const timestamp = new Date().toLocaleTimeString();

    if (dispatchResult.shouldAlert) {
      alertSoundEngine.playChurchBell(520, 2.0);
      setTestDispatchLog(prev => [
        {
          time: timestamp,
          text: `🔔 [AUDIO ALARM RINGING ON THIS DEVICE] Incoming ${alertKind} from ${isGuestHouse ? 'Room' : 'Table'} ${locationNum}. Matched assigned duty: ${dispatchResult.reason}`,
          didRing: true
        },
        ...prev.slice(0, 7)
      ]);
    } else {
      setTestDispatchLog(prev => [
        {
          time: timestamp,
          text: `🔕 [MUTED ON THIS DEVICE] Incoming ${alertKind} from ${isGuestHouse ? 'Room' : 'Table'} ${locationNum}. ${dispatchResult.reason}`,
          didRing: false
        },
        ...prev.slice(0, 7)
      ]);
    }
  };

  // Render role icon helper
  const renderRoleIcon = (iconName: string, className = "w-4 h-4") => {
    switch (iconName) {
      case 'Hotel': return <Hotel className={className} />;
      case 'Sparkles': return <Sparkles className={className} />;
      case 'Utensils': return <Utensils className={className} />;
      case 'Coffee': return <Coffee className={className} />;
      case 'Briefcase': return <Briefcase className={className} />;
      case 'Dumbbell': return <Dumbbell className={className} />;
      case 'Wrench': return <Wrench className={className} />;
      case 'ChefHat': return <ChefHat className={className} />;
      case 'UtensilsCrossed': return <UtensilsCrossed className={className} />;
      case 'CreditCard': return <CreditCard className={className} />;
      case 'Bike': return <Bike className={className} />;
      default: return <UserCheck className={className} />;
    }
  };

  const activeSessionsList = dutySessions.filter(s => s.status === 'active');
  const completedSessionsList = dutySessions.filter(s => s.status === 'completed');

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Top Header & Tenant Identity */}
        <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-bold text-white shadow-lg ${
              isGuestHouse ? 'bg-gradient-to-br from-emerald-600 to-teal-800' : 'bg-gradient-to-br from-amber-600 to-orange-800'
            }`}>
              {isGuestHouse ? <Hotel className="w-7 h-7" /> : <UtensilsCrossed className="w-7 h-7" />}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-black text-white">{business.name}</h1>
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                  isGuestHouse ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}>
                  {isGuestHouse ? '🏨 Guest House & Hotel Duty Roster' : '🍽️ Kitchen & Table Floor Duty Roster'}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-stone-400 mt-1">
                Self-Service Staff Check-In & Check-Out • Real-Time Room Alert Dispatch • Manager Floor Overview
              </p>
            </div>
          </div>

          {/* Quick Actions & Live Console Button */}
          <div className="flex items-center gap-2 flex-wrap">
            {onOpenLiveDashboard && (
              <button
                type="button"
                onClick={onOpenLiveDashboard}
                className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg transition-all cursor-pointer"
              >
                <Flame className="w-4 h-4" />
                <span>Live Order Console</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}

            {onOpenRoleSwitcher && (
              <button
                type="button"
                onClick={onOpenRoleSwitcher}
                className="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-2xl text-xs font-bold border border-stone-700 transition-colors cursor-pointer"
              >
                <span>Switch Persona ({staffName})</span>
              </button>
            )}
          </div>
        </div>

        {/* My Active Duty Badge (if checked-in on this device) */}
        {myActiveSession && (
          <div className="p-4 bg-emerald-950/40 border-2 border-emerald-500/50 rounded-3xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg backdrop-blur-sm">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500 text-stone-950 flex items-center justify-center font-black animate-pulse">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-black text-emerald-300 text-sm sm:text-base">
                    Active On Duty: {myActiveSession.staffName}
                  </span>
                  <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-md text-xs font-bold uppercase">
                    {myActiveSession.role.replace('_', ' ')}
                  </span>
                </div>
                <p className="text-xs text-stone-300 mt-0.5">
                  Assigned {isGuestHouse ? 'Rooms' : 'Tables'}: <strong className="text-white">{myActiveSession.assignedTables.join(', ')}</strong> • Shift started at {new Date(myActiveSession.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center">
              <button
                type="button"
                onClick={() => handleCheckOut(myActiveSession.id, myActiveSession.staffName)}
                className="px-3.5 py-2 bg-rose-600/90 hover:bg-rose-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Check-Out / End My Shift</span>
              </button>
            </div>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-stone-800 pb-3 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('checkin')}
            className={`px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'checkin'
                ? 'bg-amber-500 text-stone-950 shadow-md font-black'
                : 'bg-stone-900 text-stone-400 hover:text-white border border-stone-800'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            <span>1. Staff Check-In Flow</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('roster')}
            className={`px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'roster'
                ? 'bg-amber-500 text-stone-950 shadow-md font-black'
                : 'bg-stone-900 text-stone-400 hover:text-white border border-stone-800'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>2. Today's Staff Roster ({activeSessionsList.length} Active)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'overview'
                ? 'bg-amber-500 text-stone-950 shadow-md font-black'
                : 'bg-stone-900 text-stone-400 hover:text-white border border-stone-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>3. Manager Overview & Unassigned Areas</span>
            {managerOverview.unassignedUnits.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('dispatch_test')}
            className={`px-4 py-2.5 rounded-2xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'dispatch_test'
                ? 'bg-amber-500 text-stone-950 shadow-md font-black'
                : 'bg-stone-900 text-stone-400 hover:text-white border border-stone-800'
            }`}
          >
            <BellRing className="w-4 h-4" />
            <span>4. Alert Dispatch Simulator</span>
          </button>
        </div>

        {/* TAB 1: SELF-SERVICE STAFF CHECK-IN FLOW */}
        {activeTab === 'checkin' && (
          <div className="space-y-6">
            {checkInSuccessMessage && (
              <div className="p-4 bg-emerald-500/20 border border-emerald-500 text-emerald-200 rounded-3xl flex items-center gap-3 animate-bounce shadow-xl">
                <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                <span className="font-bold text-sm sm:text-base">{checkInSuccessMessage}</span>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Column: Staff Check-in Form */}
              <div className="lg:col-span-8 bg-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-7 shadow-xl space-y-6">
                <div>
                  <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                    <UserPlus className="w-5 h-5 text-amber-400" />
                    Self-Service Staff Duty Check-In
                  </h2>
                  <p className="text-xs sm:text-sm text-stone-400 mt-1">
                    Select your name, choose your operational duty role, pick your active {isGuestHouse ? 'rooms' : 'tables'}, and tap <strong>Check-In to Duty</strong>.
                  </p>
                </div>

                <form onSubmit={handleCheckInSubmit} className="space-y-6">
                  
                  {/* Step 1: Select Staff Member */}
                  <div className="space-y-3">
                    <label className="text-xs font-bold uppercase tracking-wider text-stone-300 flex items-center justify-between">
                      <span>Step 1: Select Staff Member Name</span>
                      <span className="text-amber-400 font-normal">Required</span>
                    </label>

                    {/* Fast Presets */}
                    <div className="flex flex-wrap gap-2">
                      {presetStaffList.map((preset) => {
                        const isSelected = selectedStaffName === preset.name && !customNameInput;
                        return (
                          <button
                            key={preset.name}
                            type="button"
                            onClick={() => handleSelectPreset(preset)}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                              isSelected
                                ? 'bg-amber-500 text-stone-950 shadow-md ring-2 ring-amber-400'
                                : 'bg-stone-800 text-stone-300 hover:bg-stone-750 hover:text-white border border-stone-700'
                            }`}
                          >
                            <span>{preset.name}</span>
                            {isSelected && <Check className="w-3 h-3" />}
                          </button>
                        );
                      })}
                    </div>

                    {/* Or Custom Name input */}
                    <div className="mt-2">
                      <input
                        type="text"
                        placeholder="Or enter staff member name..."
                        value={customNameInput}
                        onChange={(e) => {
                          setCustomNameInput(e.target.value);
                          if (e.target.value) setSelectedStaffName('');
                        }}
                        className="w-full px-4 py-2.5 bg-stone-950 border border-stone-800 rounded-2xl text-white text-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* Step 2: Select Operational Role */}
                  <div className="space-y-3">
                    <label className="text-xs font-bold uppercase tracking-wider text-stone-300">
                      Step 2: Operational Duty Role
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {availableDutyRoles.map((r) => {
                        const isSelected = selectedRole === r.id;
                        return (
                          <div
                            key={r.id}
                            onClick={() => setSelectedRole(r.id)}
                            className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${
                              isSelected
                                ? 'bg-amber-500/15 border-amber-500 text-white shadow-md'
                                : 'bg-stone-950/60 border-stone-800 hover:border-stone-700 text-stone-300'
                            }`}
                          >
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                              isSelected ? 'bg-amber-500 text-stone-950' : 'bg-stone-800 text-stone-400'
                            }`}>
                              {renderRoleIcon(r.iconName, "w-4 h-4")}
                            </div>
                            <div className="min-w-0">
                              <div className="text-xs sm:text-sm font-bold text-white flex items-center justify-between">
                                <span>{r.label}</span>
                                {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                              </div>
                              <p className="text-[11px] text-stone-400 line-clamp-1 mt-0.5">{r.subtitle}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Step 3: Active Rooms / Tables Multi-Select */}
                  <div className="space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-stone-300">
                        Step 3: Assign Active {isGuestHouse ? 'Rooms & Units' : 'Tables & Booths'} ({assignedUnits.length} Selected)
                      </label>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={selectFloor1}
                          className="px-2.5 py-1 bg-stone-800 hover:bg-stone-700 text-[11px] font-bold text-stone-300 rounded-lg"
                        >
                          {isGuestHouse ? 'Floor 1 (101-106)' : 'Tables 1-6'}
                        </button>
                        <button
                          type="button"
                          onClick={selectFloor2}
                          className="px-2.5 py-1 bg-stone-800 hover:bg-stone-700 text-[11px] font-bold text-stone-300 rounded-lg"
                        >
                          {isGuestHouse ? 'Floor 2 (201-204)' : 'Tables 7-12'}
                        </button>
                        <button
                          type="button"
                          onClick={selectSuitesOrVIP}
                          className="px-2.5 py-1 bg-stone-800 hover:bg-stone-700 text-[11px] font-bold text-stone-300 rounded-lg"
                        >
                          {isGuestHouse ? 'Suites & VIP' : 'VIP & Terrace'}
                        </button>
                        <button
                          type="button"
                          onClick={selectAllUnits}
                          className="px-2.5 py-1 bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 text-[11px] font-bold rounded-lg"
                        >
                          Select All
                        </button>
                        <button
                          type="button"
                          onClick={clearAllUnits}
                          className="px-2 py-1 bg-stone-800 hover:bg-stone-700 text-[11px] font-bold text-rose-400 rounded-lg"
                        >
                          Clear
                        </button>
                      </div>
                    </div>

                    {/* Unit Grid */}
                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 pt-1">
                      {allAvailableUnits.map((unit) => {
                        const isSelected = assignedUnits.includes(unit);
                        // Check if another staff is already active on this unit
                        const activeDutyOnUnit = dutySessions.find(s => s.status === 'active' && s.assignedTables.includes(unit));
                        
                        return (
                          <button
                            key={unit}
                            type="button"
                            onClick={() => toggleUnitSelection(unit)}
                            className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center ${
                              isSelected
                                ? 'bg-amber-500 border-amber-400 text-stone-950 font-black shadow-md scale-102'
                                : activeDutyOnUnit
                                ? 'bg-emerald-950/30 border-emerald-800/60 text-emerald-300 hover:border-emerald-500'
                                : 'bg-stone-950 border-stone-800 text-stone-400 hover:border-stone-700'
                            }`}
                          >
                            <span className="text-xs font-black">{unit}</span>
                            <span className="text-[9px] mt-0.5 line-clamp-1">
                              {isSelected 
                                ? '✓ Selected' 
                                : activeDutyOnUnit 
                                ? `(${activeDutyOnUnit.staffName.split(' ')[0]})` 
                                : 'Unassigned'}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Step 4: Phone & Optional Notes */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold uppercase tracking-wider text-stone-300">
                        Staff Phone / WhatsApp (Optional)
                      </label>
                      <input
                        type="text"
                        placeholder="+91 98450 11002"
                        value={staffPhone}
                        onChange={(e) => setStaffPhone(e.target.value)}
                        className="w-full mt-1.5 px-4 py-2.5 bg-stone-950 border border-stone-800 rounded-2xl text-white text-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold uppercase tracking-wider text-stone-300">
                        Shift Instructions / Notes (Optional)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Morning turn-down & towel restocking"
                        value={shiftNotes}
                        onChange={(e) => setShiftNotes(e.target.value)}
                        className="w-full mt-1.5 px-4 py-2.5 bg-stone-950 border border-stone-800 rounded-2xl text-white text-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-black text-base rounded-2xl shadow-xl flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <RefreshCw className="w-5 h-5 animate-spin" />
                    ) : (
                      <CheckCircle2 className="w-5 h-5" />
                    )}
                    <span>Check-In to Duty ({assignedUnits.length} {isGuestHouse ? 'Rooms' : 'Tables'})</span>
                  </button>
                </form>
              </div>

              {/* Right Column: Quick Status & Info */}
              <div className="lg:col-span-4 space-y-6">
                
                {/* Active Shift Summary Card */}
                <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 shadow-xl space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-stone-400">Shift Coverage Summary</span>
                    <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-md text-[11px] font-bold">
                      {managerOverview.coveragePercentage}% Covered
                    </span>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-stone-300">
                      <span>Active Staff on Duty:</span>
                      <strong className="text-white">{activeSessionsList.length} Members</strong>
                    </div>
                    <div className="flex justify-between text-xs text-stone-300">
                      <span>Covered {isGuestHouse ? 'Rooms' : 'Tables'}:</span>
                      <strong className="text-emerald-400">{managerOverview.totalCoveredUnits} / {managerOverview.totalUnits}</strong>
                    </div>
                    <div className="flex justify-between text-xs text-stone-300">
                      <span>Unassigned Units:</span>
                      <strong className="text-amber-400">{managerOverview.unassignedUnits.length} Units</strong>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-stone-950 h-2.5 rounded-full overflow-hidden border border-stone-800">
                    <div 
                      className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500"
                      style={{ width: `${managerOverview.coveragePercentage}%` }}
                    />
                  </div>
                </div>

                {/* Unassigned Warning Box */}
                {managerOverview.unassignedUnits.length > 0 && (
                  <div className="bg-amber-950/30 border border-amber-500/40 rounded-3xl p-5 space-y-3">
                    <div className="flex items-center gap-2 text-amber-300">
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                      <span className="font-bold text-xs uppercase tracking-wider">Unassigned Areas Notice</span>
                    </div>
                    <p className="text-xs text-amber-200/80">
                      The following {isGuestHouse ? 'rooms' : 'tables'} have no assigned staff member. Guest calls may go unaddressed:
                    </p>
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {managerOverview.unassignedUnits.map(unit => (
                        <span key={unit} className="px-2 py-0.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg text-xs font-mono font-bold">
                          {unit}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Fast Preset Roster Quick Tap */}
                <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 space-y-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-stone-400">Pre-Registered Staff List</span>
                  <div className="space-y-2">
                    {presetStaffList.map(p => {
                      const activeSession = dutySessions.find(s => s.status === 'active' && s.staffName.toLowerCase() === p.name.toLowerCase());
                      return (
                        <div 
                          key={p.name}
                          onClick={() => handleSelectPreset(p)}
                          className="p-2.5 bg-stone-950 hover:bg-stone-850 border border-stone-800/80 rounded-2xl flex items-center justify-between cursor-pointer transition-colors"
                        >
                          <div>
                            <div className="text-xs font-bold text-white">{p.name}</div>
                            <div className="text-[10px] text-stone-400">{p.role.replace('_', ' ')}</div>
                          </div>
                          {activeSession ? (
                            <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded-md text-[10px] font-bold">
                              On Duty
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-stone-800 text-stone-400 rounded-md text-[10px]">
                              Tap to Check-In
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>

            </div>
          </div>
        )}

        {/* TAB 2: TODAY'S STAFF ROSTER & CHECK-OUT */}
        {activeTab === 'roster' && (
          <div className="space-y-6">
            <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-7 shadow-xl space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                    <Users className="w-5 h-5 text-amber-400" />
                    Today's Active Staff Roster ({activeSessionsList.length} Checked-In)
                  </h2>
                  <p className="text-xs sm:text-sm text-stone-400 mt-1">
                    Live operational sessions, assigned {isGuestHouse ? 'rooms' : 'tables'}, and shift end controls.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTab('checkin')}
                  className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-2xl text-xs font-bold flex items-center gap-1.5 shadow-md cursor-pointer self-start sm:self-auto"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Check-In New Member</span>
                </button>
              </div>

              {/* Active Duty Staff Cards Grid */}
              {activeSessionsList.length === 0 ? (
                <div className="p-8 text-center bg-stone-950 border border-stone-800 rounded-3xl space-y-3">
                  <Users className="w-10 h-10 text-stone-600 mx-auto" />
                  <div className="text-sm font-bold text-stone-300">No Staff Members Currently On Duty</div>
                  <p className="text-xs text-stone-500 max-w-md mx-auto">
                    Staff members can tap <strong>Staff Check-In Flow</strong> above to assign their operational role and active rooms.
                  </p>
                  <button
                    type="button"
                    onClick={() => setActiveTab('checkin')}
                    className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-white rounded-xl text-xs font-bold"
                  >
                    Go to Check-In Form
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {activeSessionsList.map((session) => {
                    const checkInDate = new Date(session.checkInTime);
                    const formattedTime = checkInDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    const isMySession = session.id === mySessionId;

                    return (
                      <div
                        key={session.id}
                        className={`p-5 rounded-3xl border transition-all flex flex-col justify-between space-y-4 ${
                          isMySession 
                            ? 'bg-emerald-950/20 border-emerald-500/60 shadow-lg' 
                            : 'bg-stone-950 border-stone-800 hover:border-stone-700'
                        }`}
                      >
                        <div className="space-y-3">
                          {/* Header: Name + Status badge */}
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-white text-base">{session.staffName}</span>
                                {isMySession && (
                                  <span className="px-2 py-0.5 bg-emerald-500/30 text-emerald-300 rounded text-[10px] font-bold">
                                    You
                                  </span>
                                )}
                              </div>
                              <span className="px-2 py-0.5 bg-stone-800 text-stone-300 rounded-md text-[11px] font-bold uppercase tracking-wider inline-block mt-1">
                                {session.role.replace('_', ' ')}
                              </span>
                            </div>

                            <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-full text-xs font-bold flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                              Active
                            </span>
                          </div>

                          {/* Assigned Rooms */}
                          <div className="space-y-1">
                            <span className="text-[11px] font-bold text-stone-400 uppercase">
                              Assigned {isGuestHouse ? 'Rooms' : 'Tables'} ({session.assignedTables.length})
                            </span>
                            <div className="flex flex-wrap gap-1">
                              {session.assignedTables.map(t => (
                                <span key={t} className="px-2 py-0.5 bg-stone-800 text-amber-300 rounded text-xs font-mono font-bold">
                                  {t}
                                </span>
                              ))}
                            </div>
                          </div>

                          {/* Check-In Time & Phone */}
                          <div className="space-y-1 text-xs text-stone-400 pt-1 border-t border-stone-850">
                            <div className="flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5 text-stone-500" />
                              <span>Checked in at: <strong className="text-stone-200">{formattedTime}</strong></span>
                            </div>
                            {session.phone && (
                              <div className="flex items-center gap-1.5">
                                <Phone className="w-3.5 h-3.5 text-stone-500" />
                                <span>{session.phone}</span>
                              </div>
                            )}
                            {session.notes && (
                              <p className="text-[11px] text-stone-400 italic">"{session.notes}"</p>
                            )}
                          </div>
                        </div>

                        {/* 3. Check-Out / End Shift Action Button */}
                        <button
                          type="button"
                          onClick={() => handleCheckOut(session.id, session.staffName)}
                          className="w-full py-2.5 bg-rose-500/15 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 rounded-2xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>Check-Out / End Shift</span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Completed Shifts Section */}
              {completedSessionsList.length > 0 && (
                <div className="pt-6 border-t border-stone-800 space-y-3">
                  <h3 className="text-sm font-bold text-stone-400 uppercase tracking-wider flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-stone-500" />
                    Completed Shifts Today ({completedSessionsList.length})
                  </h3>
                  <div className="divide-y divide-stone-800/60 bg-stone-950 rounded-2xl border border-stone-800/80 overflow-hidden">
                    {completedSessionsList.slice(0, 5).map(session => (
                      <div key={session.id} className="p-3.5 flex items-center justify-between gap-3 text-xs">
                        <div>
                          <div className="font-bold text-stone-300">{session.staffName}</div>
                          <div className="text-[11px] text-stone-500">
                            {session.role.replace('_', ' ')} • Rooms: {session.assignedTables.join(', ')}
                          </div>
                        </div>
                        <div className="text-right text-[11px] text-stone-500">
                          <div>In: {new Date(session.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                          {session.checkOutTime && (
                            <div>Out: {new Date(session.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

        {/* TAB 3: MANAGER OVERVIEW & UNASSIGNED ROOM AREAS */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            
            {/* Top Metric Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              
              <div className="p-5 bg-stone-900 border border-stone-800 rounded-3xl space-y-1">
                <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">Active Staff Duty</span>
                <div className="text-2xl sm:text-3xl font-black text-white">{managerOverview.totalStaffOnDuty}</div>
                <div className="text-[11px] text-emerald-400">On duty right now</div>
              </div>

              <div className="p-5 bg-stone-900 border border-stone-800 rounded-3xl space-y-1">
                <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">Covered Units</span>
                <div className="text-2xl sm:text-3xl font-black text-emerald-400">
                  {managerOverview.totalCoveredUnits} / {managerOverview.totalUnits}
                </div>
                <div className="text-[11px] text-stone-400">{managerOverview.coveragePercentage}% of floor covered</div>
              </div>

              <div className={`p-5 rounded-3xl border space-y-1 ${
                managerOverview.unassignedUnits.length > 0 
                  ? 'bg-amber-950/30 border-amber-500/40 text-amber-300' 
                  : 'bg-stone-900 border-stone-800 text-stone-300'
              }`}>
                <span className="text-xs font-bold uppercase tracking-wider">Unassigned Areas</span>
                <div className="text-2xl sm:text-3xl font-black text-amber-400">{managerOverview.unassignedUnits.length}</div>
                <div className="text-[11px] text-amber-300/80">Requires staff assignment</div>
              </div>

              <div className="p-5 bg-stone-900 border border-stone-800 rounded-3xl space-y-1">
                <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">Operational Roles</span>
                <div className="text-2xl sm:text-3xl font-black text-sky-400">
                  {Object.keys(managerOverview.roleBreakdown).length}
                </div>
                <div className="text-[11px] text-stone-400">Unique departments</div>
              </div>

            </div>

            {/* Unassigned Areas Alert Card with 1-Tap Quick Assign */}
            {managerOverview.unassignedUnits.length > 0 && (
              <div className="p-6 bg-gradient-to-br from-amber-950/40 to-stone-900 border-2 border-amber-500/50 rounded-3xl shadow-xl space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-amber-500 text-stone-950 flex items-center justify-center font-black">
                      <AlertTriangle className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-black text-base sm:text-lg text-amber-300">
                        {managerOverview.unassignedUnits.length} Unassigned {isGuestHouse ? 'Room Areas' : 'Dining Tables'} Detected
                      </h3>
                      <p className="text-xs text-amber-200/80">
                        Guest orders and housekeeping requests in these areas have no assigned duty staff.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2 pt-2">
                  {managerOverview.unassignedUnits.map((unit) => (
                    <button
                      key={unit}
                      type="button"
                      onClick={() => {
                        setQuickAssignTargetUnit(unit);
                        setQuickAssignStaffName('');
                      }}
                      className="p-3 bg-stone-950 hover:bg-amber-500/20 border border-amber-500/40 rounded-2xl text-center transition-all cursor-pointer group"
                    >
                      <div className="text-xs font-black text-amber-300">{unit}</div>
                      <div className="text-[10px] text-amber-400/80 group-hover:text-amber-200 mt-0.5">+ Quick Assign</div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Floor Map & Live Unit Grid */}
            <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-7 shadow-xl space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                    <Layers className="w-5 h-5 text-amber-400" />
                    Live {isGuestHouse ? 'Hotel Floor & Room Grid' : 'Dining Table Floor Grid'}
                  </h2>
                  <p className="text-xs sm:text-sm text-stone-400 mt-1">
                    Real-time status of all {isGuestHouse ? 'rooms' : 'tables'} with active duty staff and instant dispatch routing.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {allAvailableUnits.map((unit) => {
                  const assignedSessions = activeSessionsList.filter(s => s.assignedTables.includes(unit));
                  const isAssigned = assignedSessions.length > 0;

                  return (
                    <div
                      key={unit}
                      className={`p-4 rounded-3xl border transition-all flex flex-col justify-between space-y-2 ${
                        isAssigned
                          ? 'bg-stone-950 border-emerald-500/40 shadow-sm'
                          : 'bg-amber-950/20 border-amber-500/50 shadow-md ring-1 ring-amber-500/30'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <span className="text-sm font-black text-white">{unit}</span>
                        {isAssigned ? (
                          <span className="w-2 h-2 rounded-full bg-emerald-400" />
                        ) : (
                          <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                        )}
                      </div>

                      {isAssigned ? (
                        <div className="space-y-1">
                          <div className="text-[11px] font-bold text-emerald-400 line-clamp-1">
                            {assignedSessions.map(s => s.staffName).join(', ')}
                          </div>
                          <div className="text-[9px] text-stone-400 uppercase">
                            {assignedSessions[0].role.replace('_', ' ')}
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <div className="text-[11px] font-bold text-amber-400">Unassigned</div>
                          <button
                            type="button"
                            onClick={() => {
                              setQuickAssignTargetUnit(unit);
                              setQuickAssignStaffName('');
                            }}
                            className="text-[10px] text-stone-300 hover:text-white underline cursor-pointer"
                          >
                            Assign Staff
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Assign Modal */}
            {quickAssignTargetUnit && (
              <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
                <div className="bg-stone-900 border border-stone-700 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-lg text-white">
                      Assign Duty to {isGuestHouse ? 'Room' : 'Table'} {quickAssignTargetUnit}
                    </h3>
                    <button
                      type="button"
                      onClick={() => setQuickAssignTargetUnit(null)}
                      className="text-stone-400 hover:text-white text-sm"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="space-y-3">
                    <label className="text-xs font-bold uppercase text-stone-300">Select or Enter Staff Member Name:</label>
                    <div className="flex flex-wrap gap-1.5">
                      {presetStaffList.map(p => (
                        <button
                          key={p.name}
                          type="button"
                          onClick={() => setQuickAssignStaffName(p.name)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                            quickAssignStaffName === p.name ? 'bg-amber-500 text-stone-950' : 'bg-stone-800 text-stone-300'
                          }`}
                        >
                          {p.name}
                        </button>
                      ))}
                    </div>
                    <input
                      type="text"
                      placeholder="Or enter staff name..."
                      value={quickAssignStaffName}
                      onChange={(e) => setQuickAssignStaffName(e.target.value)}
                      className="w-full px-3.5 py-2 bg-stone-950 border border-stone-800 rounded-xl text-white text-sm"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-2">
                    <button
                      type="button"
                      onClick={handleQuickAssignSubmit}
                      disabled={!quickAssignStaffName.trim()}
                      className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold rounded-xl text-sm disabled:opacity-50"
                    >
                      Confirm Assignment
                    </button>
                    <button
                      type="button"
                      onClick={() => setQuickAssignTargetUnit(null)}
                      className="px-4 py-2.5 bg-stone-800 text-stone-300 rounded-xl text-sm font-bold"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

        {/* TAB 4: REAL-TIME ROLE-BASED ALERT DISPATCH SIMULATOR */}
        {activeTab === 'dispatch_test' && (
          <div className="space-y-6">
            <div className="bg-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-7 shadow-xl space-y-6">
              <div>
                <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                  <BellRing className="w-5 h-5 text-amber-400" />
                  Role-Based Real-Time Alert Dispatch Tester
                </h2>
                <p className="text-xs sm:text-sm text-stone-400 mt-1">
                  Demonstrates how guest QR orders and housekeeping calls are filtered so notifications ring <strong>only</strong> on the device of the staff member assigned to that specific room/table.
                </p>
              </div>

              {/* Current Device Duty Context */}
              <div className="p-4 bg-stone-950 border border-stone-800 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="text-xs font-bold text-stone-400 uppercase">This Device Persona</div>
                  <div className="text-sm font-black text-white mt-0.5">
                    {myActiveSession ? `${myActiveSession.staffName} (${myActiveSession.role})` : `${staffName} (${currentStaffRole})`}
                  </div>
                  <div className="text-xs text-amber-300 mt-0.5">
                    Assigned Units: <strong>{myActiveSession ? myActiveSession.assignedTables.join(', ') : 'All (Global Manager Mode)'}</strong>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <label className="text-xs font-bold text-stone-300 flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={onlyAssignedFilter}
                      onChange={(e) => setOnlyAssignedFilter(e.target.checked)}
                      className="w-4 h-4 rounded text-amber-500 accent-amber-500"
                    />
                    <span>Filter: Only ring for my assigned rooms/tables</span>
                  </label>
                </div>
              </div>

              {/* Simulation Triggers */}
              <div className="space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-stone-300">
                  Simulate Guest Order / Housekeeping Call:
                </span>

                <div className="flex flex-wrap gap-2">
                  {allAvailableUnits.slice(0, 8).map(unit => (
                    <button
                      key={unit}
                      type="button"
                      onClick={() => triggerSimulatedDispatch(unit, 'food_order')}
                      className="px-3 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white rounded-xl text-xs font-bold border border-stone-700 transition-colors flex items-center gap-1.5"
                    >
                      <Utensils className="w-3.5 h-3.5 text-amber-400" />
                      <span>{isGuestHouse ? 'Room' : 'Table'} {unit} (Order)</span>
                    </button>
                  ))}

                  {isGuestHouse && (
                    <button
                      type="button"
                      onClick={() => triggerSimulatedDispatch('102', 'housekeeping')}
                      className="px-3.5 py-2 bg-emerald-600/30 hover:bg-emerald-600 text-emerald-200 hover:text-white rounded-xl text-xs font-bold border border-emerald-500/40 transition-colors flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Room 102 (Housekeeping Call)</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Live Dispatch Log */}
              <div className="space-y-3 pt-2">
                <span className="text-xs font-bold uppercase tracking-wider text-stone-400">Live Device Dispatch Log:</span>
                {testDispatchLog.length === 0 ? (
                  <div className="p-4 bg-stone-950 border border-stone-800 rounded-2xl text-xs text-stone-500 text-center">
                    Tap any simulation button above to test alert filtering on this device.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {testDispatchLog.map((entry, idx) => (
                      <div
                        key={idx}
                        className={`p-3 rounded-xl border text-xs font-mono flex items-start gap-2 ${
                          entry.didRing
                            ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300 font-bold'
                            : 'bg-stone-950 border-stone-800 text-stone-400'
                        }`}
                      >
                        <span className="text-stone-500 shrink-0">[{entry.time}]</span>
                        <span>{entry.text}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
