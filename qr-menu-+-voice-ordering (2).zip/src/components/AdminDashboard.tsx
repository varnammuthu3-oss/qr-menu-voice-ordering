import React, { useState, useMemo, useEffect } from 'react';
import { 
  LayoutDashboard, 
  BarChart3, 
  Users, 
  ShoppingBag, 
  FileText, 
  Settings, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  UserPlus, 
  CreditCard, 
  Percent, 
  Search, 
  Bell, 
  Download, 
  Plus, 
  Send, 
  Filter, 
  ChevronLeft, 
  ChevronRight, 
  MoreVertical, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  AlertCircle, 
  ArrowUpRight, 
  RefreshCw, 
  Calendar, 
  Menu as MenuIcon,
  X,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  Layers,
  Hotel,
  Coffee,
  Briefcase,
  Dumbbell,
  Wrench,
  ChefHat,
  Bike,
  Utensils,
  UtensilsCrossed,
  UserCheck,
  Check,
  Trash2,
  Phone,
  BedDouble,
  BellRing
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend 
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Business, 
  StaffAllocation, 
  StaffRole, 
  getDutyRolesForTenant,
  DutyRoleMetadata 
} from '../types';
import { 
  fetchStaffAllocations, 
  saveStaffAllocation, 
  deleteStaffAllocation, 
  formatStaffDutyAlert 
} from '../lib/staffAllocationService';

// ----------------------------------------------------------------------
// Types & Interfaces
// ----------------------------------------------------------------------
export type AdminNavTab = 'dashboard' | 'analytics' | 'users' | 'orders' | 'content' | 'settings';

export type TransactionStatus = 'Completed' | 'Pending' | 'Failed' | 'Refunded';

export interface Transaction {
  id: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  avatarUrl?: string;
  date: string;
  time: string;
  amount: number;
  currency: string;
  paymentMethod: 'Credit Card' | 'UPI / QR' | 'Cash' | 'Apple Pay';
  status: TransactionStatus;
  tableOrRoom?: string;
}

export interface KpiMetric {
  id: string;
  title: string;
  value: string;
  numericValue: number;
  change: string;
  isPositive: boolean;
  period: string;
  icon: React.ComponentType<{ className?: string }>;
  accentColor: string;
  chartColor: string;
}

// ----------------------------------------------------------------------
// Sample Analytical Dataset
// ----------------------------------------------------------------------
const REVENUE_TIMELINE_DATA = [
  { name: 'Mon', revenue: 4200, orders: 120, target: 4000 },
  { name: 'Tue', revenue: 5800, orders: 145, target: 4200 },
  { name: 'Wed', revenue: 5100, orders: 130, target: 4500 },
  { name: 'Thu', revenue: 7400, orders: 180, target: 5000 },
  { name: 'Fri', revenue: 9800, orders: 240, target: 6000 },
  { name: 'Sat', revenue: 12400, orders: 310, target: 7500 },
  { name: 'Sun', revenue: 11200, orders: 290, target: 7000 },
];

const CATEGORY_SALES_DATA = [
  { name: 'South Indian Specials', value: 42, color: '#f59e0b' },
  { name: 'Hot Beverages & Tea', value: 24, color: '#38bdf8' },
  { name: 'Tandoor & Starters', value: 20, color: '#10b981' },
  { name: 'Desserts & Combos', value: 14, color: '#a855f7' },
];

const PEAK_HOURS_DATA = [
  { hour: '08:00', morning: 65, evening: 10 },
  { hour: '10:00', morning: 95, evening: 20 },
  { hour: '12:00', morning: 140, evening: 45 },
  { hour: '14:00', morning: 110, evening: 35 },
  { hour: '18:00', morning: 30, evening: 125 },
  { hour: '20:00', morning: 15, evening: 195 },
  { hour: '22:00', morning: 5, evening: 110 },
];

const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-001',
    orderNumber: '#ORD-8942',
    customerName: 'Aarav Sharma',
    customerEmail: 'aarav.sharma@example.com',
    date: 'Today, 24 Oct',
    time: '14:23 PM',
    amount: 34.50,
    currency: '$',
    paymentMethod: 'UPI / QR',
    status: 'Completed',
    tableOrRoom: 'Table 03'
  },
  {
    id: 'tx-002',
    orderNumber: '#ORD-8941',
    customerName: 'Dr. Meera Patel',
    customerEmail: 'meera.p@hospital.org',
    date: 'Today, 24 Oct',
    time: '13:58 PM',
    amount: 88.00,
    currency: '$',
    paymentMethod: 'Credit Card',
    status: 'Completed',
    tableOrRoom: 'Room 204'
  },
  {
    id: 'tx-003',
    orderNumber: '#ORD-8940',
    customerName: 'Rohan Gupta',
    customerEmail: 'rohan.g@techcorp.in',
    date: 'Today, 24 Oct',
    time: '13:45 PM',
    amount: 19.25,
    currency: '$',
    paymentMethod: 'UPI / QR',
    status: 'Pending',
    tableOrRoom: 'Table 07'
  },
  {
    id: 'tx-004',
    orderNumber: '#ORD-8939',
    customerName: 'Pooja Sundaram',
    customerEmail: 'pooja.s@finconsult.com',
    date: 'Today, 24 Oct',
    time: '13:12 PM',
    amount: 112.50,
    currency: '$',
    paymentMethod: 'Credit Card',
    status: 'Completed',
    tableOrRoom: 'Room 101'
  },
  {
    id: 'tx-005',
    orderNumber: '#ORD-8938',
    customerName: 'Vikram Malhotra',
    customerEmail: 'v.malhotra@cloudnet.io',
    date: 'Today, 24 Oct',
    time: '12:30 PM',
    amount: 45.00,
    currency: '$',
    paymentMethod: 'Cash',
    status: 'Failed',
    tableOrRoom: 'Table 12'
  },
  {
    id: 'tx-006',
    orderNumber: '#ORD-8937',
    customerName: 'Ananya Reddy',
    customerEmail: 'ananya.r@designstudio.co',
    date: 'Yesterday, 23 Oct',
    time: '21:05 PM',
    amount: 54.00,
    currency: '$',
    paymentMethod: 'Credit Card',
    status: 'Refunded',
    tableOrRoom: 'Table 04'
  },
];

interface AdminDashboardProps {
  business?: Business;
  onBackToApp?: () => void;
  brandName?: string;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  business,
  onBackToApp,
  brandName = 'Gourmet POS & Analytics'
}) => {
  const isGuestHouse = business ? (business.businessType === 'guesthouse' || business.id.includes('guesthouse') || business.id.includes('hotel')) : false;
  const currentBizId = business?.id || (isGuestHouse ? 'green-valley-guesthouse' : 'sri-murugan-tiffin-center');
  const availableRoles = useMemo(() => getDutyRolesForTenant(isGuestHouse ? 'guesthouse' : 'restaurant'), [isGuestHouse]);

  // Navigation & Layout State
  const [activeTab, setActiveTab] = useState<AdminNavTab>('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);
  
  // Controls & Filters State
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | '12m'>('30d');
  const [chartMetric, setChartMetric] = useState<'revenue' | 'orders'>('revenue');
  const [statusFilter, setStatusFilter] = useState<'All' | TransactionStatus>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Notification / Action feedback toast
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  // Staff Modal state
  const [isStaffModalOpen, setIsStaffModalOpen] = useState<boolean>(false);
  const [staffList, setStaffList] = useState<StaffAllocation[]>([]);
  const [staffLoading, setStaffLoading] = useState<boolean>(false);
  const [staffSaving, setStaffSaving] = useState<boolean>(false);
  const [editingStaffId, setEditingStaffId] = useState<string | null>(null);

  // Staff form state inside modal
  const [formStaffName, setFormStaffName] = useState<string>('');
  const [formStaffRole, setFormStaffRole] = useState<StaffRole>(isGuestHouse ? 'front_desk' : 'waiter');
  const [formStaffPhone, setFormStaffPhone] = useState<string>('');
  const [formStaffNotes, setFormStaffNotes] = useState<string>('');
  const [formStaffUnits, setFormStaffUnits] = useState<string[]>(isGuestHouse ? ['101', '102'] : ['01', '02']);

  const todayDate = new Date().toISOString().slice(0, 10);

  // Load staff allocations
  const loadStaffData = async () => {
    setStaffLoading(true);
    try {
      const data = await fetchStaffAllocations(currentBizId, todayDate);
      setStaffList(data);
    } catch (e) {
      console.warn('Error loading staff allocations in admin:', e);
    } finally {
      setStaffLoading(false);
    }
  };

  useEffect(() => {
    loadStaffData();
  }, [currentBizId]);

  const triggerToast = (msg: string) => {
    setActionMessage(msg);
    setTimeout(() => setActionMessage(null), 3000);
  };

  // Open staff add modal
  const openAddStaffModal = () => {
    setEditingStaffId(null);
    setFormStaffName('');
    setFormStaffRole(isGuestHouse ? 'front_desk' : 'waiter');
    setFormStaffPhone('');
    setFormStaffNotes('');
    setFormStaffUnits(isGuestHouse ? ['101', '102'] : ['01', '02']);
    setIsStaffModalOpen(true);
  };

  // Open edit staff modal
  const openEditStaffModal = (staff: StaffAllocation) => {
    setEditingStaffId(staff.id);
    setFormStaffName(staff.staffName);
    setFormStaffRole(staff.role);
    setFormStaffPhone(staff.phone || '');
    setFormStaffNotes(staff.notes || '');
    setFormStaffUnits(staff.assignedTables || []);
    setIsStaffModalOpen(true);
  };

  // Save staff member from modal
  const handleSaveStaffMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formStaffName.trim()) {
      alert('Please enter staff name');
      return;
    }
    if (formStaffUnits.length === 0) {
      alert(`Please assign at least one ${isGuestHouse ? 'room' : 'table'}`);
      return;
    }

    setStaffSaving(true);
    try {
      await saveStaffAllocation({
        id: editingStaffId || undefined,
        restaurantId: currentBizId,
        staffName: formStaffName.trim(),
        role: formStaffRole,
        phone: formStaffPhone.trim() || undefined,
        shiftDate: todayDate,
        assignedTables: formStaffUnits,
        isActive: true,
        notes: formStaffNotes.trim() || undefined
      });

      triggerToast(`Staff member ${formStaffName} saved with role [${formStaffRole}]`);
      setIsStaffModalOpen(false);
      await loadStaffData();
    } catch (err) {
      console.error(err);
      alert('Failed to save staff member');
    } finally {
      setStaffSaving(false);
    }
  };

  // Delete staff member
  const handleDeleteStaffMember = async (id: string, name: string) => {
    if (!confirm(`Delete ${name} from active staff roster?`)) return;
    try {
      await deleteStaffAllocation(currentBizId, id, todayDate);
      triggerToast(`Removed ${name} from staff roster`);
      await loadStaffData();
    } catch (e) {
      console.error(e);
    }
  };

  // Helper to render role icons
  const renderRoleIcon = (iconName: string, className: string = "w-4 h-4") => {
    switch (iconName) {
      case 'Hotel': return <Hotel className={className} />;
      case 'Sparkles': return <Sparkles className={className} />;
      case 'Utensils': return <Utensils className={className} />;
      case 'Coffee': return <Coffee className={className} />;
      case 'Briefcase': return <Briefcase className={className} />;
      case 'Dumbbell': return <Dumbbell className={className} />;
      case 'Wrench': return <Wrench className={className} />;
      case 'ChefHat': return <ChefHat className={className} />;
      case 'UtensilsCrossed': return <UtensilsCrossed className={className} />;
      case 'CreditCard': return <CreditCard className={className} />;
      case 'Bike': return <Bike className={className} />;
      default: return <UserCheck className={className} />;
    }
  };

  // KPI Metrics calculation
  const kpiMetrics: KpiMetric[] = [
    {
      id: 'revenue',
      title: 'Total Revenue',
      value: '$48,295.50',
      numericValue: 48295.50,
      change: '+12.5%',
      isPositive: true,
      period: 'vs last month',
      icon: DollarSign,
      accentColor: 'from-amber-500/20 to-amber-600/5 text-amber-400 border-amber-500/30',
      chartColor: '#f59e0b'
    },
    {
      id: 'users',
      title: isGuestHouse ? 'Active Guests' : 'New Customers',
      value: '1,429',
      numericValue: 1429,
      change: '+18.2%',
      isPositive: true,
      period: 'vs last month',
      icon: UserPlus,
      accentColor: 'from-sky-500/20 to-sky-600/5 text-sky-400 border-sky-500/30',
      chartColor: '#38bdf8'
    },
    {
      id: 'subscriptions',
      title: isGuestHouse ? 'Room Requests' : 'Active Orders',
      value: '384',
      numericValue: 384,
      change: '+5.4%',
      isPositive: true,
      period: 'vs yesterday',
      icon: CreditCard,
      accentColor: 'from-emerald-500/20 to-emerald-600/5 text-emerald-400 border-emerald-500/30',
      chartColor: '#10b981'
    },
    {
      id: 'conversion',
      title: 'Conversion Rate',
      value: '3.82%',
      numericValue: 3.82,
      change: '-0.4%',
      isPositive: false,
      period: 'vs last week',
      icon: Percent,
      accentColor: 'from-purple-500/20 to-purple-600/5 text-purple-400 border-purple-500/30',
      chartColor: '#a855f7'
    }
  ];

  // Filtered Transactions
  const filteredTransactions = useMemo(() => {
    return INITIAL_TRANSACTIONS.filter((tx) => {
      const matchesStatus = statusFilter === 'All' || tx.status === statusFilter;
      const matchesSearch = 
        tx.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.customerEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (tx.tableOrRoom && tx.tableOrRoom.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesStatus && matchesSearch;
    });
  }, [statusFilter, searchQuery]);

  // Sidebar Menu Items Definition
  const sidebarNavItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, badge: null },
    { id: 'analytics', label: 'Analytics', icon: BarChart3, badge: 'Live' },
    { id: 'users', label: isGuestHouse ? 'Hotel Staff & Duties' : 'Users & Staff', icon: Users, badge: `${staffList.length}` },
    { id: 'orders', label: isGuestHouse ? 'Rooms & Services' : 'Orders & Tables', icon: ShoppingBag, badge: 'Live' },
    { id: 'content', label: isGuestHouse ? 'Amenities & Services' : 'Menu & Content', icon: FileText, badge: null },
    { id: 'settings', label: 'Settings', icon: Settings, badge: null },
  ];

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col font-sans selection:bg-amber-500 selection:text-stone-950">
      
      {/* Action Message Notification Toast */}
      {actionMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 border border-amber-500/40 text-amber-300 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs font-semibold animate-bounce">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{actionMessage}</span>
        </div>
      )}

      <div className="flex flex-1 relative overflow-hidden">

        {/* ═══════════════════════════════════════════════════════════════ */}
        {/* 1. STICKY COLLAPSIBLE SIDEBAR NAVIGATION                        */}
        {/* ═══════════════════════════════════════════════════════════════ */}
        
        {/* Mobile Backdrop */}
        {isMobileSidebarOpen && (
          <div 
            onClick={() => setIsMobileSidebarOpen(false)}
            className="fixed inset-0 bg-black/80 backdrop-blur-xs z-40 lg:hidden"
          />
        )}

        <aside
          className={`fixed lg:sticky top-0 h-screen z-50 bg-stone-900 border-r border-stone-800 transition-all duration-300 ease-in-out flex flex-col justify-between ${
            isSidebarCollapsed ? 'w-20' : 'w-64'
          } ${
            isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          }`}
        >
          {/* Sidebar Top: Logo & Collapse Toggle */}
          <div>
            <div className="h-16 flex items-center justify-between px-4 border-b border-stone-800">
              <div className="flex items-center gap-3 overflow-hidden">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-base shrink-0 shadow-md ${
                  isGuestHouse 
                    ? 'bg-gradient-to-br from-sky-500 to-sky-600 text-stone-950' 
                    : 'bg-gradient-to-br from-amber-500 to-amber-600 text-stone-950'
                }`}>
                  {isGuestHouse ? <Hotel className="w-5 h-5" /> : 'A'}
                </div>
                {!isSidebarCollapsed && (
                  <div className="flex flex-col truncate">
                    <span className="font-extrabold text-sm tracking-tight text-white truncate">
                      {brandName}
                    </span>
                    <span className={`text-[10px] font-mono uppercase tracking-wider font-bold ${
                      isGuestHouse ? 'text-sky-400' : 'text-amber-400'
                    }`}>
                      {isGuestHouse ? 'Hotel Management Suite' : 'Enterprise Admin POS'}
                    </span>
                  </div>
                )}
              </div>

              {/* Desktop Toggle Button */}
              <button
                type="button"
                onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                className="hidden lg:flex p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
                title={isSidebarCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
              >
                {isSidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
              </button>
            </div>

            {/* Navigation List */}
            <nav className="p-3 space-y-1.5">
              {!isSidebarCollapsed && (
                <div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-stone-400">
                  Main Menu
                </div>
              )}
              {sidebarNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(item.id as AdminNavTab);
                      setIsMobileSidebarOpen(false);
                    }}
                    title={isSidebarCollapsed ? item.label : undefined}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer group ${
                      isActive
                        ? isGuestHouse 
                          ? 'bg-sky-500 text-stone-950 font-bold shadow-md shadow-sky-500/10' 
                          : 'bg-amber-500 text-stone-950 font-bold shadow-md shadow-amber-500/10'
                        : 'text-stone-300 hover:text-white hover:bg-stone-800/80'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                      isActive ? 'text-stone-950' : (isGuestHouse ? 'text-stone-400 group-hover:text-sky-400' : 'text-stone-400 group-hover:text-amber-400')
                    }`} />
                    {!isSidebarCollapsed && (
                      <span className="flex-1 text-left truncate">{item.label}</span>
                    )}
                    {!isSidebarCollapsed && item.badge && (
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        isActive 
                          ? 'bg-stone-950 text-amber-400' 
                          : (isGuestHouse ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30')
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Sidebar Bottom: Quick App Switcher / Footer */}
          <div className="p-3 border-t border-stone-800">
            {onBackToApp && (
              <button
                type="button"
                onClick={onBackToApp}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-200 text-xs font-bold transition-colors border border-stone-700 cursor-pointer"
              >
                <Layers className="w-4 h-4 text-amber-400" />
                {!isSidebarCollapsed && <span>Return to Main POS</span>}
              </button>
            )}

            {!isSidebarCollapsed && (
              <div className="mt-3 px-3 py-2 bg-stone-950/60 rounded-xl border border-stone-800/60 flex items-center justify-between text-[11px] text-stone-400">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Cloud API Sync</span>
                </span>
                <span className="font-mono text-[10px] text-stone-400">v2.8.0</span>
              </div>
            )}
          </div>
        </aside>

        {/* ═══════════════════════════════════════════════════════════════ */}
        {/* 2. MAIN HEADER & TOP TOOLBAR                                    */}
        {/* ═══════════════════════════════════════════════════════════════ */}
        <div className="flex-1 flex flex-col min-w-0 overflow-y-auto max-h-screen">
          
          <header className="h-16 bg-stone-900/90 backdrop-blur-md border-b border-stone-800 sticky top-0 z-30 px-4 sm:px-6 flex items-center justify-between gap-4">
            
            {/* Left: Mobile Menu Toggle & Title */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setIsMobileSidebarOpen(true)}
                className="lg:hidden p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
              >
                <MenuIcon className="w-5 h-5" />
              </button>

              <div>
                <h1 className="text-base sm:text-lg font-black text-white tracking-tight flex items-center gap-2">
                  <span>{activeTab === 'users' ? (isGuestHouse ? 'Hotel Staff & Duty Assignment' : 'Users & Staff Management') : 'Executive Analytics & Control Hub'}</span>
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold ${
                    isGuestHouse ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}>
                    {isGuestHouse ? 'GUESTHOUSE MODE' : 'RESTAURANT MODE'}
                  </span>
                </h1>
                <p className="text-[11px] text-stone-400 hidden sm:block">
                  {isGuestHouse 
                    ? 'Managing hotel reception, housekeeping, room service, concierge, and maintenance' 
                    : 'Managing dine-in kitchen, waiters, POS billing, and food runners'}
                </p>
              </div>
            </div>

            {/* Right: Search, Filter & Quick Actions */}
            <div className="flex items-center gap-2.5">
              
              {/* Search Bar */}
              <div className="relative hidden md:block w-48 lg:w-64">
                <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search orders, rooms, guests..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-stone-950 border border-stone-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-stone-200 placeholder-stone-400 focus:outline-hidden focus:border-amber-500 transition-colors"
                />
              </div>

              {/* Time Range Filter */}
              <div className="flex items-center bg-stone-800 border border-stone-700 rounded-xl p-1 text-xs">
                {(['7d', '30d', '90d', '12m'] as const).map((range) => (
                  <button
                    key={range}
                    type="button"
                    onClick={() => {
                      setTimeRange(range);
                      triggerToast(`Switched timeframe to ${range}`);
                    }}
                    className={`px-2.5 py-1 rounded-lg font-bold transition-colors cursor-pointer ${
                      timeRange === range
                        ? (isGuestHouse ? 'bg-sky-500 text-stone-950' : 'bg-amber-500 text-stone-950')
                        : 'text-stone-400 hover:text-white'
                    }`}
                  >
                    {range.toUpperCase()}
                  </button>
                ))}
              </div>

              {/* Add Staff Button in Header */}
              <button
                type="button"
                onClick={openAddStaffModal}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-black text-xs transition-all shadow-md active:scale-95 cursor-pointer ${
                  isGuestHouse ? 'bg-sky-400 hover:bg-sky-300 text-stone-950' : 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Add Staff</span>
              </button>

              {/* Notification Bell */}
              <button
                type="button"
                onClick={() => triggerToast("3 new operational alerts received")}
                className="p-2 rounded-xl text-stone-300 hover:text-white hover:bg-stone-800 transition-colors relative cursor-pointer"
              >
                <Bell className="w-4 h-4" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-500 animate-ping" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-500" />
              </button>
            </div>
          </header>

          {/* ═══════════════════════════════════════════════════════════ */}
          {/* 3. MAIN DASHBOARD OR USERS & STAFF TAB                      */}
          {/* ═══════════════════════════════════════════════════════════ */}
          <main className="p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">

            {/* TAB: USERS & STAFF */}
            {activeTab === 'users' ? (
              <div className="space-y-6">
                
                {/* Header Banner */}
                <div className="bg-stone-900 border border-stone-800 rounded-3xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
                      <Users className={`w-5 h-5 ${isGuestHouse ? 'text-sky-400' : 'text-amber-400'}`} />
                      <span>{isGuestHouse ? 'Hotel Operational Staff & Duty Roster' : 'Restaurant Staff & Table Coverage'}</span>
                    </h2>
                    <p className="text-xs text-stone-400 mt-1">
                      {isGuestHouse 
                        ? 'Roles: Front Desk, Housekeeping, Room Service, Barista, Concierge, Facilities & Maintenance' 
                        : 'Roles: Head Chef, Table Waiter, Cashier, Delivery Runner'}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={openAddStaffModal}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-black text-xs transition-all shadow-md cursor-pointer ${
                      isGuestHouse ? 'bg-sky-400 hover:bg-sky-300 text-stone-950' : 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                    }`}
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>Assign / Add New Staff</span>
                  </button>
                </div>

                {/* Staff Roster Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {staffList.map((staff) => {
                    const roleMeta = availableRoles.find(r => r.id === staff.role) || {
                      id: staff.role,
                      label: staff.role,
                      iconName: 'UserCheck',
                      color: 'amber'
                    };

                    return (
                      <div
                        key={staff.id}
                        className="bg-stone-900 border border-stone-800 hover:border-stone-700 rounded-2xl p-5 shadow-lg space-y-3 transition-all"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
                              isGuestHouse ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            }`}>
                              {renderRoleIcon(roleMeta.iconName, "w-5 h-5")}
                            </div>
                            <div>
                              <h3 className="font-extrabold text-white text-sm">{staff.staffName}</h3>
                              <span className={`inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-md mt-0.5 ${
                                isGuestHouse ? 'bg-sky-950 text-sky-300 border border-sky-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                              }`}>
                                {roleMeta.label}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => openEditStaffModal(staff)}
                              className="p-1.5 text-stone-400 hover:text-white rounded-lg hover:bg-stone-800 transition-colors"
                              title="Edit Staff Member"
                            >
                              <UserCheck className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteStaffMember(staff.id, staff.staffName)}
                              className="p-1.5 text-stone-400 hover:text-red-400 rounded-lg hover:bg-stone-800 transition-colors"
                              title="Delete Staff"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {staff.phone && (
                          <div className="text-xs text-stone-400 font-mono flex items-center gap-1.5">
                            <Phone className="w-3.5 h-3.5 text-stone-400" />
                            <span>{staff.phone}</span>
                          </div>
                        )}

                        {staff.notes && (
                          <div className="text-xs text-stone-400 italic bg-stone-950/60 p-2.5 rounded-xl border border-stone-800/60">
                            "{staff.notes}"
                          </div>
                        )}

                        <div className="pt-2 border-t border-stone-800 flex flex-wrap items-center gap-1">
                          <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider mr-1">
                            {isGuestHouse ? 'Rooms / Areas:' : 'Tables:'}
                          </span>
                          {staff.assignedTables.map(u => (
                            <span
                              key={u}
                              className="px-2 py-0.5 bg-stone-800 text-stone-200 rounded text-xs font-mono font-bold"
                            >
                              {u}
                            </span>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <>
                {/* ── A. 4 KEY METRICS / KPI CARDS ─────────────────────── */}
                <section aria-labelledby="kpi-cards-title">
                  <h2 id="kpi-cards-title" className="sr-only">Key Performance Indicators</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {kpiMetrics.map((kpi) => {
                      const Icon = kpi.icon;
                      return (
                        <div
                          key={kpi.id}
                          className="bg-stone-900 border border-stone-800 hover:border-stone-700 p-5 rounded-2xl shadow-lg transition-all duration-200 hover:-translate-y-0.5 flex flex-col justify-between group"
                        >
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-xs font-bold text-stone-400 tracking-wide uppercase">
                              {kpi.title}
                            </span>
                            <div className={`p-2.5 rounded-xl border bg-gradient-to-br ${kpi.accentColor}`}>
                              <Icon className="w-4 h-4" />
                            </div>
                          </div>

                          <div>
                            <div className="text-2xl lg:text-3xl font-black text-white tracking-tight">
                              {kpi.value}
                            </div>
                            <div className="flex items-center gap-1.5 mt-2 text-xs">
                              <span className={`flex items-center font-bold font-mono ${
                                kpi.isPositive ? 'text-emerald-400' : 'text-rose-400'
                              }`}>
                                {kpi.isPositive ? <TrendingUp className="w-3.5 h-3.5 mr-0.5" /> : <TrendingDown className="w-3.5 h-3.5 mr-0.5" />}
                                {kpi.change}
                              </span>
                              <span className="text-stone-400 text-[11px]">
                                {kpi.period}
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </section>

                {/* ── B. ANALYTICAL CHARTS SECTION ──────────────────────── */}
                <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  
                  {/* Revenue / Orders Timeline Area Chart (2 cols) */}
                  <div className="lg:col-span-2 bg-stone-900 border border-stone-800 p-5 rounded-2xl shadow-lg flex flex-col justify-between">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
                      <div>
                        <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                          <span>Revenue & Order Volume Performance</span>
                          <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            +14.2% Growth
                          </span>
                        </h3>
                        <p className="text-xs text-stone-400 mt-0.5">
                          Daily sales velocity vs weekly projected revenue benchmark
                        </p>
                      </div>

                      {/* Chart Metric Toggle */}
                      <div className="flex items-center bg-stone-950 border border-stone-800 p-1 rounded-xl text-xs">
                        <button
                          type="button"
                          onClick={() => setChartMetric('revenue')}
                          className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                            chartMetric === 'revenue'
                              ? 'bg-amber-500 text-stone-950 shadow-xs'
                              : 'text-stone-400 hover:text-white'
                          }`}
                        >
                          Revenue ($)
                        </button>
                        <button
                          type="button"
                          onClick={() => setChartMetric('orders')}
                          className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                            chartMetric === 'orders'
                              ? 'bg-amber-500 text-stone-950 shadow-xs'
                              : 'text-stone-400 hover:text-white'
                          }`}
                        >
                          Orders (#)
                        </button>
                      </div>
                    </div>

                    {/* Recharts Area Chart */}
                    <div className="h-64 sm:h-72 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={REVENUE_TIMELINE_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                          <defs>
                            <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4}/>
                              <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0}/>
                            </linearGradient>
                            <linearGradient id="colorOrders" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.4}/>
                              <stop offset="95%" stopColor="#38bdf8" stopOpacity={0.0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#292524" vertical={false} />
                          <XAxis dataKey="name" stroke="#78716c" fontSize={11} tickLine={false} />
                          <YAxis stroke="#78716c" fontSize={11} tickLine={false} axisLine={false} />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#1c1917', 
                              borderColor: '#44403c', 
                              borderRadius: '0.75rem',
                              color: '#f5f5f4',
                              fontSize: '12px',
                              boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)'
                            }} 
                          />
                          <Area 
                            type="monotone" 
                            dataKey={chartMetric === 'revenue' ? 'revenue' : 'orders'} 
                            stroke={chartMetric === 'revenue' ? '#f59e0b' : '#38bdf8'} 
                            strokeWidth={3}
                            fillOpacity={1} 
                            fill={chartMetric === 'revenue' ? 'url(#colorRevenue)' : 'url(#colorOrders)'} 
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Category Revenue Distribution Pie/Bar Chart (1 col) */}
                  <div className="bg-stone-900 border border-stone-800 p-5 rounded-2xl shadow-lg flex flex-col justify-between">
                    <div className="mb-4">
                      <h3 className="text-base font-extrabold text-white">
                        {isGuestHouse ? 'Revenue by Service' : 'Sales by Menu Category'}
                      </h3>
                      <p className="text-xs text-stone-400 mt-0.5">
                        Breakdown of top culinary & service contributions
                      </p>
                    </div>

                    <div className="h-52 w-full relative">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={CATEGORY_SALES_DATA}
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={75}
                            paddingAngle={4}
                            dataKey="value"
                          >
                            {CATEGORY_SALES_DATA.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#1c1917', 
                              borderColor: '#44403c', 
                              borderRadius: '0.75rem',
                              color: '#f5f5f4',
                              fontSize: '11px'
                            }} 
                          />
                        </PieChart>
                      </ResponsiveContainer>
                      
                      {/* Center Stats */}
                      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                        <span className="text-xs text-stone-400 font-bold uppercase">Total</span>
                        <span className="text-base font-black text-white font-mono">100%</span>
                      </div>
                    </div>

                    {/* Category Legend Badges */}
                    <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-stone-800">
                      {CATEGORY_SALES_DATA.map((item) => (
                        <div key={item.name} className="flex items-center gap-2 text-xs">
                          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                          <span className="text-stone-300 truncate font-medium">{item.name}</span>
                          <span className="font-mono font-bold text-stone-400 text-[10px] ml-auto">{item.value}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </section>

                {/* ── C. QUICK ACTIONS PANEL ───────────────────────────── */}
                <section className="bg-gradient-to-r from-stone-900 via-stone-900 to-stone-850 border border-stone-800 p-5 rounded-2xl shadow-lg">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-amber-400" />
                        <span>Quick Administrative Actions</span>
                      </h3>
                      <p className="text-xs text-stone-400 mt-0.5">
                        Trigger frequent administrative operations with one click
                      </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-2.5">
                      <button
                        type="button"
                        onClick={openAddStaffModal}
                        className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl font-black text-xs transition-all shadow-md active:scale-95 cursor-pointer ${
                          isGuestHouse ? 'bg-sky-400 hover:bg-sky-300 text-stone-950' : 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                        }`}
                      >
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>{isGuestHouse ? 'Add Hotel Staff' : 'Add Restaurant Staff'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => triggerToast("Exporting month-end financial summary to CSV...")}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 text-xs font-bold transition-all active:scale-95 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5 text-amber-400" />
                        <span>Export Report</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => triggerToast("Broadcast message sent to all active table/room sessions!")}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-200 border border-stone-700 text-xs font-bold transition-all active:scale-95 cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Send Announcement</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => triggerToast("Hardware synchronized")}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-300 border border-stone-700 text-xs font-bold transition-all cursor-pointer"
                        title="Sync Hardware"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-sky-400" />
                        <span className="hidden xl:inline">Sync Hardware</span>
                      </button>
                    </div>
                  </div>
                </section>

                {/* ── D. RECENT TRANSACTIONS / ACTIVITY TABLE ──────────── */}
                <section className="bg-stone-900 border border-stone-800 rounded-2xl shadow-lg overflow-hidden">
                  
                  {/* Table Top Controls */}
                  <div className="p-5 border-b border-stone-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                        <span>Recent Transactions & Activity</span>
                        <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-stone-800 text-stone-300 border border-stone-700">
                          {filteredTransactions.length} records
                        </span>
                      </h3>
                      <p className="text-xs text-stone-400 mt-0.5">
                        Live log of customer orders, room services, and payment settlements
                      </p>
                    </div>

                    {/* Status Tabs & Filters */}
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="flex items-center bg-stone-950 border border-stone-800 p-1 rounded-xl text-xs">
                        {(['All', 'Completed', 'Pending', 'Failed', 'Refunded'] as const).map((st) => (
                          <button
                            key={st}
                            type="button"
                            onClick={() => setStatusFilter(st)}
                            className={`px-3 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                              statusFilter === st
                                ? 'bg-amber-500 text-stone-950 shadow-xs'
                                : 'text-stone-400 hover:text-white'
                            }`}
                          >
                            {st}
                          </button>
                        ))}
                      </div>

                      <button
                        type="button"
                        onClick={() => triggerToast("Refreshed transaction feed")}
                        className="p-2 rounded-xl bg-stone-800 hover:bg-stone-750 text-stone-300 border border-stone-700 transition-colors cursor-pointer"
                        title="Refresh Transactions"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Data Table */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-stone-950/70 text-stone-400 font-bold uppercase tracking-wider text-[10px] border-b border-stone-800">
                        <tr>
                          <th className="py-3.5 px-4">Order / ID</th>
                          <th className="py-3.5 px-4">{isGuestHouse ? 'Guest & Room' : 'Customer & Table'}</th>
                          <th className="py-3.5 px-4">Date & Time</th>
                          <th className="py-3.5 px-4">Payment Method</th>
                          <th className="py-3.5 px-4 text-right">Amount</th>
                          <th className="py-3.5 px-4 text-center">Status</th>
                          <th className="py-3.5 px-4 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-800 text-stone-200">
                        {filteredTransactions.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="py-8 text-center text-stone-500 font-medium">
                              No transactions found matching the selected filter or search term.
                            </td>
                          </tr>
                        ) : (
                          filteredTransactions.map((tx) => (
                            <tr key={tx.id} className="hover:bg-stone-800/40 transition-colors">
                              
                              {/* Order Number */}
                              <td className="py-3.5 px-4 font-mono font-bold text-amber-400">
                                {tx.orderNumber}
                              </td>

                              {/* Customer & Location */}
                              <td className="py-3.5 px-4">
                                <div className="flex items-center gap-2.5">
                                  <div className="w-7 h-7 rounded-full bg-stone-800 border border-stone-700 flex items-center justify-center font-bold text-white text-[11px] shrink-0">
                                    {tx.customerName.charAt(0)}
                                  </div>
                                  <div className="flex flex-col">
                                    <span className="font-bold text-white">{tx.customerName}</span>
                                    <span className="text-[11px] text-stone-400 flex items-center gap-1.5">
                                      <span>{tx.customerEmail}</span>
                                      {tx.tableOrRoom && (
                                        <span className="font-mono text-amber-300 font-bold">
                                          • {tx.tableOrRoom}
                                        </span>
                                      )}
                                    </span>
                                  </div>
                                </div>
                              </td>

                              {/* Date & Time */}
                              <td className="py-3.5 px-4 text-stone-300 font-mono text-[11px]">
                                <div>{tx.date}</div>
                                <div className="text-stone-400">{tx.time}</div>
                              </td>

                              {/* Payment Method */}
                              <td className="py-3.5 px-4 font-medium text-stone-300">
                                <span className="px-2 py-0.5 rounded-md bg-stone-800 border border-stone-750 text-[11px]">
                                  {tx.paymentMethod}
                                </span>
                              </td>

                              {/* Amount */}
                              <td className="py-3.5 px-4 text-right font-black font-mono text-sm text-white">
                                {tx.currency}{tx.amount.toFixed(2)}
                              </td>

                              {/* Status Badge */}
                              <td className="py-3.5 px-4 text-center">
                                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold ${
                                  tx.status === 'Completed'
                                    ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                    : tx.status === 'Pending'
                                    ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                                    : tx.status === 'Failed'
                                    ? 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                                    : 'bg-purple-500/15 text-purple-300 border border-purple-500/30'
                                }`}>
                                  {tx.status === 'Completed' && <CheckCircle2 className="w-3 h-3" />}
                                  {tx.status === 'Pending' && <Clock className="w-3 h-3" />}
                                  {tx.status === 'Failed' && <XCircle className="w-3 h-3" />}
                                  {tx.status === 'Refunded' && <AlertCircle className="w-3 h-3" />}
                                  <span>{tx.status}</span>
                                </span>
                              </td>

                              {/* Actions */}
                              <td className="py-3.5 px-4 text-right">
                                <button
                                  type="button"
                                  onClick={() => triggerToast(`Receipt for ${tx.orderNumber} generated`)}
                                  className="px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white transition-colors text-[11px] font-semibold cursor-pointer"
                                >
                                  Details
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Table Footer Pagination */}
                  <div className="p-4 bg-stone-950/40 border-t border-stone-800 flex items-center justify-between text-xs text-stone-400">
                    <span>Showing 1 to {filteredTransactions.length} of {filteredTransactions.length} entries</span>
                    <div className="flex items-center gap-1">
                      <button type="button" disabled className="p-1.5 rounded-lg text-stone-600 cursor-not-allowed">
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <button type="button" className="px-2.5 py-1 rounded-lg bg-amber-500 text-stone-950 font-bold">1</button>
                      <button type="button" disabled className="p-1.5 rounded-lg text-stone-600 cursor-not-allowed">
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </section>
              </>
            )}
          </main>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════ */}
      {/* 4. DYNAMIC STAFF MANAGEMENT & DUTY MODAL (HOTEL VS RESTAURANT)  */}
      {/* ═══════════════════════════════════════════════════════════════ */}
      <AnimatePresence>
        {isStaffModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsStaffModalOpen(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-xs"
            />

            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-xl bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-2xl z-10 space-y-5 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                <div className="flex items-center gap-2.5">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold ${
                    isGuestHouse ? 'bg-sky-500 text-stone-950' : 'bg-amber-500 text-stone-950'
                  }`}>
                    {isGuestHouse ? <Hotel className="w-5 h-5" /> : <ShieldCheck className="w-5 h-5" />}
                  </div>
                  <div>
                    <h3 className="font-extrabold text-white text-base">
                      {editingStaffId ? 'Edit Staff Member Duty' : (isGuestHouse ? 'Add Hotel Staff Member' : 'Add Restaurant Staff Member')}
                    </h3>
                    <p className="text-xs text-stone-400">
                      {isGuestHouse ? 'Hotel Mode (type=guesthouse)' : 'Restaurant Mode (type=restaurant)'}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsStaffModalOpen(false)}
                  className="w-8 h-8 rounded-full bg-stone-800 hover:bg-stone-700 flex items-center justify-center text-stone-400 hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveStaffMember} className="space-y-4">
                
                {/* Staff Name */}
                <div>
                  <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-1.5">
                    Staff Member Full Name
                  </label>
                  <input
                    type="text"
                    placeholder={isGuestHouse ? "e.g. Anita Sharma (Front Desk)" : "e.g. Waiter Ramesh"}
                    value={formStaffName}
                    onChange={(e) => setFormStaffName(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 bg-stone-950 border border-stone-800 rounded-xl text-xs font-semibold text-white focus:outline-hidden focus:border-amber-500"
                  />
                </div>

                {/* Role Selector - Dynamic based on businessType */}
                <div>
                  <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-2">
                    {isGuestHouse ? 'Select Hotel Operational Duty Role:' : 'Select Restaurant Service Role:'}
                  </label>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                    {availableRoles.map((roleMeta) => {
                      const isSelected = formStaffRole === roleMeta.id;
                      return (
                        <button
                          key={roleMeta.id}
                          type="button"
                          onClick={() => setFormStaffRole(roleMeta.id)}
                          className={`p-2.5 rounded-xl border text-left flex items-start gap-2.5 transition-all cursor-pointer ${
                            isSelected
                              ? isGuestHouse
                                ? 'bg-sky-500 text-stone-950 border-sky-400 font-bold shadow-xs'
                                : 'bg-amber-500 text-stone-950 border-amber-400 font-bold shadow-xs'
                              : 'bg-stone-950 border-stone-800 text-stone-300 hover:bg-stone-800/60'
                          }`}
                        >
                          <div className={`p-1.5 rounded-lg shrink-0 ${isSelected ? 'bg-black/20 text-stone-950' : 'bg-stone-800 text-stone-400'}`}>
                            {renderRoleIcon(roleMeta.iconName, "w-4 h-4")}
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="text-xs font-extrabold truncate">{roleMeta.label}</div>
                            <div className={`text-[10px] leading-tight line-clamp-1 ${isSelected ? 'text-stone-900' : 'text-stone-400'}`}>
                              {roleMeta.subtitle}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Assigned Units */}
                <div>
                  <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-1.5">
                    {isGuestHouse ? 'Assigned Rooms / Suites / Areas (Comma separated)' : 'Assigned Tables (Comma separated)'}
                  </label>
                  <input
                    type="text"
                    placeholder={isGuestHouse ? "e.g. 101, 102, 103, Suite-A, Poolside" : "e.g. 01, 02, 03, VIP-1"}
                    value={formStaffUnits.join(', ')}
                    onChange={(e) => {
                      const list = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                      setFormStaffUnits(list);
                    }}
                    required
                    className="w-full px-3.5 py-2.5 bg-stone-950 border border-stone-800 rounded-xl text-xs font-mono text-white focus:outline-hidden focus:border-amber-500"
                  />
                  <span className="text-[11px] text-stone-400 mt-1 block">
                    {isGuestHouse 
                      ? 'Example units: 101, 102, 201, 202, Suite-A, VIP-Lounge, Poolside, Gym' 
                      : 'Example tables: 01, 02, 03, 04, 05, 06, VIP-1, Terrace-A'}
                  </span>
                </div>

                {/* Phone & Scope */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-1.5">
                      Phone Number (Optional)
                    </label>
                    <input
                      type="tel"
                      placeholder="+91 98450 12345"
                      value={formStaffPhone}
                      onChange={(e) => setFormStaffPhone(e.target.value)}
                      className="w-full px-3.5 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-1.5">
                      Duty Instructions (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder={isGuestHouse ? "e.g. Morning linen & room turnover" : "e.g. Dine-in floor supervisor"}
                      value={formStaffNotes}
                      onChange={(e) => setFormStaffNotes(e.target.value)}
                      className="w-full px-3.5 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-amber-500"
                    />
                  </div>
                </div>

                {/* Submit button */}
                <div className="pt-3 flex items-center justify-end gap-3 border-t border-stone-800">
                  <button
                    type="button"
                    onClick={() => setIsStaffModalOpen(false)}
                    className="px-4 py-2 bg-stone-800 hover:bg-stone-750 text-stone-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={staffSaving}
                    className={`px-5 py-2.5 rounded-xl font-black text-xs transition-all shadow-md flex items-center gap-2 cursor-pointer ${
                      isGuestHouse ? 'bg-sky-400 hover:bg-sky-300 text-stone-950' : 'bg-amber-500 hover:bg-amber-400 text-stone-950'
                    }`}
                  >
                    {staffSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                    <span>{editingStaffId ? 'Update Staff Duty' : 'Save Staff Member'}</span>
                  </button>
                </div>

              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};

export default AdminDashboard;
