import React, { useState } from 'react';
import { Utensils, Hotel, Lock, Mail, Building2, Layers, CheckCircle2, ArrowRight, X } from 'lucide-react';

export interface AuthPayload {
  mode: 'login' | 'signup';
  businessType: 'restaurant' | 'guesthouse';
  email: string;
  password?: string;
  businessName?: string;
  phone?: string;
  totalUnits?: string;
  tenantId: string;
}

export interface AppAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCompleteAuth: (payload: AuthPayload) => void;
  onOpenPartnerSignIn?: () => void;
  initialMode?: 'login' | 'signup';
  initialBusinessType?: 'restaurant' | 'guesthouse';
}

export default function AppAuthModal({
  isOpen,
  onClose,
  onCompleteAuth,
  onOpenPartnerSignIn,
  initialMode = 'login',
  initialBusinessType = 'restaurant',
}: AppAuthModalProps) {
  const [authMode, setAuthMode] = useState<'login' | 'signup'>(initialMode);
  const [businessType, setBusinessType] = useState<'restaurant' | 'guesthouse'>(initialBusinessType);

  const [formData, setFormData] = useState({
    email: '',
    password: '',
    businessName: '',
    phone: '',
    totalUnits: '10', // Table count or Room count
  });

  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (error) setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.email.trim()) {
      setError('Please provide a valid email address');
      return;
    }

    if (!formData.password.trim() || formData.password.length < 4) {
      setError('Password must be at least 4 characters');
      return;
    }

    if (authMode === 'signup' && !formData.businessName.trim()) {
      setError('Please provide your business / property name');
      return;
    }

    // Auto-derive clean tenantId slug from businessName if signup
    const generatedSlug = authMode === 'signup' && formData.businessName
      ? formData.businessName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
      : `tenant-${Date.now()}`;

    const payload: AuthPayload = {
      mode: authMode,
      businessType,
      ...formData,
      tenantId: generatedSlug || `tenant-${Date.now()}`,
    };

    onCompleteAuth(payload);
    onClose();
  };

  return (
    <div 
      id="app-auth-modal-backdrop" 
      className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200"
    >
      <div 
        id="app-auth-modal-card" 
        className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-md p-6 sm:p-7 text-white shadow-2xl relative overflow-hidden"
      >
        {/* Subtle decorative top accent */}
        <div className={`absolute top-0 left-0 right-0 h-1.5 ${
          businessType === 'guesthouse' ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600' : 'bg-gradient-to-r from-amber-500 via-orange-400 to-amber-600'
        }`} />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full text-stone-400 hover:text-white hover:bg-stone-800 transition cursor-pointer"
          title="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-5">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xl">{businessType === 'guesthouse' ? '🏨' : '🍽️'}</span>
            <h2 className="text-lg font-black text-white tracking-tight">
              {authMode === 'login' ? 'Merchant Portal Sign In' : 'Register New Property'}
            </h2>
          </div>
          <p className="text-xs text-stone-400">
            {authMode === 'login' 
              ? 'Access live floor orders, duty roster & menu controls' 
              : 'Launch your restaurant QR menu or guest house SOP in seconds'}
          </p>
        </div>

        {/* Header Tabs: Login vs Register */}
        <div className="flex bg-stone-800/80 p-1 rounded-2xl mb-4 border border-stone-700/40">
          <button
            type="button"
            id="auth-tab-signin"
            className={`flex-1 py-2 text-xs sm:text-sm font-bold rounded-xl transition cursor-pointer ${
              authMode === 'login' 
                ? 'bg-amber-500 text-stone-950 shadow-sm' 
                : 'text-stone-400 hover:text-white'
            }`}
            onClick={() => setAuthMode('login')}
          >
            Sign In
          </button>
          <button
            type="button"
            id="auth-tab-register"
            className={`flex-1 py-2 text-xs sm:text-sm font-bold rounded-xl transition cursor-pointer ${
              authMode === 'signup' 
                ? 'bg-amber-500 text-stone-950 shadow-sm' 
                : 'text-stone-400 hover:text-white'
            }`}
            onClick={() => setAuthMode('signup')}
          >
            Register Business
          </button>
        </div>

        {/* Quick link to passwordless Supabase OTP sign in for restaurant partners */}
        {authMode === 'login' && onOpenPartnerSignIn && (
          <div className="mb-4 p-2.5 bg-emerald-950/40 border border-emerald-500/30 rounded-2xl flex items-center justify-between gap-2">
            <div className="text-left">
              <span className="text-[11px] font-bold text-emerald-300 block">Restaurant Partner?</span>
              <span className="text-[10px] text-stone-400 block">Login without password using email OTP</span>
            </div>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenPartnerSignIn();
              }}
              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-[10px] transition cursor-pointer shrink-0"
            >
              Partner OTP &rarr;
            </button>
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-rose-300 text-xs flex items-center gap-2">
            <span>⚠️</span>
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          
          {/* Business Type Selector (Only on Sign Up) */}
          {authMode === 'signup' && (
            <div>
              <label className="block text-[11px] font-bold text-stone-400 mb-1.5 uppercase tracking-wider">
                Select Service Type
              </label>
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  id="select-type-restaurant"
                  onClick={() => setBusinessType('restaurant')}
                  className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition cursor-pointer ${
                    businessType === 'restaurant' 
                      ? 'border-amber-500/80 bg-amber-500/15 text-amber-300 ring-2 ring-amber-500/30' 
                      : 'border-stone-800 bg-stone-800/40 text-stone-400 hover:border-stone-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xl">🍽️</span>
                    {businessType === 'restaurant' && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
                  </div>
                  <div>
                    <span className="text-xs font-black block mt-2 text-white">Restaurant QR</span>
                    <span className="text-[10px] text-stone-400">Kitchen & Tables</span>
                  </div>
                </button>

                <button
                  type="button"
                  id="select-type-guesthouse"
                  onClick={() => setBusinessType('guesthouse')}
                  className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition cursor-pointer ${
                    businessType === 'guesthouse' 
                      ? 'border-emerald-500/80 bg-emerald-500/15 text-emerald-300 ring-2 ring-emerald-500/30' 
                      : 'border-stone-800 bg-stone-800/40 text-stone-400 hover:border-stone-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xl">🏨</span>
                    {businessType === 'guesthouse' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  </div>
                  <div>
                    <span className="text-xs font-black block mt-2 text-white">Guest House SOP</span>
                    <span className="text-[10px] text-stone-400">Rooms & Duty Roster</span>
                  </div>
                </button>
              </div>
            </div>
          )}

          {/* Business Name (Sign Up Only) */}
          {authMode === 'signup' && (
            <div>
              <label className="block text-xs text-stone-300 mb-1 font-medium">
                {businessType === 'restaurant' ? 'Restaurant / Diner Name' : 'Guest House / Property Name'}
              </label>
              <div className="relative">
                <Building2 className="w-4 h-4 text-stone-500 absolute left-3 top-2.5" />
                <input
                  required
                  type="text"
                  name="businessName"
                  id="auth-business-name"
                  placeholder={businessType === 'restaurant' ? 'e.g. Kongu Mess' : 'e.g. Green Villa Residency'}
                  value={formData.businessName}
                  onChange={handleChange}
                  className="w-full bg-stone-800 border border-stone-700 rounded-xl pl-9 pr-3 py-2 text-sm text-white placeholder-stone-500 focus:outline-hidden focus:border-amber-500 transition"
                />
              </div>
            </div>
          )}

          {/* Email */}
          <div>
            <label className="block text-xs text-stone-300 mb-1 font-medium">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-stone-500 absolute left-3 top-2.5" />
              <input
                required
                type="email"
                name="email"
                id="auth-email"
                placeholder="owner@business.com"
                value={formData.email}
                onChange={handleChange}
                className="w-full bg-stone-800 border border-stone-700 rounded-xl pl-9 pr-3 py-2 text-sm text-white placeholder-stone-500 focus:outline-hidden focus:border-amber-500 transition"
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block text-xs text-stone-300 mb-1 font-medium">Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-stone-500 absolute left-3 top-2.5" />
              <input
                required
                type="password"
                name="password"
                id="auth-password"
                placeholder="••••••••"
                value={formData.password}
                onChange={handleChange}
                className="w-full bg-stone-800 border border-stone-700 rounded-xl pl-9 pr-3 py-2 text-sm text-white placeholder-stone-500 focus:outline-hidden focus:border-amber-500 transition"
              />
            </div>
          </div>

          {/* Dynamic Extra Field (Sign Up Only) */}
          {authMode === 'signup' && (
            <div>
              <label className="block text-xs text-stone-300 mb-1 font-medium">
                {businessType === 'restaurant' ? 'Total Dining Tables' : 'Total Rooms / Suites'}
              </label>
              <div className="relative">
                <Layers className="w-4 h-4 text-stone-500 absolute left-3 top-2.5" />
                <input
                  type="number"
                  name="totalUnits"
                  id="auth-total-units"
                  min="1"
                  max="100"
                  value={formData.totalUnits}
                  onChange={handleChange}
                  className="w-full bg-stone-800 border border-stone-700 rounded-xl pl-9 pr-3 py-2 text-sm text-white placeholder-stone-500 focus:outline-hidden focus:border-amber-500 transition"
                />
              </div>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            id="auth-submit-btn"
            className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-stone-950 font-black rounded-xl text-sm transition mt-4 shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
          >
            <span>
              {authMode === 'login' 
                ? 'Sign In to Dashboard' 
                : `Create ${businessType === 'restaurant' ? 'Restaurant' : 'Guest House'} Account`}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <button
          type="button"
          onClick={onClose}
          className="w-full text-center text-xs text-stone-500 hover:text-stone-300 mt-4 transition cursor-pointer"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}
