import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  onSnapshot,
  writeBatch
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Business, MenuCategory, MenuItem, ExtractedCategory, ExtractedMenuItem, MenuStyle } from '../types';
import { SEED_BUSINESSES, SEED_CATEGORIES, SEED_ITEMS } from '../data/seedData';
import { getStoredShops, storedShopToBusiness } from '../utils/shopPersistence';

const BUSINESSES_COLLECTION = 'businesses';
const LOCAL_STORAGE_CUSTOM_BIZ_KEY = 'qr_menu_custom_businesses_cache';
const LOCAL_STORAGE_DELETED_BIZ_KEY = 'qr_menu_deleted_businesses_list';
const LOCAL_STORAGE_CUSTOM_MENUS_KEY = 'qr_menu_custom_menus_by_biz_v2';

// In-memory / localStorage cache for menus isolated by business ID: { [businessId: string]: { categories: MenuCategory[], items: MenuItem[] } }
export function getLocalMenuCache(businessId: string): { categories: MenuCategory[]; items: MenuItem[] } {
  const normalizedId = businessId === 'city_diner' ? 'city-diner' : businessId;
  if (typeof window === 'undefined' || !businessId) {
    const cats = SEED_CATEGORIES.filter(c => c.businessId === businessId || c.businessId === normalizedId);
    const itms = SEED_ITEMS.filter(i => i.businessId === businessId || i.businessId === normalizedId);
    return {
      categories: cats.map(c => ({ ...c, businessId })),
      items: itms.map(i => ({ ...i, businessId }))
    };
  }
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_CUSTOM_MENUS_KEY);
    if (raw) {
      const allMenus = JSON.parse(raw);
      if (allMenus && (allMenus[businessId] || allMenus[normalizedId])) {
        const entry = allMenus[businessId] || allMenus[normalizedId];
        const cats = Array.isArray(entry.categories) ? entry.categories : [];
        const itms = Array.isArray(entry.items) ? entry.items : [];
        if (cats.length > 0) {
          return {
            categories: cats.map((c: MenuCategory) => ({ ...c, businessId })),
            items: itms.map((i: MenuItem) => {
              const seedMatch = SEED_ITEMS.find(si => si.id === i.id);
              return {
                ...i,
                businessId,
                variants: i.variants && i.variants.length > 0 ? i.variants : seedMatch?.variants
              };
            })
          };
        }
      }
    }
  } catch (err) {
    console.warn('Error reading local menu cache for business', businessId, err);
  }

  // Fallback to seed data strictly for this businessId or normalized counterpart
  const fallbackCats = SEED_CATEGORIES.filter(c => c.businessId === businessId || c.businessId === normalizedId);
  const fallbackItems = SEED_ITEMS.filter(i => i.businessId === businessId || i.businessId === normalizedId);
  return {
    categories: fallbackCats.map(c => ({ ...c, businessId })),
    items: fallbackItems.map(i => ({ ...i, businessId }))
  };
}

export function saveLocalMenuCache(businessId: string, categories: MenuCategory[], items: MenuItem[]) {
  if (typeof window === 'undefined' || !businessId) return;
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_CUSTOM_MENUS_KEY);
    const allMenus = raw ? JSON.parse(raw) : {};
    allMenus[businessId] = {
      categories: categories.map(c => ({ ...c, businessId })),
      items: items.map(i => ({ ...i, businessId }))
    };
    localStorage.setItem(LOCAL_STORAGE_CUSTOM_MENUS_KEY, JSON.stringify(allMenus));
  } catch (err) {
    console.warn('Error saving local menu cache for business', businessId, err);
  }
}

// Helper to get list of deleted business IDs
export function getDeletedBusinessIds(): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_DELETED_BIZ_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

// Helper to mark a business as deleted locally
export function markBusinessDeletedLocally(businessId: string) {
  if (typeof window === 'undefined' || !businessId) return;
  try {
    const deleted = getDeletedBusinessIds();
    if (!deleted.includes(businessId)) {
      localStorage.setItem(LOCAL_STORAGE_DELETED_BIZ_KEY, JSON.stringify([...deleted, businessId]));
    }
    // Also remove from custom cache if present
    const custom = getLocalCustomBusinesses().filter(b => b.id !== businessId);
    localStorage.setItem(LOCAL_STORAGE_CUSTOM_BIZ_KEY, JSON.stringify(custom));
  } catch (err) {
    console.warn('Could not record deleted business in local storage:', err);
  }
}

// Filter helper to ensure no empty, null, or '/b/' stub entries leak into state
function isValidBusinessRecord(b: any): b is Business {
  if (!b || typeof b !== 'object') return false;
  const id = (b.id || '').trim();
  const name = (b.name || '').trim();
  if (!id || !name) return false;
  if (id === '/b/' || id === 'b' || id === '/b' || name === '/b/' || name.toLowerCase() === 'untitled') return false;
  return true;
}

// Helper to get locally cached businesses
export function getLocalCustomBusinesses(): Business[] {
  if (typeof window === 'undefined') return [];
  try {
    const deletedIds = new Set(getDeletedBusinessIds());
    const raw = localStorage.getItem(LOCAL_STORAGE_CUSTOM_BIZ_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Business[];
    if (!Array.isArray(parsed)) return [];
    // Filter out invalid/empty records and deleted ones
    return parsed.filter(b => isValidBusinessRecord(b) && !deletedIds.has(b.id));
  } catch {
    return [];
  }
}

// Helper to save business into local cache
export function saveLocalCustomBusiness(biz: Business) {
  if (typeof window === 'undefined' || !isValidBusinessRecord(biz)) return;
  try {
    // If it was previously marked deleted, unmark it
    const deleted = getDeletedBusinessIds().filter(id => id !== biz.id);
    localStorage.setItem(LOCAL_STORAGE_DELETED_BIZ_KEY, JSON.stringify(deleted));

    const existing = getLocalCustomBusinesses();
    // Update existing entry by ID in-place if present, otherwise prepend
    const existingIndex = existing.findIndex(b => b.id === biz.id);
    let updated: Business[];
    if (existingIndex >= 0) {
      updated = [...existing];
      updated[existingIndex] = biz;
    } else {
      updated = [biz, ...existing.filter(b => b.id !== biz.id)];
    }
    localStorage.setItem(LOCAL_STORAGE_CUSTOM_BIZ_KEY, JSON.stringify(updated.filter(isValidBusinessRecord)));
  } catch (err) {
    console.warn('Could not save business to local cache:', err);
  }
}

// Merge seed, Firestore, and locally cached businesses without duplicates
// Custom edits or Firestore edits take precedence over default hardcoded seed data
export function mergeAllBusinesses(firestoreList: Business[] = []): Business[] {
  const custom = getLocalCustomBusinesses();
  const deletedIds = new Set(getDeletedBusinessIds());
  const map = new Map<string, Business>();

  // 1. Seed defaults (lowest priority)
  for (const b of SEED_BUSINESSES) {
    if (isValidBusinessRecord(b) && !deletedIds.has(b.id)) {
      map.set(b.id, b);
    }
  }

  // 2. Custom local cache (overrides seed when edited locally)
  for (const b of custom) {
    if (isValidBusinessRecord(b) && !deletedIds.has(b.id)) {
      map.set(b.id, b);
    }
  }

  // 3. Firestore (highest priority if live cloud record exists)
  for (const b of firestoreList) {
    if (isValidBusinessRecord(b) && !deletedIds.has(b.id)) {
      map.set(b.id, b);
    }
  }

  // 4. Ensure DEFAULT_SHOPS / pwa_restaurants (kannayah, city_diner) are always present with tables & features
  try {
    const storedShops = getStoredShops();
    for (const shop of storedShops) {
      if (!deletedIds.has(shop.id)) {
        const existing = map.get(shop.id);
        if (existing) {
          map.set(shop.id, {
            ...existing,
            tables: Array.isArray(shop.tables) && shop.tables.length > 0 ? shop.tables : existing.tables,
            features: { ...(existing.features || {}), ...(shop.features || {}) }
          });
        } else {
          map.set(shop.id, storedShopToBusiness(shop));
        }
      }
    }
  } catch (err) {
    console.warn('Could not load stored shops in mergeAllBusinesses', err);
  }

  return Array.from(map.values()).filter(isValidBusinessRecord);
}

// Initialize sample data into Firestore if Firestore is empty
export async function seedInitialDataIfNeeded(): Promise<void> {
  try {
    const businessRef = doc(db, BUSINESSES_COLLECTION, 'sri-murugan-tiffin-center');
    const docSnap = await getDoc(businessRef);
    
    if (!docSnap.exists()) {
      console.log('Seeding initial Indian restaurant data into Firestore...');
      const batch = writeBatch(db);

      // Seed businesses
      for (const biz of SEED_BUSINESSES) {
        const bDoc = doc(db, BUSINESSES_COLLECTION, biz.id);
        batch.set(bDoc, biz);
      }

      // Seed categories
      for (const cat of SEED_CATEGORIES) {
        const catDoc = doc(db, `${BUSINESSES_COLLECTION}/${cat.businessId}/categories`, cat.id);
        batch.set(catDoc, cat);
      }

      // Seed items
      for (const item of SEED_ITEMS) {
        const itemDoc = doc(db, `${BUSINESSES_COLLECTION}/${item.businessId}/items`, item.id);
        batch.set(itemDoc, item);
      }

      await batch.commit();
      console.log('Seed data successfully committed to Firestore');
    }
  } catch (error) {
    console.warn('Could not connect to Firestore for seed, using offline/seed fallbacks:', error);
  }
}

// Fetch single business by ID
export async function getBusinessById(businessId: string): Promise<Business | null> {
  try {
    const docRef = doc(db, BUSINESSES_COLLECTION, businessId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as Business;
    }
  } catch (err) {
    console.error(`Error fetching business ${businessId} from Firestore:`, err);
  }
  // Check local cache, then fallback to seed
  const allMerged = mergeAllBusinesses();
  return allMerged.find(b => b.id === businessId) || null;
}

// Check if a business ID already exists
export async function checkIfBusinessIdExists(businessId: string): Promise<boolean> {
  // Check local seed and local cache first
  const allMerged = mergeAllBusinesses();
  if (allMerged.some(b => b.id === businessId)) {
    return true;
  }
  try {
    const docRef = doc(db, BUSINESSES_COLLECTION, businessId);
    const snap = await getDoc(docRef);
    return snap.exists();
  } catch {
    return false;
  }
}

// Subscribe to a business in real-time
export function subscribeToBusiness(
  businessId: string,
  callback: (business: Business | null) => void
): () => void {
  try {
    const docRef = doc(db, BUSINESSES_COLLECTION, businessId);
    return onSnapshot(
      docRef,
      (snapshot) => {
        if (snapshot.exists()) {
          callback(snapshot.data() as Business);
        } else {
          const fallback = mergeAllBusinesses().find(b => b.id === businessId) || null;
          callback(fallback);
        }
      },
      (error) => {
        console.warn('Firestore subscription error for business:', error);
        const fallback = mergeAllBusinesses().find(b => b.id === businessId) || null;
        callback(fallback);
      }
    );
  } catch (e) {
    console.error('Failed to subscribe to business:', e);
    const fallback = mergeAllBusinesses().find(b => b.id === businessId) || null;
    callback(fallback);
    return () => {};
  }
}

// Subscribe to categories
export function subscribeToCategories(
  businessId: string,
  callback: (categories: MenuCategory[]) => void
): () => void {
  try {
    const catsCol = collection(db, `${BUSINESSES_COLLECTION}/${businessId}/categories`);
    const q = query(catsCol, orderBy('displayOrder', 'asc'));
    return onSnapshot(
      q,
      (snapshot) => {
        if (!snapshot.empty) {
          const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as MenuCategory)).filter(c => c.businessId === businessId);
          // Sync local isolated cache
          const currentLocal = getLocalMenuCache(businessId);
          saveLocalMenuCache(businessId, list, currentLocal.items);
          callback(list);
        } else {
          const fallback = getLocalMenuCache(businessId).categories;
          callback(fallback);
        }
      },
      (err) => {
        console.warn('Firestore subscription error for categories:', err);
        const fallback = getLocalMenuCache(businessId).categories;
        callback(fallback);
      }
    );
  } catch (e) {
    console.error('Failed to subscribe to categories:', e);
    const fallback = getLocalMenuCache(businessId).categories;
    callback(fallback);
    return () => {};
  }
}

// Subscribe to menu items
export function subscribeToMenuItems(
  businessId: string,
  callback: (items: MenuItem[]) => void
): () => void {
  try {
    const itemsCol = collection(db, `${BUSINESSES_COLLECTION}/${businessId}/items`);
    const q = query(itemsCol, orderBy('displayOrder', 'asc'));
    return onSnapshot(
      q,
      (snapshot) => {
        if (!snapshot.empty) {
          const list = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as MenuItem)).filter(i => i.businessId === businessId);
          // Sync local isolated cache
          const currentLocal = getLocalMenuCache(businessId);
          saveLocalMenuCache(businessId, currentLocal.categories, list);
          callback(list);
        } else {
          const fallback = getLocalMenuCache(businessId).items;
          callback(fallback);
        }
      },
      (err) => {
        console.warn('Firestore subscription error for items:', err);
        const fallback = getLocalMenuCache(businessId).items;
        callback(fallback);
      }
    );
  } catch (e) {
    console.error('Failed to subscribe to items:', e);
    const fallback = getLocalMenuCache(businessId).items;
    callback(fallback);
    return () => {};
  }
}

// List all businesses for owner / selector
export async function getAllBusinesses(): Promise<Business[]> {
  try {
    const colRef = collection(db, BUSINESSES_COLLECTION);
    const snap = await getDocs(colRef);
    if (!snap.empty) {
      const list = snap.docs.map(d => d.data() as Business);
      return mergeAllBusinesses(list);
    }
  } catch (err) {
    console.warn('Error getting all businesses from Firestore:', err);
  }
  return mergeAllBusinesses();
}

// Subscribe to all businesses in real-time
export function subscribeToAllBusinesses(
  callback: (businesses: Business[]) => void
): () => void {
  try {
    const colRef = collection(db, BUSINESSES_COLLECTION);
    return onSnapshot(
      colRef,
      (snapshot) => {
        if (!snapshot.empty) {
          const list = snapshot.docs.map(d => d.data() as Business);
          callback(mergeAllBusinesses(list));
        } else {
          callback(mergeAllBusinesses());
        }
      },
      (err) => {
        console.warn('Firestore subscription error for businesses list:', err);
        callback(mergeAllBusinesses());
      }
    );
  } catch (e) {
    console.error('Failed to subscribe to all businesses:', e);
    callback(mergeAllBusinesses());
    return () => {};
  }
}

// Save or update business with offline fallback and persistence
export async function saveBusiness(business: Business): Promise<void> {
  const updatedBusiness: Business = {
    ...business,
    updatedAt: new Date().toISOString()
  };

  // Always update local cache so UI immediately succeeds even offline
  saveLocalCustomBusiness(updatedBusiness);

  try {
    const docRef = doc(db, BUSINESSES_COLLECTION, business.id);
    await setDoc(docRef, updatedBusiness, { merge: true });
  } catch (err) {
    console.warn(`Firestore saveBusiness failed for ${business.id}, but saved to local fallback:`, err);
  }
}

// Permanently delete a business profile, its subcollections, and remove from cache
export async function deleteBusiness(businessId: string): Promise<void> {
  if (!businessId) return;

  // 1. Mark as deleted locally and purge from cache
  markBusinessDeletedLocally(businessId);

  // 2. Delete from Firestore if online
  try {
    const docRef = doc(db, BUSINESSES_COLLECTION, businessId);
    await deleteDoc(docRef);
  } catch (err) {
    console.warn(`Firestore deleteBusiness failed for ${businessId}, removed locally:`, err);
  }
}

// Explicit alias for deleteBusiness as requested
export const deleteRestaurant = deleteBusiness;

// Save category
export async function saveCategory(category: MenuCategory): Promise<void> {
  // Update local cache
  const local = getLocalMenuCache(category.businessId);
  const existingIdx = local.categories.findIndex(c => c.id === category.id);
  let updatedCats: MenuCategory[];
  if (existingIdx >= 0) {
    updatedCats = [...local.categories];
    updatedCats[existingIdx] = category;
  } else {
    updatedCats = [...local.categories, category];
  }
  saveLocalMenuCache(category.businessId, updatedCats, local.items);

  try {
    const docRef = doc(db, `${BUSINESSES_COLLECTION}/${category.businessId}/categories`, category.id);
    await setDoc(docRef, category, { merge: true });
  } catch (err) {
    console.warn(`Firestore saveCategory failed for ${category.id}, saved to local:`, err);
  }
}

// Delete category
export async function deleteCategory(businessId: string, categoryId: string): Promise<void> {
  const local = getLocalMenuCache(businessId);
  const updatedCats = local.categories.filter(c => c.id !== categoryId);
  saveLocalMenuCache(businessId, updatedCats, local.items);

  try {
    const docRef = doc(db, `${BUSINESSES_COLLECTION}/${businessId}/categories`, categoryId);
    await deleteDoc(docRef);
  } catch (err) {
    console.warn(`Firestore deleteCategory failed for ${categoryId}, removed from local:`, err);
  }
}

// Save item
export async function saveMenuItem(item: MenuItem): Promise<void> {
  const local = getLocalMenuCache(item.businessId);
  const existingIdx = local.items.findIndex(i => i.id === item.id);
  let updatedItems: MenuItem[];
  if (existingIdx >= 0) {
    updatedItems = [...local.items];
    updatedItems[existingIdx] = item;
  } else {
    updatedItems = [...local.items, item];
  }
  saveLocalMenuCache(item.businessId, local.categories, updatedItems);

  try {
    const docRef = doc(db, `${BUSINESSES_COLLECTION}/${item.businessId}/items`, item.id);
    await setDoc(docRef, item, { merge: true });
  } catch (err) {
    console.warn(`Firestore saveMenuItem failed for ${item.id}, saved to local:`, err);
  }
}

// Delete item
export async function deleteMenuItem(businessId: string, itemId: string): Promise<void> {
  const local = getLocalMenuCache(businessId);
  const updatedItems = local.items.filter(i => i.id !== itemId);
  saveLocalMenuCache(businessId, local.categories, updatedItems);

  try {
    const docRef = doc(db, `${BUSINESSES_COLLECTION}/${businessId}/items`, itemId);
    await deleteDoc(docRef);
  } catch (err) {
    console.warn(`Firestore deleteMenuItem failed for ${itemId}, removed from local:`, err);
  }
}

// Fast toggle item availability (Sold out / In stock)
export async function toggleItemAvailability(
  businessId: string,
  itemId: string,
  isAvailable: boolean
): Promise<void> {
  const local = getLocalMenuCache(businessId);
  const updatedItems = local.items.map(i => i.id === itemId ? { ...i, isAvailable } : i);
  saveLocalMenuCache(businessId, local.categories, updatedItems);

  try {
    const docRef = doc(db, `${BUSINESSES_COLLECTION}/${businessId}/items`, itemId);
    await updateDoc(docRef, { isAvailable });
  } catch (err) {
    console.warn(`Firestore toggleItemAvailability failed for ${itemId}, updated in local:`, err);
  }
}

// Apply AI-extracted menu to business (Supports replace all or append + menuStyle)
export async function applyExtractedMenu(
  businessId: string,
  extractedCategories: ExtractedCategory[],
  extractedItems: ExtractedMenuItem[],
  mode: 'replace' | 'append',
  existingCategories: MenuCategory[],
  existingItems: MenuItem[],
  selectedStyle?: MenuStyle
): Promise<{ addedCategoriesCount: number; addedItemsCount: number }> {
  try {
    const batch = writeBatch(db);

    // If a menu style was chosen, update the business document safely with set merge:true
    if (selectedStyle) {
      const bizRef = doc(db, BUSINESSES_COLLECTION, businessId);
      batch.set(bizRef, {
        menuStyle: selectedStyle,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }

    // If replace mode, delete all existing items and categories for this business
    if (mode === 'replace') {
      for (const item of existingItems) {
        const itemRef = doc(db, `${BUSINESSES_COLLECTION}/${businessId}/items`, item.id);
        batch.delete(itemRef);
      }
      for (const cat of existingCategories) {
        const catRef = doc(db, `${BUSINESSES_COLLECTION}/${businessId}/categories`, cat.id);
        batch.delete(catRef);
      }
    }

    // Map to store Category Name -> Category ID
    const categoryNameToIdMap = new Map<string, string>();
    let catDisplayOrder = mode === 'replace' ? 1 : (existingCategories.length + 1);
    let addedCategoriesCount = 0;

    // For append mode, populate existing categories first
    if (mode === 'append') {
      for (const cat of existingCategories) {
        categoryNameToIdMap.set(cat.name.trim().toLowerCase(), cat.id);
      }
    }

    // Collect all final categories and items to save to local cache
    const finalSavedCategories: MenuCategory[] = [];
    const finalSavedItems: MenuItem[] = [];

    // Process categories
    for (const cat of extractedCategories) {
      const cleanName = cat.name.trim();
      const lookupKey = cleanName.toLowerCase();

      if (!categoryNameToIdMap.has(lookupKey)) {
        const catId = `cat_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
        const newCat: MenuCategory = {
          id: catId,
          businessId,
          name: cleanName,
          description: cat.description || '',
          displayOrder: catDisplayOrder++,
          isActive: true
        };
        const catRef = doc(db, `${BUSINESSES_COLLECTION}/${businessId}/categories`, catId);
        batch.set(catRef, newCat);
        categoryNameToIdMap.set(lookupKey, catId);
        finalSavedCategories.push(newCat);
        addedCategoriesCount++;
      }
    }

    // Process items
    let itemDisplayOrder = mode === 'replace' ? 1 : (existingItems.length + 1);
    let addedItemsCount = 0;

    for (const item of extractedItems) {
      const catKey = (item.categoryName || 'General').trim().toLowerCase();
      let targetCatId = categoryNameToIdMap.get(catKey);

      // Fallback if category wasn't registered
      if (!targetCatId) {
        targetCatId = `cat_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
        const fallbackCat: MenuCategory = {
          id: targetCatId,
          businessId,
          name: item.categoryName || 'General Dishes',
          displayOrder: catDisplayOrder++,
          isActive: true
        };
        const catRef = doc(db, `${BUSINESSES_COLLECTION}/${businessId}/categories`, targetCatId);
        batch.set(catRef, fallbackCat);
        categoryNameToIdMap.set(catKey, targetCatId);
        finalSavedCategories.push(fallbackCat);
        addedCategoriesCount++;
      }

      const itemId = `item_${Date.now()}_${addedItemsCount}_${Math.random().toString(36).substr(2, 6)}`;
      const exactPrice = typeof item.price === 'number' ? item.price : 0;
      const newMenuItem: MenuItem = {
        id: itemId,
        businessId,
        categoryId: targetCatId,
        name: item.name.trim(),
        description: item.description?.trim() || '',
        price: exactPrice,
        isVeg: item.isVeg,
        isAvailable: item.isAvailable,
        displayOrder: itemDisplayOrder++
      };

      console.log(`[DB applyExtractedMenu] Processing item: "${newMenuItem.name}" | Price: ₹${exactPrice} | Category: "${catKey}"`);

      const itemRef = doc(db, `${BUSINESSES_COLLECTION}/${businessId}/items`, itemId);
      batch.set(itemRef, newMenuItem);
      finalSavedItems.push(newMenuItem);
      addedItemsCount++;
    }

    // Sync isolated local cache for this specific business
    const allFinalCats = mode === 'replace' 
      ? finalSavedCategories 
      : [...existingCategories, ...finalSavedCategories];
    const allFinalItems = mode === 'replace' 
      ? finalSavedItems 
      : [...existingItems, ...finalSavedItems];
    saveLocalMenuCache(businessId, allFinalCats, allFinalItems);

    console.log(`[DB applyExtractedMenu] Saved ${addedCategoriesCount} categories & ${addedItemsCount} items for businessId: ${businessId}`);

    try {
      await batch.commit();
    } catch (batchErr) {
      console.warn('Batch commit to Firestore had an issue, saved to isolated local cache:', batchErr);
    }
    return { addedCategoriesCount, addedItemsCount };
  } catch (error) {
    console.error('Error applying extracted menu in Firestore batch:', error);
    throw error;
  }
}

