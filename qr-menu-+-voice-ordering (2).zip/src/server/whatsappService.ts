import makeWASocket, {
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  WASocket,
  ConnectionState
} from '@whiskeysockets/baileys';
import { Boom } from '@hapi/boom';
import qrcode from 'qrcode';
import qrcodeTerminal from 'qrcode-terminal';
import pino from 'pino';
import fs from 'fs';
import path from 'path';

export interface OrderPayloadItem {
  name: string;
  quantity: number;
  price: number;
  unitPrice?: number;
  isVeg?: string;
  selectedOptions?: string[];
  customNote?: string;
  totalItemPrice?: number;
}

export interface OrderPayload {
  id: string;
  restaurantId: string;
  orderId: number; // Auto-incrementing daily per restaurant, starting at #1
  orderSerial?: string; // Sequential formatted serial number (e.g. #001, #002)
  orderDate: string; // YYYY-MM-DD
  orderTime: string; // HH:MM:SS format
  tableNumber: string;
  customerName?: string;
  customerPhone?: string;
  assignedStaffName?: string; // e.g. "Waiter Ramesh" (Daily Table & Duty Allocation)
  items: OrderPayloadItem[];
  totalPrice: number;
  merchantPhone?: string;
  alertSoundType?: 'ringtone' | 'church_bell';
  customerNotes?: string;
  restaurantName?: string;
  restaurantAddress?: string;
  currencySymbol?: string;
  formattedSummary?: string;
  createdAt: string;
  status: 'pending' | 'accepted' | 'completed' | 'cancelled';
  whatsappStatus?: 'sent' | 'failed' | 'not_configured' | 'pending' | 'not_paired';
}

class WhatsAppNotificationService {
  private sock: WASocket | null = null;
  private qrCodeDataUrl: string | null = null;
  private qrCodeRaw: string | null = null;
  private connectionStatus: 'disconnected' | 'connecting' | 'qr_ready' | 'connected' = 'disconnected';
  private pairedUser: string | null = null;
  private authDir: string = path.join(process.cwd(), '.baileys_auth_info');
  private sseClients: Array<(data: any) => void> = [];
  private recentOrders: OrderPayload[] = [];
  private isInitializing: boolean = false;

  constructor() {
    if (!fs.existsSync(this.authDir)) {
      try {
        fs.mkdirSync(this.authDir, { recursive: true });
      } catch (err) {
        console.error('[Baileys] Error creating auth folder:', err);
      }
    }
  }

  public async initialize(): Promise<void> {
    if (this.isInitializing || this.connectionStatus === 'connected') {
      return;
    }

    this.isInitializing = true;
    this.connectionStatus = 'connecting';
    console.log('[Baileys] Starting WhatsApp background service with $0-cost WebSocket engine...');

    try {
      const { state, saveCreds } = await useMultiFileAuthState(this.authDir);
      const { version, isLatest } = await fetchLatestBaileysVersion();
      console.log(`[Baileys] Using WA version v${version.join('.')}, isLatest: ${isLatest}`);

      const logger = pino({ level: 'silent' });

      this.sock = makeWASocket({
        version,
        logger,
        printQRInTerminal: false,
        auth: state,
        browser: ['QR Menu Alert Engine', 'Chrome', '1.0.0'],
        syncFullHistory: false,
        generateHighQualityLinkPreview: false,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 60000,
        keepAliveIntervalMs: 30000
      });

      this.sock.ev.on('creds.update', saveCreds);

      this.sock.ev.on('connection.update', async (update: Partial<ConnectionState>) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr) {
          this.qrCodeRaw = qr;
          this.connectionStatus = 'qr_ready';
          try {
            this.qrCodeDataUrl = await qrcode.toDataURL(qr, { margin: 2, scale: 6 });
            console.log('\n======================================================');
            console.log('📱 [WHATSAPP ZERO-COST PAIRING QR CODE]');
            console.log('Scan this with WhatsApp on your phone (Linked Devices):');
            console.log('======================================================\n');
            qrcodeTerminal.generate(qr, { small: true });
            console.log('\n======================================================\n');
          } catch (e) {
            console.error('[Baileys] Error generating QR data URL:', e);
          }
          this.broadcastStatus();
        }

        if (connection === 'close') {
          const statusCode = (lastDisconnect?.error as Boom)?.output?.statusCode;
          const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
          console.log(`[Baileys] Connection closed (status: ${statusCode}). Reconnecting: ${shouldReconnect}`);
          
          this.connectionStatus = 'disconnected';
          this.qrCodeDataUrl = null;
          this.pairedUser = null;
          this.isInitializing = false;
          this.broadcastStatus();

          if (shouldReconnect) {
            setTimeout(() => this.initialize(), 3000);
          }
        } else if (connection === 'open') {
          console.log('✅ [Baileys] WhatsApp Web connection successfully OPENED!');
          this.connectionStatus = 'connected';
          this.qrCodeDataUrl = null;
          this.qrCodeRaw = null;
          this.isInitializing = false;
          const userJid = this.sock?.user?.id;
          this.pairedUser = userJid ? userJid.split(':')[0] : 'Linked Device';
          console.log(`[Baileys] Connected as merchant WhatsApp ID: ${this.pairedUser}`);
          this.broadcastStatus();
        }
      });

    } catch (error) {
      console.error('[Baileys] Initialization error:', error);
      this.connectionStatus = 'disconnected';
      this.isInitializing = false;
      this.broadcastStatus();
    }
  }

  public getStatus() {
    return {
      status: this.connectionStatus,
      qrCodeDataUrl: this.qrCodeDataUrl,
      pairedUser: this.pairedUser,
      authDir: this.authDir,
      connected: this.connectionStatus === 'connected'
    };
  }

  public async disconnectAndReset(): Promise<void> {
    try {
      if (this.sock) {
        await this.sock.logout();
        this.sock = null;
      }
    } catch {
      // Ignore logout errors if socket is dead
    }
    try {
      if (fs.existsSync(this.authDir)) {
        fs.rmSync(this.authDir, { recursive: true, force: true });
        fs.mkdirSync(this.authDir, { recursive: true });
      }
    } catch (e) {
      console.error('[Baileys] Error clearing auth folder:', e);
    }
    this.connectionStatus = 'disconnected';
    this.pairedUser = null;
    this.qrCodeDataUrl = null;
    this.broadcastStatus();
    setTimeout(() => this.initialize(), 1000);
  }

  public formatOrderMessage(order: OrderPayload): string {
    const storeName = (order.restaurantName || 'RESTAURANT').trim();
    const orderId = order.orderId || (order.id ? order.id.slice(-4) : Math.floor(1000 + Math.random() * 9000));
    
    // Parse order date or use now
    const d = order.createdAt ? new Date(order.createdAt) : new Date();
    const validDate = isNaN(d.getTime()) ? new Date() : d;
    const day = String(validDate.getDate()).padStart(2, '0');
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const formattedDate = `${day} ${months[validDate.getMonth()]} ${validDate.getFullYear()}`;
    
    let hours = validDate.getHours();
    const minutes = String(validDate.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    const formattedTime = `${String(hours).padStart(2, '0')}:${minutes} ${ampm}`;

    const rawLoc = (order.tableNumber || '').trim();
    let tableFormatted = 'Takeaway';
    if (rawLoc) {
      if (/^(table|room)/i.test(rawLoc)) {
        tableFormatted = rawLoc;
      } else {
        tableFormatted = `Table ${rawLoc}`;
      }
    }

    const itemsFormattedList = order.items.map((item) => {
      const itemTotal = item.totalItemPrice !== undefined ? item.totalItemPrice : (item.unitPrice || item.price || 0) * item.quantity;
      let line = `• ${item.quantity}x ${item.name} ........ ₹${itemTotal}`;
      if (item.customNote && item.customNote.trim()) {
        line += `\n  ↳ Note: ${item.customNote.trim()}`;
      }
      return line;
    }).join('\n');

    let itemsSection = itemsFormattedList;
    if (order.customerNotes && order.customerNotes.trim()) {
      itemsSection += `\n\n📝 *Special Instructions:*\n${order.customerNotes.trim()}`;
    }

    const lines = [
      '━━━━━━━━━━━━━━━━━━━━━━━━━━━━',
      `🧾 *${storeName.toUpperCase()}*`,
      '📍 *Kitchen Order Ticket (KOT)*',
      '━━━━━━━━━━━━━━━━━━━━━━━━━━━━',
      '',
      `*Order ID:* #${orderId}`,
      `*Date:* ${formattedDate} | ${formattedTime}`,
      `*Table / Type:* ${tableFormatted}`,
      '',
      '────────────────────────────',
      '*ITEMS TO PREPARE*',
      '────────────────────────────',
      itemsSection,
      '',
      '────────────────────────────',
      `💰 *ESTIMATED TOTAL: ₹${order.totalPrice}*`,
      '────────────────────────────',
      '*_Taxes & service charges may apply on final bill._',
      '',
      `*Payment:* Cash / UPI at Counter`,
      '*Status:* ⏳ Pending Kitchen',
      '━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
    ];

    return lines.join('\n');
  }

  public async sendOrderToMerchant(order: OrderPayload): Promise<boolean> {
    if (!this.sock || this.connectionStatus !== 'connected') {
      // In preview or when unpaired, orders route through client-side WhatsApp intent
      return false;
    }

    const rawPhone = order.merchantPhone || this.pairedUser;
    if (!rawPhone) {
      console.warn('[Baileys] No target merchant phone number found.');
      return false;
    }

    // Clean phone number to WhatsApp JID format
    const cleanedDigits = rawPhone.replace(/\D/g, '');
    if (cleanedDigits.length < 7) {
      console.warn('[Baileys] Target phone number too short:', cleanedDigits);
      return false;
    }

    const targetJid = `${cleanedDigits}@s.whatsapp.net`;
    const messageText = this.formatOrderMessage(order);

    try {
      console.log(`[Baileys] Sending order notification to: ${targetJid}`);
      await this.sock.sendMessage(targetJid, { text: messageText });
      console.log(`✅ [Baileys] Order notification successfully sent to ${targetJid}`);
      return true;
    } catch (err: any) {
      console.error(`[Baileys] Failed to send WhatsApp message to ${targetJid}:`, err?.message || err);
      return false;
    }
  }

  // SSE (Server-Sent Events) live order dispatching
  public registerSSEClient(send: (data: any) => void) {
    this.sseClients.push(send);
    // Send initial state & recent orders
    send({
      type: 'INIT',
      waStatus: this.getStatus(),
      orders: this.recentOrders
    });
  }

  public unregisterSSEClient(send: (data: any) => void) {
    this.sseClients = this.sseClients.filter(client => client !== send);
  }

  public broadcast(payload: any) {
    this.sseClients.forEach(send => {
      try {
        send(payload);
      } catch (err) {
        // Client might have closed
      }
    });
  }

  public broadcastStatus() {
    this.broadcast({
      type: 'WA_STATUS',
      waStatus: this.getStatus()
    });
  }

  public addOrder(order: OrderPayload) {
    this.recentOrders.unshift(order);
    if (this.recentOrders.length > 200) {
      this.recentOrders = this.recentOrders.slice(0, 200);
    }
    // Broadcast live order event to all open dashboards
    this.broadcast({
      type: 'NEW_ORDER',
      order
    });
  }

  public getOrders(restaurantId?: string, orderDate?: string): OrderPayload[] {
    let filtered = this.recentOrders;
    if (restaurantId) {
      filtered = filtered.filter(o => o.restaurantId === restaurantId);
    }
    if (orderDate) {
      filtered = filtered.filter(o => o.orderDate === orderDate);
    }
    return filtered;
  }

  public updateOrderStatus(orderId: string, status: OrderPayload['status']): OrderPayload | null {
    const order = this.recentOrders.find(o => o.id === orderId);
    if (order) {
      order.status = status;
      this.broadcast({
        type: 'ORDER_UPDATED',
        order
      });
      return order;
    }
    return null;
  }
}

export const waService = new WhatsAppNotificationService();
