import { AppStaffRole, RolePermissions, StaffRoleConfig } from '../types';

export const STAFF_ROLE_STORAGE_KEY = 'restaurant_staff_role';
export const STAFF_NAME_STORAGE_KEY = 'restaurant_staff_name';
export const STAFF_LOGGED_IN_KEY = 'restaurant_staff_logged_in';

export const MASTER_ADMIN_TOKEN_KEY = 'qr_master_admin_session_token';
export const MASTER_ADMIN_SECRET_KEY = 'SUPERADMIN2026';

export const ROLE_CONFIGS: Record<AppStaffRole, StaffRoleConfig> = {
  owner: {
    role: 'owner',
    title: 'Owner / Admin',
    subtitle: 'Full System Control & Financials',
    badge: '👑 Full Authority',
    color: 'amber',
    icon: 'Crown',
    description: 'Full permissions including daily revenue totals, menu management, business configuration, and staff duty reports.',
    permissions: {
      canViewAllOrders: true,
      canAssignWaiters: true,
      canMuteAudioAlerts: true,
      canViewFinancialTotals: true,
      canViewStaffDutyReports: true,
      canManageMenu: true,
      canManageBusinessSettings: true,
      canAcceptOrders: true,
      canCompleteOrders: true,
      canAccessMasterAdmin: false,
    },
    allowedViews: ['customer', 'owner', 'orders', 'duty'],
    defaultView: 'orders',
  },
  manager: {
    role: 'manager',
    title: 'Captain / Manager',
    subtitle: 'Floor Coordination & Duty Control',
    badge: '🛡️ Supervisor',
    color: 'sky',
    icon: 'Shield',
    description: 'Permissions to view all table orders, assign waiters to tables, and mute audio alerts across devices. Financial totals are hidden.',
    permissions: {
      canViewAllOrders: true,
      canAssignWaiters: true,
      canMuteAudioAlerts: true,
      canViewFinancialTotals: false,
      canViewStaffDutyReports: true,
      canManageMenu: false,
      canManageBusinessSettings: false,
      canAcceptOrders: true,
      canCompleteOrders: true,
      canAccessMasterAdmin: false,
    },
    allowedViews: ['customer', 'orders', 'duty'],
    defaultView: 'orders',
  },
  waiter: {
    role: 'waiter',
    title: 'Waiter',
    subtitle: 'Table Service & Order Action',
    badge: '🤵 Table Service',
    color: 'emerald',
    icon: 'UserCheck',
    description: 'Direct table-level order ringing notifications, item checkoff, and instant customer service status updates.',
    permissions: {
      canViewAllOrders: false, // Waiters focus primarily on their assigned tables
      canAssignWaiters: false,
      canMuteAudioAlerts: true, // Can silence audio alerts for their tables
      canViewFinancialTotals: false,
      canViewStaffDutyReports: false,
      canManageMenu: false,
      canManageBusinessSettings: false,
      canAcceptOrders: true,
      canCompleteOrders: true,
      canAccessMasterAdmin: false,
    },
    allowedViews: ['customer', 'orders', 'duty'],
    defaultView: 'orders',
  },
  master_admin: {
    role: 'master_admin',
    title: 'Super Master Admin',
    subtitle: 'Platform-Wide Tenant & System Fleet Control',
    badge: '⚡ Platform Super Admin',
    color: 'purple',
    icon: 'ShieldAlert',
    description: 'Cross-tenant oversight, platform-wide gross revenue analytics, tenant status controls, and global order streams.',
    permissions: {
      canViewAllOrders: true,
      canAssignWaiters: true,
      canMuteAudioAlerts: true,
      canViewFinancialTotals: true,
      canViewStaffDutyReports: true,
      canManageMenu: true,
      canManageBusinessSettings: true,
      canAcceptOrders: true,
      canCompleteOrders: true,
      canAccessMasterAdmin: true,
    },
    allowedViews: ['customer', 'owner', 'orders', 'duty', 'master_admin'],
    defaultView: 'master_admin',
  },
};

/**
 * Retrieve current saved staff role from localStorage
 */
export function getStoredStaffRole(): AppStaffRole | null {
  if (typeof window === 'undefined') return null;
  try {
    const saved = localStorage.getItem(STAFF_ROLE_STORAGE_KEY) as AppStaffRole | null;
    if (saved && (saved === 'owner' || saved === 'manager' || saved === 'waiter' || saved === 'master_admin')) {
      return saved;
    }
  } catch (e) {
    console.warn('Unable to read staff role from localStorage:', e);
  }
  return null;
}

/**
 * Check if Master Admin token is active
 */
export function isMasterAdminAuthenticated(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const token = sessionStorage.getItem(MASTER_ADMIN_TOKEN_KEY) || localStorage.getItem(MASTER_ADMIN_TOKEN_KEY);
    return Boolean(token && token.length > 8);
  } catch {
    return false;
  }
}

/**
 * Store Master Admin session
 */
export function setMasterAdminAuthenticated(token: string): void {
  if (typeof window === 'undefined') return;
  try {
    sessionStorage.setItem(MASTER_ADMIN_TOKEN_KEY, token);
    localStorage.setItem(MASTER_ADMIN_TOKEN_KEY, token);
  } catch (e) {
    console.warn('Unable to save master admin session token:', e);
  }
}

/**
 * Clear Master Admin session
 */
export function clearMasterAdminAuthentication(): void {
  if (typeof window === 'undefined') return;
  try {
    sessionStorage.removeItem(MASTER_ADMIN_TOKEN_KEY);
    localStorage.removeItem(MASTER_ADMIN_TOKEN_KEY);
  } catch (e) {
    console.warn('Unable to clear master admin session:', e);
  }
}

/**
 * Retrieve saved staff name if available
 */
export function getStoredStaffName(): string {
  if (typeof window === 'undefined') return '';
  try {
    return localStorage.getItem(STAFF_NAME_STORAGE_KEY) || '';
  } catch {
    return '';
  }
}

/**
 * Save staff role and optional name to localStorage
 */
export function saveStoredStaffRole(role: AppStaffRole, staffName?: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STAFF_ROLE_STORAGE_KEY, role);
    localStorage.setItem(STAFF_LOGGED_IN_KEY, 'true');
    if (staffName !== undefined) {
      localStorage.setItem(STAFF_NAME_STORAGE_KEY, staffName);
    }
  } catch (e) {
    console.warn('Unable to save staff role to localStorage:', e);
  }
}

/**
 * Clear stored role (Log Out / Reset Role)
 */
export function clearStoredStaffRole(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(STAFF_ROLE_STORAGE_KEY);
    localStorage.removeItem(STAFF_LOGGED_IN_KEY);
    localStorage.removeItem(STAFF_NAME_STORAGE_KEY);
  } catch (e) {
    console.warn('Unable to clear staff role:', e);
  }
}

/**
 * Check if a role has a specific permission
 */
export function checkPermission(role: AppStaffRole, permission: keyof RolePermissions): boolean {
  const config = ROLE_CONFIGS[role];
  if (!config) return false;
  return Boolean(config.permissions[permission]);
}
