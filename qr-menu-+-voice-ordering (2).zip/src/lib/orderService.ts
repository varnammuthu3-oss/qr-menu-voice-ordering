/**
 * ==============================================================================
 * 📦 MULTI-TENANT RESTAURANT ORDER TRACKING & DAILY LOGS SERVICE (orderService.ts)
 * Logic:
 *  - Formats order summaries as: "Order #102 | Date: 2026-08-21 | Time: 16:30 | Table 4"
 *  - Multi-tenant isolation: All queries filtered strictly by restaurant_id
 *  - Per-restaurant auto-incrementing order numbers starting at #1 daily
 * ==============================================================================
 */

export interface RestaurantOrderRecord {
  id: string;
  restaurantId: string;
  orderId: number; // Auto-incrementing daily sequence starting at #1
  orderSerial?: string; // Sequential formatted serial number (e.g. #001, #002)
  orderDate: string; // YYYY-MM-DD
  orderTime: string; // HH:MM:SS format
  tableNumber: string;
  items: Array<{
    name: string;
    quantity: number;
    price: number;
    isVeg?: string;
  }>;
  totalPrice: number;
  customerName?: string;
  customerPhone?: string;
  customerNotes?: string;
  status: 'pending' | 'accepted' | 'preparing' | 'completed' | 'cancelled';
  alertSoundType?: 'ringtone' | 'church_bell';
  formattedSummary?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface InsertOrderInput {
  restaurantId: string;
  tableNumber: string;
  items: Array<{
    name: string;
    quantity: number;
    price: number;
    isVeg?: string;
  }>;
  totalPrice?: number;
  customerName?: string;
  customerPhone?: string;
  customerNotes?: string;
  alertSoundType?: 'ringtone' | 'church_bell';
  orderDate?: string;
  orderTime?: string;
  orderId?: number;
}

export function formatOrderSerialNumber(orderId: number): string {
  return `#${String(orderId).padStart(3, '0')}`;
}

/**
 * Formats order summary strictly as: "Order #001 | Date: 2026-08-21 | Time: 16:30 | Table 4"
 */
export function formatOrderSummary(order: {
  orderId?: number;
  order_id?: number;
  orderDate?: string;
  order_date?: string;
  orderTime?: string;
  order_time?: string;
  tableNumber?: string;
  table_number?: string;
  createdAt?: string;
  created_at?: string;
}): string {
  const num = order.orderId ?? order.order_id ?? 1;
  const serial = formatOrderSerialNumber(num);
  
  let dateStr = order.orderDate ?? order.order_date;
  let timeStr = order.orderTime ?? order.order_time;
  
  if (!dateStr || !timeStr) {
    const rawDate = new Date(order.createdAt ?? order.created_at ?? Date.now());
    if (!dateStr) {
      dateStr = rawDate.toISOString().slice(0, 10);
    }
    if (!timeStr) {
      timeStr = rawDate.toTimeString().slice(0, 8);
    }
  }

  // Format time to HH:MM (e.g., 16:30)
  const shortTime = timeStr.slice(0, 5);
  const table = order.tableNumber ?? order.table_number ?? 'Table 1';
  const tableLabel = table.toLowerCase().startsWith('table') || table.toLowerCase().startsWith('room') || table.toLowerCase().includes('parcel') 
    ? table 
    : `Table ${table}`;

  return `Order ${serial} | Date: ${dateStr} | Time: ${shortTime} | ${tableLabel}`;
}

/**
 * In-memory fallback sequence counter per restaurant per date (used when offline/standalone)
 */
const dailyRestaurantSequenceMap = new Map<string, number>();

function getDailySequenceKey(restaurantId: string, dateStr: string): string {
  return `${restaurantId}:${dateStr}`;
}

export function getNextLocalDailyOrderId(restaurantId: string, dateStr: string): number {
  const key = getDailySequenceKey(restaurantId, dateStr);
  const current = dailyRestaurantSequenceMap.get(key) || 0;
  const next = current + 1;
  dailyRestaurantSequenceMap.set(key, next);
  return next;
}

export function resetDailySequence(restaurantId: string, dateStr: string, startAt: number = 0) {
  const key = getDailySequenceKey(restaurantId, dateStr);
  dailyRestaurantSequenceMap.set(key, startAt);
}

/**
 * JavaScript helper: Inserts a new order with multi-tenant isolation and per-restaurant daily sequence
 */
export async function insertRestaurantOrder(
  input: InsertOrderInput,
  supabaseClient?: any
): Promise<RestaurantOrderRecord> {
  const now = new Date();
  const orderDate = input.orderDate || now.toISOString().slice(0, 10); // YYYY-MM-DD
  const orderTime = input.orderTime || now.toTimeString().slice(0, 8); // HH:MM:SS
  const computedTotal = input.totalPrice ?? input.items.reduce((sum, it) => sum + (it.price || 0) * (it.quantity || 1), 0);
  // Validate required fields
  if (!input.restaurantId || typeof input.restaurantId !== 'string' || !input.restaurantId.trim()) {
    throw new Error('Missing required field: restaurant_id');
  }

  const tableNum = String(input.tableNumber || '').trim();
  if (!tableNum) {
    throw new Error('Missing required field: table_number');
  }

  // If connected to Supabase client
  if (supabaseClient) {
    const { data, error } = await supabaseClient
      .from('orders')
      .insert({
        restaurant_id: input.restaurantId.trim(),
        table_number: tableNum,
        items: input.items,
        total_price: computedTotal,
        customer_name: input.customerName || null,
        customer_phone: input.customerPhone || null,
        customer_notes: input.customerNotes || null,
        alert_sound_type: input.alertSoundType || 'church_bell',
        order_date: orderDate,
        order_time: orderTime,
        status: 'pending'
      })
      .select()
      .single();

    if (error) {
      throw new Error(`Supabase order insert failed: ${error.message || error.details || error.hint || JSON.stringify(error)}`);
    }

    if (data) {
      const orderId = data.order_id || 1;
      const formattedSummary = formatOrderSummary({
        order_id: orderId,
        order_date: data.order_date,
        order_time: data.order_time,
        table_number: data.table_number
      });

      return {
        id: data.id,
        restaurantId: data.restaurant_id,
        orderId,
        orderSerial: formatOrderSerialNumber(orderId),
        orderDate: data.order_date,
        orderTime: data.order_time,
        tableNumber: data.table_number,
        items: data.items,
        totalPrice: Number(data.total_price),
        customerName: data.customer_name,
        customerPhone: data.customer_phone,
        customerNotes: data.customer_notes,
        status: data.status,
        alertSoundType: data.alert_sound_type,
        formattedSummary,
        createdAt: data.created_at
      };
    }
  }

  // Standalone / API fallback engine
  const orderId = input.orderId || getNextLocalDailyOrderId(input.restaurantId, orderDate);
  const formattedSummary = formatOrderSummary({
    orderId,
    orderDate,
    orderTime,
    tableNumber: tableNum
  });

  const record: RestaurantOrderRecord = {
    id: `ord_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    restaurantId: input.restaurantId,
    orderId,
    orderSerial: formatOrderSerialNumber(orderId),
    orderDate,
    orderTime,
    tableNumber: tableNum,
    items: input.items,
    totalPrice: computedTotal,
    customerName: input.customerName,
    customerPhone: input.customerPhone,
    customerNotes: input.customerNotes,
    status: 'pending',
    alertSoundType: input.alertSoundType || 'church_bell',
    formattedSummary,
    createdAt: now.toISOString()
  };

  return record;
}

/**
 * JavaScript helper: Fetches daily order logs filtered strictly by restaurant_id (Multi-Tenant Isolation)
 */
export async function fetchRestaurantDailyOrders(
  restaurantId: string,
  orderDate?: string,
  supabaseClient?: any
): Promise<{
  restaurantId: string;
  orderDate: string;
  totalOrders: number;
  totalRevenue: number;
  orders: RestaurantOrderRecord[];
}> {
  const targetDate = orderDate || new Date().toISOString().slice(0, 10);

  if (supabaseClient) {
    try {
      // 1. Try invoking the multi-tenant RPC stored procedure
      const { data: rpcData, error: rpcError } = await supabaseClient.rpc('get_restaurant_daily_orders', {
        p_restaurant_id: restaurantId,
        p_order_date: targetDate
      });

      if (!rpcError && Array.isArray(rpcData)) {
        const orders: RestaurantOrderRecord[] = rpcData.map((row: any) => ({
          id: row.id,
          restaurantId: row.restaurant_id,
          orderId: row.order_id,
          orderDate: row.order_date,
          orderTime: row.order_time,
          tableNumber: row.table_number,
          items: row.items,
          totalPrice: Number(row.total_price),
          customerNotes: row.customer_notes,
          status: row.status,
          formattedSummary: row.formatted_summary || formatOrderSummary({
            order_id: row.order_id,
            order_date: row.order_date,
            order_time: row.order_time,
            table_number: row.table_number
          }),
          createdAt: row.created_at
        }));

        const totalRevenue = orders.reduce((acc, o) => acc + (o.status !== 'cancelled' ? o.totalPrice : 0), 0);

        return {
          restaurantId,
          orderDate: targetDate,
          totalOrders: orders.length,
          totalRevenue,
          orders
        };
      }

      // 2. Direct table select filtered strictly by restaurant_id
      const { data, error } = await supabaseClient
        .from('orders')
        .select('*')
        .eq('restaurant_id', restaurantId)
        .eq('order_date', targetDate)
        .order('order_id', { ascending: false });

      if (!error && Array.isArray(data)) {
        const orders: RestaurantOrderRecord[] = data.map((row: any) => ({
          id: row.id,
          restaurantId: row.restaurant_id,
          orderId: row.order_id,
          orderDate: row.order_date,
          orderTime: row.order_time,
          tableNumber: row.table_number,
          items: row.items,
          totalPrice: Number(row.total_price),
          customerNotes: row.customer_notes,
          status: row.status,
          alertSoundType: row.alert_sound_type,
          formattedSummary: formatOrderSummary({
            order_id: row.order_id,
            order_date: row.order_date,
            order_time: row.order_time,
            table_number: row.table_number
          }),
          createdAt: row.created_at
        }));

        const totalRevenue = orders.reduce((acc, o) => acc + (o.status !== 'cancelled' ? o.totalPrice : 0), 0);

        return {
          restaurantId,
          orderDate: targetDate,
          totalOrders: orders.length,
          totalRevenue,
          orders
        };
      }
    } catch (err) {
      console.warn('[orderService] Supabase fetch error:', err);
    }
  }

  // Fallback: Fetch via backend Express API endpoint
  try {
    const res = await fetch(`/api/orders?restaurant_id=${encodeURIComponent(restaurantId)}&date=${encodeURIComponent(targetDate)}`);
    if (res.ok) {
      const json = await res.json();
      const rawOrders = json.orders || [];
      const orders: RestaurantOrderRecord[] = rawOrders.map((o: any) => ({
        id: o.id,
        restaurantId: o.restaurantId || restaurantId,
        orderId: o.orderId || o.order_id || 1,
        orderDate: o.orderDate || o.order_date || targetDate,
        orderTime: o.orderTime || o.order_time || '00:00:00',
        tableNumber: o.tableNumber || o.table_number || '1',
        items: o.items || [],
        totalPrice: Number(o.totalPrice || o.total_price || 0),
        customerNotes: o.customerNotes || o.customer_notes,
        status: o.status || 'pending',
        alertSoundType: o.alertSoundType || o.alert_sound_type,
        formattedSummary: o.formattedSummary || formatOrderSummary(o),
        createdAt: o.createdAt || o.created_at
      }));

      const totalRevenue = orders.reduce((acc, o) => acc + (o.status !== 'cancelled' ? o.totalPrice : 0), 0);

      return {
        restaurantId,
        orderDate: targetDate,
        totalOrders: orders.length,
        totalRevenue,
        orders
      };
    }
  } catch (apiErr) {
    console.warn('[orderService] Fetch API error:', apiErr);
  }

  return {
    restaurantId,
    orderDate: targetDate,
    totalOrders: 0,
    totalRevenue: 0,
    orders: []
  };
}
