/**
 * ==============================================================================
 * 👨‍🍳 MULTI-TENANT STAFF DUTY & TABLE ALLOCATION SERVICE (staffAllocationService.ts)
 * Features:
 *  - Staff view: Choose Name/Role and allocate daily tables (e.g. Tables 1, 2, 3)
 *  - Real-time matching: Auto-resolves waiter for any table (e.g. Table 2 -> Waiter Ramesh)
 *  - Owner notifications: "Table 2 (Assigned to: Waiter Ramesh) - New Order Received!"
 *  - Live grid generator: Status of all tables + duty holder
 * ==============================================================================
 */

import { StaffAllocation, TableDutyState, StaffRole, GUESTHOUSE_DUTY_ROLES, RESTAURANT_DUTY_ROLES } from '../types';

export const DEFAULT_STAFF_SEED: Record<string, StaffAllocation[]> = {
  // 🏨 Guest House / Hotel Seeds
  'green-villa-guesthouse': [
    {
      id: 'staff_gv_frontdesk',
      restaurantId: 'green-villa-guesthouse',
      staffName: 'Anita Sharma (Front Desk)',
      role: 'front_desk',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['101', '102', '103', '104', '105', '106'],
      isActive: true,
      notes: 'Lobby Check-in & Guest Inquiries',
      phone: '+91 98450 11001'
    },
    {
      id: 'staff_gv_housekeeping',
      restaurantId: 'green-villa-guesthouse',
      staffName: 'Lakshmi Devi (Housekeeping)',
      role: 'housekeeping',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['101', '102', '103'],
      isActive: true,
      notes: '1st Floor Linen & Room Deep Clean',
      phone: '+91 98450 11002'
    },
    {
      id: 'staff_gv_roomservice',
      restaurantId: 'green-villa-guesthouse',
      staffName: 'Ravi Kumar (Room Service)',
      role: 'room_service',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['102', '103', '104', '105'],
      isActive: true,
      notes: 'In-Room Dining Trays & Express Service',
      phone: '+91 98450 11003'
    },
    {
      id: 'staff_gv_coffeebar',
      restaurantId: 'green-villa-guesthouse',
      staffName: 'Kiran Das (Barista & Bar)',
      role: 'coffee_bar',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['101', '102', '103', '104', '105', '106', 'VIP-Lounge'],
      isActive: true,
      notes: 'Artisan Coffee, Juices & Evening Mocktails',
      phone: '+91 98450 11004'
    },
    {
      id: 'staff_gv_bellboy',
      restaurantId: 'green-villa-guesthouse',
      staffName: 'Manoj Singh (Concierge & Bell Boy)',
      role: 'bellboy',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['101', '102', '103', '104', '105', '106'],
      isActive: true,
      notes: 'Luggage assistance, airport taxi & transfers',
      phone: '+91 98450 11005'
    },
    {
      id: 'staff_gv_facilities',
      restaurantId: 'green-villa-guesthouse',
      staffName: 'Sunil Verma (Facilities & Recreation)',
      role: 'facilities',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['Gym', 'Poolside', 'Banquet-Hall'],
      isActive: true,
      notes: 'Gym, Swimming Pool, Salon & Banquet support',
      phone: '+91 98450 11006'
    },
    {
      id: 'staff_gv_maintenance',
      restaurantId: 'green-villa-guesthouse',
      staffName: 'Arun Patel (Chief Maintenance)',
      role: 'maintenance',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['101', '102', '103', '104', '105', '106'],
      isActive: true,
      notes: 'AC servicing, plumbing & electrical upkeep',
      phone: '+91 98450 11007'
    }
  ],

  // 🍽️ Restaurant Seeds
  'city-diner': [
    {
      id: 'staff_cd_chef',
      restaurantId: 'city-diner',
      staffName: 'Chef Anbu (Kitchen Lead)',
      role: 'head_chef',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['01', '02', '03', '04', '05', '06', '07', '08'],
      isActive: true,
      notes: 'Kitchen pass expediting & live hot orders',
      phone: '+91 98450 22001'
    },
    {
      id: 'staff_cd_waiter1',
      restaurantId: 'city-diner',
      staffName: 'Waiter Ramesh (Floor Captain)',
      role: 'waiter',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['01', '02', '03', '04', '05'],
      isActive: true,
      notes: 'Central dining tables & express service',
      phone: '+91 98450 22002'
    },
    {
      id: 'staff_cd_cashier',
      restaurantId: 'city-diner',
      staffName: 'Sundar (Cashier & Billing)',
      role: 'cashier',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['01', '02', '03', '04', '05', '06', '07', '08'],
      isActive: true,
      notes: 'POS settlements, GST bills & UPI QR checks',
      phone: '+91 98450 22003'
    },
    {
      id: 'staff_cd_runner',
      restaurantId: 'city-diner',
      staffName: 'Karthik (Delivery Runner)',
      role: 'runner',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['05', '06', '07', '08'],
      isActive: true,
      notes: 'Hot food runner to tables & takeaway dispatch',
      phone: '+91 98450 22004'
    }
  ],

  'sri-murugan-tiffin-center': [
    {
      id: 'staff_ramesh_1',
      restaurantId: 'sri-murugan-tiffin-center',
      staffName: 'Waiter Ramesh',
      role: 'waiter',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['1', '2', '3'],
      isActive: true,
      notes: 'Front hall section',
      phone: '+91 98450 11223'
    },
    {
      id: 'staff_priya_2',
      restaurantId: 'sri-murugan-tiffin-center',
      staffName: 'Captain Priya',
      role: 'captain',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['4', '5', '6'],
      isActive: true,
      notes: 'Central dining & VIP booths',
      phone: '+91 98450 44556'
    },
    {
      id: 'staff_suresh_3',
      restaurantId: 'sri-murugan-tiffin-center',
      staffName: 'Waiter Suresh',
      role: 'waiter',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['7', '8', '9', '10'],
      isActive: true,
      notes: 'Terrace & outdoor garden',
      phone: '+91 98450 77889'
    }
  ],
  'the-royal-bistro': [
    {
      id: 'staff_anita_1',
      restaurantId: 'the-royal-bistro',
      staffName: 'Staff Anita',
      role: 'waiter',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['1', '2', '3', '4'],
      isActive: true,
      notes: 'Bistro Main Deck',
      phone: '+91 98765 12345'
    },
    {
      id: 'staff_vikram_2',
      restaurantId: 'the-royal-bistro',
      staffName: 'Captain Vikram',
      role: 'captain',
      shiftDate: new Date().toISOString().slice(0, 10),
      assignedTables: ['5', '6', '7', '8'],
      isActive: true,
      notes: 'Lounge & Rooftop',
      phone: '+91 98765 67890'
    }
  ]
};

const LOCAL_STORAGE_KEY_PREFIX = 'qr_menu_staff_allocations_';

function getStorageKey(restaurantId: string, date: string): string {
  return `${LOCAL_STORAGE_KEY_PREFIX}${restaurantId}_${date}`;
}

export function getLocalStaffAllocations(restaurantId: string, date?: string): StaffAllocation[] {
  const targetDate = date || new Date().toISOString().slice(0, 10);
  const key = getStorageKey(restaurantId, targetDate);

  if (typeof window !== 'undefined') {
    try {
      const saved = localStorage.getItem(key);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Error reading local staff allocations:', e);
    }
  }

  // Fallback to seed data for this tenant
  const tenantSeeds = DEFAULT_STAFF_SEED[restaurantId] || DEFAULT_STAFF_SEED['sri-murugan-tiffin-center'] || [];
  return tenantSeeds.map(s => ({ ...s, shiftDate: targetDate, restaurantId }));
}

export function saveLocalStaffAllocations(restaurantId: string, allocations: StaffAllocation[], date?: string) {
  const targetDate = date || new Date().toISOString().slice(0, 10);
  const key = getStorageKey(restaurantId, targetDate);
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(key, JSON.stringify(allocations));
    } catch (e) {
      console.warn('Error saving local staff allocations:', e);
    }
  }
}

/**
 * Format notification alert message for Owner device
 */
export function formatStaffDutyAlert(
  tableNumber: string | number,
  staffName?: string | null,
  role?: string | null,
  isGuestHouse?: boolean
): string {
  const cleanTable = String(tableNumber).trim();
  const isRoom = isGuestHouse || cleanTable.toLowerCase().includes('room') || (Number(cleanTable) >= 100 && !cleanTable.toLowerCase().startsWith('table'));
  const tableLabel = cleanTable.toLowerCase().startsWith('table') || cleanTable.toLowerCase().startsWith('room') 
    ? cleanTable 
    : isRoom ? `Room ${cleanTable}` : `Table ${cleanTable}`;
  
  const roleTag = role ? ` [${role}]` : '';

  if (staffName && staffName.trim()) {
    return isRoom
      ? `${tableLabel} (Assigned to: ${staffName.trim()}${roleTag}) - New In-Room Request!`
      : `${tableLabel} (Assigned to: ${staffName.trim()}${roleTag}) - New Order Received!`;
  }
  return isRoom
    ? `${tableLabel} (Unassigned) - New In-Room Service Request!`
    : `${tableLabel} (Unassigned) - New Order Received!`;
}

/**
 * Resolve staff assigned to a specific unit (table or room) in real time
 */
export function getStaffForUnit(
  unitNumber: string | number,
  allocations: StaffAllocation[]
): StaffAllocation | null {
  const raw = String(unitNumber).trim();
  const normalizedNum = raw.replace(/^(table|room)\s*/i, '').trim();

  for (const staff of allocations) {
    if (!staff.isActive) continue;
    for (const assigned of staff.assignedTables) {
      const staffUnitNum = String(assigned).replace(/^(table|room)\s*/i, '').trim();
      if (staffUnitNum.toLowerCase() === normalizedNum.toLowerCase() || assigned.toLowerCase() === raw.toLowerCase()) {
        return staff;
      }
    }
  }
  return null;
}

export const getStaffForTable = getStaffForUnit;

/**
 * Build Live Table / Room Grid combining staff assignments + live orders state
 */
export function buildTableDutyGrid(
  restaurantId: string,
  allocations: StaffAllocation[],
  activeOrders: any[] = [],
  totalUnitsCount: number = 12,
  customUnitList?: string[]
): TableDutyState[] {
  const grid: TableDutyState[] = [];
  const isGuestHouse = restaurantId.includes('guesthouse') || restaurantId.includes('hotel');
  
  const unitsToRender = customUnitList || (
    isGuestHouse 
      ? ['101', '102', '103', '104', '105', '106', '201', '202', '203', '204', 'Suite-A', 'VIP-Lounge']
      : Array.from({ length: totalUnitsCount }, (_, i) => String(i + 1))
  );

  for (const unitNumStr of unitsToRender) {
    const assignedStaff = getStaffForUnit(unitNumStr, allocations);
    
    // Find active orders for this unit (table or room)
    const unitOrders = activeOrders.filter(o => {
      const ordUnitStr = String(o.tableNumber || o.table_number || '').replace(/^(table|room)\s*/i, '').trim();
      return ordUnitStr.toLowerCase() === unitNumStr.toLowerCase() || String(o.tableNumber || o.table_number || '').toLowerCase() === unitNumStr.toLowerCase();
    });

    const pendingOrders = unitOrders.filter(o => o.status === 'pending');
    const acceptedOrders = unitOrders.filter(o => o.status === 'accepted' || o.status === 'preparing');
    const servedOrders = unitOrders.filter(o => o.status === 'completed');

    let status: TableDutyState['status'] = 'idle';
    if (!assignedStaff) {
      status = 'unassigned';
    }

    if (pendingOrders.length > 0) {
      status = 'ringing'; // incoming active order
    } else if (acceptedOrders.length > 0) {
      status = 'preparing';
    } else if (servedOrders.length > 0 && unitOrders.length > 0) {
      status = 'served';
    } else if (unitOrders.length > 0) {
      status = 'pending';
    } else if (assignedStaff) {
      status = 'idle';
    }

    const latestOrder = unitOrders[0];
    const totalBill = unitOrders.reduce((sum, o) => sum + (o.status !== 'cancelled' ? Number(o.totalPrice || o.total_price || 0) : 0), 0);

    grid.push({
      tableNumber: unitNumStr,
      assignedStaff,
      assignedStaffName: assignedStaff ? assignedStaff.staffName : null,
      status,
      activeOrdersCount: unitOrders.length,
      latestOrderId: latestOrder?.orderId || latestOrder?.order_id,
      latestOrderTime: latestOrder?.orderTime || latestOrder?.order_time,
      totalBillAmount: totalBill
    });
  }

  return grid;
}
export async function fetchStaffAllocations(
  restaurantId: string,
  shiftDate?: string,
  supabaseClient?: any
): Promise<StaffAllocation[]> {
  const targetDate = shiftDate || new Date().toISOString().slice(0, 10);

  if (supabaseClient) {
    try {
      const { data, error } = await supabaseClient
        .from('staff_allocations')
        .select('*')
        .eq('restaurant_id', restaurantId)
        .eq('shift_date', targetDate)
        .order('created_at', { ascending: true });

      if (!error && Array.isArray(data) && data.length > 0) {
        const mapped: StaffAllocation[] = data.map((row: any) => ({
          id: row.id,
          restaurantId: row.restaurant_id,
          staffName: row.staff_name,
          role: row.role as StaffRole,
          phone: row.phone || undefined,
          shiftDate: row.shift_date,
          assignedTables: Array.isArray(row.assigned_tables) ? row.assigned_tables.map(String) : [],
          isActive: row.is_active ?? true,
          notes: row.notes || undefined,
          createdAt: row.created_at,
          updatedAt: row.updated_at
        }));
        saveLocalStaffAllocations(restaurantId, mapped, targetDate);
        return mapped;
      }
    } catch (dbErr) {
      console.warn('[staffService] Supabase fetch error, fallback to API/local:', dbErr);
    }
  }

  // Try Express backend API
  try {
    const res = await fetch(`/api/staff-allocations?restaurant_id=${encodeURIComponent(restaurantId)}&date=${encodeURIComponent(targetDate)}`);
    if (res.ok) {
      const json = await res.json();
      if (Array.isArray(json.allocations) && json.allocations.length > 0) {
        saveLocalStaffAllocations(restaurantId, json.allocations, targetDate);
        return json.allocations;
      }
    }
  } catch (apiErr) {
    console.warn('[staffService] Express API fetch fallback to local:', apiErr);
  }

  return getLocalStaffAllocations(restaurantId, targetDate);
}

/**
 * Save or update staff table allocation
 */
export async function saveStaffAllocation(
  allocation: Omit<StaffAllocation, 'id'> & { id?: string },
  supabaseClient?: any
): Promise<StaffAllocation> {
  const targetDate = allocation.shiftDate || new Date().toISOString().slice(0, 10);
  const recordId = allocation.id || `staff_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

  const finalRecord: StaffAllocation = {
    ...allocation,
    id: recordId,
    shiftDate: targetDate,
    assignedTables: Array.from(new Set(allocation.assignedTables.map(t => String(t).trim()))),
    updatedAt: new Date().toISOString()
  };

  // 1. Update local cache
  const localList = getLocalStaffAllocations(allocation.restaurantId, targetDate);
  const existingIdx = localList.findIndex(a => a.id === recordId || (a.staffName.toLowerCase() === allocation.staffName.toLowerCase() && a.restaurantId === allocation.restaurantId));
  let updatedList: StaffAllocation[];
  if (existingIdx >= 0) {
    updatedList = [...localList];
    updatedList[existingIdx] = finalRecord;
  } else {
    updatedList = [...localList, finalRecord];
  }
  saveLocalStaffAllocations(allocation.restaurantId, updatedList, targetDate);

  // 2. Sync to Supabase
  if (supabaseClient) {
    try {
      const { data, error } = await supabaseClient
        .from('staff_allocations')
        .upsert({
          id: allocation.id || undefined,
          restaurant_id: allocation.restaurantId,
          staff_name: allocation.staffName,
          role: allocation.role || 'waiter',
          phone: allocation.phone || null,
          shift_date: targetDate,
          assigned_tables: finalRecord.assignedTables,
          is_active: allocation.isActive ?? true,
          notes: allocation.notes || null,
          updated_at: new Date().toISOString()
        }, { onConflict: 'restaurant_id, shift_date, staff_name' })
        .select()
        .single();

      if (!error && data) {
        finalRecord.id = data.id;
      }
    } catch (dbErr) {
      console.warn('[staffService] Supabase upsert error:', dbErr);
    }
  }

  // 3. Sync to Express Backend API
  try {
    await fetch('/api/staff-allocations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(finalRecord)
    });
  } catch (apiErr) {
    // Non-blocking
  }

  return finalRecord;
}

/**
 * Delete a staff duty allocation
 */
export async function deleteStaffAllocation(
  restaurantId: string,
  allocationId: string,
  shiftDate?: string,
  supabaseClient?: any
): Promise<boolean> {
  const targetDate = shiftDate || new Date().toISOString().slice(0, 10);

  // 1. Remove from local storage
  const currentList = getLocalStaffAllocations(restaurantId, targetDate);
  const updated = currentList.filter(a => a.id !== allocationId);
  saveLocalStaffAllocations(restaurantId, updated, targetDate);

  // 2. Supabase delete
  if (supabaseClient) {
    try {
      await supabaseClient
        .from('staff_allocations')
        .delete()
        .eq('id', allocationId)
        .eq('restaurant_id', restaurantId);
    } catch (dbErr) {
      console.warn('[staffService] Supabase delete error:', dbErr);
    }
  }

  // 3. API delete
  try {
    await fetch(`/api/staff-allocations/${encodeURIComponent(allocationId)}?restaurant_id=${encodeURIComponent(restaurantId)}`, {
      method: 'DELETE'
    });
  } catch (e) {
    // Non-blocking
  }

  return true;
}
