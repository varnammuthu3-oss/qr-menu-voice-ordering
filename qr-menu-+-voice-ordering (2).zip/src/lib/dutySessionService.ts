import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  getDocs, 
  query, 
  where, 
  onSnapshot 
} from 'firebase/firestore';
import { db } from './firebase';
import { DutySession, StaffRole, ManagerDutyOverview } from '../types';
import { saveStaffAllocation } from './staffAllocationService';

const DUTY_SESSIONS_COLLECTION = 'duty_sessions';
const LOCAL_STORAGE_DUTY_SESSIONS_PREFIX = 'qr_duty_sessions_';
const LOCAL_STORAGE_MY_ACTIVE_SESSION_KEY = 'qr_my_active_duty_session_id';

// Default initial duty sessions seed for instant visual feedback and demo stability
export const SEED_DUTY_SESSIONS: Record<string, DutySession[]> = {
  'green-villa-guesthouse': [
    {
      id: 'session_gv_1',
      businessId: 'green-villa-guesthouse',
      restaurantId: 'green-villa-guesthouse',
      staffName: 'Anita Sharma',
      role: 'front_desk',
      assignedTables: ['101', '102', '103', '104', '105', '106'],
      phone: '+91 98450 11001',
      shiftDate: new Date().toISOString().slice(0, 10),
      checkInTime: new Date(Date.now() - 3.5 * 3600 * 1000).toISOString(),
      status: 'active',
      notes: 'Morning Check-in & Concierge Desk',
      createdAt: new Date(Date.now() - 3.5 * 3600 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 3.5 * 3600 * 1000).toISOString()
    },
    {
      id: 'session_gv_2',
      businessId: 'green-villa-guesthouse',
      restaurantId: 'green-villa-guesthouse',
      staffName: 'Lakshmi Devi',
      role: 'housekeeping',
      assignedTables: ['101', '102', '103'],
      phone: '+91 98450 11002',
      shiftDate: new Date().toISOString().slice(0, 10),
      checkInTime: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
      status: 'active',
      notes: '1st Floor Linen & Fresh Towels Restock',
      createdAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 2 * 3600 * 1000).toISOString()
    },
    {
      id: 'session_gv_3',
      businessId: 'green-villa-guesthouse',
      restaurantId: 'green-villa-guesthouse',
      staffName: 'Ravi Kumar',
      role: 'room_service',
      assignedTables: ['101', '102', '103', '104', '105'],
      phone: '+91 98450 11003',
      shiftDate: new Date().toISOString().slice(0, 10),
      checkInTime: new Date(Date.now() - 1.5 * 3600 * 1000).toISOString(),
      status: 'active',
      notes: 'Breakfast & Hot Tea In-Room Orders',
      createdAt: new Date(Date.now() - 1.5 * 3600 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 1.5 * 3600 * 1000).toISOString()
    },
    {
      id: 'session_gv_4',
      businessId: 'green-villa-guesthouse',
      restaurantId: 'green-villa-guesthouse',
      staffName: 'Kiran Das',
      role: 'coffee_bar',
      assignedTables: ['101', '102', '103', '104', '105', '106', 'VIP-Lounge'],
      phone: '+91 98450 11004',
      shiftDate: new Date().toISOString().slice(0, 10),
      checkInTime: new Date(Date.now() - 4 * 3600 * 1000).toISOString(),
      status: 'active',
      notes: 'Coffee Barista & Fresh Mocktails',
      createdAt: new Date(Date.now() - 4 * 3600 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 4 * 3600 * 1000).toISOString()
    }
  ],
  'city-diner': [
    {
      id: 'session_cd_1',
      businessId: 'city-diner',
      restaurantId: 'city-diner',
      staffName: 'Chef Anbu',
      role: 'head_chef',
      assignedTables: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'],
      phone: '+91 98450 22001',
      shiftDate: new Date().toISOString().slice(0, 10),
      checkInTime: new Date(Date.now() - 3 * 3600 * 1000).toISOString(),
      status: 'active',
      notes: 'Kitchen Expediter & Hot Line',
      createdAt: new Date(Date.now() - 3 * 3600 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 3 * 3600 * 1000).toISOString()
    },
    {
      id: 'session_cd_2',
      businessId: 'city-diner',
      restaurantId: 'city-diner',
      staffName: 'Waiter Ramesh',
      role: 'waiter',
      assignedTables: ['01', '02', '03', '04', '05'],
      phone: '+91 98450 11223',
      shiftDate: new Date().toISOString().slice(0, 10),
      checkInTime: new Date(Date.now() - 2.5 * 3600 * 1000).toISOString(),
      status: 'active',
      notes: 'Front Dine-In Tables Section',
      createdAt: new Date(Date.now() - 2.5 * 3600 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 2.5 * 3600 * 1000).toISOString()
    },
    {
      id: 'session_cd_3',
      businessId: 'city-diner',
      restaurantId: 'city-diner',
      staffName: 'Captain Priya',
      role: 'waiter',
      assignedTables: ['06', '07', '08', '09', '10'],
      phone: '+91 98450 44556',
      shiftDate: new Date().toISOString().slice(0, 10),
      checkInTime: new Date(Date.now() - 1.8 * 3600 * 1000).toISOString(),
      status: 'active',
      notes: 'Center Hall & Family Booths',
      createdAt: new Date(Date.now() - 1.8 * 3600 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 1.8 * 3600 * 1000).toISOString()
    }
  ]
};

export function getLocalDutySessions(businessId: string): DutySession[] {
  if (typeof window === 'undefined' || !businessId) {
    return SEED_DUTY_SESSIONS[businessId] || [];
  }
  try {
    const raw = localStorage.getItem(`${LOCAL_STORAGE_DUTY_SESSIONS_PREFIX}${businessId}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('[DutySessionService] Error reading local duty sessions:', e);
  }
  return SEED_DUTY_SESSIONS[businessId] || [];
}

export function saveLocalDutySessions(businessId: string, sessions: DutySession[]) {
  if (typeof window === 'undefined' || !businessId) return;
  try {
    localStorage.setItem(`${LOCAL_STORAGE_DUTY_SESSIONS_PREFIX}${businessId}`, JSON.stringify(sessions));
  } catch (e) {
    console.warn('[DutySessionService] Error saving local duty sessions:', e);
  }
}

export function getMyStoredDutySessionId(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(LOCAL_STORAGE_MY_ACTIVE_SESSION_KEY);
}

export function setMyStoredDutySessionId(sessionId: string | null) {
  if (typeof window === 'undefined') return;
  if (sessionId) {
    localStorage.setItem(LOCAL_STORAGE_MY_ACTIVE_SESSION_KEY, sessionId);
  } else {
    localStorage.removeItem(LOCAL_STORAGE_MY_ACTIVE_SESSION_KEY);
  }
}

/**
 * Real-time listener for Duty Sessions (Firestore with local fallback)
 */
export function subscribeToDutySessions(
  businessId: string,
  onUpdate: (sessions: DutySession[]) => void
): () => void {
  const localInitial = getLocalDutySessions(businessId);
  onUpdate(localInitial);

  let unsubscribeFirestore = () => {};

  try {
    const sessionsCol = collection(db, DUTY_SESSIONS_COLLECTION);
    unsubscribeFirestore = onSnapshot(
      sessionsCol,
      (snapshot) => {
        if (!snapshot.empty) {
          const fetched: DutySession[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data() as DutySession;
            if (data.businessId === businessId || data.restaurantId === businessId) {
              fetched.push({
                ...data,
                id: docSnap.id
              });
            }
          });

          if (fetched.length > 0) {
            // Sort by check-in time descending
            fetched.sort((a, b) => new Date(b.checkInTime).getTime() - new Date(a.checkInTime).getTime());
            saveLocalDutySessions(businessId, fetched);
            onUpdate(fetched);
            return;
          }
        }
        // Fallback to local if empty on server
        onUpdate(getLocalDutySessions(businessId));
      },
      (error) => {
        console.warn('[DutySessionService] Firestore subscription error, using local state:', error);
        onUpdate(getLocalDutySessions(businessId));
      }
    );
  } catch (err) {
    console.warn('[DutySessionService] Could not initialize Firestore listener:', err);
    onUpdate(localInitial);
  }

  return () => {
    unsubscribeFirestore();
  };
}

/**
 * Check-In a Staff Member to Active Duty
 */
export async function checkInStaffSession(params: {
  businessId: string;
  staffName: string;
  role: StaffRole;
  assignedTables: string[];
  phone?: string;
  notes?: string;
}): Promise<DutySession> {
  const { businessId, staffName, role, assignedTables, phone, notes } = params;
  const now = new Date();
  const sessionId = `session_${businessId}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const todayStr = now.toISOString().slice(0, 10);

  const cleanTables = Array.from(new Set(assignedTables.map(t => String(t).trim()))).filter(Boolean);

  const newSession: DutySession = {
    id: sessionId,
    businessId,
    restaurantId: businessId,
    staffName: staffName.trim(),
    role,
    assignedTables: cleanTables,
    phone: phone?.trim() || undefined,
    shiftDate: todayStr,
    checkInTime: now.toISOString(),
    status: 'active',
    notes: notes?.trim() || undefined,
    createdAt: now.toISOString(),
    updatedAt: now.toISOString()
  };

  // 1. Update Local Storage Cache
  const current = getLocalDutySessions(businessId);
  // Mark any previous active session for this same staff name on the same day as completed or supersede it
  const updatedList = current.map(s => {
    if (s.staffName.toLowerCase() === newSession.staffName.toLowerCase() && s.status === 'active') {
      return { ...s, status: 'completed' as const, checkOutTime: now.toISOString(), updatedAt: now.toISOString() };
    }
    return s;
  });
  const finalList = [newSession, ...updatedList];
  saveLocalDutySessions(businessId, finalList);
  setMyStoredDutySessionId(newSession.id);

  // 2. Sync to Firestore
  try {
    const docRef = doc(db, DUTY_SESSIONS_COLLECTION, sessionId);
    await setDoc(docRef, newSession);
  } catch (err) {
    console.warn('[DutySessionService] Firestore save error (local state preserved):', err);
  }

  // 3. Sync to Legacy Staff Allocation service for seamless backwards compatibility
  try {
    await saveStaffAllocation({
      restaurantId: businessId,
      staffName: newSession.staffName,
      role: newSession.role,
      phone: newSession.phone,
      shiftDate: newSession.shiftDate,
      assignedTables: newSession.assignedTables,
      isActive: true,
      notes: newSession.notes
    });
  } catch (e) {
    console.warn('[DutySessionService] Staff allocation sync notice:', e);
  }

  return newSession;
}

/**
 * Check-Out a Staff Member / End Shift
 */
export async function checkOutStaffSession(
  businessId: string,
  sessionId: string
): Promise<DutySession | null> {
  const now = new Date().toISOString();
  const current = getLocalDutySessions(businessId);
  let updatedSession: DutySession | null = null;

  const updatedList = current.map(s => {
    if (s.id === sessionId) {
      updatedSession = {
        ...s,
        status: 'completed' as const,
        checkOutTime: now,
        updatedAt: now
      };
      return updatedSession;
    }
    return s;
  });

  saveLocalDutySessions(businessId, updatedList);

  if (getMyStoredDutySessionId() === sessionId) {
    setMyStoredDutySessionId(null);
  }

  // Sync to Firestore
  try {
    const docRef = doc(db, DUTY_SESSIONS_COLLECTION, sessionId);
    await updateDoc(docRef, {
      status: 'completed',
      checkOutTime: now,
      updatedAt: now
    });
  } catch (err) {
    console.warn('[DutySessionService] Firestore check-out error:', err);
  }

  return updatedSession;
}

/**
 * Calculate Manager Overview Metrics & Real-time Room Coverage
 */
export function computeManagerDutyOverview(
  sessions: DutySession[],
  allUnits: string[]
): ManagerDutyOverview {
  const activeSessions = sessions.filter(s => s.status === 'active');
  const coveredUnitsSet = new Set<string>();

  const roleBreakdown: Record<string, number> = {};

  activeSessions.forEach(session => {
    roleBreakdown[session.role] = (roleBreakdown[session.role] || 0) + 1;
    session.assignedTables.forEach(t => {
      coveredUnitsSet.add(t);
    });
  });

  const unassignedUnits = allUnits.filter(u => !coveredUnitsSet.has(u));
  const totalUnits = allUnits.length || 1;
  const totalCoveredUnits = coveredUnitsSet.size;
  const coveragePercentage = Math.round((totalCoveredUnits / totalUnits) * 100);

  return {
    totalStaffOnDuty: activeSessions.length,
    totalCoveredUnits,
    totalUnits,
    coveragePercentage: Math.min(100, coveragePercentage),
    unassignedUnits,
    roleBreakdown,
    activeDutySessions: activeSessions
  };
}

/**
 * Real-Time Alert Dispatch Checker:
 * Determines if a live incoming order or housekeeping request should play an audio alert
 * on the current device based on assigned rooms and operational roles.
 */
export function shouldPlayAlertForStaff(params: {
  targetLocation: string; // e.g. "102", "Room 102", "Table 05", "05"
  staffRole?: string; // 'owner' | 'manager' | 'waiter' | 'housekeeping' | etc.
  myStaffName?: string;
  activeDutySessions: DutySession[];
  alertType?: 'food_order' | 'housekeeping' | 'concierge' | 'billing' | 'general';
  isOnlyAssignedFilterEnabled?: boolean;
}): { shouldAlert: boolean; assignedStaffName: string | null; reason: string } {
  const { 
    targetLocation, 
    staffRole, 
    myStaffName, 
    activeDutySessions, 
    alertType = 'food_order',
    isOnlyAssignedFilterEnabled = true 
  } = params;

  // Extract clean unit number (e.g. "Room 102" -> "102", "Table 05" -> "05")
  const cleanUnit = targetLocation.replace(/^(room|table|suite|booth)\s*/i, '').trim();

  // Find which active staff covers this unit
  const matchingSessions = activeDutySessions.filter(s => 
    s.status === 'active' && 
    s.assignedTables.some(t => {
      const cleanAssigned = t.replace(/^(room|table|suite|booth)\s*/i, '').trim();
      return cleanAssigned.toLowerCase() === cleanUnit.toLowerCase() || t.toLowerCase() === targetLocation.toLowerCase();
    })
  );

  const assignedStaffNames = matchingSessions.map(s => s.staffName).join(', ');

  // 1. Owners and Managers receive all alerts by default unless strict filter is turned on
  if ((staffRole === 'owner' || staffRole === 'manager' || staffRole === 'master_admin') && !isOnlyAssignedFilterEnabled) {
    return {
      shouldAlert: true,
      assignedStaffName: assignedStaffNames || null,
      reason: 'Owner / Manager Global Monitor Mode'
    };
  }

  // 2. Check if current staff member is assigned to this specific room/table
  if (myStaffName) {
    const isMeAssigned = matchingSessions.some(
      s => s.staffName.toLowerCase() === myStaffName.toLowerCase()
    );

    if (isMeAssigned) {
      return {
        shouldAlert: true,
        assignedStaffName: myStaffName,
        reason: `Direct Dispatch: Assigned to ${myStaffName}`
      };
    }
  }

  // If filtered mode is enabled and device is not assigned to this unit -> Mute alert
  if (isOnlyAssignedFilterEnabled) {
    return {
      shouldAlert: false,
      assignedStaffName: assignedStaffNames || null,
      reason: assignedStaffNames ? `Dispatched to ${assignedStaffNames}` : 'Unassigned Room / Alert Muted for this Device'
    };
  }

  // Default fallback
  return {
    shouldAlert: true,
    assignedStaffName: assignedStaffNames || null,
    reason: 'Global alert broadcast'
  };
}
