export type FoodDietType = 'veg' | 'non-veg' | 'egg';
export type MenuStyle = 'classic' | 'modern' | 'minimal' | 'visual';
export type TenantType = 'restaurant' | 'guesthouse';

export type TenantStatus = 'active' | 'paused' | 'suspended';
export type TenantSubscriptionTier = 'starter' | 'pro' | 'enterprise';

export interface ShopFeatures {
  enable_whatsapp_orders?: boolean;
  enable_table_selector?: boolean;
  enable_bluetooth_speaker_alerts?: boolean;
  enable_kpi_reports?: boolean;
  enable_visual_menu?: boolean;
  enable_visual_menu_images?: boolean;
}

export interface StoredShop {
  id: string;
  name: string;
  tables: string[];
  features: ShopFeatures;
  phone?: string;
  whatsappNumber?: string;
  address?: string;
  city?: string;
  is_approved?: boolean;
  isApproved?: boolean;
}

export interface Business {
  id: string;
  ownerUid: string;
  name: string;
  ownerEmail?: string;
  whatsappGroupUrl?: string;
  businessType?: TenantType;
  tagline?: string;
  description?: string;
  logoUrl?: string;
  coverUrl?: string;
  address: string;
  city?: string;
  state?: string;
  pincode?: string;
  locationMapUrl?: string;
  phone: string;
  whatsappNumber: string;
  openingHours: string;
  currencySymbol: string;
  menuStyle?: MenuStyle;
  menuDisplayMode?: 'text' | 'photo'; // Vendor preference: clean text list vs rich photo cards
  isActive: boolean;
  is_approved?: boolean;
  isApproved?: boolean;
  status?: TenantStatus;
  subscriptionTier?: TenantSubscriptionTier;
  tables?: string[];
  features?: ShopFeatures;
  createdAt: string;
  updatedAt: string;
}

export interface MenuCategory {
  id: string;
  businessId: string;
  name: string;
  description?: string;
  displayOrder: number;
  isActive: boolean;
}

export interface MenuItemVariant {
  id: string;
  name: string; // e.g. 'Regular (8")', 'Medium (10")', 'Large (12")', 'Small', 'Medium', 'Large', 'Half', 'Full'
  price: number;
  isDefault?: boolean;
}

export interface MenuItem {
  id: string;
  businessId: string;
  categoryId: string;
  name: string;
  description?: string;
  price: number;
  imageUrl?: string;
  isVeg: FoodDietType;
  isAvailable: boolean;
  displayOrder: number;
  tags?: string[];
  variants?: MenuItemVariant[];
}

export interface ItemModifierOption {
  id: string;
  name: string;
  priceDelta: number;
  category: 'spice' | 'prep' | 'addon' | 'kitchen_note';
}

export interface CartItem {
  cartItemId: string;
  itemId: string;
  name: string;
  price: number;
  unitPrice: number;
  quantity: number;
  item: MenuItem;
  selectedVariant?: MenuItemVariant;
  selectedOptions: string[];
  customNote?: string;
  totalItemPrice: number;
}

export interface OrderItemPayload {
  itemId?: string;
  name: string;
  variantName?: string;
  quantity: number;
  price: number;
  unitPrice?: number;
  isVeg?: string;
  selectedOptions?: string[];
  customNote?: string;
  totalItemPrice?: number;
}

export interface OwnerProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  businessIds: string[];
}

export interface ExtractedMenuItem {
  tempId: string;
  categoryName: string;
  name: string;
  description: string;
  price: number | null;
  isVeg: FoodDietType;
  isAvailable: boolean;
  needsReview: boolean;
  reviewReason?: string;
  pageNumber?: number;
}

export interface ExtractedCategory {
  name: string;
  description?: string;
}

export interface MenuExtractionResult {
  categories: ExtractedCategory[];
  items: ExtractedMenuItem[];
  confidenceNote?: string;
}

// Staff Duty Operational Roles
export type RestaurantStaffRole =
  | 'head_chef'
  | 'waiter'
  | 'captain'
  | 'cashier'
  | 'runner'
  | 'server'
  | 'manager';

export type GuestHouseStaffRole =
  | 'front_desk'
  | 'housekeeping'
  | 'room_service'
  | 'coffee_bar'
  | 'bellboy'
  | 'facilities'
  | 'maintenance'
  | 'manager';

export type StaffRole = RestaurantStaffRole | GuestHouseStaffRole;

export interface DutyRoleMetadata {
  id: StaffRole;
  label: string;
  subtitle: string;
  category: 'restaurant' | 'guesthouse';
  badgeColor: string;
  iconName: string;
  defaultUnitType: 'table' | 'room' | 'area';
  description: string;
}

export const GUESTHOUSE_DUTY_ROLES: DutyRoleMetadata[] = [
  {
    id: 'front_desk',
    label: 'Front Desk / Reception',
    subtitle: 'Check-in, guest inquiries',
    category: 'guesthouse',
    badgeColor: 'sky',
    iconName: 'Hotel',
    defaultUnitType: 'room',
    description: 'Handles guest check-in, key card issuance, concierge inquiries, and reservation desk support.'
  },
  {
    id: 'housekeeping',
    label: 'Housekeeping & Linen',
    subtitle: 'Room cleaning, fresh towels/bedsheets',
    category: 'guesthouse',
    badgeColor: 'emerald',
    iconName: 'Sparkles',
    defaultUnitType: 'room',
    description: 'Manages room cleaning turns, fresh linen changes, towel supplies, and hygiene restocking.'
  },
  {
    id: 'room_service',
    label: 'Room Service',
    subtitle: 'In-room dining orders',
    category: 'guesthouse',
    badgeColor: 'amber',
    iconName: 'Utensils',
    defaultUnitType: 'room',
    description: 'Prepares and delivers breakfast trays, in-room dining orders, midnight snacks, and beverages.'
  },
  {
    id: 'coffee_bar',
    label: 'Coffee Shop / Bar',
    subtitle: 'Beverage requests',
    category: 'guesthouse',
    badgeColor: 'rose',
    iconName: 'Coffee',
    defaultUnitType: 'room',
    description: 'Barista beverage preparation, fresh fruit juices, gourmet coffee, and lounge cocktail service.'
  },
  {
    id: 'bellboy',
    label: 'Bell Boy / Concierge',
    subtitle: 'Luggage assistance, guest transport',
    category: 'guesthouse',
    badgeColor: 'purple',
    iconName: 'Briefcase',
    defaultUnitType: 'room',
    description: 'Provides luggage porter assistance, taxi booking, airport transfers, and guest baggage storage.'
  },
  {
    id: 'facilities',
    label: 'Facilities & Recreation',
    subtitle: 'Gym, Swimming Pool, Salon, Banquet management',
    category: 'guesthouse',
    badgeColor: 'indigo',
    iconName: 'Dumbbell',
    defaultUnitType: 'area',
    description: 'Oversees fitness gym facilities, swimming pool towels, salon appointments, and banquet hall coordination.'
  },
  {
    id: 'maintenance',
    label: 'Maintenance',
    subtitle: 'AC, plumbing, electrical issues',
    category: 'guesthouse',
    badgeColor: 'orange',
    iconName: 'Wrench',
    defaultUnitType: 'room',
    description: 'Diagnoses and fixes air conditioning issues, bathroom plumbing, power sockets, and electronic amenities.'
  }
];

export const RESTAURANT_DUTY_ROLES: DutyRoleMetadata[] = [
  {
    id: 'head_chef',
    label: 'Head Chef / Kitchen Staff',
    subtitle: 'Kitchen food prep & cooking',
    category: 'restaurant',
    badgeColor: 'rose',
    iconName: 'ChefHat',
    defaultUnitType: 'table',
    description: 'Lead culinary preparation, cook line operations, order expediting, and kitchen station monitoring.'
  },
  {
    id: 'waiter',
    label: 'Table Waiter / Captain',
    subtitle: 'Table service & order taking',
    category: 'restaurant',
    badgeColor: 'amber',
    iconName: 'UtensilsCrossed',
    defaultUnitType: 'table',
    description: 'Attends to guest tables, takes live orders, serves fresh courses, and assists diners with requests.'
  },
  {
    id: 'cashier',
    label: 'Cashier / Billing Counter',
    subtitle: 'POS billing, cash & UPI settlements',
    category: 'restaurant',
    badgeColor: 'emerald',
    iconName: 'CreditCard',
    defaultUnitType: 'table',
    description: 'Generates GST restaurant bills, processes UPI QR codes and card payments, and reconciles cash register.'
  },
  {
    id: 'runner',
    label: 'Delivery / Runner',
    subtitle: 'Order delivery to tables & dispatch',
    category: 'restaurant',
    badgeColor: 'sky',
    iconName: 'Bike',
    defaultUnitType: 'table',
    description: 'Transports prepared dishes rapidly from kitchen pass to dining tables and handles packaging for takeout.'
  }
];

export function getDutyRolesForTenant(tenantType?: TenantType | string): DutyRoleMetadata[] {
  return tenantType === 'guesthouse' ? GUESTHOUSE_DUTY_ROLES : RESTAURANT_DUTY_ROLES;
}

export type AppStaffRole = 'owner' | 'manager' | 'waiter' | 'master_admin';

export interface RolePermissions {
  canViewAllOrders: boolean;
  canAssignWaiters: boolean;
  canMuteAudioAlerts: boolean;
  canViewFinancialTotals: boolean;
  canViewStaffDutyReports: boolean;
  canManageMenu: boolean;
  canManageBusinessSettings: boolean;
  canAcceptOrders: boolean;
  canCompleteOrders: boolean;
  canAccessMasterAdmin?: boolean;
}

export interface StaffRoleConfig {
  role: AppStaffRole;
  title: string;
  subtitle: string;
  badge: string;
  color: string;
  icon: string;
  description: string;
  permissions: RolePermissions;
  allowedViews: Array<'customer' | 'owner' | 'orders' | 'duty' | 'master_admin'>;
  defaultView: 'customer' | 'owner' | 'orders' | 'duty' | 'master_admin';
}

export interface StaffAllocation {
  id: string;
  restaurantId: string;
  staffName: string; // e.g. "Waiter Ramesh"
  role: StaffRole;
  phone?: string;
  shiftDate: string; // YYYY-MM-DD
  assignedTables: string[]; // e.g. ['1', '2', '3']
  isActive: boolean;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface TableDutyState {
  tableNumber: string;
  assignedStaff: StaffAllocation | null;
  assignedStaffName: string | null;
  status: 'idle' | 'ringing' | 'pending' | 'preparing' | 'served' | 'unassigned';
  activeOrdersCount: number;
  latestOrderId?: number;
  latestOrderTime?: string;
  totalBillAmount: number;
}

export interface DutySession {
  id: string;
  businessId: string;
  restaurantId: string;
  staffName: string;
  role: StaffRole;
  assignedTables: string[]; // e.g. ['101', '102', '103'] or ['01', '02', '03']
  phone?: string;
  shiftDate: string; // YYYY-MM-DD
  checkInTime: string; // ISO string or timestamp
  checkOutTime?: string | null;
  status: 'active' | 'completed';
  notes?: string;
  deviceId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ManagerDutyOverview {
  totalStaffOnDuty: number;
  totalCoveredUnits: number;
  totalUnits: number;
  coveragePercentage: number;
  unassignedUnits: string[];
  roleBreakdown: Record<string, number>;
  activeDutySessions: DutySession[];
}

