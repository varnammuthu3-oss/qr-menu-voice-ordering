import { StoredShop, Business } from '../types';

export const PWA_RESTAURANTS_STORAGE_KEY = 'pwa_restaurants';
export const STORAGE_VERSION_KEY = 'pwa_app_version';
export const CURRENT_VERSION = '2.1'; // Increment this whenever you push future code updates

// Default persistent test restaurants with defined tables & feature flags
export const DEFAULT_SHOPS: StoredShop[] = [
  {
    id: 'kannayah',
    name: 'Kannayah Hotel',
    tables: ['1', '2', '3', '4', '5'],
    features: { 
      enable_whatsapp_orders: true, 
      enable_table_selector: true,
      enable_visual_menu: true,
      enable_visual_menu_images: true
    },
    is_approved: true
  },
  {
    id: 'city_diner',
    name: 'City Diner',
    tables: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', 'VIP-1', 'VIP-2', 'Garden-1', 'Terrace-A'],
    features: { 
      enable_whatsapp_orders: true, 
      enable_table_selector: true, 
      enable_visual_menu: true,
      enable_visual_menu_images: true
    },
    is_approved: true
  }
];

/**
 * Persistent Store Manager with Auto-Migration for Future Updates
 * Guarantees test restaurants and manually added restaurants never get wiped on future updates
 */
export function initializePersistentStorage(): void {
  if (typeof window === 'undefined') return;

  const savedVersion = localStorage.getItem(STORAGE_VERSION_KEY);
  const existingData = localStorage.getItem(PWA_RESTAURANTS_STORAGE_KEY);

  if (!savedVersion || savedVersion !== CURRENT_VERSION || !existingData) {
    let mergedShops = DEFAULT_SHOPS;

    if (existingData) {
      try {
        const parsedOldData = JSON.parse(existingData);
        if (Array.isArray(parsedOldData)) {
          // Merge old manually added restaurants so they never get wiped on future updates
          const existingIds = new Set(parsedOldData.map((s: StoredShop) => s.id));
          const missingDefaults = DEFAULT_SHOPS.filter((s) => !existingIds.has(s.id));
          mergedShops = [...parsedOldData, ...missingDefaults];
        }
      } catch (e) {
        console.warn('Failed to parse existing data during migration, falling back to defaults:', e);
        mergedShops = DEFAULT_SHOPS;
      }
    }

    localStorage.setItem(PWA_RESTAURANTS_STORAGE_KEY, JSON.stringify(mergedShops));
    localStorage.setItem(STORAGE_VERSION_KEY, CURRENT_VERSION);
  }
}

// Execute on app load
if (typeof window !== 'undefined') {
  initializePersistentStorage();
}

/**
 * Retrieve stored restaurants
 */
export function getRestaurants(): StoredShop[] {
  if (typeof window === 'undefined') {
    return DEFAULT_SHOPS;
  }
  try {
    const data = localStorage.getItem(PWA_RESTAURANTS_STORAGE_KEY);
    return data ? JSON.parse(data) : DEFAULT_SHOPS;
  } catch (e) {
    return DEFAULT_SHOPS;
  }
}

/**
 * Save or update a restaurant in the persistent store
 */
export function saveRestaurant(newShop: StoredShop): void {
  const shops = getRestaurants();
  const index = shops.findIndex((s) => s.id === newShop.id);
  if (index >= 0) {
    shops[index] = newShop;
  } else {
    shops.push(newShop);
  }
  if (typeof window !== 'undefined') {
    localStorage.setItem(PWA_RESTAURANTS_STORAGE_KEY, JSON.stringify(shops));
  }
}

/**
 * Retrieve stored shops from localStorage with fallback to DEFAULT_SHOPS
 * Guarantees test restaurants never disappear on reload or cache updates.
 */
export function getStoredShops(): StoredShop[] {
  return getRestaurants();
}

/**
 * Save updated shops list to localStorage
 */
export function saveStoredShops(shops: StoredShop[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(PWA_RESTAURANTS_STORAGE_KEY, JSON.stringify(shops));
  } catch (err) {
    console.warn('Failed to save pwa_restaurants to localStorage:', err);
  }
}

/**
 * Get active shop safely resolving URL parameter `?shop=<id>`
 * Falling back safely to 'kannayah' or the first stored shop.
 */
export function resolveActiveShop(searchString?: string): {
  activeShopId: string;
  shops: StoredShop[];
  currentShop: StoredShop;
} {
  const query = typeof searchString === 'string' 
    ? searchString 
    : (typeof window !== 'undefined' ? window.location.search : '');
  
  const urlParams = new URLSearchParams(query);
  const rawShopParam = urlParams.get('shop') || urlParams.get('bizId') || urlParams.get('biz') || urlParams.get('b');
  const activeShopId = rawShopParam || 'kannayah';
  const shops = getStoredShops();

  // Normalize IDs to handle underscores and hyphens (e.g., city_diner <-> city-diner)
  const normalizedTarget = activeShopId.toLowerCase().replace(/[-_]/g, '');
  const currentShop = shops.find(s => {
    if (s.id === activeShopId) return true;
    const norm = s.id.toLowerCase().replace(/[-_]/g, '');
    return norm === normalizedTarget;
  }) || shops[0] || DEFAULT_SHOPS[0];

  return {
    activeShopId: currentShop.id,
    shops,
    currentShop
  };
}

/**
 * Update the approval status of a restaurant in the persistent store
 */
export function updateShopApproval(shopId: string, isApproved: boolean): void {
  const shops = getRestaurants();
  const index = shops.findIndex((s) => s.id === shopId);
  if (index >= 0) {
    shops[index].is_approved = isApproved;
    if (typeof window !== 'undefined') {
      localStorage.setItem(PWA_RESTAURANTS_STORAGE_KEY, JSON.stringify(shops));
    }
  }
}

/**
 * Converts a StoredShop into a full Business entity for app compatibility
 */
export function storedShopToBusiness(shop: StoredShop): Business {
  const isCityDiner = shop.id.includes('city');
  const isKannayah = shop.id.includes('kannayah');

  return {
    id: shop.id,
    ownerUid: `owner-${shop.id}`,
    name: shop.name,
    businessType: 'restaurant',
    tagline: isKannayah 
      ? 'Authentic Traditional Flavours, Chettinad Specials & Biryani'
      : 'Crispy Dosas, Gourmet Curries & Authentic Indian Delicacies',
    address: shop.address || (isKannayah ? '142 Temple Street, Near Clock Tower' : 'Table Zone, 5th Avenue Boulevard'),
    city: shop.city || (isKannayah ? 'Madurai' : 'Bengaluru'),
    phone: shop.phone || '+91 98450 12345',
    whatsappNumber: shop.whatsappNumber || '+919845012345',
    openingHours: 'Mon - Sun: 7:00 AM – 11:00 PM',
    currencySymbol: '₹',
    menuStyle: shop.features?.enable_visual_menu ? 'visual' : (isCityDiner ? 'visual' : 'classic'),
    isActive: true,
    is_approved: shop.is_approved ?? true,
    tables: shop.tables,
    features: shop.features,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}
