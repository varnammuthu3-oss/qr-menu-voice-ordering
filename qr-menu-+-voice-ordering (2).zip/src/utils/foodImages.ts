/**
 * Cloud Repository of Free Food Images
 * Curated high-resolution, web-optimized food photography with fast CDN delivery (Unsplash food collection).
 * Used by the PWA Visual Menu to display appetizing item photos for pizzas, coffee, starters, curries, and more.
 */

export interface FoodImageMapping {
  keywords: string[];
  imageUrl: string;
}

// Curated free cloud images with CDN optimizations (600px width, webp/auto format, 80% quality)
export const CLOUD_FOOD_IMAGES = {
  // --- PIZZAS ---
  pizzaMargherita: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=600&auto=format&fit=crop&q=80',
  pizzaPepperoni: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=600&auto=format&fit=crop&q=80',
  pizzaFarmhouseVeggie: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&auto=format&fit=crop&q=80',
  pizzaPaneerTikka: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&auto=format&fit=crop&q=80',
  pizzaBBQChicken: 'https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?w=600&auto=format&fit=crop&q=80',
  pizzaMushroomCheese: 'https://images.unsplash.com/photo-1571997478779-2adcbbe9ab2f?w=600&auto=format&fit=crop&q=80',
  pizzaArtisanWoodfired: 'https://images.unsplash.com/photo-1579751626657-72bc17010498?w=600&auto=format&fit=crop&q=80',

  // --- COFFEES & HOT BEVERAGES ---
  filterCoffeeSouthIndian: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&auto=format&fit=crop&q=80',
  espressoCup: 'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=600&auto=format&fit=crop&q=80',
  cappuccinoLatteArt: 'https://images.unsplash.com/photo-1534778101976-62847782c213?w=600&auto=format&fit=crop&q=80',
  caffeLatteGlass: 'https://images.unsplash.com/photo-1570968915860-54d5c301fa9f?w=600&auto=format&fit=crop&q=80',
  coldCoffeeIceCream: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=600&auto=format&fit=crop&q=80',
  masalaChaiTea: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&auto=format&fit=crop&q=80',
  greenTeaLemon: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=600&auto=format&fit=crop&q=80',
  hotChocolateMarshmallow: 'https://images.unsplash.com/photo-1542990253-0d0f5be5f0ed?w=600&auto=format&fit=crop&q=80',

  // --- STARTERS & APPETIZERS ---
  paneerTikka: 'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=600&auto=format&fit=crop&q=80',
  crispyCorn: 'https://images.unsplash.com/photo-1551782450-a2132b4ba21d?w=600&auto=format&fit=crop&q=80',
  springRolls: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=600&auto=format&fit=crop&q=80',
  meduVada: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600&auto=format&fit=crop&q=80',
  samosaChutney: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600&auto=format&fit=crop&q=80',
  frenchFries: 'https://images.unsplash.com/photo-1576107232684-1279f3908594?w=600&auto=format&fit=crop&q=80',
  periPeriFries: 'https://images.unsplash.com/photo-1585109649139-366815a0d713?w=600&auto=format&fit=crop&q=80',
  nachosCheese: 'https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?w=600&auto=format&fit=crop&q=80',
  chickenWings: 'https://images.unsplash.com/photo-1567620832903-9fc6debc209f?w=600&auto=format&fit=crop&q=80',
  chickenTikkaKebab: 'https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=600&auto=format&fit=crop&q=80',
  fishFryCrispy: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=600&auto=format&fit=crop&q=80',
  gobiManchurian: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=600&auto=format&fit=crop&q=80',
  garlicBreadCheese: 'https://images.unsplash.com/photo-1619895092538-128341789043?w=600&auto=format&fit=crop&q=80',
  momosDimsum: 'https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?w=600&auto=format&fit=crop&q=80',

  // --- SOUTH INDIAN & BREAKFAST ---
  masalaDosa: 'https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=600&auto=format&fit=crop&q=80',
  gheeRoastDosa: 'https://images.unsplash.com/photo-1668236543090-82eba5ee5976?w=600&auto=format&fit=crop&q=80',
  steamedIdliSambar: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=600&auto=format&fit=crop&q=80',
  uttapamOnion: 'https://images.unsplash.com/photo-1630383249896-424e482df921?w=600&auto=format&fit=crop&q=80',
  parottaSalna: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=600&auto=format&fit=crop&q=80',
  choleBhature: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=600&auto=format&fit=crop&q=80',
  puriBhaji: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600&auto=format&fit=crop&q=80',

  // --- MAIN COURSE & CURRIES ---
  paneerButterMasala: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=600&auto=format&fit=crop&q=80',
  butterChicken: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=600&auto=format&fit=crop&q=80',
  dalMakhani: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=600&auto=format&fit=crop&q=80',
  kadaiPaneer: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=600&auto=format&fit=crop&q=80',
  garlicButterNaan: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600&auto=format&fit=crop&q=80',
  chettinadChickenFry: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=600&auto=format&fit=crop&q=80',

  // --- BIRYANI & RICE ---
  chickenDumBiryani: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=600&auto=format&fit=crop&q=80',
  vegBiryaniPulao: 'https://images.unsplash.com/photo-1633945274405-b6c8069047b0?w=600&auto=format&fit=crop&q=80',
  friedRiceIndoChinese: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=600&auto=format&fit=crop&q=80',

  // --- BURGERS & SANDWICHES ---
  vegBurgerCrispy: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80',
  cheeseBurgerGourmet: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=600&auto=format&fit=crop&q=80',
  grilledSandwich: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=600&auto=format&fit=crop&q=80',
  clubSandwich: 'https://images.unsplash.com/photo-1553909489-cd47e0907980?w=600&auto=format&fit=crop&q=80',

  // --- PASTAS & NOODLES ---
  whiteSauceAlfredoPasta: 'https://images.unsplash.com/photo-1621996346565-e3d5d6281696?w=600&auto=format&fit=crop&q=80',
  redSauceArrabbiataPasta: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=600&auto=format&fit=crop&q=80',
  hakkaNoodlesChowMein: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?w=600&auto=format&fit=crop&q=80',

  // --- DESSERTS ---
  gulabJamun: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=600&auto=format&fit=crop&q=80',
  brownieIceCream: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=600&auto=format&fit=crop&q=80',
  cheesecakeSlice: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=600&auto=format&fit=crop&q=80',
  tiramisuClassic: 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=600&auto=format&fit=crop&q=80',
  iceCreamSundae: 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=600&auto=format&fit=crop&q=80',
  jigarthandaMadurai: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=600&auto=format&fit=crop&q=80',

  // --- COLD BEVERAGES & SHAKES ---
  mangoShakeLassi: 'https://images.unsplash.com/photo-1546173159-315724a31696?w=600&auto=format&fit=crop&q=80',
  chocolateMilkshake: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=600&auto=format&fit=crop&q=80',
  freshLimeSoda: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=600&auto=format&fit=crop&q=80',
  virginMojitoMint: 'https://images.unsplash.com/photo-1551538827-9c037cb4f32a?w=600&auto=format&fit=crop&q=80',
  icedTeaLemon: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=600&auto=format&fit=crop&q=80',

  // --- GENERAL CATEGORY DEFAULTS ---
  defaultPizza: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&auto=format&fit=crop&q=80',
  defaultCoffee: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=600&auto=format&fit=crop&q=80',
  defaultStarter: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=600&auto=format&fit=crop&q=80',
  defaultMainCourse: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=600&auto=format&fit=crop&q=80',
  defaultBiryani: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=600&auto=format&fit=crop&q=80',
  defaultDessert: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=600&auto=format&fit=crop&q=80',
  defaultBeverage: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=600&auto=format&fit=crop&q=80',
  defaultSalad: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=600&auto=format&fit=crop&q=80',
  defaultFoodFallback: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600&auto=format&fit=crop&q=80',
};

// Explicit keyword mapping hierarchy for item names and descriptions
const ITEM_NAME_RULES: { keywords: string[]; imageUrl: string }[] = [
  // --- PIZZAS ---
  {
    keywords: ['margherita', 'margarita', 'cheese burst', 'double cheese'],
    imageUrl: CLOUD_FOOD_IMAGES.pizzaMargherita,
  },
  {
    keywords: ['pepperoni', 'salami'],
    imageUrl: CLOUD_FOOD_IMAGES.pizzaPepperoni,
  },
  {
    keywords: ['farmhouse', 'veggie paradise', 'veggie supreme', 'garden pizza', 'veg pizza'],
    imageUrl: CLOUD_FOOD_IMAGES.pizzaFarmhouseVeggie,
  },
  {
    keywords: ['paneer pizza', 'paneer tikka pizza'],
    imageUrl: CLOUD_FOOD_IMAGES.pizzaPaneerTikka,
  },
  {
    keywords: ['bbq chicken', 'chicken pizza', 'barbecue pizza'],
    imageUrl: CLOUD_FOOD_IMAGES.pizzaBBQChicken,
  },
  {
    keywords: ['mushroom pizza', 'truffle pizza', 'fungi'],
    imageUrl: CLOUD_FOOD_IMAGES.pizzaMushroomCheese,
  },
  {
    keywords: ['wood fired', 'wood-fired', 'artisan pizza', 'thin crust pizza'],
    imageUrl: CLOUD_FOOD_IMAGES.pizzaArtisanWoodfired,
  },
  {
    keywords: ['pizza', 'calzone'],
    imageUrl: CLOUD_FOOD_IMAGES.defaultPizza,
  },

  // --- COFFEES & HOT BEVERAGES ---
  {
    keywords: ['filter coffee', 'degree coffee', 'filter kaapi', 'kaapi', 'kumbakonam'],
    imageUrl: CLOUD_FOOD_IMAGES.filterCoffeeSouthIndian,
  },
  {
    keywords: ['espresso', 'ristretto', 'macchiato'],
    imageUrl: CLOUD_FOOD_IMAGES.espressoCup,
  },
  {
    keywords: ['cappuccino', 'flat white'],
    imageUrl: CLOUD_FOOD_IMAGES.cappuccinoLatteArt,
  },
  {
    keywords: ['latte', 'caffe latte', 'caramel latte', 'vanilla latte'],
    imageUrl: CLOUD_FOOD_IMAGES.caffeLatteGlass,
  },
  {
    keywords: ['cold coffee', 'iced coffee', 'frappe', 'iced latte', 'iced americano'],
    imageUrl: CLOUD_FOOD_IMAGES.coldCoffeeIceCream,
  },
  {
    keywords: ['chai', 'masala chai', 'ginger tea', 'adrak chai', 'tea', 'kadak chai'],
    imageUrl: CLOUD_FOOD_IMAGES.masalaChaiTea,
  },
  {
    keywords: ['green tea', 'lemon tea', 'herbal tea', 'chamomile'],
    imageUrl: CLOUD_FOOD_IMAGES.greenTeaLemon,
  },
  {
    keywords: ['hot chocolate', 'cocoa'],
    imageUrl: CLOUD_FOOD_IMAGES.hotChocolateMarshmallow,
  },
  {
    keywords: ['coffee'],
    imageUrl: CLOUD_FOOD_IMAGES.defaultCoffee,
  },

  // --- STARTERS & APPETIZERS ---
  {
    keywords: ['paneer tikka', 'tandoori paneer', 'malai paneer tikka'],
    imageUrl: CLOUD_FOOD_IMAGES.paneerTikka,
  },
  {
    keywords: ['crispy corn', 'butter corn', 'corn kernels'],
    imageUrl: CLOUD_FOOD_IMAGES.crispyCorn,
  },
  {
    keywords: ['spring roll', 'spring rolls', 'veg roll'],
    imageUrl: CLOUD_FOOD_IMAGES.springRolls,
  },
  {
    keywords: ['vada', 'medu vada', 'sambar vada', 'vadai'],
    imageUrl: CLOUD_FOOD_IMAGES.meduVada,
  },
  {
    keywords: ['samosa', 'samosas'],
    imageUrl: CLOUD_FOOD_IMAGES.samosaChutney,
  },
  {
    keywords: ['peri peri fries', 'masala fries', 'loaded fries'],
    imageUrl: CLOUD_FOOD_IMAGES.periPeriFries,
  },
  {
    keywords: ['french fries', 'potato fries', 'finger chips', 'fries'],
    imageUrl: CLOUD_FOOD_IMAGES.frenchFries,
  },
  {
    keywords: ['nachos', 'nacho chips', 'tortilla chips'],
    imageUrl: CLOUD_FOOD_IMAGES.nachosCheese,
  },
  {
    keywords: ['chicken wings', 'hot wings', 'bbq wings', 'buffalo wings'],
    imageUrl: CLOUD_FOOD_IMAGES.chickenWings,
  },
  {
    keywords: ['chicken tikka', 'tandoori chicken', 'kebab', 'seekh kebab', 'chicken fry'],
    imageUrl: CLOUD_FOOD_IMAGES.chickenTikkaKebab,
  },
  {
    keywords: ['fish fry', 'crispy fish', 'fish fingers', 'prawn fry'],
    imageUrl: CLOUD_FOOD_IMAGES.fishFryCrispy,
  },
  {
    keywords: ['gobi manchurian', 'veg manchurian', 'paneer 65', 'gobi 65'],
    imageUrl: CLOUD_FOOD_IMAGES.gobiManchurian,
  },
  {
    keywords: ['garlic bread', 'cheese garlic bread', 'bruschetta'],
    imageUrl: CLOUD_FOOD_IMAGES.garlicBreadCheese,
  },
  {
    keywords: ['momo', 'momos', 'dimsum', 'dumpling'],
    imageUrl: CLOUD_FOOD_IMAGES.momosDimsum,
  },

  // --- SOUTH INDIAN & BREAKFAST ---
  {
    keywords: ['masala dosa', 'mysore masala dosa'],
    imageUrl: CLOUD_FOOD_IMAGES.masalaDosa,
  },
  {
    keywords: ['ghee roast', 'podi roast', 'podi dosa', 'plain dosa', 'paper roast', 'dosa'],
    imageUrl: CLOUD_FOOD_IMAGES.gheeRoastDosa,
  },
  {
    keywords: ['idli', 'idly', 'sambar idli', 'steamed idli'],
    imageUrl: CLOUD_FOOD_IMAGES.steamedIdliSambar,
  },
  {
    keywords: ['uttapam', 'onion uttapam', 'tomato uttapam'],
    imageUrl: CLOUD_FOOD_IMAGES.uttapamOnion,
  },
  {
    keywords: ['parotta', 'paratha', 'kothu parotta', 'ceylon parotta', 'salna'],
    imageUrl: CLOUD_FOOD_IMAGES.parottaSalna,
  },
  {
    keywords: ['chole bhature', 'bhature', 'chana bhatura'],
    imageUrl: CLOUD_FOOD_IMAGES.choleBhature,
  },
  {
    keywords: ['puri', 'poori', 'puri bhaji', 'poori masala'],
    imageUrl: CLOUD_FOOD_IMAGES.puriBhaji,
  },

  // --- MAIN COURSE & CURRIES ---
  {
    keywords: ['paneer butter masala', 'butter paneer', 'shahi paneer'],
    imageUrl: CLOUD_FOOD_IMAGES.paneerButterMasala,
  },
  {
    keywords: ['butter chicken', 'chicken makhani', 'murgh makhani'],
    imageUrl: CLOUD_FOOD_IMAGES.butterChicken,
  },
  {
    keywords: ['dal makhani', 'dal makhni', 'dal tadka', 'yellow dal'],
    imageUrl: CLOUD_FOOD_IMAGES.dalMakhani,
  },
  {
    keywords: ['kadai paneer', 'matar paneer', 'palak paneer', 'paneer tikka masala'],
    imageUrl: CLOUD_FOOD_IMAGES.kadaiPaneer,
  },
  {
    keywords: ['naan', 'garlic naan', 'butter naan', 'tandoori roti', 'roti', 'kulcha'],
    imageUrl: CLOUD_FOOD_IMAGES.garlicButterNaan,
  },
  {
    keywords: ['chettinad', 'pepper chicken', 'chicken curry', 'mutton curry'],
    imageUrl: CLOUD_FOOD_IMAGES.chettinadChickenFry,
  },

  // --- BIRYANI & RICE ---
  {
    keywords: ['chicken biryani', 'mutton biryani', 'dum biryani', 'hyderabadi biryani'],
    imageUrl: CLOUD_FOOD_IMAGES.chickenDumBiryani,
  },
  {
    keywords: ['veg biryani', 'paneer biryani', 'pulao', 'jeera rice'],
    imageUrl: CLOUD_FOOD_IMAGES.vegBiryaniPulao,
  },
  {
    keywords: ['fried rice', 'schezwan rice', 'chinese rice'],
    imageUrl: CLOUD_FOOD_IMAGES.friedRiceIndoChinese,
  },
  {
    keywords: ['biryani', 'biriyani'],
    imageUrl: CLOUD_FOOD_IMAGES.defaultBiryani,
  },

  // --- BURGERS & SANDWICHES ---
  {
    keywords: ['veg burger', 'veggie burger', 'aloo tikki burger'],
    imageUrl: CLOUD_FOOD_IMAGES.vegBurgerCrispy,
  },
  {
    keywords: ['cheese burger', 'cheeseburger', 'double burger', 'chicken burger'],
    imageUrl: CLOUD_FOOD_IMAGES.cheeseBurgerGourmet,
  },
  {
    keywords: ['grilled sandwich', 'paneer sandwich', 'cheese sandwich', 'toast'],
    imageUrl: CLOUD_FOOD_IMAGES.grilledSandwich,
  },
  {
    keywords: ['club sandwich', 'sandwich'],
    imageUrl: CLOUD_FOOD_IMAGES.clubSandwich,
  },

  // --- PASTAS & NOODLES ---
  {
    keywords: ['white sauce', 'alfredo', 'carbonara', 'cream pasta', 'penne alfredo'],
    imageUrl: CLOUD_FOOD_IMAGES.whiteSauceAlfredoPasta,
  },
  {
    keywords: ['red sauce', 'arrabbiata', 'arrabiata', 'marinara', 'penne arrabbiata', 'pasta'],
    imageUrl: CLOUD_FOOD_IMAGES.redSauceArrabbiataPasta,
  },
  {
    keywords: ['noodles', 'hakka noodles', 'chow mein', 'ramen', 'spaghetti'],
    imageUrl: CLOUD_FOOD_IMAGES.hakkaNoodlesChowMein,
  },

  // --- DESSERTS ---
  {
    keywords: ['gulab jamun', 'rasgulla', 'rasmalai', 'sweet'],
    imageUrl: CLOUD_FOOD_IMAGES.gulabJamun,
  },
  {
    keywords: ['brownie', 'sizzling brownie', 'lava cake', 'chocolate cake'],
    imageUrl: CLOUD_FOOD_IMAGES.brownieIceCream,
  },
  {
    keywords: ['cheesecake', 'cheese cake'],
    imageUrl: CLOUD_FOOD_IMAGES.cheesecakeSlice,
  },
  {
    keywords: ['tiramisu'],
    imageUrl: CLOUD_FOOD_IMAGES.tiramisuClassic,
  },
  {
    keywords: ['ice cream', 'sundae', 'gelato', 'kulfi', 'cassata'],
    imageUrl: CLOUD_FOOD_IMAGES.iceCreamSundae,
  },
  {
    keywords: ['jigarthanda'],
    imageUrl: CLOUD_FOOD_IMAGES.jigarthandaMadurai,
  },

  // --- COLD BEVERAGES & SHAKES ---
  {
    keywords: ['mango shake', 'mango lassi', 'lassi', 'sweet lassi'],
    imageUrl: CLOUD_FOOD_IMAGES.mangoShakeLassi,
  },
  {
    keywords: ['chocolate shake', 'oreo shake', 'milkshake', 'thick shake', 'shake'],
    imageUrl: CLOUD_FOOD_IMAGES.chocolateMilkshake,
  },
  {
    keywords: ['lime soda', 'fresh lime', 'lemonade', 'nimbu soda', 'soda'],
    imageUrl: CLOUD_FOOD_IMAGES.freshLimeSoda,
  },
  {
    keywords: ['mojito', 'virgin mojito', 'mint cooler', 'mocktail'],
    imageUrl: CLOUD_FOOD_IMAGES.virginMojitoMint,
  },
  {
    keywords: ['iced tea', 'ice tea', 'peach iced tea'],
    imageUrl: CLOUD_FOOD_IMAGES.icedTeaLemon,
  },
];

// Fallback rules based on category name
const CATEGORY_RULES: { keywords: string[]; imageUrl: string }[] = [
  { keywords: ['pizza', 'pizzas', 'crust'], imageUrl: CLOUD_FOOD_IMAGES.defaultPizza },
  { keywords: ['coffee', 'tea', 'hot beverage', 'hot drink', 'kaapi', 'brew'], imageUrl: CLOUD_FOOD_IMAGES.defaultCoffee },
  { keywords: ['starter', 'starters', 'appetizer', 'appetizers', 'snack', 'snacks', 'finger food', 'bites'], imageUrl: CLOUD_FOOD_IMAGES.defaultStarter },
  { keywords: ['biryani', 'biriyanis', 'rice', 'pulao'], imageUrl: CLOUD_FOOD_IMAGES.defaultBiryani },
  { keywords: ['south indian', 'tiffin', 'tiffins', 'dosa', 'idli', 'breakfast'], imageUrl: CLOUD_FOOD_IMAGES.masalaDosa },
  { keywords: ['main course', 'curry', 'curries', 'gravy', 'gravies', 'gravies & curries', 'mains', 'sabzi'], imageUrl: CLOUD_FOOD_IMAGES.defaultMainCourse },
  { keywords: ['pasta', 'italian', 'continental', 'noodles'], imageUrl: CLOUD_FOOD_IMAGES.whiteSauceAlfredoPasta },
  { keywords: ['burger', 'burgers', 'sandwich', 'sandwiches'], imageUrl: CLOUD_FOOD_IMAGES.vegBurgerCrispy },
  { keywords: ['dessert', 'desserts', 'sweet', 'sweets', 'ice cream', 'bakery', 'cake'], imageUrl: CLOUD_FOOD_IMAGES.defaultDessert },
  { keywords: ['beverage', 'beverages', 'drink', 'drinks', 'shake', 'shakes', 'mocktail', 'juice', 'cooler'], imageUrl: CLOUD_FOOD_IMAGES.defaultBeverage },
  { keywords: ['salad', 'salads', 'healthy'], imageUrl: CLOUD_FOOD_IMAGES.defaultSalad },
];

/**
 * Maps a MenuItem and its Category to a curated high-definition cloud food image.
 * If the item already has a non-empty, valid imageUrl, that is preserved.
 * Otherwise, it executes intelligent semantic keyword matching against the cloud repository.
 */
export function getFoodImageUrl(
  item: { name: string; description?: string; imageUrl?: string; isVeg?: string },
  categoryName?: string
): string {
  // 1. If explicit valid image exists, use it
  if (item.imageUrl && item.imageUrl.trim().length > 0 && !item.imageUrl.includes('placeholder')) {
    return item.imageUrl.trim();
  }

  const nameLower = (item.name || '').toLowerCase();
  const descLower = (item.description || '').toLowerCase();
  const combinedItemText = `${nameLower} ${descLower}`;
  const catLower = (categoryName || '').toLowerCase();

  // 2. Check item name & description against specific dish rules
  for (const rule of ITEM_NAME_RULES) {
    if (rule.keywords.some((kw) => combinedItemText.includes(kw))) {
      return rule.imageUrl;
    }
  }

  // 3. Check category name
  for (const rule of CATEGORY_RULES) {
    if (rule.keywords.some((kw) => catLower.includes(kw))) {
      return rule.imageUrl;
    }
  }

  // 4. Default fallback based on vegetarian status
  if (item.isVeg === 'non-veg') {
    return CLOUD_FOOD_IMAGES.chickenTikkaKebab;
  }
  
  // 5. Ultimate appetizing culinary spread fallback
  return CLOUD_FOOD_IMAGES.defaultFoodFallback;
}
