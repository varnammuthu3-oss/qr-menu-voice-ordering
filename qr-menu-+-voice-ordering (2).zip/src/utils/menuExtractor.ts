import { ExtractedCategory, ExtractedMenuItem, MenuExtractionResult, FoodDietType } from '../types';

/**
 * Static-friendly offline rule-based parser for raw menu text, pasted lists,
 * or uploaded document text (.txt, .csv, markdown).
 * Ensures instant menu item generation without requiring an active server or API key.
 */
export function parseMenuTextOffline(rawText: string): MenuExtractionResult {
  if (!rawText || !rawText.trim()) {
    return { categories: [], items: [], confidenceNote: 'No text provided for extraction.' };
  }

  const lines = rawText
    .split(/\r?\n/)
    .map(l => l.trim())
    .filter(l => l.length > 0);

  const categories: ExtractedCategory[] = [];
  const items: ExtractedMenuItem[] = [];

  let currentCategory = 'Popular Specials';
  const categorySet = new Set<string>();

  const nonVegKeywords = ['chicken', 'mutton', 'lamb', 'beef', 'pork', 'fish', 'prawn', 'shrimp', 'crab', 'meat', 'keema', 'bacon', 'ham'];
  const eggKeywords = ['egg', 'omelette', 'omlet', 'bhurji', 'scrambled'];

  const detectDiet = (name: string, desc: string): FoodDietType => {
    const combined = `${name} ${desc}`.toLowerCase();
    if (nonVegKeywords.some(k => combined.includes(k))) return 'non-veg';
    if (eggKeywords.some(k => combined.includes(k))) return 'egg';
    return 'veg';
  };

  const isCategoryHeader = (line: string): boolean => {
    // Looks like [Category], === Category ===, Category:, or UPPERCASE short phrase
    if (/^(\[|\*|-|=)+(.*?)(\]|\*|-|=)+$/.test(line)) return true;
    if (line.endsWith(':') && line.length < 35 && !/\d{2,}/.test(line)) return true;
    if (line === line.toUpperCase() && line.length > 3 && line.length < 32 && !/\d/.test(line)) return true;
    return false;
  };

  const cleanCategoryName = (line: string): string => {
    return line.replace(/^(\[|\*|-|=)+/, '').replace(/(\]|\*|-|=)+$/, '').replace(/:$/, '').trim();
  };

  lines.forEach((line, idx) => {
    // Check if line is a category header
    if (isCategoryHeader(line)) {
      const catName = cleanCategoryName(line);
      if (catName && catName.length > 1) {
        currentCategory = catName;
        if (!categorySet.has(currentCategory)) {
          categorySet.add(currentCategory);
          categories.push({ name: currentCategory });
        }
        return;
      }
    }

    // Try extracting price: matches trailing or delimited numbers like - 120, : ₹80, ... 150, ₹ 220
    const priceMatch = line.match(/(?:[-:–|•.]|\s+)?(?:\u20B9|\$|₹|Rs\.?|INR)?\s*(\d+(?:\.\d{1,2})?)\s*(?:\/-)?$/i)
      || line.match(/^(.*?)(?:[-:–|•.]|\s{2,})(?:\u20B9|\$|₹|Rs\.?|INR)?\s*(\d+(?:\.\d{1,2})?)/i);

    if (priceMatch) {
      let itemName = '';
      let priceVal: number | null = null;
      let description = '';

      if (priceMatch[2]) {
        // Matched item ... price
        itemName = priceMatch[1].trim();
        priceVal = parseFloat(priceMatch[2]);
      } else {
        // Matched trailing price
        const priceStr = priceMatch[1];
        priceVal = parseFloat(priceStr);
        itemName = line.substring(0, line.lastIndexOf(priceMatch[0])).trim();
      }

      // Cleanup leading bullets, numbers (e.g. "1. Masala Dosa" -> "Masala Dosa")
      itemName = itemName.replace(/^\d+[\.\)]\s*/, '').replace(/^[-•*]\s*/, '').trim();

      // Check for parenthetical description
      const descMatch = itemName.match(/\((.*?)\)/);
      if (descMatch) {
        description = descMatch[1].trim();
      }

      if (itemName.length >= 2) {
        if (!categorySet.has(currentCategory)) {
          categorySet.add(currentCategory);
          categories.push({ name: currentCategory });
        }

        items.push({
          tempId: `item_${Date.now()}_${idx}`,
          categoryName: currentCategory,
          name: itemName,
          description,
          price: priceVal || 50,
          isVeg: detectDiet(itemName, description),
          isAvailable: true,
          needsReview: false
        });
      }
    } else if (line.length >= 3 && line.length < 50 && !line.includes('http')) {
      // Line without obvious price: add with default placeholder price
      const cleanName = line.replace(/^\d+[\.\)]\s*/, '').replace(/^[-•*]\s*/, '').trim();
      if (cleanName.length >= 2) {
        if (!categorySet.has(currentCategory)) {
          categorySet.add(currentCategory);
          categories.push({ name: currentCategory });
        }

        items.push({
          tempId: `item_${Date.now()}_${idx}`,
          categoryName: currentCategory,
          name: cleanName,
          description: '',
          price: 60,
          isVeg: detectDiet(cleanName, ''),
          isAvailable: true,
          needsReview: true,
          reviewReason: 'Price estimated'
        });
      }
    }
  });

  return {
    categories: categories.length > 0 ? categories : [{ name: 'All Day Menu' }],
    items,
    confidenceNote: `Parsed ${items.length} items across ${categories.length || 1} categories via static text extractor.`
  };
}

/**
 * High-performance Automated Menu Extraction
 * Dispatches to server-side Gemini 3.8 Flash model, with automatic fallback
 * to the client-side rule-based text parser if offline or server is unavailable.
 */
export async function extractMenuWithAI(params: {
  images?: { base64Data: string; mimeType: string }[];
  text?: string;
}): Promise<MenuExtractionResult> {
  const { images = [], text = '' } = params;

  // If text is provided and no images, we can attempt server-side Gemini first,
  // falling back immediately to static parser if needed.
  try {
    const res = await fetch('/api/extract-menu', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        images,
        rawText: text
      })
    });

    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.items) && data.items.length > 0) {
        return {
          categories: Array.isArray(data.categories) && data.categories.length > 0 ? data.categories : [{ name: 'Main Menu' }],
          items: data.items.map((it: any, idx: number) => ({
            tempId: it.tempId || `ai_item_${Date.now()}_${idx}`,
            categoryName: it.categoryName || 'Main Menu',
            name: it.name || 'Unnamed Dish',
            description: it.description || '',
            price: typeof it.price === 'number' && it.price > 0 ? it.price : 50,
            isVeg: it.isVeg === 'non-veg' ? 'non-veg' : it.isVeg === 'egg' ? 'egg' : 'veg',
            isAvailable: it.isAvailable !== false,
            needsReview: !!it.needsReview,
            reviewReason: it.reviewReason || ''
          })),
          confidenceNote: data.confidenceNote || `Extracted ${data.items.length} items using Gemini AI.`
        };
      }
    }
  } catch (err) {
    console.warn('[extractMenuWithAI] Server Gemini call encountered error, attempting offline parser:', err);
  }

  // Fallback: If text was provided, parse offline
  if (text.trim().length > 0) {
    return parseMenuTextOffline(text);
  }

  throw new Error('Menu extraction could not detect items. Please upload a clear photo or paste your menu list.');
}

/**
 * Pre-curated Starter Menus for 1-Click Instant Onboarding
 */
export const PRESET_SAMPLE_MENUS = {
  southIndian: {
    name: 'South Indian Tiffin & Filter Coffee',
    text: `[Tiffin & Breakfast]
Idli (2 pcs with Sambar & 2 Chutneys) - 35
Medu Vada (Crispy golden lentil fritter) - 30
Masala Dosa (Crispy golden crepe with spiced potato) - 70
Ghee Podi Roast (Crispy dosa tossed with aromatic gunpowder ghee) - 95
Rava Onion Dosa - 85
Poori Masala (2 fluffy puris with potato sagu) - 60
Ghee Ven Pongal (Melting rice-dal porridge with cashews) - 65

[Beverages]
Filter Coffee (Freshly decocted chicory coffee) - 25
Masala Chai (Ginger cardamom brewed tea) - 20
Sweet Lassi - 40`
  },
  cafeBakery: {
    name: 'Urban Cafe & Bakery',
    text: `[Artisan Coffee & Drinks]
Espresso Solo - 90
Cappuccino Classic - 140
Iced Americano - 120
Cold Brew Tonic - 160
Hot Chocolate with Marshmallows - 150

[Sandwiches & Quick Bites]
Paneer Tikka Croissant - 180
Classic Grilled Cheese Sandwich - 130
Smoked Chicken Club Sandwich - 210
French Fries with Truffle Mayo - 120`
  },
  biryaniNorth: {
    name: 'Royal Biryani & Tandoor',
    text: `[Dum Biryani Specialties]
Dum Chicken Biryani (Served with Salan & Raita) - 220
Mutton Dum Biryani (Tender aromatic cuts) - 320
Paneer Subz Dum Biryani - 180
Egg Dum Biryani (2 spiced boiled eggs) - 160

[Tandoori & Starters]
Chicken Tikka Kebab (6 pcs) - 240
Paneer Malai Tikka - 210
Butter Garlic Naan - 50`
  }
};
