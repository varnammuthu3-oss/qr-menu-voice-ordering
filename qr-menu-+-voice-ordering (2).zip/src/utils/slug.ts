/**
 * Utilities for URL slug generation, parsing, and routing
 */

// Reserved routing segments that are NOT merchant slugs
export const RESERVED_SLUGS = new Set([
  '',
  'api',
  'admin',
  'master-admin',
  'super-dashboard',
  'service-worker.js',
  'manifest.json',
  'favicon.ico',
  'onboard',
  'onboarding',
  'register',
  'login',
  'signup',
  'assets',
  'duty',
  'orders'
]);

/**
 * Clean and convert a restaurant name into a URL-friendly slug
 * e.g., "Kannayah Briyani & Tiffin Center" -> "kannayah-briyani-tiffin-center"
 */
export function generateSlug(name: string, existingIds: string[] = []): string {
  if (!name || !name.trim()) {
    return `restaurant-${Date.now().toString(36)}`;
  }

  // 1. Lowercase and replace non-alphanumerics with hyphens
  let slug = name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

  if (!slug) {
    slug = `shop-${Date.now().toString(36)}`;
  }

  // Avoid reserved slugs
  if (RESERVED_SLUGS.has(slug)) {
    slug = `${slug}-menu`;
  }

  // Ensure uniqueness against existing IDs
  const existingSet = new Set(existingIds.map(id => id.toLowerCase()));
  if (!existingSet.has(slug)) {
    return slug;
  }

  // If duplicate, append numerical suffix
  let counter = 2;
  while (existingSet.has(`${slug}-${counter}`)) {
    counter++;
  }
  return `${slug}-${counter}`;
}

/**
 * Extract active restaurant slug from current window location.
 * Checks pathname (e.g. /kannayah or /b/kannayah), hash (e.g. #b/kannayah or #kannayah),
 * and query parameters (?slug=kannayah or ?shop=kannayah or ?bizId=kannayah).
 * Returns null if no slug is present (meaning root/onboarding fallback).
 */
export function extractSlugFromUrl(): string | null {
  if (typeof window === 'undefined') return null;

  const pathname = window.location.pathname;
  const hash = window.location.hash;
  const searchParams = new URLSearchParams(window.location.search);

  // 1. Explicit query parameters (highest priority for strict links)
  const querySlug =
    searchParams.get('slug') ||
    searchParams.get('shop') ||
    searchParams.get('bizId') ||
    searchParams.get('restaurant_id') ||
    searchParams.get('restaurant') ||
    searchParams.get('b') ||
    searchParams.get('id');

  if (querySlug && querySlug.trim()) {
    const clean = querySlug.trim().toLowerCase();
    if (!RESERVED_SLUGS.has(clean)) {
      return clean;
    }
  }

  // 2. Hash routing: e.g. #b/kannayah, #/b/kannayah, #/kannayah, or #kannayah
  if (hash) {
    const cleanHash = hash.replace(/^#\/?/, '').split('?')[0];
    // Check #b/slug or #/b/slug
    const bMatch = cleanHash.match(/^(?:b\/)?([a-zA-Z0-9_-]+)/);
    if (bMatch && bMatch[1]) {
      const candidate = bMatch[1].toLowerCase();
      if (!RESERVED_SLUGS.has(candidate)) {
        return candidate;
      }
    }
  }

  // 3. Pathname routing: e.g. /kannayah or /b/kannayah
  if (pathname && pathname !== '/') {
    const trimmed = pathname.replace(/^\/+|\/+$/g, '');
    const segments = trimmed.split('/').filter(Boolean);

    if (segments.length === 1) {
      const candidate = segments[0].toLowerCase();
      if (!RESERVED_SLUGS.has(candidate)) {
        return candidate;
      }
    } else if (segments.length >= 2 && segments[0] === 'b') {
      const candidate = segments[1].toLowerCase();
      if (!RESERVED_SLUGS.has(candidate)) {
        return candidate;
      }
    }
  }

  return null;
}

/**
 * Generate canonical shareable customer menu URL for a given slug
 * Produces clean slug URLs e.g. https://domain.com/kannayah or https://domain.com/#b/kannayah
 */
export function buildRestaurantMenuUrl(slug: string, origin?: string): string {
  const base = origin || (typeof window !== 'undefined' ? window.location.origin : '');
  if (!slug) return base;
  return `${base}/#b/${encodeURIComponent(slug)}`;
}
