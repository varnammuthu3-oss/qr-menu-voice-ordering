import { TenantType, MenuCategory, MenuItem } from '../types';

export interface TenantConfig {
  type: TenantType;
  locationHeader: string;
  locationPlaceholder: string;
  orderCtaText: string;
  primaryCategories: string[];
  defaultBusinessId: string;
  defaultBusinessName: string;
  defaultLocationNumber: string;
}

export const RESTAURANT_CONFIG: TenantConfig = {
  type: 'restaurant',
  locationHeader: 'Table Number',
  locationPlaceholder: 'e.g. Table 05',
  orderCtaText: 'Send Order to Kitchen',
  primaryCategories: ['Starters', 'Main Course', 'Beverages'],
  defaultBusinessId: 'city-diner',
  defaultBusinessName: 'City Diner',
  defaultLocationNumber: '05'
};

export const GUESTHOUSE_CONFIG: TenantConfig = {
  type: 'guesthouse',
  locationHeader: 'Room Number',
  locationPlaceholder: 'e.g. Room 102',
  orderCtaText: 'Send Request to Reception',
  primaryCategories: ['Breakfast', 'In-Room Dining', 'Housekeeping & Amenities'],
  defaultBusinessId: 'green-villa-guesthouse',
  defaultBusinessName: 'Green Villa Guest House',
  defaultLocationNumber: '102'
};

export const LOCKED_TENANT_TYPE_KEY = 'qr_menu_locked_tenant_type';
export const LOCKED_LOCATION_ID_KEY = 'qr_menu_locked_location_id';
export const LOCKED_BIZ_ID_KEY = 'qr_menu_last_selected_biz_id';

export function getTenantConfig(type?: string | null): TenantConfig {
  if (type && type.toLowerCase() === 'guesthouse') {
    return GUESTHOUSE_CONFIG;
  }
  return RESTAURANT_CONFIG;
}

/**
 * Strict QR URL Generator locked to business type and unit ID:
 * - Restaurant: ?type=restaurant&bizId=<ID>&table=<TableNumber>
 * - Guest House: ?type=guesthouse&bizId=<ID>&room=<RoomNumber>
 */
export function generateQrUrl(options: {
  businessId: string;
  businessType?: TenantType;
  unitNumber?: string;
  origin?: string;
}): string {
  const baseOrigin = options.origin || (typeof window !== 'undefined' ? window.location.origin : '');
  const isGuestHouse = options.businessType === 'guesthouse';
  const bizId = options.businessId || (isGuestHouse ? 'green-villa-guesthouse' : 'city-diner');

  if (isGuestHouse) {
    const room = options.unitNumber?.trim() || '102';
    return `${baseOrigin}/?type=guesthouse&bizId=${encodeURIComponent(bizId)}&room=${encodeURIComponent(room)}`;
  } else {
    const table = options.unitNumber?.trim() || '05';
    return `${baseOrigin}/?type=restaurant&bizId=${encodeURIComponent(bizId)}&table=${encodeURIComponent(table)}`;
  }
}

/**
 * Parses URL query params and hash parameters for strict tenant locking:
 * Handles `?type=restaurant&bizId=<ID>&table=<TableNumber>`
 * Handles `?type=guesthouse&bizId=<ID>&room=<RoomNumber>`
 */
export function parseUrlTenantParams(): {
  tenantType: TenantType;
  locationId: string;
  businessIdFromUrl: string;
  isExplicitFromQr: boolean;
} {
  if (typeof window === 'undefined') {
    return {
      tenantType: 'restaurant',
      locationId: '',
      businessIdFromUrl: 'city-diner',
      isExplicitFromQr: false
    };
  }

  // Check search params
  const searchParams = new URLSearchParams(window.location.search);
  let rawType = searchParams.get('type');
  let rawBizId = searchParams.get('restaurant_id') || searchParams.get('restaurantId') || searchParams.get('restaurant') || searchParams.get('shop') || searchParams.get('bizId') || searchParams.get('biz') || searchParams.get('b') || searchParams.get('businessId') || '';
  let rawTable = searchParams.get('table_number') || searchParams.get('tableNumber') || searchParams.get('table_no') || searchParams.get('tableno') || searchParams.get('table') || searchParams.get('tbl');
  let rawRoom = searchParams.get('room_number') || searchParams.get('roomNumber') || searchParams.get('room_no') || searchParams.get('room');
  let rawId = searchParams.get('id');

  // Check hash parameters if query string is placed after hash (e.g., /#/?type=guesthouse&bizId=...&room=102)
  const hash = window.location.hash;
  if (hash.includes('?')) {
    const hashQuery = hash.split('?')[1];
    const hashParams = new URLSearchParams(hashQuery);
    if (!rawType && hashParams.get('type')) rawType = hashParams.get('type');
    if (!rawBizId) {
      rawBizId = hashParams.get('restaurant_id') || hashParams.get('restaurantId') || hashParams.get('restaurant') || hashParams.get('shop') || hashParams.get('bizId') || hashParams.get('biz') || hashParams.get('b') || hashParams.get('businessId') || '';
    }
    if (!rawTable) {
      rawTable = hashParams.get('table_number') || hashParams.get('tableNumber') || hashParams.get('table_no') || hashParams.get('tableno') || hashParams.get('table') || hashParams.get('tbl');
    }
    if (!rawRoom) {
      rawRoom = hashParams.get('room_number') || hashParams.get('roomNumber') || hashParams.get('room_no') || hashParams.get('room');
    }
    if (!rawId && hashParams.get('id')) rawId = hashParams.get('id');
  }

  // Also check pathname for direct /b/:id routes
  if (!rawBizId) {
    const pathMatch = window.location.pathname.match(/^\/b\/([a-zA-Z0-9_-]+)/);
    if (pathMatch && pathMatch[1]) {
      rawBizId = pathMatch[1];
    }
  }

  const hasExplicitQrParams = Boolean(rawType || rawTable || rawRoom || rawBizId || rawId);

  // Determine strict tenant mode
  let tenantType: TenantType = 'restaurant';
  let locationId = '';

  if (rawRoom) {
    tenantType = 'guesthouse';
    locationId = rawRoom;
  } else if (rawTable) {
    tenantType = 'restaurant';
    locationId = rawTable;
  } else if (rawType && rawType.toLowerCase() === 'guesthouse') {
    tenantType = 'guesthouse';
    locationId = rawId || '';
  } else if (rawType && rawType.toLowerCase() === 'restaurant') {
    tenantType = 'restaurant';
    locationId = rawId || '';
  } else if (rawBizId === 'green-villa-guesthouse') {
    tenantType = 'guesthouse';
    locationId = '';
  } else {
    // Check saved state from previous locked QR scan
    const savedType = localStorage.getItem(LOCKED_TENANT_TYPE_KEY) as TenantType | null;
    const savedLoc = localStorage.getItem(LOCKED_LOCATION_ID_KEY);
    if (savedType === 'guesthouse' || savedType === 'restaurant') {
      tenantType = savedType;
      locationId = savedLoc || '';
    } else {
      tenantType = 'restaurant';
      locationId = '';
    }
  }

  // Clean location string (remove leading 'table' or 'room' prefixes if customer types just number)
  if (locationId) {
    locationId = locationId.trim();
  }

  return {
    tenantType,
    locationId,
    businessIdFromUrl: rawBizId,
    isExplicitFromQr: hasExplicitQrParams
  };
}

/**
 * Checks if a category is specific to Housekeeping / Guest House amenities
 */
export function isHousekeepingCategory(categoryName: string, categoryId?: string): boolean {
  if (categoryId === 'cat-gv-housekeeping') return true;
  const lower = (categoryName || '').toLowerCase();
  return (
    lower.includes('housekeeping') ||
    lower.includes('amenities') ||
    lower.includes('room service') ||
    lower.includes('toiletries') ||
    lower.includes('towel') ||
    lower.includes('linen') ||
    lower.includes('laundry')
  );
}

/**
 * Strictly filters categories based on active tenant mode:
 * In Restaurant mode, completely hides Housekeeping & Guest House tabs.
 */
export function filterCategoriesForTenant(categories: MenuCategory[], tenantType: TenantType): MenuCategory[] {
  if (tenantType === 'restaurant') {
    return categories.filter((cat) => !isHousekeepingCategory(cat.name, cat.id));
  }
  return categories;
}

/**
 * Strictly filters items based on active tenant mode:
 * In Restaurant mode, completely hides housekeeping / room service items.
 */
export function filterItemsForTenant(items: MenuItem[], categories: MenuCategory[], tenantType: TenantType): MenuItem[] {
  if (tenantType === 'restaurant') {
    const hiddenCategoryIds = new Set(
      categories.filter((cat) => isHousekeepingCategory(cat.name, cat.id)).map((cat) => cat.id)
    );
    hiddenCategoryIds.add('cat-gv-housekeeping');

    return items.filter((item) => {
      if (hiddenCategoryIds.has(item.categoryId)) return false;
      const tags = (item.tags || []).map((t) => t.toLowerCase());
      if (tags.some((t) => t.includes('housekeeping') || t.includes('amenity') || t.includes('room request'))) {
        return false;
      }
      return true;
    });
  }
  return items;
}

