/**
 * 🔔 Dual Sound Alert Engine using Web Audio API ($0-cost, Zero external asset dependencies)
 * Supports:
 *  1. 'church_bell': Rich reverberant multi-harmonic church bell acoustic chime
 *  2. 'ringtone': 15-20s continuous rhythmic upbeat synthesizer ringtone
 */

class AudioAlertEngine {
  private ctx: AudioContext | null = null;
  private isAlarmPlaying: boolean = false;
  private activeIntervalId: any = null;
  private activeTimeouts: any[] = [];
  private volume: number = 0.85;

  private initContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtxClass();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
  }

  public getVolume(): number {
    return this.volume;
  }

  public isPlaying(): boolean {
    return this.isAlarmPlaying;
  }

  /**
   * 🔔 CHURCH BELL SYNTHESIS
   * Uses real physical bell harmonic ratios (Hum tone, Prime, Tierce, Quint, Nominal, Superquint)
   */
  public playChurchBell(baseFreq = 440, duration = 3.5): void {
    const ctx = this.initContext();
    const now = ctx.currentTime;

    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(this.volume, now);
    masterGain.connect(ctx.destination);

    // Harmonic partial ratios of church bells & their relative amplitudes/decay
    const partials = [
      { ratio: 0.5, amp: 0.8, decay: duration * 1.2 },    // Hum tone (sub-octave)
      { ratio: 1.0, amp: 1.0, decay: duration * 0.9 },    // Prime / Fundamental
      { ratio: 1.19, amp: 0.6, decay: duration * 0.8 },   // Minor Tierce
      { ratio: 1.5, amp: 0.5, decay: duration * 0.7 },    // Fifth / Quint
      { ratio: 2.0, amp: 0.7, decay: duration * 0.6 },    // Nominal (octave above)
      { ratio: 2.76, amp: 0.35, decay: duration * 0.4 },  // Superquint
      { ratio: 3.98, amp: 0.25, decay: duration * 0.25 }  // High strike chime
    ];

    partials.forEach(({ ratio, amp, decay }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      // Sine wave with slight triangle shaping for metallic strike
      osc.type = ratio > 2 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(baseFreq * ratio, now);

      // Instant strike attack, then long natural exponential decay
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.exponentialRampToValueAtTime(amp * 0.25, now + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + decay);

      osc.connect(gain);
      gain.connect(masterGain);

      osc.start(now);
      osc.stop(now + decay);
    });
  }

  /**
   * 🎵 CONTINUOUS RINGTONE SYNTHESIS
   * Upbeat, urgent, highly audible marimba/synth sequence
   */
  public playRingtoneBurst(): void {
    const ctx = this.initContext();
    const now = ctx.currentTime;

    const masterGain = ctx.createGain();
    masterGain.gain.setValueAtTime(this.volume, now);
    masterGain.connect(ctx.destination);

    // Notes: C5 (523Hz), E5 (659Hz), G5 (784Hz), B5 (987Hz), C6 (1046Hz)
    const melody = [
      { freq: 523.25, time: 0.00, dur: 0.12 },
      { freq: 659.25, time: 0.12, dur: 0.12 },
      { freq: 783.99, time: 0.24, dur: 0.12 },
      { freq: 1046.50, time: 0.36, dur: 0.28 },
      { freq: 783.99, time: 0.68, dur: 0.12 },
      { freq: 1046.50, time: 0.80, dur: 0.38 }
    ];

    melody.forEach(({ freq, time, dur }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + time);

      gain.gain.setValueAtTime(0.001, now + time);
      gain.gain.linearRampToValueAtTime(0.3, now + time + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + time + dur);

      osc.connect(gain);
      gain.connect(masterGain);

      osc.start(now + time);
      osc.stop(now + time + dur);
    });
  }

  /**
   * 🚨 START CONTINUOUS ALARM (Loops until silenced)
   */
  public startContinuousAlert(type: 'church_bell' | 'ringtone' = 'church_bell'): void {
    this.stopAlert();
    this.isAlarmPlaying = true;
    this.initContext();

    if (type === 'church_bell') {
      // Bell toll pattern: 2 tolls every 3.2 seconds
      const tollPattern = () => {
        if (!this.isAlarmPlaying) return;
        this.playChurchBell(392, 3.0); // G4 bell
        const t1 = setTimeout(() => {
          if (this.isAlarmPlaying) {
            this.playChurchBell(523.25, 3.2); // C5 bell
          }
        }, 1100);
        this.activeTimeouts.push(t1);
      };

      tollPattern();
      this.activeIntervalId = setInterval(tollPattern, 3200);

    } else {
      // Ringtone pattern: upbeat melody repeat every 1.5 seconds
      const ringPattern = () => {
        if (!this.isAlarmPlaying) return;
        this.playRingtoneBurst();
      };

      ringPattern();
      this.activeIntervalId = setInterval(ringPattern, 1500);
    }
  }

  /**
   * 🛑 SILENCE / STOP ALERT
   */
  public stopAlert(): void {
    this.isAlarmPlaying = false;
    if (this.activeIntervalId) {
      clearInterval(this.activeIntervalId);
      this.activeIntervalId = null;
    }
    this.activeTimeouts.forEach(t => clearTimeout(t));
    this.activeTimeouts = [];
  }
}

export const alertSoundEngine = new AudioAlertEngine();
