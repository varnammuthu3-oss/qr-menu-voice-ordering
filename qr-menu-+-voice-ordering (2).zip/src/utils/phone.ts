/**
 * Utilities for formatting and sanitizing WhatsApp and phone numbers
 */

export function sanitizeWhatsappNumber(phone: string | undefined | null, defaultCode = '91'): string {
  if (!phone) return `${defaultCode}9845012345`;

  // Strict regex: remove any non-numeric characters (spaces, dashes, parentheses, plus signs)
  let clean = phone.replace(/[^0-9]/g, '');

  if (!clean) return `${defaultCode}9845012345`;

  // If the sanitized string starts with 0, strip the leading zero(s) and prepend country code 91
  // (e.g., 09943491595 -> 9943491595 -> 919943491595)
  if (clean.startsWith('0')) {
    clean = clean.replace(/^0+/, '');
    clean = `${defaultCode}${clean}`;
    return clean;
  }

  // If the number is a standard 10-digit number without country code, prepend default country code (91)
  if (clean.length === 10) {
    clean = `${defaultCode}${clean}`;
  }

  return clean;
}

export function createWhatsappDirectUrl(
  phone: string | undefined | null,
  businessName?: string
): string {
  const cleanNumber = sanitizeWhatsappNumber(phone);
  const bizTitle = businessName ? ` ${businessName}` : '';
  const message = `Hello${bizTitle}! I would like to inquire regarding your menu & services.`;
  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
}

export function createWhatsappOrderUrl(
  phone: string | undefined | null,
  businessName: string | undefined | null,
  itemName?: string,
  price?: number | string,
  currencySymbol = '₹'
): string {
  const cleanNumber = sanitizeWhatsappNumber(phone);
  const bizTitle = businessName || 'Restaurant';

  let message = `Hello ${bizTitle}, I would like to place an order from your digital QR menu.`;
  if (itemName) {
    message = `Hello ${bizTitle}, I would like to order: *${itemName}* (Price: ${currencySymbol}${price || ''}).`;
  }

  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
}

export interface CartItemLike {
  name?: string;
  item: { name: string; price: number; isVeg?: string };
  selectedVariant?: { id: string; name: string; price: number };
  quantity: number;
  selectedOptions?: string[];
  customNote?: string;
  unitPrice?: number;
  totalItemPrice?: number;
}

export interface KotOrderOptions {
  orderId?: string | number;
  notes?: string;
  tableNumber?: string;
  customerName?: string;
  customerPhone?: string;
  paymentMode?: string;
  tenantType?: 'restaurant' | 'guesthouse';
  orderDate?: Date | string;
}

/**
 * Format Date as DD Mon YYYY (e.g. 02 Sep 2026)
 */
export function formatKotDate(dateInput?: Date | string): string {
  const d = dateInput instanceof Date ? dateInput : (dateInput ? new Date(dateInput) : new Date());
  const validDate = isNaN(d.getTime()) ? new Date() : d;
  const day = String(validDate.getDate()).padStart(2, '0');
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = months[validDate.getMonth()];
  const year = validDate.getFullYear();
  return `${day} ${month} ${year}`;
}

/**
 * Format Time in 12-hour AM/PM format (e.g. 07:15 PM)
 */
export function formatKotTime(dateInput?: Date | string): string {
  const d = dateInput instanceof Date ? dateInput : (dateInput ? new Date(dateInput) : new Date());
  const validDate = isNaN(d.getTime()) ? new Date() : d;
  let hours = validDate.getHours();
  const minutes = String(validDate.getMinutes()).padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  const formattedHours = String(hours).padStart(2, '0');
  return `${formattedHours}:${minutes} ${ampm}`;
}

/**
 * Generates formatted Kitchen Order Ticket (KOT) text payload for WhatsApp routing
 */
export function generateKotMessage(
  storeName: string,
  cartItems: CartItemLike[],
  options?: KotOrderOptions
): string {
  const cleanStoreName = (storeName || 'RESTAURANT').trim();
  const orderId = options?.orderId || Math.floor(1000 + Math.random() * 9000);
  const formattedDate = formatKotDate(options?.orderDate);
  const formattedTime = formatKotTime(options?.orderDate);
  
  // Table / Room / Takeaway Type formatting
  const rawLoc = (options?.tableNumber || '').trim();
  let tableFormatted = '📦 Parcel / Counter Pickup';
  if (rawLoc && !/^(parcel|takeaway)/i.test(rawLoc)) {
    if (/^(table|room)/i.test(rawLoc)) {
      tableFormatted = rawLoc;
    } else if (options?.tenantType === 'guesthouse') {
      tableFormatted = `Room ${rawLoc}`;
    } else {
      tableFormatted = `Table ${rawLoc}`;
    }
  }

  // Calculate total amount
  const totalAmount = cartItems.reduce((acc, ci) => {
    const itemPrice = ci.totalItemPrice !== undefined ? ci.totalItemPrice : (ci.unitPrice || ci.item.price || 0) * ci.quantity;
    return acc + itemPrice;
  }, 0);

  // Format bullet items: • ${quantity}x ${itemName} ........ ₹${itemTotal}
  const itemsFormattedList = cartItems.map((ci) => {
    const qty = ci.quantity;
    const variantSuffix = ci.selectedVariant ? ` [${ci.selectedVariant.name}]` : '';
    const name = ci.name && ci.name.includes('(') ? ci.name : `${ci.item.name}${variantSuffix}`;
    const itemTotal = ci.totalItemPrice !== undefined ? ci.totalItemPrice : (ci.unitPrice || ci.item.price || 0) * qty;
    let line = `• ${qty}x ${name} ........ ₹${itemTotal}`;
    if (ci.customNote && ci.customNote.trim()) {
      line += `\n  ↳ Note: ${ci.customNote.trim()}`;
    }
    return line;
  }).join('\n');

  let itemsSection = itemsFormattedList;
  if (options?.notes && options.notes.trim()) {
    itemsSection += `\n\n📝 *Special Instructions / Packing:*\n${options.notes.trim()}`;
  }

  const paymentMode = options?.paymentMode || 'Cash / UPI at Counter';

  const customerLines: string[] = [];
  if (options?.customerName && options.customerName.trim()) {
    customerLines.push(`*Customer:* ${options.customerName.trim()}`);
  }
  if (options?.customerPhone && options.customerPhone.trim()) {
    customerLines.push(`*Phone:* ${options.customerPhone.trim()}`);
  }

  const lines = [
    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━',
    `🧾 *${cleanStoreName.toUpperCase()}*`,
    '📦 *PARCEL KITCHEN ORDER TICKET*',
    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━',
    '',
    `*Order ID:* #${orderId}`,
    `*Date:* ${formattedDate} | ${formattedTime}`,
    `*Order Type:* ${tableFormatted}`,
    ...customerLines,
    '',
    '────────────────────────────',
    '*PARCEL ITEMS TO PREPARE*',
    '────────────────────────────',
    itemsSection,
    '',
    '────────────────────────────',
    `💰 *ESTIMATED TOTAL: ₹${totalAmount}*`,
    '────────────────────────────',
    '*_Please pack fresh and securely for counter pickup._',
    '',
    `*Payment:* ${paymentMode}`,
    '*Status:* ⏳ Pending Kitchen Prep',
    '━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
  ];

  return lines.join('\n');
}

export function createWhatsappCartOrderUrl(
  phone: string | undefined | null,
  business: { name?: string; address?: string; city?: string; currencySymbol?: string; businessType?: string; whatsappGroupUrl?: string },
  cartItems: CartItemLike[],
  options?: KotOrderOptions
): string {
  const storeName = business.name || (business.businessType === 'guesthouse' ? 'Green Villa Guest House' : 'Restaurant');
  const message = generateKotMessage(storeName, cartItems, options);

  // Check if a designated WhatsApp group link is provided (e.g., chat.whatsapp.com/...)
  const rawTarget = (business.whatsappGroupUrl || phone || '').trim();
  if (rawTarget.includes('chat.whatsapp.com')) {
    const groupLink = rawTarget.startsWith('http') ? rawTarget : `https://${rawTarget}`;
    return groupLink;
  }

  const cleanNumber = sanitizeWhatsappNumber(phone);
  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
}
