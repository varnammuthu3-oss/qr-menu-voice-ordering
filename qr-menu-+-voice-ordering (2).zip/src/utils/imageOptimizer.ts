/**
 * Client-side image optimization utility
 * Resizes and compresses menu photos in-browser before transmitting to AI API.
 * Keeps memory footprint minimal, avoids storing huge originals, and preserves text clarity.
 */

export interface OptimizedImage {
  id: string;
  originalName: string;
  originalSize: number;
  optimizedSize: number;
  previewUrl: string;
  base64Data: string; // Pure base64 without data URI scheme
  mimeType: string;
  width: number;
  height: number;
}

const MAX_DIMENSION = 1600; // Max width or height in pixels for high legibility
const COMPRESSION_QUALITY = 0.85; // JPEG quality

export async function optimizeMenuImage(file: File): Promise<OptimizedImage> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (readerEvent) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;

        // Calculate scaling keeping aspect ratio
        if (width > MAX_DIMENSION || height > MAX_DIMENSION) {
          if (width > height) {
            height = Math.round((height * MAX_DIMENSION) / width);
            width = MAX_DIMENSION;
          } else {
            width = Math.round((width * MAX_DIMENSION) / height);
            height = MAX_DIMENSION;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');

        if (!ctx) {
          reject(new Error('Canvas context not available'));
          return;
        }

        // Draw with high quality smoothing
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        // Export as JPEG
        const dataUrl = canvas.toDataURL('image/jpeg', COMPRESSION_QUALITY);
        const base64Data = dataUrl.split(',')[1];
        
        // Calculate estimated byte size from base64
        const optimizedSize = Math.round((base64Data.length * 3) / 4);

        const optimized: OptimizedImage = {
          id: `img_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
          originalName: file.name || 'menu_photo.jpg',
          originalSize: file.size,
          optimizedSize,
          previewUrl: dataUrl,
          base64Data,
          mimeType: 'image/jpeg',
          width,
          height,
        };

        resolve(optimized);
      };

      img.onerror = (e) => {
        reject(new Error('Failed to load image file'));
      };

      if (readerEvent.target?.result) {
        img.src = readerEvent.target.result as string;
      }
    };

    reader.onerror = (e) => {
      reject(new Error('Failed to read file'));
    };

    reader.readAsDataURL(file);
  });
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
