import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Business, MenuCategory, MenuItem, AppStaffRole } from './types';
import { 
  seedInitialDataIfNeeded, 
  getAllBusinesses,
  subscribeToAllBusinesses,
  subscribeToBusiness, 
  subscribeToCategories, 
  subscribeToMenuItems,
  mergeAllBusinesses,
  deleteBusiness,
  getLocalMenuCache
} from './services/db';
import { 
  getStoredStaffRole, 
  getStoredStaffName, 
  saveStoredStaffRole,
  ROLE_CONFIGS 
} from './lib/roleAccessControl';
import { Navbar } from './components/Navbar';
import { CustomerMenu } from './components/CustomerMenu';
import { OwnerDashboard } from './components/OwnerDashboard';
import { MerchantOrderDashboard } from './components/MerchantOrderDashboard';
import { StaffAllocationView } from './components/StaffAllocationView';
import { MasterAdminDashboard } from './components/MasterAdminDashboard';
import { RoleSwitcherModal } from './components/RoleSwitcherModal';
import { RestaurantOnboardingModal } from './components/RestaurantOnboardingModal';
import AppAuthModal, { AuthPayload } from './components/AppAuthModal';
import { PartnerSignInModal } from './components/PartnerSignInModal';
import { saveBusiness } from './services/db';
import { SEED_BUSINESSES, SEED_CATEGORIES, SEED_ITEMS } from './data/seedData';
import { parseUrlTenantParams, getTenantConfig, generateQrUrl, LOCKED_TENANT_TYPE_KEY, LOCKED_LOCATION_ID_KEY } from './utils/tenant';
import { DEFAULT_SHOPS, getStoredShops, resolveActiveShop } from './utils/shopPersistence';
import { Loader2, QrCode, AlertTriangle, ExternalLink, Package, MessageCircle, Store } from 'lucide-react';
import { PrintQRModal } from './components/PrintQRModal';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';
import { MerchantOnboardingView } from './components/MerchantOnboardingView';
import { extractSlugFromUrl } from './utils/slug';

const LAST_SELECTED_BIZ_KEY = 'qr_menu_last_selected_biz_id';

export default function App() {
  const [businesses, setBusinesses] = useState<Business[]>(() => mergeAllBusinesses());
  const [tenantParams, setTenantParams] = useState(() => parseUrlTenantParams());
  const [selectedBusinessId, setSelectedBusinessId] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const slug = extractSlugFromUrl();
      if (slug) return slug;

      // Ensure active shop falls back safely if URL slug is missing
      const urlParams = new URLSearchParams(window.location.search);
      const activeShopId = urlParams.get("shop");
      if (activeShopId) {
        const shops = getStoredShops();
        const found = shops.find(s => s.id === activeShopId || s.id.replace(/_/g, '-') === activeShopId.replace(/_/g, '-'));
        return found ? found.id : activeShopId;
      }

      const parsed = parseUrlTenantParams();
      if (parsed.businessIdFromUrl) return parsed.businessIdFromUrl;
      const rawType = urlParams.get('type');
      if (rawType === 'guesthouse' || parsed.tenantType === 'guesthouse') {
        return 'green-villa-guesthouse';
      }
      if (rawType === 'restaurant' || urlParams.has('table') || urlParams.has('table_number') || urlParams.has('restaurant_id')) {
        return 'kannayah';
      }

      const saved = localStorage.getItem(LAST_SELECTED_BIZ_KEY);
      if (saved) return saved;

      const shops = getStoredShops();
      const currentShop = shops.find(s => s.id === 'kannayah') || shops[0] || DEFAULT_SHOPS[0];
      return currentShop.id;
    }
    return 'kannayah';
  });

  // Staff Role & Access State with LocalStorage Persistence
  const [staffRole, setStaffRole] = useState<AppStaffRole>(() => getStoredStaffRole() || 'owner');
  const [staffName, setStaffName] = useState<string>(() => getStoredStaffName() || 'Owner / Admin');
  const [isRoleModalOpen, setIsRoleModalOpen] = useState<boolean>(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState<boolean>(false);

  const [currentView, setCurrentView] = useState<'customer' | 'owner' | 'orders' | 'duty' | 'master_admin' | 'onboarding'>(() => {
    if (typeof window !== 'undefined') {
      const path = window.location.pathname;
      const hash = window.location.hash;
      const searchParams = new URLSearchParams(window.location.search);
      if (
        path.startsWith('/admin/super-dashboard') ||
        path.startsWith('/master-admin') ||
        hash.includes('admin/super-dashboard') ||
        hash.includes('super-dashboard') ||
        hash.includes('master-admin') ||
        searchParams.has('super-dashboard') ||
        searchParams.has('master-admin') ||
        searchParams.get('view') === 'master-admin' ||
        searchParams.get('view') === 'super-dashboard'
      ) {
        return 'master_admin';
      }
      if (
        searchParams.get('view') === 'orders' ||
        searchParams.get('admin') === 'orders' ||
        hash.includes('view=orders')
      ) {
        return 'orders';
      }
      if (
        searchParams.has('onboard') ||
        searchParams.has('onboarding') ||
        searchParams.get('view') === 'onboarding' ||
        hash.includes('onboard')
      ) {
        return 'onboarding';
      }

      // Check if a specific restaurant slug is present in URL
      const slug = extractSlugFromUrl();
      if (slug) {
        return 'customer';
      }

      // Seamless Fallback:
      // If no slug is present in the URL, default to this onboarding view so the owner can register on the spot.
      return 'onboarding';
    }
    return 'onboarding';
  });
  const [isNewBizModalOpen, setIsNewBizModalOpen] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.has('onboard') || params.has('onboarding') || window.location.hash.includes('onboard');
    }
    return false;
  });
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup'>('login');
  const [isPartnerSignInOpen, setIsPartnerSignInOpen] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.has('partner-login') || params.get('login') === 'partner' || window.location.hash.includes('partner-login');
    }
    return false;
  });

  // Handle Partner Passwordless Sign In Success
  const handlePartnerSignInSuccess = (userEmail: string) => {
    handleSelectRole('owner', `${userEmail.split('@')[0]} (Partner Owner)`);
    setCurrentView('orders');
    if (typeof window !== 'undefined') {
      localStorage.setItem(LAST_SELECTED_BIZ_KEY, selectedBusinessId);
    }
  };

  // Handle Auth Completion (Login / Signup)
  const handleCompleteAuth = async (payload: AuthPayload) => {
    if (payload.mode === 'signup') {
      const cleanName = payload.businessName?.trim() || (payload.businessType === 'guesthouse' ? 'Green Villa Residency' : 'Royal Feast Diner');
      const slug = payload.tenantId || cleanName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      
      const newBiz: Business = {
        id: slug,
        ownerUid: `owner-${Date.now()}`,
        name: cleanName,
        businessType: payload.businessType,
        tagline: payload.businessType === 'guesthouse' ? 'Luxury Stay & Room Service SOP' : 'Freshly prepared food & beverages',
        description: `Registered by ${payload.email}`,
        logoUrl: payload.businessType === 'guesthouse' 
          ? 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=200&auto=format&fit=crop&q=80'
          : 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=200&auto=format&fit=crop&q=80',
        coverUrl: payload.businessType === 'guesthouse'
          ? 'https://images.unsplash.com/photo-1582719508461-905c673771fd?w=800&auto=format&fit=crop&q=80'
          : 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=80',
        address: 'Bengaluru, Karnataka, India',
        city: 'Bengaluru',
        phone: payload.phone || '+91 98765 43210',
        whatsappNumber: payload.phone || '+91 98765 43210',
        openingHours: payload.businessType === 'guesthouse' ? '24/7 Front Desk' : 'Mon - Sun: 7:00 AM – 10:30 PM',
        currencySymbol: '₹',
        menuStyle: payload.businessType === 'guesthouse' ? 'modern' : 'classic',
        isActive: true,
        status: 'active',
        subscriptionTier: 'pro',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      try {
        await saveBusiness(newBiz);
      } catch (err) {
        console.warn('Save business error:', err);
      }

      setBusinesses(prev => [newBiz, ...prev.filter(b => b.id !== newBiz.id)]);
      setSelectedBusinessId(newBiz.id);
      handleSelectRole('owner', `${cleanName} (Owner)`);
      setCurrentView('owner');
      if (typeof window !== 'undefined') {
        localStorage.setItem(LAST_SELECTED_BIZ_KEY, newBiz.id);
        window.history.replaceState(null, '', `#b/${newBiz.id}`);
      }
    } else {
      // Login flow
      const matched = businesses.find(
        b => b.id.toLowerCase() === payload.tenantId.toLowerCase() ||
             b.name.toLowerCase().includes(payload.email.split('@')[0].toLowerCase()) ||
             b.businessType === payload.businessType
      ) || businesses[0];

      if (matched) {
        setSelectedBusinessId(matched.id);
        handleSelectRole('owner', `${payload.email.split('@')[0]} (Admin)`);
        setCurrentView('orders');
        if (typeof window !== 'undefined') {
          localStorage.setItem(LAST_SELECTED_BIZ_KEY, matched.id);
          window.history.replaceState(null, '', `#b/${matched.id}`);
        }
      }
    }
  };

  // Handle role selection and save to localStorage
  const handleSelectRole = (newRole: AppStaffRole, customName?: string) => {
    const finalName = customName || (
      newRole === 'owner' ? 'Owner / Admin' :
      newRole === 'manager' ? 'Captain Priya' : 
      newRole === 'master_admin' ? 'Master Super Admin' : 'Waiter Ramesh'
    );
    setStaffRole(newRole);
    setStaffName(finalName);
    saveStoredStaffRole(newRole, finalName);
    setIsRoleModalOpen(false);

    if (newRole === 'master_admin') {
      setCurrentView('master_admin');
      window.history.pushState(null, '', '/master-admin');
      return;
    }

    // If role has no access to menu manager, switch to orders or duty
    const permissions = ROLE_CONFIGS[newRole].permissions;
    if (currentView === 'owner' && !permissions.canManageMenu) {
      setCurrentView('orders');
    }
  };

  // Active business data
  const [business, setBusiness] = useState<Business | null>(() => {
    const all = mergeAllBusinesses();
    return all.find(b => b.id === selectedBusinessId) || all[0] || SEED_BUSINESSES[0];
  });
  const [categories, setCategories] = useState<MenuCategory[]>(() => {
    return getLocalMenuCache(selectedBusinessId).categories;
  });
  const [items, setItems] = useState<MenuItem[]>(() => {
    return getLocalMenuCache(selectedBusinessId).items;
  });
  const [loading, setLoading] = useState<boolean>(false);

  // Parse business ID and view from URL
  const parseUrl = useCallback(() => {
    const path = window.location.pathname;
    const hash = window.location.hash;
    const searchParams = new URLSearchParams(window.location.search);
    const currentTenant = parseUrlTenantParams();
    setTenantParams(currentTenant);

    // Check if accessing secret master admin / super dashboard route
    if (
      path.startsWith('/admin/super-dashboard') ||
      path.startsWith('/master-admin') ||
      hash.includes('admin/super-dashboard') ||
      hash.includes('super-dashboard') ||
      hash.includes('master-admin') ||
      searchParams.has('super-dashboard') ||
      searchParams.has('master-admin') ||
      searchParams.get('view') === 'master-admin' ||
      searchParams.get('view') === 'super-dashboard'
    ) {
      setCurrentView('master_admin');
      return;
    }

    // Check if onboarding explicitly requested
    if (
      searchParams.has('onboard') ||
      searchParams.has('onboarding') ||
      searchParams.get('view') === 'onboarding' ||
      hash.includes('onboard')
    ) {
      setCurrentView('onboarding');
      return;
    }

    if (
      searchParams.get('view') === 'orders' ||
      searchParams.get('admin') === 'orders' ||
      hash.includes('view=orders')
    ) {
      setCurrentView('orders');
      return;
    }

    // Extract slug from URL
    const detectedSlug = extractSlugFromUrl();
    if (detectedSlug) {
      setSelectedBusinessId(detectedSlug);
      if (typeof window !== 'undefined') {
        localStorage.setItem(LAST_SELECTED_BIZ_KEY, detectedSlug);
      }
      setCurrentView('customer');
    } else {
      // Check for legacy tenant param fallback or default to onboarding
      let targetBizId = currentTenant.businessIdFromUrl || '';
      const pathMatch = path.match(/^\/b\/([a-zA-Z0-9_-]+)/);
      const hashMatch = hash.match(/^#\/?b\/([a-zA-Z0-9_-]+)/);

      if (pathMatch && pathMatch[1]) {
        targetBizId = pathMatch[1];
      } else if (hashMatch && hashMatch[1]) {
        targetBizId = hashMatch[1];
      }

      if (targetBizId) {
        setSelectedBusinessId(targetBizId);
        if (typeof window !== 'undefined') {
          localStorage.setItem(LAST_SELECTED_BIZ_KEY, targetBizId);
        }
        setCurrentView('customer');
      } else {
        // Seamless fallback: If no slug is present in the URL, default to onboarding view
        setCurrentView('onboarding');
      }
    }
  }, []);

  // Initial startup: seed if needed & load businesses
  useEffect(() => {
    let isMounted = true;
    let unsubAll: (() => void) | undefined;

    async function init() {
      try {
        await seedInitialDataIfNeeded();
        const allBiz = await getAllBusinesses();
        if (isMounted && allBiz.length > 0) {
          setBusinesses(allBiz);
        }
      } catch (err) {
        console.warn('Initialization error:', err);
      } finally {
        if (isMounted) {
          parseUrl();
          setLoading(false);
        }
      }

      // Real-time listener for the businesses collection
      if (isMounted) {
        unsubAll = subscribeToAllBusinesses((allList) => {
          if (isMounted && allList.length > 0) {
            setBusinesses(allList);
          }
        });
      }
    }

    init();

    window.addEventListener('popstate', parseUrl);
    window.addEventListener('hashchange', parseUrl);

    return () => {
      isMounted = false;
      if (unsubAll) unsubAll();
      window.removeEventListener('popstate', parseUrl);
      window.removeEventListener('hashchange', parseUrl);
    };
  }, [parseUrl]);

  // Real-time subscriptions for selected business
  useEffect(() => {
    if (!selectedBusinessId) return;

    // Immediately isolate & switch to the menu items and categories keyed to this specific businessId
    const localMenu = getLocalMenuCache(selectedBusinessId);
    setCategories(localMenu.categories);
    setItems(localMenu.items);

    // Populate local cached/seed data immediately if available for smooth instant transitions
    const localMerged = mergeAllBusinesses();
    const cachedBiz = localMerged.find(b => b.id === selectedBusinessId);
    if (cachedBiz) {
      setBusiness(cachedBiz);
    } else {
      setBusiness(null);
    }

    const unsubBiz = subscribeToBusiness(selectedBusinessId, (biz) => {
      if (biz) {
        setBusiness(biz);
        // Also ensure business list entry reflects any instant title/attribute changes
        setBusinesses(prev => {
          const index = prev.findIndex(b => b.id === biz.id);
          if (index >= 0) {
            const updated = [...prev];
            updated[index] = biz;
            return updated;
          }
          return [biz, ...prev];
        });
      }
    });

    const unsubCats = subscribeToCategories(selectedBusinessId, (cats) => {
      setCategories(cats.filter(c => c.businessId === selectedBusinessId));
    });

    const unsubItems = subscribeToMenuItems(selectedBusinessId, (menuItems) => {
      setItems(menuItems.filter(i => i.businessId === selectedBusinessId));
    });

    return () => {
      unsubBiz();
      unsubCats();
      unsubItems();
    };
  }, [selectedBusinessId]);

  // Instant refresh / update helper
  const handleRefresh = async (updatedBiz?: Business) => {
    if (updatedBiz) {
      setBusiness(updatedBiz);
      setBusinesses(prev => {
        const idx = prev.findIndex(b => b.id === updatedBiz.id);
        if (idx >= 0) {
          const updated = [...prev];
          updated[idx] = updatedBiz;
          return updated;
        }
        return [updatedBiz, ...prev];
      });
    }
    const currentMenu = getLocalMenuCache(selectedBusinessId);
    setCategories(currentMenu.categories);
    setItems(currentMenu.items);
    const all = await getAllBusinesses();
    setBusinesses(all);
  };

  const handleSelectBusiness = (id: string) => {
    setSelectedBusinessId(id);
    if (typeof window !== 'undefined') {
      localStorage.setItem(LAST_SELECTED_BIZ_KEY, id);
    }
    // Update hash for easy direct sharing
    window.history.replaceState(null, '', `#b/${id}`);
  };

  const handleEditBusiness = (id: string) => {
    setSelectedBusinessId(id);
    if (typeof window !== 'undefined') {
      localStorage.setItem(LAST_SELECTED_BIZ_KEY, id);
    }
    setCurrentView('owner');
    window.history.replaceState(null, '', `#b/${id}`);
  };

  const handleDeleteBusiness = async (id: string) => {
    await deleteBusiness(id);
    setBusinesses((prev) => prev.filter(b => b.id !== id));
    
    // If the currently selected business was deleted, switch to another existing one
    if (selectedBusinessId === id) {
      const remaining = businesses.filter(b => b.id !== id);
      const nextBiz = remaining[0] || SEED_BUSINESSES[0];
      setSelectedBusinessId(nextBiz.id);
      setBusiness(nextBiz);
      if (typeof window !== 'undefined') {
        localStorage.setItem(LAST_SELECTED_BIZ_KEY, nextBiz.id);
      }
      window.history.replaceState(null, '', `#b/${nextBiz.id}`);
    }
  };

  const handleSelectTenantView = (tenantType: 'restaurant' | 'guesthouse', locationId: string, targetBizId?: string) => {
    let finalBizId = targetBizId;
    if (!finalBizId) {
      if (tenantType === 'guesthouse') {
        const found = businesses.find(b => b.businessType === 'guesthouse');
        finalBizId = found ? found.id : 'green-villa-guesthouse';
      } else {
        const found = businesses.find(b => b.businessType === 'restaurant' || !b.businessType);
        finalBizId = found ? found.id : 'city-diner';
      }
    }
    const finalLocationId = locationId || (tenantType === 'guesthouse' ? '102' : '05');
    setTenantParams({
      tenantType,
      locationId: finalLocationId,
      businessIdFromUrl: finalBizId,
      isExplicitFromQr: true
    });
    setSelectedBusinessId(finalBizId);
    if (typeof window !== 'undefined') {
      localStorage.setItem(LAST_SELECTED_BIZ_KEY, finalBizId);
      localStorage.setItem(LOCKED_TENANT_TYPE_KEY, tenantType);
      localStorage.setItem(LOCKED_LOCATION_ID_KEY, finalLocationId);
      const newUrl = generateQrUrl({
        businessId: finalBizId,
        businessType: tenantType,
        unitNumber: finalLocationId,
        origin: ''
      });
      window.history.pushState(null, '', newUrl);
    }
    setCurrentView('customer');
  };

  const handleBusinessCreated = (newBiz: Business) => {
    setBusinesses((prev) => [newBiz, ...prev.filter(b => b.id !== newBiz.id)]);
    setSelectedBusinessId(newBiz.id);
    if (typeof window !== 'undefined') {
      localStorage.setItem(LAST_SELECTED_BIZ_KEY, newBiz.id);
    }
    setCurrentView('owner');
    window.history.replaceState(null, '', `#b/${newBiz.id}`);
  };

  if (loading && !business) {
    return (
      <div className="min-h-screen bg-stone-950 flex flex-col items-center justify-center p-4 text-white">
        <Loader2 className="w-8 h-8 text-amber-500 animate-spin mb-3" />
        <div className="text-sm font-bold tracking-tight">Loading QR Menu Platform...</div>
        <div className="text-xs text-stone-400 mt-1">Connecting to Firestore database</div>
      </div>
    );
  }

  const activeBiz = business 
    || businesses.find((b) => b.id === selectedBusinessId) 
    || businesses.find((b) => b.id.replace(/_/g, '-') === selectedBusinessId.replace(/_/g, '-')) 
    || businesses.find((b) => b.id === 'kannayah')
    || businesses[0];

  // Merchant Self-Service Onboarding View (Default when no slug is present in URL or when onboarding view is active)
  if (currentView === 'onboarding') {
    return (
      <MerchantOnboardingView
        availableBusinesses={businesses}
        onComplete={(newBiz) => {
          setBusinesses((prev) => {
            const idx = prev.findIndex((b) => b.id === newBiz.id);
            if (idx >= 0) {
              const copy = [...prev];
              copy[idx] = newBiz;
              return copy;
            }
            return [newBiz, ...prev];
          });
          setSelectedBusinessId(newBiz.id);
          setBusiness(newBiz);
          if (typeof window !== 'undefined') {
            localStorage.setItem(LAST_SELECTED_BIZ_KEY, newBiz.id);
            window.history.pushState(null, '', `/#b/${newBiz.id}`);
          }
          setCurrentView('customer');
        }}
        onSelectExistingRestaurant={(targetBizId) => {
          setSelectedBusinessId(targetBizId);
          if (typeof window !== 'undefined') {
            localStorage.setItem(LAST_SELECTED_BIZ_KEY, targetBizId);
            window.history.pushState(null, '', `/#b/${targetBizId}`);
          }
          setCurrentView('customer');
        }}
      />
    );
  }

  // If in Master Admin Mode, render the Master Super Admin Fleet Console
  if (currentView === 'master_admin') {
    return (
      <MasterAdminDashboard
        businesses={businesses}
        onSelectBusiness={(bizId) => {
          setSelectedBusinessId(bizId);
          if (typeof window !== 'undefined') {
            localStorage.setItem(LAST_SELECTED_BIZ_KEY, bizId);
          }
        }}
        onImpersonateBusiness={(bizId, targetView) => {
          setSelectedBusinessId(bizId);
          if (typeof window !== 'undefined') {
            localStorage.setItem(LAST_SELECTED_BIZ_KEY, bizId);
            window.history.pushState(null, '', `/#b/${bizId}`);
          }
          setCurrentView(targetView);
        }}
        onExitMasterAdmin={() => {
          setCurrentView('orders');
          if (typeof window !== 'undefined') {
            window.history.pushState(null, '', '/');
          }
        }}
        onPropertyRegistered={(newBiz) => {
          setBusinesses(prev => {
            if (prev.some(b => b.id === newBiz.id)) return prev;
            return [newBiz, ...prev];
          });
        }}
      />
    );
  }

  // Frictionless Parcel-Only Customer PWA View (Default for QR scans and visitors)
  if (currentView === 'customer' && activeBiz) {
    return (
      <div className="min-h-screen bg-stone-950 flex flex-col font-sans text-stone-100 selection:bg-amber-400 selection:text-stone-950">
        {/* Offline PWA Connectivity Indicator */}
        <OfflineIndicator />

        {/* Pure Frictionless PWA Top Header */}
        <header className="sticky top-0 z-40 bg-stone-950/95 backdrop-blur-md border-b border-stone-800 px-3 sm:px-6 py-2.5 flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-black shrink-0 shadow-xs">
              <Package className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-sm font-black text-white tracking-tight truncate">
                  {activeBiz.name}
                </span>
                <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 whitespace-nowrap">
                  PARCEL PICKUP
                </span>
              </div>
              <p className="text-[10px] text-stone-400 truncate">
                Direct WhatsApp Takeaway Ordering
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Install PWA Prompt Button */}
            <PWAInstallButton />

            {/* Onboard Restaurant Button */}
            <button
              type="button"
              onClick={() => {
                setCurrentView('onboarding');
                if (typeof window !== 'undefined') {
                  window.history.pushState(null, '', '/#onboard');
                }
              }}
              className="px-2.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 hover:text-amber-300 text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              title="Onboard your restaurant"
            >
              <Store className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Onboard</span>
            </button>

            {/* Counter QR Standee Button */}
            <button
              type="button"
              onClick={() => setIsPrintModalOpen(true)}
              className="px-2.5 py-1.5 rounded-xl bg-stone-900 hover:bg-stone-800 border border-stone-800 text-stone-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              title="View & Print Counter QR Code Standee"
            >
              <QrCode className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Counter QR</span>
            </button>
          </div>
        </header>

        {/* Direct Food Menu Screen */}
        <main className="flex-1">
          <CustomerMenu
            business={activeBiz}
            categories={categories}
            items={items}
            tenantType={tenantParams.tenantType}
            initialLocationNumber={tenantParams.locationId || ''}
          />
        </main>

        {/* Counter QR Standee Modal */}
        <PrintQRModal
          isOpen={isPrintModalOpen}
          onClose={() => setIsPrintModalOpen(false)}
          business={activeBiz}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col font-sans text-stone-900 selection:bg-amber-400 selection:text-stone-950">
      {/* Top Universal Navbar (Only shown in staff / admin view) */}
      <Navbar
        currentView={currentView}
        onViewChange={(v) => setCurrentView(v)}
        businesses={businesses}
        selectedBusinessId={selectedBusinessId}
        activeBusiness={activeBiz}
        onSelectBusiness={handleSelectBusiness}
        onSelectTenantView={handleSelectTenantView}
        onEditBusiness={handleEditBusiness}
        onDeleteBusiness={handleDeleteBusiness}
        onCreateNewBusiness={() => {
          setCurrentView('onboarding');
          if (typeof window !== 'undefined') {
            window.history.pushState(null, '', '/#onboard');
          }
        }}
        onOpenAuthModal={(mode) => {
          setAuthModalMode(mode || 'login');
          setIsAuthModalOpen(true);
        }}
        onOpenPartnerSignIn={() => setIsPartnerSignInOpen(true)}
        currentStaffRole={staffRole}
        staffName={staffName}
        onOpenRoleSwitcher={() => setIsRoleModalOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1">
        {currentView === 'orders' ? (
          <MerchantOrderDashboard
            business={activeBiz || businesses[0]}
            currentStaffRole={staffRole}
            staffName={staffName}
            onOpenRoleSwitcher={() => setIsRoleModalOpen(true)}
          />
        ) : currentView === 'duty' ? (
          <StaffAllocationView
            business={activeBiz || businesses[0]}
            onOpenLiveDashboard={() => setCurrentView('orders')}
            currentStaffRole={staffRole}
            staffName={staffName}
            onOpenRoleSwitcher={() => setIsRoleModalOpen(true)}
          />
        ) : activeBiz ? (
          <OwnerDashboard
            business={activeBiz}
            categories={categories}
            items={items}
            onOpenCustomerView={(bId) => {
              setSelectedBusinessId(bId);
              setCurrentView('customer');
              window.history.replaceState(null, '', `#b/${bId}`);
            }}
            onRefresh={handleRefresh}
          />
        ) : (
          <div className="max-w-md mx-auto my-20 p-8 bg-white rounded-2xl border border-stone-200 text-center space-y-4">
            <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto" />
            <h2 className="text-lg font-bold text-stone-900">Restaurant Not Found</h2>
            <p className="text-xs text-stone-500">
              The business ID <span className="font-mono text-amber-600 font-bold">"{selectedBusinessId}"</span> does not exist or has been removed.
            </p>
            <button
              onClick={() => handleSelectBusiness(businesses[0]?.id || 'sri-murugan-tiffin-center')}
              className="px-4 py-2 bg-stone-900 text-white text-xs font-bold rounded-xl"
            >
              Switch to Default Restaurant
            </button>
          </div>
        )}
      </main>

      {/* Role Switcher Modal */}
      <RoleSwitcherModal
        isOpen={isRoleModalOpen}
        onClose={() => setIsRoleModalOpen(false)}
        currentRole={staffRole}
        staffName={staffName}
        onSelectRole={handleSelectRole}
      />

      {/* Restaurant Fast Onboarding Modal (AI Menu Extraction + Counter QR) */}
      <RestaurantOnboardingModal
        isOpen={isNewBizModalOpen}
        onClose={() => setIsNewBizModalOpen(false)}
        onOnboardingComplete={handleBusinessCreated}
      />

      {/* App Auth Modal (Login & Register) */}
      <AppAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onCompleteAuth={handleCompleteAuth}
        onOpenPartnerSignIn={() => setIsPartnerSignInOpen(true)}
        initialMode={authModalMode}
      />

      {/* Restaurant Partner Passwordless Sign In (Supabase OTP) */}
      <PartnerSignInModal
        isOpen={isPartnerSignInOpen}
        onClose={() => setIsPartnerSignInOpen(false)}
        onSuccess={handlePartnerSignInSuccess}
        currentBusiness={activeBiz}
      />
    </div>
  );
}
