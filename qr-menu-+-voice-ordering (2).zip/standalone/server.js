/**
 * 🚀 PRODUCTION $0-COST ORDER ALERT & WHATSAPP ENGINE (STANDALONE NODE.JS SERVER)
 * Stack: Express.js + @whiskeysockets/baileys + WebSockets / SSE + Web Audio API
 * Deployment: Free Tier on Render, Railway, Fly.io, or VPS
 */

const express = require('express');
const path = require('path');
const fs = require('fs');
const qrcode = require('qrcode');
const qrcodeTerminal = require('qrcode-terminal');
const pino = require('pino');
const { 
  default: makeWASocket, 
  DisconnectReason, 
  useMultiFileAuthState, 
  fetchLatestBaileysVersion 
} = require('@whiskeysockets/baileys');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-Memory state & Local Auth Storage
const AUTH_DIR = path.join(__dirname, '.baileys_auth_info');
if (!fs.existsSync(AUTH_DIR)) {
  fs.mkdirSync(AUTH_DIR, { recursive: true });
}

let sock = null;
let qrCodeDataUrl = null;
let connectionStatus = 'disconnected';
let pairedUser = null;
let sseClients = [];
let recentOrders = [];

// Initialize Baileys Zero-Cost WhatsApp Background Service
async function initWhatsAppEngine() {
  if (connectionStatus === 'connected') return;

  try {
    connectionStatus = 'connecting';
    console.log('[Baileys] Connecting to WhatsApp Web protocol via WebSockets...');

    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
    const { version } = await fetchLatestBaileysVersion();
    const logger = pino({ level: 'silent' });

    sock = makeWASocket({
      version,
      logger,
      auth: state,
      browser: ['QR Menu Alert Engine', 'Chrome', '1.0.0'],
      syncFullHistory: false
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (qr) {
        connectionStatus = 'qr_ready';
        try {
          qrCodeDataUrl = await qrcode.toDataURL(qr, { margin: 2, scale: 6 });
          console.log('\n======================================================');
          console.log('📱 [WHATSAPP ZERO-COST PAIRING QR CODE]');
          console.log('Scan with your WhatsApp phone: Linked Devices -> Link a Device');
          console.log('======================================================\n');
          qrcodeTerminal.generate(qr, { small: true });
        } catch (e) {
          console.error(e);
        }
        broadcastStatus();
      }

      if (connection === 'close') {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
        console.log(`[Baileys] Connection closed (${statusCode}). Reconnect: ${shouldReconnect}`);
        connectionStatus = 'disconnected';
        qrCodeDataUrl = null;
        pairedUser = null;
        broadcastStatus();

        if (shouldReconnect) {
          setTimeout(() => initWhatsAppEngine(), 3000);
        }
      } else if (connection === 'open') {
        connectionStatus = 'connected';
        qrCodeDataUrl = null;
        const userJid = sock?.user?.id;
        pairedUser = userJid ? userJid.split(':')[0] : 'Linked Device';
        console.log(`✅ [Baileys] WhatsApp connected successfully as +${pairedUser}!`);
        broadcastStatus();
      }
    });

  } catch (err) {
    console.error('[Baileys] Init error:', err);
    connectionStatus = 'disconnected';
    broadcastStatus();
  }
}

// Broadcast updates to connected SSE browser screens
function broadcast(payload) {
  sseClients.forEach(send => {
    try { send(payload); } catch (e) {}
  });
}

function broadcastStatus() {
  broadcast({
    type: 'WA_STATUS',
    waStatus: {
      status: connectionStatus,
      qrCodeDataUrl,
      pairedUser,
      connected: connectionStatus === 'connected'
    }
  });
}

// Format WhatsApp Order Text
function formatOrderMessage(order) {
  const currency = order.currencySymbol || '₹';
  let msg = `🚨 *NEW LIVE ORDER RECEIVED!*\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `🪑 *Table / Source:* Table ${order.tableNumber || '1'}\n`;
  if (order.restaurantName) msg += `🏪 *Restaurant:* ${order.restaurantName}\n`;
  msg += `⏰ *Time:* ${new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}\n`;
  msg += `━━━━━━━━━━━━━━━━━━━━━\n\n`;
  msg += `📋 *ORDER ITEMS:*\n`;

  order.items.forEach((item, idx) => {
    msg += `${idx + 1}. *${item.name}* x ${item.quantity} ➜ ${currency}${item.price * item.quantity}\n`;
  });

  msg += `\n━━━━━━━━━━━━━━━━━━━━━\n`;
  msg += `💰 *TOTAL:* *${currency}${order.totalPrice}*\n`;
  if (order.customerNotes) msg += `📝 *Notes:* ${order.customerNotes}\n`;
  msg += `\n_Instant $0-Cost Alert Engine_`;
  return msg;
}

// API Routes
app.get('/api/whatsapp/status', (req, res) => {
  res.json({
    status: connectionStatus,
    qrCodeDataUrl,
    pairedUser,
    connected: connectionStatus === 'connected'
  });
});

app.post('/api/whatsapp/reset', async (req, res) => {
  try {
    if (sock) await sock.logout();
    fs.rmSync(AUTH_DIR, { recursive: true, force: true });
    fs.mkdirSync(AUTH_DIR, { recursive: true });
    connectionStatus = 'disconnected';
    pairedUser = null;
    broadcastStatus();
    setTimeout(() => initWhatsAppEngine(), 1000);
    res.json({ success: true, message: 'Session reset. Generating new QR...' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Server-Sent Events (SSE) for Real-Time Merchant Screen
app.get('/api/orders/events', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const sendEvent = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);
  sseClients.push(sendEvent);

  sendEvent({
    type: 'INIT',
    waStatus: {
      status: connectionStatus,
      qrCodeDataUrl,
      pairedUser,
      connected: connectionStatus === 'connected'
    },
    orders: recentOrders
  });

  req.on('close', () => {
    sseClients = sseClients.filter(c => c !== sendEvent);
  });
});

// Submit Order (Customer or Table QR Scan)
app.post('/api/orders', async (req, res) => {
  try {
    const { tableNumber, items, totalPrice, merchantPhone, alertSoundType = 'church_bell', customerNotes } = req.body;

    const newOrder = {
      id: `ord_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      tableNumber: String(tableNumber || 1),
      items: items || [],
      totalPrice: Number(totalPrice) || 0,
      merchantPhone,
      alertSoundType,
      customerNotes: customerNotes || '',
      createdAt: new Date().toISOString(),
      status: 'pending'
    };

    // 1. Add to live queue & broadcast SSE to sound the alarm on merchant screen
    recentOrders.unshift(newOrder);
    broadcast({ type: 'NEW_ORDER', order: newOrder });

    // 2. Dispatch native WhatsApp message if paired
    let whatsappSent = false;
    if (sock && connectionStatus === 'connected') {
      const targetNumber = merchantPhone || pairedUser;
      if (targetNumber) {
        const jid = `${targetNumber.replace(/\D/g, '')}@s.whatsapp.net`;
        const text = formatOrderMessage(newOrder);
        await sock.sendMessage(jid, { text });
        whatsappSent = true;
        console.log(`[Baileys] Sent order to WhatsApp ${jid}`);
      }
    }

    res.status(201).json({ success: true, order: newOrder, whatsappSent });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update order status (Accept & Silence Alarm)
app.patch('/api/orders/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const order = recentOrders.find(o => o.id === id);
  if (order) {
    order.status = status;
    broadcast({ type: 'ORDER_UPDATED', order });
    return res.json({ success: true, order });
  }
  res.status(404).json({ error: 'Order not found' });
});

// Fallback to index.html for dashboard
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start Server & Baileys
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 [Order Alert Engine] Running on http://0.0.0.0:${PORT}`);
  initWhatsAppEngine();
});
