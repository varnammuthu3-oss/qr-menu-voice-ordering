-- ==============================================================================
-- 🚀 PRODUCTION MULTI-TENANT RESTAURANT QR MENU & REALTIME ALERTS (SUPABASE FREE TIER)
-- Designed for 500+ Restaurants at ₹0 / $0 Infrastructure & API Cost
-- ==============================================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Restaurants (Multi-Tenant Master Table)
CREATE TABLE IF NOT EXISTS public.restaurants (
    id TEXT PRIMARY KEY, -- Slug or UUID (e.g. 'sri-murugan-tiffin-center')
    name TEXT NOT NULL,
    phone TEXT NOT NULL, -- Format: 919845012345 (used for client-side wa.me deep link)
    whatsapp_number TEXT,
    currency_symbol TEXT DEFAULT '₹',
    address TEXT,
    city TEXT,
    upi_id TEXT, -- e.g. merchant@okhdfcbank for direct zero-commission UPI QR
    theme_color TEXT DEFAULT '#10b981',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Categories
CREATE TABLE IF NOT EXISTS public.categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id TEXT REFERENCES public.restaurants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Menu Items
CREATE TABLE IF NOT EXISTS public.menu_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id TEXT REFERENCES public.restaurants(id) ON DELETE CASCADE,
    category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    price NUMERIC(10, 2) NOT NULL,
    is_veg TEXT CHECK (is_veg IN ('veg', 'nonveg', 'egg')) DEFAULT 'veg',
    description TEXT,
    is_available BOOLEAN DEFAULT TRUE,
    image_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Staff Allocations (Daily Table & Duty Mapping per Restaurant)
CREATE TABLE IF NOT EXISTS public.staff_allocations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id TEXT NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
    staff_name TEXT NOT NULL, -- e.g. 'Waiter Ramesh', 'Captain Priya'
    role TEXT NOT NULL DEFAULT 'waiter', -- 'waiter', 'captain', 'server', 'runner', 'manager'
    phone TEXT,
    shift_date DATE NOT NULL DEFAULT CURRENT_DATE, -- YYYY-MM-DD
    assigned_tables TEXT[] NOT NULL DEFAULT '{}', -- e.g. ARRAY['1', '2', '3']
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_staff_restaurant_date_name UNIQUE (restaurant_id, shift_date, staff_name)
);

-- 6. Orders (Multi-Tenant High-Throughput Table with Daily Auto-Increment Sequence & Realtime Subscription)
CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id TEXT NOT NULL REFERENCES public.restaurants(id) ON DELETE CASCADE,
    order_id INT NOT NULL DEFAULT 1, -- Auto-incrementing per restaurant, resets to #1 daily
    order_date DATE NOT NULL DEFAULT CURRENT_DATE, -- YYYY-MM-DD
    order_time TIME NOT NULL DEFAULT CURRENT_TIME, -- HH:MM:SS
    table_number TEXT NOT NULL DEFAULT '1',
    assigned_staff_name TEXT, -- e.g. 'Waiter Ramesh' (Matched in real-time)
    items JSONB NOT NULL DEFAULT '[]'::jsonb, -- Array of { name, quantity, price, isVeg }
    total_price NUMERIC(10, 2) NOT NULL DEFAULT 0,
    customer_name TEXT,
    customer_phone TEXT,
    customer_notes TEXT,
    status TEXT CHECK (status IN ('pending', 'accepted', 'preparing', 'completed', 'cancelled')) DEFAULT 'pending',
    alert_sound_type TEXT DEFAULT 'church_bell', -- 'church_bell' or 'ringtone'
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_restaurant_daily_order UNIQUE (restaurant_id, order_date, order_id)
);

-- ==============================================================================
-- ⚙️ POSTGRESQL TRIGGER: DAILY PER-RESTAURANT ORDER_ID & WAITER DUTY ALLOCATION MATCHING
-- ==============================================================================
CREATE OR REPLACE FUNCTION public.set_daily_restaurant_order_number()
RETURNS TRIGGER AS $$
DECLARE
    next_order_num INT;
    calc_date DATE;
    calc_time TIME;
    matched_waiter TEXT;
    clean_table_num TEXT;
BEGIN
    -- Determine order_date and order_time if not explicitly passed
    calc_date := COALESCE(NEW.order_date, CURRENT_DATE);
    calc_time := COALESCE(NEW.order_time, CURRENT_TIME::TIME(0));

    NEW.order_date := calc_date;
    NEW.order_time := calc_time;

    -- If order_id is not provided or set to 0/1 default on insert, compute the next daily sequence for this tenant
    IF NEW.order_id IS NULL OR NEW.order_id <= 0 OR NEW.order_id = 1 THEN
        SELECT COALESCE(MAX(order_id), 0) + 1
        INTO next_order_num
        FROM public.orders
        WHERE restaurant_id = NEW.restaurant_id
          AND order_date = calc_date;

        NEW.order_id := next_order_num;
    END IF;

    -- Automatic Real-time Waiter Duty Matching if not already provided
    IF NEW.assigned_staff_name IS NULL OR TRIM(NEW.assigned_staff_name) = '' THEN
        -- Normalize table number (e.g. 'Table 2' -> '2', '2' -> '2')
        clean_table_num := REGEXP_REPLACE(NEW.table_number, '^[Tt]able\s*', '');

        SELECT staff_name
        INTO matched_waiter
        FROM public.staff_allocations
        WHERE restaurant_id = NEW.restaurant_id
          AND shift_date = calc_date
          AND is_active = TRUE
          AND (clean_table_num = ANY(assigned_tables) OR NEW.table_number = ANY(assigned_tables))
        LIMIT 1;

        IF matched_waiter IS NOT NULL THEN
            NEW.assigned_staff_name := matched_waiter;
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_set_daily_restaurant_order_number ON public.orders;
CREATE TRIGGER trg_set_daily_restaurant_order_number
BEFORE INSERT ON public.orders
FOR EACH ROW
EXECUTE FUNCTION public.set_daily_restaurant_order_number();

-- ==============================================================================
-- 📊 MULTI-TENANT ISOLATED STORED PROCEDURE: GET RESTAURANT DAILY ORDER LOGS
-- ==============================================================================
CREATE OR REPLACE FUNCTION public.get_restaurant_daily_orders(
    p_restaurant_id TEXT,
    p_order_date DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE (
    id UUID,
    restaurant_id TEXT,
    order_id INT,
    order_date DATE,
    order_time TIME,
    table_number TEXT,
    assigned_staff_name TEXT,
    formatted_summary TEXT,
    items JSONB,
    total_price NUMERIC,
    status TEXT,
    customer_notes TEXT,
    created_at TIMESTAMPTZ
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        o.id,
        o.restaurant_id,
        o.order_id,
        o.order_date,
        o.order_time,
        o.table_number,
        o.assigned_staff_name,
        ('Order #' || o.order_id || ' | Date: ' || TO_CHAR(o.order_date, 'YYYY-MM-DD') || ' | Time: ' || TO_CHAR(o.order_time, 'HH24:MI') || ' | ' || o.table_number || COALESCE(' (' || o.assigned_staff_name || ')', ''))::TEXT AS formatted_summary,
        o.items,
        o.total_price,
        o.status,
        o.customer_notes,
        o.created_at
    FROM public.orders o
    WHERE o.restaurant_id = p_restaurant_id
      AND o.order_date = p_order_date
    ORDER BY o.order_id DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ==============================================================================
-- ⚡ PERFORMANCE INDEXES (OPTIMIZED FOR 500+ CONCURRENT RESTAURANTS)
-- ==============================================================================
CREATE INDEX IF NOT EXISTS idx_orders_tenant_daily ON public.orders (restaurant_id, order_date, order_id DESC);
CREATE INDEX IF NOT EXISTS idx_orders_restaurant_created ON public.orders (restaurant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders (restaurant_id, status);
CREATE INDEX IF NOT EXISTS idx_staff_allocations_tenant_date ON public.staff_allocations (restaurant_id, shift_date, is_active);
CREATE INDEX IF NOT EXISTS idx_menu_items_restaurant ON public.menu_items (restaurant_id, is_available);
CREATE INDEX IF NOT EXISTS idx_categories_restaurant ON public.categories (restaurant_id, sort_order);

-- ==============================================================================
-- 🔔 ENABLE SUPABASE REALTIME (WEBSOCKET PUSH FOR INSTANT AUDIO & DUTY ALERTS)
-- ==============================================================================
-- Add orders and staff_allocations tables to Supabase Realtime publication
ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
ALTER PUBLICATION supabase_realtime ADD TABLE public.staff_allocations;

-- Set replica identity to FULL so realtime updates send old and new records
ALTER TABLE public.orders REPLICA IDENTITY FULL;
ALTER TABLE public.staff_allocations REPLICA IDENTITY FULL;

-- ==============================================================================
-- 🔒 ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================
ALTER TABLE public.restaurants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_allocations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Public Read for Customer Menus & Staff Duty
CREATE POLICY "Public can view restaurants" 
ON public.restaurants FOR SELECT USING (true);

CREATE POLICY "Public can view categories" 
ON public.categories FOR SELECT USING (true);

CREATE POLICY "Public can view menu items" 
ON public.menu_items FOR SELECT USING (true);

-- Staff Allocations Policies
CREATE POLICY "Public can view staff allocations" 
ON public.staff_allocations FOR SELECT USING (true);

CREATE POLICY "Staff and Merchants can insert allocations" 
ON public.staff_allocations FOR INSERT WITH CHECK (true);

CREATE POLICY "Staff and Merchants can update allocations" 
ON public.staff_allocations FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "Staff and Merchants can delete allocations" 
ON public.staff_allocations FOR DELETE USING (true);

-- Public / Customer can insert orders
CREATE POLICY "Public can insert orders" 
ON public.orders FOR INSERT WITH CHECK (true);

-- Merchants / Public can view and update orders (In multi-tenant, restricted by restaurant_id or merchant auth)
CREATE POLICY "Public can select orders" 
ON public.orders FOR SELECT USING (true);

CREATE POLICY "Public can update order status" 
ON public.orders FOR UPDATE USING (true) WITH CHECK (true);

-- ==============================================================================
-- 🌱 SEED DATA FOR DEMO RESTAURANTS (SRI MURUGAN TIFFIN CENTER & BISTRO)
-- ==============================================================================
INSERT INTO public.restaurants (id, name, phone, whatsapp_number, currency_symbol, address, city, upi_id)
VALUES 
(
    'sri-murugan-tiffin-center',
    'Sri Murugan Tiffin Center',
    '919845012345',
    '919845012345',
    '₹',
    '#42 Temple Road, Malleshwaram',
    'Bengaluru',
    'srimurugan@upi'
),
(
    'the-royal-bistro',
    'The Royal Bistro',
    '919876543210',
    '919876543210',
    '₹',
    '124 Food Street, MG Road',
    'Bengaluru',
    'royalbistro@upi'
)
ON CONFLICT (id) DO NOTHING;

-- Seed Daily Staff Table Allocations (e.g. Ramesh -> Tables 1, 2, 3)
INSERT INTO public.staff_allocations (restaurant_id, staff_name, role, shift_date, assigned_tables, is_active, notes)
VALUES
(
    'sri-murugan-tiffin-center',
    'Waiter Ramesh',
    'waiter',
    CURRENT_DATE,
    ARRAY['1', '2', '3'],
    TRUE,
    'Morning & Afternoon section lead'
),
(
    'sri-murugan-tiffin-center',
    'Captain Priya',
    'captain',
    CURRENT_DATE,
    ARRAY['4', '5', '6'],
    TRUE,
    'Central hall supervisor'
),
(
    'sri-murugan-tiffin-center',
    'Waiter Suresh',
    'waiter',
    CURRENT_DATE,
    ARRAY['7', '8', '9', '10'],
    TRUE,
    'Terrace & garden tables'
)
ON CONFLICT (restaurant_id, shift_date, staff_name) 
DO UPDATE SET 
    assigned_tables = EXCLUDED.assigned_tables,
    updated_at = NOW();

-- Seed Categories
INSERT INTO public.categories (id, restaurant_id, name, sort_order)
VALUES 
('a1111111-1111-1111-1111-111111111111', 'sri-murugan-tiffin-center', 'Hot Tiffin & Breakfast', 1),
('a2222222-2222-2222-2222-222222222222', 'sri-murugan-tiffin-center', 'Dosa Specialties', 2),
('a3333333-3333-3333-3333-333333333333', 'sri-murugan-tiffin-center', 'Filter Coffee & Beverages', 3)
ON CONFLICT (id) DO NOTHING;

-- Seed Menu Items
INSERT INTO public.menu_items (restaurant_id, category_id, name, price, is_veg, description, is_available)
VALUES 
('sri-murugan-tiffin-center', 'a1111111-1111-1111-1111-111111111111', 'Ghee Podi Idli (2 Pcs)', 70, 'veg', 'Soft button idlis tossed in pure ghee and spicy gun powder chutney.', true),
('sri-murugan-tiffin-center', 'a1111111-1111-1111-1111-111111111111', 'Crispy Medu Vada (1 Pc)', 35, 'veg', 'Golden fried lentil fritter served with fresh coconut chutney & hot sambar.', true),
('sri-murugan-tiffin-center', 'a2222222-2222-2222-2222-222222222222', 'Butter Masala Dosa', 110, 'veg', 'Crispy fermented crepe smeared with red chutney and spiced potato masala.', true),
('sri-murugan-tiffin-center', 'a2222222-2222-2222-2222-222222222222', 'Rava Onion Dosa', 120, 'veg', 'Semolina crepe crisped with chopped onions, green chilies, and curry leaves.', true),
('sri-murugan-tiffin-center', 'a3333333-3333-3333-3333-333333333333', 'Degree Filter Coffee', 35, 'veg', 'Authentic South Indian chicory-blend filter coffee in brass dabarah.', true)
ON CONFLICT DO NOTHING;
